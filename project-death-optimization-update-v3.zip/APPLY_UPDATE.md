# Project Death Optimization Update

This archive contains only the files added or changed by the technical optimization pass. It does not include the omitted `Assets` or `.godot` directories, and it does not require Git.

## Install

1. Back up the current project folder.
2. Extract this archive directly into the Project Death project root: the folder that already contains `project.godot`.
3. When prompted, allow the extracted files to replace matching files.
4. Open the project in Godot 4.7 and allow Godot to finish importing resources.

The archive does not delete existing files. Your assets and local `.godot` import data will remain in place.

## Rebuild Generated Content

After opening the updated project, run these editor scripts in order:

1. `scripts/editor_tools/build_item_catalog.gd`
2. `scripts/editor_tools/bake_resource_collision_metadata.gd`
3. `scripts/editor_tools/repair_placeable_footprints.gd`
4. `scripts/editor_tools/split_world_into_cells.gd`
5. `scripts/editor_tools/bake_grass.gd`
6. `scripts/editor_tools/validate_runtime_content.gd`

Running `split_world_into_cells.gd` is mandatory before playing. Runtime deliberately removes the editor-only `WorldContent` staging tree and loads the generated cell scenes instead. Run the splitter even if cells already exist; it regenerates the complete cell set and removes stale generated cells that are no longer part of the source world.

## Verification

- Run the project and check startup/output for validation errors.
- Test crossing several cell boundaries in both directions.
- Test saving, quitting, and restoring in multiple cells.
- Test harvesting, dropped items, placed objects, and inventory persistence.
- Run the scripts in `tests/` using the project's normal test workflow.

The updated scripts were parser- and compiler-checked with Godot 4.7.1 in headless editor mode. The original review archive intentionally omitted the large asset set, so final gameplay validation and profiling must still be performed in the complete project on the build PC.
