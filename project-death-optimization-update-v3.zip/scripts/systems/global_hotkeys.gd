extends Node

## Permanent global hotkeys not tied to any specific gameplay system.
## Attach to a Node in World.tscn.
##
##   F5  — quicksave
##   F9  — quickload
##   V   — swap camera view direction (180-degree flip around the player)
##   Y   — TEST: sleep (skip to next night) — see autoloads/day_night_manager.gd.
##         No bed object exists yet to trigger this properly; wire it to
##         one when ready, this is just here to see the system work now.
##
## Ground restoration moved to real gameplay — right-click while holding a
## RestorationToolData item (e.g. the Spirit Trowel) instead of a debug
## key. See scenes/player/player.gd.
##
## These duplicate what's available through the pause menu (Save/Load
## buttons) and are just fast-access shortcuts for testing/play — keep
## them even after the pause menu exists, most games offer both.

func _ready() -> void:
	# _ready() only fires once, at true game boot — which now happens
	# while MainMenu is the active scene (no player, no world content),
	# since it's the new run/main_scene. WorldManager and DayNightManager
	# both tried to find things that didn't exist yet at that point and
	# have no other trigger to retry — this is that trigger, since THIS
	# script's _ready() genuinely re-fires every time World.tscn loads.
	# Sibling _ready() order is not a safe startup contract. Defer world
	# discovery until the complete World scene has finished its ready pass.
	call_deferred("_initialize_world")

	if SaveManager.pending_new_game:
		SaveManager.pending_new_game = false
		call_deferred("_do_pending_new_game")
	elif SaveManager.pending_continue_load:
		SaveManager.pending_continue_load = false
		# A couple of deferred hops so this runs after other World.tscn
		# systems' own deferred setup (TerrainRestoration finding the
		# terrain, WorldManager finding the player, etc.) has completed —
		# same safety margin those already give themselves.
		call_deferred("_do_pending_continue")


func _initialize_world() -> void:
	WorldManager.reinitialize()
	DayNightManager.reinitialize()


func _do_pending_new_game() -> void:
	SaveManager.reset_runtime_state_for_new_game()


func _do_pending_continue() -> void:
	call_deferred("_do_pending_continue_2")


func _do_pending_continue_2() -> void:
	SaveManager.load_game()


func _input(event: InputEvent) -> void:
	if not (event is InputEventKey and event.pressed and not event.echo):
		return

	if event.keycode == KEY_F5:
		SaveManager.save_game()
	elif event.keycode == KEY_F9:
		SaveManager.load_game()
	elif event.keycode == KEY_V:
		var camera_rig := get_tree().get_first_node_in_group("camera_rig")
		if camera_rig:
			camera_rig.toggle_view_direction()
	elif event.keycode == KEY_Y:
		DayNightManager.sleep()
		print("Slept — now %.1fh, %s." % [DayNightManager.time_of_day, "night" if DayNightManager.is_night() else "day"])
