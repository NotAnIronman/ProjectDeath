@tool
extends EditorScript

## Bakes ResourceNode collision bounds once in the editor so streaming a cell
## never instantiates a second temporary mature visual just to measure it.

const ROOT := "res://resources/"


func _run() -> void:
	var updated := _scan(ROOT)
	print("bake_resource_collision_metadata: updated %d resource definition(s)." % updated)


func _scan(path: String) -> int:
	var dir := DirAccess.open(path)
	if dir == null:
		return 0
	var updated := 0
	for child_dir in dir.get_directories():
		updated += _scan(path.path_join(child_dir))
	for file_name in dir.get_files():
		if not file_name.ends_with(".tres"):
			continue
		var resource_path := path.path_join(file_name)
		var data := load(resource_path) as ResourceNodeData
		if data == null:
			continue
		var bounds: Variant = null
		if data.mature_mesh != null:
			bounds = data.mature_mesh.get_aabb()
		elif data.mature_scene != null:
			var instance := data.mature_scene.instantiate()
			bounds = MeshUtils.compute_world_aabb(instance)
			instance.free()
		if bounds == null:
			continue
		var aabb: AABB = bounds
		data.collision_size = aabb.size
		data.collision_center = aabb.get_center()
		if ResourceSaver.save(data, resource_path) == OK:
			updated += 1
	return updated
