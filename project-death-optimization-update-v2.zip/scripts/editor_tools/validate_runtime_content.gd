@tool
extends EditorScript

## Release/pre-commit validator. Run after restoring the asset tree and after
## regenerating cells/catalogs. It deliberately fails loudly instead of
## allowing traversal order or a missing path to define runtime behavior.

const ROOT := "res://"
const CELLS := "res://scenes/world/cells/"


func _run() -> void:
	var errors: Array[String] = []
	_validate_resource_references(ROOT, errors)
	_validate_item_ids("res://resources/", {}, errors)
	_validate_cell_entity_ids(errors)
	if errors.is_empty():
		print("validate_runtime_content: all checks passed.")
		return
	for message in errors:
		push_error(message)
	push_error("validate_runtime_content: %d error(s)." % errors.size())


func _validate_resource_references(path: String, errors: Array[String]) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return
	for child_dir in dir.get_directories():
		if child_dir == ".godot":
			continue
		_validate_resource_references(path.path_join(child_dir), errors)
	for file_name in dir.get_files():
		if not file_name.ends_with(".tres") and not file_name.ends_with(".tscn"):
			continue
		var source_path := path.path_join(file_name)
		var file := FileAccess.open(source_path, FileAccess.READ)
		if file == null:
			continue
		var text := file.get_as_text()
		file.close()
		var regex := RegEx.new()
		regex.compile("path=\"(res://[^\"]+)\"")
		for match in regex.search_all(text):
			var referenced_path := match.get_string(1)
			if not ResourceLoader.exists(referenced_path):
				errors.append("%s references missing %s" % [source_path, referenced_path])


func _validate_item_ids(path: String, ids: Dictionary, errors: Array[String]) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return
	for child_dir in dir.get_directories():
		_validate_item_ids(path.path_join(child_dir), ids, errors)
	for file_name in dir.get_files():
		if not file_name.ends_with(".tres"):
			continue
		var resource_path := path.path_join(file_name)
		var resource := load(resource_path)
		if not (resource is ItemData):
			continue
		if resource.id == "":
			errors.append("ItemData has no id: %s" % resource_path)
		elif ids.has(resource.id):
			errors.append("Duplicate item id '%s': %s and %s" % [resource.id, ids[resource.id], resource_path])
		else:
			ids[resource.id] = resource_path


func _validate_cell_entity_ids(errors: Array[String]) -> void:
	var dir := DirAccess.open(CELLS)
	if dir == null:
		return
	var ids: Dictionary = {}
	for file_name in dir.get_files():
		if not file_name.ends_with(".tscn"):
			continue
		var scene_path := CELLS.path_join(file_name)
		var packed := load(scene_path) as PackedScene
		if packed == null:
			errors.append("Cell cannot be loaded: %s" % scene_path)
			continue
		var root := packed.instantiate()
		_collect_entity_ids(root, scene_path, ids, errors)
		root.free()


func _collect_entity_ids(node: Node, scene_path: String, ids: Dictionary, errors: Array[String]) -> void:
	if node.has_method("get_persistent_id"):
		var id: String = node.get_persistent_id()
		if id == "":
			errors.append("Persistent entity has no stable id: %s:%s" % [scene_path, node.get_path()])
		elif ids.has(id):
			errors.append("Duplicate persistent id '%s': %s and %s:%s" % [id, ids[id], scene_path, node.get_path()])
		else:
			ids[id] = "%s:%s" % [scene_path, node.get_path()]
	for child in node.get_children():
		_collect_entity_ids(child, scene_path, ids, errors)
