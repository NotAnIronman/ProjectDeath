@tool
extends EditorScript

## One-time migration for generated placeable scenes. Recomputes only default
## 1x1 decor footprints from their visual bounds; explicitly authored larger
## footprints are preserved.

const ROOT := "res://resources/"


func _run() -> void:
	var updated := _scan(ROOT)
	print("repair_placeable_footprints: updated %d scene(s)." % updated)


func _scan(path: String) -> int:
	var dir := DirAccess.open(path)
	if dir == null:
		return 0
	var updated := 0
	for child_dir in dir.get_directories():
		updated += _scan(path.path_join(child_dir))
	for file_name in dir.get_files():
		if not file_name.ends_with("_placeable.tscn"):
			continue
		var scene_path := path.path_join(file_name)
		var packed := load(scene_path) as PackedScene
		if packed == null:
			continue
		var instance := packed.instantiate()
		if not (instance is Placeable) or instance.tier != Placeable.GridTier.DECOR or instance.footprint_size != Vector2i.ONE:
			instance.free()
			continue
		var bounds: Variant = MeshUtils.compute_world_aabb(instance)
		if bounds == null:
			instance.free()
			continue
		var aabb: AABB = bounds
		instance.footprint_size = Vector2i(
			maxi(1, ceili(aabb.size.x / BuildGrid.DECOR_CELL_SIZE)),
			maxi(1, ceili(aabb.size.z / BuildGrid.DECOR_CELL_SIZE))
		)
		var replacement := PackedScene.new()
		if replacement.pack(instance) == OK and ResourceSaver.save(replacement, scene_path) == OK:
			updated += 1
		instance.free()
	return updated
