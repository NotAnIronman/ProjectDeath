@tool
extends EditorScript

## Generates the exact list InventoryManager loads at startup. This moves the
## recursive type-discovery scan to authoring time and makes duplicate IDs a
## build error rather than traversal-order behavior.

const ROOT := "res://resources/"
const OUTPUT := "res://data/item_catalog.json"


func _run() -> void:
	var paths: Array[String] = []
	var ids: Dictionary = {}
	var failed := not _scan(ROOT, paths, ids)
	if failed:
		push_error("build_item_catalog: duplicate/invalid content found; catalog was not replaced.")
		return
	paths.sort()
	var file := FileAccess.open(OUTPUT, FileAccess.WRITE)
	if file == null:
		push_error("build_item_catalog: could not open %s." % OUTPUT)
		return
	file.store_string(JSON.stringify(paths))
	file.close()
	print("build_item_catalog: wrote %d item paths to %s." % [paths.size(), OUTPUT])


func _scan(path: String, paths: Array[String], ids: Dictionary) -> bool:
	var dir := DirAccess.open(path)
	if dir == null:
		return true
	var valid := true
	for entry in dir.get_directories():
		valid = _scan(path.path_join(entry), paths, ids) and valid
	for entry in dir.get_files():
		if not entry.ends_with(".tres"):
			continue
		var resource_path := path.path_join(entry)
		var resource := load(resource_path)
		if not (resource is ItemData):
			continue
		if resource.id == "":
			push_error("build_item_catalog: ItemData has no id: %s" % resource_path)
			valid = false
		elif ids.has(resource.id):
			push_error("build_item_catalog: duplicate id '%s': %s and %s" % [resource.id, ids[resource.id], resource_path])
			valid = false
		else:
			ids[resource.id] = resource_path
			paths.append(resource_path)
	return valid
