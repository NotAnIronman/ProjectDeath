@tool
extends EditorScript

## Recursively splits everything under the "WorldContent" node (see
## scripts/systems/world_content_staging.gd) into per-cell scene files
## under scenes/world/cells/, bucketed by each object's global position
## using the SAME cell math as WorldManager (autoloads/world_manager.gd) —
## if you change CELL_SIZE in one, change it in the other.
##
## Safe to re-run anytime. Fully regenerates every affected cell file from
## WorldContent's current children each time — never hand-edit a
## scenes/world/cells/*.tscn file directly, always edit WorldContent and
## re-run this instead.

## FOLDERS FOR ORGANIZATION: fully supported. Nest content under as many
## plain Node3D "folder" nodes as you want, as deep as you want, purely for
## your own Scene-tree tidiness — this tool tells a real placed object
## apart from an organizational folder by checking scene_file_path: any
## node that's itself an instanced scene (a FarmPlot, a decor prop, a
## resource node — anything saved as its own .tscn) is treated as one
## atomic object and bucketed by its own position, no matter how deep it's
## nested. A plain node with an empty scene_file_path (i.e. you made it
## directly in World.tscn, it was never saved as its own file) is treated
## as a folder and recursed into instead of bucketed itself.
##
## NOTE ON OBJECTS NEAR A CELL BOUNDARY: a node is assigned ENTIRELY to
## whichever cell its own position falls in — there's no partial-splitting
## of a single object across two cells. A large object straddling a
## boundary will pop in/out as one whole piece at that cell's load/unload
## distance, same as everything else in it. For anything large enough that
## this would be noticeable (a big building), either make sure its
## position isn't right on a boundary, or keep CELL_SIZE comfortably
## larger than your biggest single structure.

const WORLD_MANAGER_SCRIPT := preload("res://autoloads/world_manager.gd")
const CELL_SIZE: float = WORLD_MANAGER_SCRIPT.CELL_SIZE
const OUTPUT_PATH := "res://scenes/world/cells/"
const CONTENT_CONTAINER_NAME := "WorldContent"


func _run() -> void:
	var scene_root: Node = get_scene()
	if scene_root == null:
		push_error("split_world_into_cells: no scene open. Open World.tscn first.")
		return

	var content: Node = scene_root.get_node_or_null(CONTENT_CONTAINER_NAME)
	if content == null:
		push_error("split_world_into_cells: no '%s' node found under the open scene. Create a Node3D named '%s', attach world_content_staging.gd to it, and put your cell-able content underneath." % [CONTENT_CONTAINER_NAME, CONTENT_CONTAINER_NAME])
		return
	if content.get_script() == null or content.get_script().resource_path != "res://scripts/systems/world_content_staging.gd":
		push_error("split_world_into_cells: WorldContent must use world_content_staging.gd or source content will also run in-game.")
		return

	if content.get_child_count() == 0:
		print("split_world_into_cells: '%s' has no children — nothing to split." % CONTENT_CONTAINER_NAME)
		return

	var buckets: Dictionary = {}  # Vector2i -> Array[Node]
	var object_count: int = _gather_recursive(content, buckets)

	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(OUTPUT_PATH))

	var all_writes_succeeded := true
	for cell_coord in buckets:
		all_writes_succeeded = _write_cell_scene(cell_coord, buckets[cell_coord]) and all_writes_succeeded
	if not all_writes_succeeded:
		push_error("split_world_into_cells: generation failed; old cells were preserved for safety.")
		return
	_remove_stale_cells(buckets)

	print("split_world_into_cells: done — wrote %d cell scene(s) covering %d object(s)." % [buckets.size(), object_count])


## Walks `node`'s children: buckets actual placed objects (instanced
## scenes) by their global position, and recurses into plain organizational
## folders. Returns the total number of objects bucketed.
func _gather_recursive(node: Node, buckets: Dictionary) -> int:
	var count: int = 0
	for child in node.get_children():
		if child.scene_file_path != "":
			if not (child is Node3D):
				push_warning("split_world_into_cells: skipping '%s' — not a Node3D, can't determine its world position." % child.name)
				continue
			var cell_coord: Vector2i = _world_to_cell(child.global_position)
			if not buckets.has(cell_coord):
				buckets[cell_coord] = []
			buckets[cell_coord].append(child)
			count += 1
		else:
			# Plain node, never saved as its own scene — an organizational
			# folder. Look inside it instead of bucketing it as one thing.
			count += _gather_recursive(child, buckets)
	return count


func _world_to_cell(position: Vector3) -> Vector2i:
	return Vector2i(floori(position.x / CELL_SIZE), floori(position.z / CELL_SIZE))


func _write_cell_scene(cell_coord: Vector2i, nodes: Array) -> bool:
	var cell_root := Node3D.new()
	cell_root.name = "Cell_%d_%d" % [cell_coord.x, cell_coord.y]

	for original in nodes:
		var duplicate: Node = original.duplicate(Node.DUPLICATE_USE_INSTANTIATION)
		cell_root.add_child(duplicate)
		_set_owner_recursive(duplicate, cell_root)

	var packed := PackedScene.new()
	var pack_err: int = packed.pack(cell_root)
	if pack_err != OK:
		push_error("split_world_into_cells: failed to pack cell %s (error %d)" % [cell_coord, pack_err])
		cell_root.free()
		return false

	var path := "%scell_%d_%d.tscn" % [OUTPUT_PATH, cell_coord.x, cell_coord.y]
	var save_err: int = ResourceSaver.save(packed, path)
	if save_err != OK:
		push_error("split_world_into_cells: failed to save %s (error %d)" % [path, save_err])
	else:
		print("  wrote %s (%d node(s))" % [path, nodes.size()])

	cell_root.free()
	return save_err == OK


func _remove_stale_cells(generated_buckets: Dictionary) -> void:
	var dir := DirAccess.open(OUTPUT_PATH)
	if dir == null:
		return
	for file_name in dir.get_files():
		if not file_name.begins_with("cell_") or not file_name.ends_with(".tscn"):
			continue
		var pieces := file_name.trim_prefix("cell_").trim_suffix(".tscn").split("_")
		if pieces.size() != 2 or not pieces[0].is_valid_int() or not pieces[1].is_valid_int():
			continue
		var coord := Vector2i(int(pieces[0]), int(pieces[1]))
		if not generated_buckets.has(coord):
			var error := dir.remove(file_name)
			if error != OK:
				push_error("split_world_into_cells: could not remove stale %s (error %d)." % [file_name, error])
			else:
				print("  removed stale %s" % file_name)


func _set_owner_recursive(node: Node, owner: Node) -> void:
	if node != owner:
		node.owner = owner
	for child in node.get_children():
		_set_owner_recursive(child, owner)
