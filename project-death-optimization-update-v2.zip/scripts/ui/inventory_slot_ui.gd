extends PanelContainer
class_name InventorySlotUI

## A single fixed-size inventory slot supporting drag-and-drop.
## Used for both hotbar slots and main inventory grid slots — set
## slot_type/slot_index to identify which underlying InventorySlotManager
## slot this widget represents.

signal hovered_item_changed(item_name: String)

## Set/cleared by UILayer.open_storage()/close_storage(). When non-null, a
## left-click on any inventory slot deposits into this container instead
## of its normal behavior (hotbar-select) — see _gui_input below.
static var active_storage_target: StorageContainer = null

## Same idea, for shops — set/cleared by UILayer.open_shop()/close_shop().
## When non-null, left-click SELLS the slot's contents instead.
static var active_shop_target: TradingPost = null

## Shared "cursor payload" for the split-and-carry interaction (shift-click
## picks up half a stack here; clicking any valid slot afterward places
## it). Shared across InventorySlotUI AND StorageSlotUI so an item can be
## carried between your inventory and an open chest, not just within one.
## UILayer polls these each frame to draw the floating icon following the
## mouse — see UILayer._process().
static var held_item_id: String = ""
static var held_quantity: int = 0


static func cancel_held_payload() -> void:
	if held_item_id == "" or held_quantity <= 0:
		held_item_id = ""
		held_quantity = 0
		return
	var returned: int = InventoryManager.try_add_item(held_item_id, held_quantity)
	held_quantity -= returned
	if held_quantity <= 0:
		held_item_id = ""
		held_quantity = 0
	else:
		push_error("InventorySlotUI: cursor payload could not be fully returned; preserving %d x %s." % [held_quantity, held_item_id])

var slot_type: InventorySlotManager.SlotType
var slot_index: int
var is_hotbar_selectable: bool = false  # only hotbar slots show the gold "selected" border

var icon: TextureRect
var count_label: Label

static var style_normal: StyleBoxFlat
static var style_hover: StyleBoxFlat
static var style_selected: StyleBoxFlat

var _is_hovered: bool = false


func _init() -> void:
	if style_normal == null:
		_build_shared_styles()

	mouse_filter = Control.MOUSE_FILTER_STOP
	add_theme_stylebox_override("panel", style_normal)

	var center := CenterContainer.new()
	add_child(center)

	icon = TextureRect.new()
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	center.add_child(icon)

	count_label = Label.new()
	count_label.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	count_label.add_theme_font_size_override("font_size", 12)
	count_label.clip_text = true  # prevents text length from affecting the slot's own layout size
	count_label.custom_minimum_size = Vector2.ZERO
	add_child(count_label)

	mouse_entered.connect(_on_mouse_entered)
	mouse_exited.connect(_on_mouse_exited)


static func _build_shared_styles() -> void:
	style_normal = StyleBoxFlat.new()
	style_normal.bg_color = Color(0.1, 0.1, 0.1, 0.55)
	style_normal.set_border_width_all(2)
	style_normal.border_color = Color(1, 1, 1, 0.15)
	style_normal.set_corner_radius_all(4)

	style_hover = style_normal.duplicate()
	style_hover.border_color = Color(1, 1, 1, 0.85)

	style_selected = style_normal.duplicate()
	style_selected.border_color = Color(1.0, 0.85, 0.3, 1.0)
	style_selected.set_border_width_all(3)


func setup(type: InventorySlotManager.SlotType, index: int, hotbar_selectable: bool, icon_size: float) -> void:
	slot_type = type
	slot_index = index
	is_hotbar_selectable = hotbar_selectable
	icon.custom_minimum_size = Vector2(icon_size, icon_size)


func refresh() -> void:
	var slot := InventorySlotManager.get_slot(slot_type, slot_index)
	var item_id: String = slot["item_id"]

	if item_id == "":
		icon.texture = null
		count_label.text = ""
		tooltip_text = ""
	else:
		var def: ItemData = InventoryManager.item_defs.get(item_id)
		icon.texture = def.icon if def else null
		var qty: int = slot["quantity"]
		count_label.text = str(qty) if qty > 1 else ""
		tooltip_text = def.display_name if def else item_id

	_update_style()


func _update_style() -> void:
	var is_selected: bool = is_hotbar_selectable \
		and slot_type == InventorySlotManager.SlotType.HOTBAR \
		and slot_index == InventorySlotManager.selected_hotbar_index

	if is_selected:
		add_theme_stylebox_override("panel", style_selected)
	elif _is_hovered:
		add_theme_stylebox_override("panel", style_hover)
	else:
		add_theme_stylebox_override("panel", style_normal)


func _on_mouse_entered() -> void:
	_is_hovered = true
	_update_style()
	hovered_item_changed.emit(_get_display_name())


func _on_mouse_exited() -> void:
	_is_hovered = false
	_update_style()
	hovered_item_changed.emit("")


func _get_display_name() -> String:
	var slot := InventorySlotManager.get_slot(slot_type, slot_index)
	var item_id: String = slot["item_id"]
	if item_id == "":
		return ""
	var def: ItemData = InventoryManager.item_defs.get(item_id)
	return def.display_name if def else item_id


## --- Drag and drop (built-in Godot Control virtual methods) ---

func _get_drag_data(_at_position: Vector2) -> Variant:
	var slot := InventorySlotManager.get_slot(slot_type, slot_index)
	if slot["item_id"] == "":
		return null  # nothing to drag from an empty slot

	# Visual preview that follows the cursor while dragging.
	var preview := TextureRect.new()
	preview.texture = icon.texture
	preview.custom_minimum_size = icon.custom_minimum_size
	preview.modulate.a = 0.8
	set_drag_preview(preview)

	return {"origin": "inventory", "slot_type": slot_type, "slot_index": slot_index}


func _can_drop_data(_at_position: Vector2, data: Variant) -> bool:
	return typeof(data) == TYPE_DICTIONARY and data.has("origin")


func _drop_data(_at_position: Vector2, data: Variant) -> void:
	var origin: String = data.get("origin", "")
	if origin == "inventory":
		var from_type: InventorySlotManager.SlotType = data["slot_type"]
		var from_index: int = data["slot_index"]
		InventorySlotManager.move_item(from_type, from_index, slot_type, slot_index)
	elif origin == "storage":
		var container: StorageContainer = data["container"]
		var from_slot_index: int = data["slot_index"]
		var item_id: String = data["item_id"]
		var quantity: int = data["quantity"]

		var target_slot := InventorySlotManager.get_slot(slot_type, slot_index)
		var existing_item_id: String = target_slot["item_id"]
		var existing_qty: int = target_slot["quantity"]

		if existing_item_id == "" or existing_item_id == item_id:
			var def: ItemData = InventoryManager.item_defs.get(item_id)
			var max_stack: int = def.max_stack if def else 99
			var space: int = max_stack - existing_qty
			var move_amount: int = mini(space, quantity)
			if move_amount <= 0:
				return  # this exact slot's stack is already full

			container.take_from_slot(from_slot_index)
			InventorySlotManager.place_in_slot_from_external(slot_type, slot_index, item_id, existing_qty + move_amount)

			var leftover: int = quantity - move_amount
			if leftover > 0:
				container.place_in_slot(from_slot_index, item_id, leftover)  # didn't all fit — leave the remainder where it was
		else:
			# Genuinely different item — true swap, exact slots both sides.
			container.take_from_slot(from_slot_index)
			InventorySlotManager.place_in_slot_from_external(slot_type, slot_index, item_id, quantity)
			container.place_in_slot(from_slot_index, existing_item_id, existing_qty)


## --- Right-click: context menu (was instant discard — see _open_context_menu) ---
## Left-click: shift held moves/sells/deposits HALF the stack instead of
## all of it (a quick "split" shortcut); the full context menu also has an
## explicit Split Stack option for when you want to split without also
## transferring anywhere.

var _context_menu: PopupMenu

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_RIGHT:
		_open_context_menu()
	elif event is InputEventMouseButton and not event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if held_item_id != "":
			_try_place_held_item()
			return
		if Input.is_key_pressed(KEY_SHIFT):
			_try_pick_up_half()
			return

		if active_shop_target != null:
			var slot := InventorySlotManager.get_slot(slot_type, slot_index)
			var item_id: String = slot["item_id"]
			if item_id != "":
				if active_shop_target.sell(item_id, slot["quantity"]):
					print("Sold %d x %s." % [slot["quantity"], item_id])
				else:
					print("This shop won't buy that.")
			return
		if active_storage_target != null:
			var slot := InventorySlotManager.get_slot(slot_type, slot_index)
			var item_id: String = slot["item_id"]
			if item_id != "":
				var deposited: int = active_storage_target.deposit(item_id, slot["quantity"])
				if deposited > 0:
					InventoryManager.remove_item(item_id, deposited)
			return  # storage is open — this click was a deposit attempt, not hotbar selection
		# Left-click a hotbar slot to select it (empty slots included, so
		# clicking one to go empty-handed works the same as scrolling to it).
		if is_hotbar_selectable and slot_type == InventorySlotManager.SlotType.HOTBAR:
			InventorySlotManager.select_hotbar_index(slot_index)


## Picks up half this slot's stack onto the shared cursor payload — the
## other half stays here. Works anywhere (not just while storage/shop is
## open), and the destination can be any inventory OR storage slot.
func _try_pick_up_half() -> void:
	if held_item_id != "":
		return  # already holding something
	var slot := InventorySlotManager.get_slot(slot_type, slot_index)
	var item_id: String = slot["item_id"]
	if item_id == "" or slot["quantity"] <= 1:
		return

	var half: int = slot["quantity"] / 2
	var remaining: int = slot["quantity"] - half
	InventorySlotManager.place_in_slot_from_external(slot_type, slot_index, item_id, remaining)
	held_item_id = item_id
	held_quantity = half


## Places whatever's held on the cursor into this slot — merges if empty
## or the same item (respecting max_stack), swaps if a different item
## occupies it.
func _try_place_held_item() -> void:
	var slot := InventorySlotManager.get_slot(slot_type, slot_index)
	var existing_item_id: String = slot["item_id"]
	var existing_qty: int = slot["quantity"]

	if existing_item_id == "" or existing_item_id == held_item_id:
		var def: ItemData = InventoryManager.item_defs.get(held_item_id)
		var max_stack: int = def.max_stack if def else 99
		var space: int = max_stack - existing_qty
		var move_amount: int = mini(space, held_quantity)
		if move_amount <= 0:
			return  # full, nothing placed, still holding

		InventorySlotManager.place_in_slot_from_external(slot_type, slot_index, held_item_id, existing_qty + move_amount)
		held_quantity -= move_amount
		if held_quantity <= 0:
			held_item_id = ""
			held_quantity = 0
	else:
		InventorySlotManager.place_in_slot_from_external(slot_type, slot_index, held_item_id, held_quantity)
		held_item_id = existing_item_id
		held_quantity = existing_qty


## Layout is always: 1) context-dependent primary action, 2) Split Stack,
## 3) Drop, 4) Cancel — same four slots regardless of context, only what
## option 1 actually DOES changes.
func _open_context_menu() -> void:
	var slot := InventorySlotManager.get_slot(slot_type, slot_index)
	if slot["item_id"] == "":
		return  # nothing here to act on

	if _context_menu == null:
		_context_menu = PopupMenu.new()
		add_child(_context_menu)
		_context_menu.id_pressed.connect(_on_context_menu_id_pressed)

	_context_menu.clear()
	_context_menu.add_item(_primary_action_label(), 0)
	_context_menu.add_item("Split Stack", 1)
	_context_menu.add_item("Drop", 2)
	_context_menu.add_item("Cancel", 3)

	_context_menu.position = get_viewport().get_mouse_position()  # viewport-local, not OS-global — DisplayServer coords broke under an embedded editor window
	_context_menu.popup()


func _primary_action_label() -> String:
	if active_storage_target != null:
		return "Move to Chest"
	if active_shop_target != null:
		return "Sell"
	if slot_type == InventorySlotManager.SlotType.HOTBAR:
		return "Send to Inventory"
	return "Send to Hotbar"


func _on_context_menu_id_pressed(id: int) -> void:
	var slot := InventorySlotManager.get_slot(slot_type, slot_index)
	var item_id: String = slot["item_id"]
	if item_id == "":
		return  # slot emptied itself between opening the menu and clicking an option

	match id:
		0:
			_do_primary_action(item_id, slot)
		1:
			InventorySlotManager.split_slot(slot_type, slot_index)
		2:
			InventorySlotManager.discard_from_slot(slot_type, slot_index)
		3:
			pass  # Cancel — do nothing


func _do_primary_action(item_id: String, slot: Dictionary) -> void:
	if active_storage_target != null:
		var deposited: int = active_storage_target.deposit(item_id, slot["quantity"])
		if deposited > 0:
			InventoryManager.remove_item(item_id, deposited)
	elif active_shop_target != null:
		active_shop_target.sell(item_id, slot["quantity"])
	elif slot_type == InventorySlotManager.SlotType.HOTBAR:
		var target_index := _find_empty_slot(InventorySlotManager.SlotType.MAIN)
		if target_index != -1:
			InventorySlotManager.move_item(slot_type, slot_index, InventorySlotManager.SlotType.MAIN, target_index)
		else:
			print("No empty inventory slot to send this to.")
	else:
		var target_index := _find_empty_slot(InventorySlotManager.SlotType.HOTBAR)
		if target_index != -1:
			InventorySlotManager.move_item(slot_type, slot_index, InventorySlotManager.SlotType.HOTBAR, target_index)
		else:
			print("No empty hotbar slot to send this to.")


func _find_empty_slot(check_type: InventorySlotManager.SlotType) -> int:
	var size: int = InventorySlotManager.HOTBAR_SIZE if check_type == InventorySlotManager.SlotType.HOTBAR else InventorySlotManager.MAIN_SIZE
	for i in size:
		if InventorySlotManager.get_slot(check_type, i)["item_id"] == "":
			return i
	return -1
