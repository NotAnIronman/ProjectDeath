extends Node3D
class_name Placeable

## Attach to the root of any object that should participate in the grid
## system — a ground tile, a wall section, or a piece of furniture.
## Describes its own footprint so BuildGrid can track/validate placement.
##
## Pickup is intentionally NOT passive/ambient — it's only available while
## the player has explicitly entered Pickup Mode (press B with an empty or
## non-placeable hotbar slot selected). Player raycasts for a Placeable
## directly rather than using the ambient "interactables" group/selection-
## ring system that crops/plots use, so walking past furniture never shows
## an unwanted prompt, and it stays reliable at scale (hundreds of objects).

enum GridTier { STRUCTURAL, DECOR }

@export var tier: GridTier = GridTier.DECOR

## Footprint size in grid cells (that tier's cell size — 1.0 for structural,
## 0.25 for decor). Most furniture is 1x1 on the decor grid even though the
## model itself is smaller than a full structural tile; multi-cell footprints
## (e.g. a long table) are for genuinely large objects.
@export var footprint_size: Vector2i = Vector2i(1, 1)

## Which item this returns to the inventory when picked up. Set
## automatically by Player when placing from the hotbar — only needs
## manual authoring if you're hand-placing pickup-able decor directly in
## a level scene rather than through build mode.
@export var source_item_id: String = ""
@export var persistent_id: String = ""

## Whether this instance can currently be picked up at all. Leave false for
## permanent level geometry you never want the player able to pick up,
## even while in Pickup Mode.
@export var is_pickupable: bool = true

var _current_footprint_cells: Array[Vector3i] = []
var _is_placed: bool = false


## Called directly by Player's Pickup Mode raycast targeting (not through
## the ambient interactables system). Returns true if pickup succeeded.
func pick_up() -> bool:
	if not is_pickupable:
		return false

	if source_item_id == "":
		push_warning("Placeable '%s': no source_item_id set, can't return it to inventory." % name)
		return false

	if InventoryManager.try_add_item(source_item_id, 1) != 1:
		return false
	release_placement()
	queue_free()
	print("Picked up: ", source_item_id)
	return true


## --- Collision toggling, used by Player during ghost preview ---
## Ghost previews must NOT physically collide with the player/terrain
## while being dragged around before placement is confirmed — this
## recursively finds any CollisionShape3D under this node and disables it,
## and can re-enable them once placement is actually confirmed.

func set_collision_enabled(enabled: bool) -> void:
	_set_collision_enabled_recursive(self, enabled)


func _set_collision_enabled_recursive(node: Node, enabled: bool) -> void:
	if node is CollisionShape3D:
		node.disabled = not enabled
	for child in node.get_children():
		_set_collision_enabled_recursive(child, enabled)


## Call once when the object settles into its final position (after a
## placement drag, or on level load) to register it with BuildGrid.
func commit_placement() -> bool:
	rotation.y = BuildGrid.snap_rotation_90(rotation.y)
	_ensure_persistent_id()
	_current_footprint_cells = _compute_footprint_cells()

	var success: bool
	if tier == GridTier.STRUCTURAL:
		success = BuildGrid.place_structural(_current_footprint_cells[0], _current_footprint_cells, self)
	else:
		success = BuildGrid.place_decor(_current_footprint_cells, self)

	_is_placed = success
	if success:
		WorldManager.adopt_node_to_cell(self)
	return success


## Call before moving/deleting a placed object, to free up its cells.
func release_placement() -> void:
	if not _is_placed:
		return
	if tier == GridTier.STRUCTURAL:
		BuildGrid.remove_structural(_current_footprint_cells)
	else:
		BuildGrid.remove_decor(_current_footprint_cells)
	_is_placed = false


func _compute_footprint_cells() -> Array[Vector3i]:
	var base_cell: Vector3i
	if tier == GridTier.STRUCTURAL:
		base_cell = BuildGrid.world_to_structural_cell(global_position)
	else:
		base_cell = BuildGrid.world_to_decor_cell(global_position)

	var size := footprint_size
	var quarter_turns := posmod(roundi(rotation.y / (PI / 2.0)), 4)
	if quarter_turns % 2 == 1:
		size = Vector2i(footprint_size.y, footprint_size.x)
	var cells: Array[Vector3i] = []
	for x in maxi(1, size.x):
		for z in maxi(1, size.y):
			cells.append(base_cell + Vector3i(x, 0, z))
	return cells


func _ensure_persistent_id() -> void:
	if persistent_id == "":
		persistent_id = "placed_%d_%d" % [Time.get_ticks_usec(), randi()]


func get_persistent_id() -> String:
	return persistent_id


func _exit_tree() -> void:
	release_placement()


## --- Save/Load — captures exactly where/how this object is placed, so
## decorated locations survive exactly as the player left them. ---

func get_save_data() -> Dictionary:
	return {
		"source_item_id": source_item_id,
		"persistent_id": persistent_id,
		"position": {"x": global_position.x, "y": global_position.y, "z": global_position.z},
		"rotation_y": rotation.y,
	}


## Applies saved position/rotation and commits placement. Call this on a
## freshly-instantiated Placeable (from ItemData.placed_scene) right after
## adding it to the scene tree.
func load_save_data(data: Dictionary) -> void:
	source_item_id = data.get("source_item_id", "")
	persistent_id = data.get("persistent_id", persistent_id)
	var pos: Dictionary = data.get("position", {})
	global_position = Vector3(pos.get("x", 0.0), pos.get("y", 0.0), pos.get("z", 0.0))
	rotation.y = data.get("rotation_y", 0.0)
	commit_placement()
