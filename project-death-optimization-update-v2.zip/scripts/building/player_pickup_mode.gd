extends Node
class_name PlayerPickupMode

## Owns the "Pickup" sub-mode of Decorate Mode: raycast-targeting a placed
## Placeable under the cursor, rotating it, and picking it back up into
## inventory. Split out of player.gd alongside PlayerBuildMode.
##
## Deliberately separate from crop/plot's ambient interactables system —
## raycast-targeted, only active while the player has explicitly chosen to
## decorate, never while just walking around.

## Physics layer(s) the pickup raycast should hit. Includes both terrain
## (1) and the dedicated placed-object layer (4) — hits are validated by
## checking for a Placeable script, so terrain hits are safely ignored
## regardless of mask overlap. Covering both means this works whether an
## object was generated before or after the dedicated layer was added.
@export_flags_3d_physics var pickup_raycast_mask: int = 5
## Mesh shown as the targeting reticle while hovering something pickup-able.
@export var pickup_target_mesh: Mesh

var player: Player
var is_active: bool = false

var _target: Placeable = null


func setup(owning_player: Player) -> void:
	player = owning_player


func _process(_delta: float) -> void:
	if is_active:
		_update_target()


func start() -> void:
	is_active = true
	_target = null
	player.selection_indicator.visible = false
	player.decorate_mode_changed.emit(true, "picking_up")
	print("Pickup mode — click to pick up, hold R + scroll to rotate the targeted object, Esc to exit. Scroll to a placeable item to switch to Placing.")


func stop() -> void:
	is_active = false
	_target = null
	player.selection_indicator.visible = false


## Handles the "hold R + scroll" rotate gesture on the currently targeted
## object. Returns true if it consumed the event.
func handle_scroll_rotate(event: InputEventMouseButton) -> bool:
	if not is_active or _target == null:
		return false
	var step_degrees: float = 90.0
	var step_radians: float = deg_to_rad(step_degrees)
	var direction: float = 1.0 if event.button_index == MOUSE_BUTTON_WHEEL_UP else -1.0
	var previous_rotation := _target.rotation.y
	_target.release_placement()
	_target.rotation.y += step_radians * direction
	_target.rotation.y = BuildGrid.snap_rotation_90(_target.rotation.y)
	if not _target.commit_placement():
		_target.rotation.y = previous_rotation
		_target.commit_placement()
		return true
	player.rotation_changed.emit(fposmod(rad_to_deg(_target.rotation.y), 360.0))
	return true


func try_pickup() -> void:
	if _target == null:
		return
	_target.pick_up()
	_target = null
	player.selection_indicator.visible = false


func _update_target() -> void:
	if player._camera_rig == null:
		return

	var camera: Camera3D = player._camera_rig.camera
	var mouse_pos := player.get_viewport().get_mouse_position()
	var ray_origin := camera.project_ray_origin(mouse_pos)
	var ray_dir := camera.project_ray_normal(mouse_pos)
	var ray_end := ray_origin + ray_dir * 1000.0

	var space_state := player.get_world_3d().direct_space_state
	var query := PhysicsRayQueryParameters3D.create(ray_origin, ray_end, pickup_raycast_mask)
	var hit := space_state.intersect_ray(query)

	# Validate by checking for the Placeable script specifically, rather
	# than trusting collision layer alone — this stays correct even for
	# objects generated before the dedicated placed-object layer existed,
	# and safely ignores terrain hits even though the mask covers it too.
	var target: Placeable = null
	if hit:
		var collider: Object = hit.collider
		var owner_node: Node = collider.owner if collider is Node else null
		if owner_node is Placeable and owner_node.is_pickupable:
			target = owner_node

	var previous_target := _target
	_target = target
	if target and target != previous_target:
		player.rotation_changed.emit(fposmod(rad_to_deg(target.rotation.y), 360.0))

	if target:
		player.selection_indicator.visible = true
		player.selection_indicator.global_position = target.global_position
		if pickup_target_mesh:
			player.selection_indicator.mesh = pickup_target_mesh
	else:
		player.selection_indicator.visible = false
