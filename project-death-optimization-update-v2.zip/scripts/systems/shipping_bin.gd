extends StorageContainer
class_name ShippingBin

## A passive sell mechanism, separate from directly walking to a shop —
## deposit items during the day, and every item still in the bin (that
## actually has a sell_price) is automatically sold and converted to
## currency the moment DayNightManager announces a new day, then the bin
## empties itself.
##
## Reuses ALL of StorageContainer's placement/interaction/UI machinery
## completely unchanged (opens the exact same storage panel, same
## drag-and-drop, same everything) — this file only overrides what the
## bin will accept and adds the overnight-sell behavior on top.

func _ready() -> void:
	super._ready()
	DayNightManager.day_started.connect(_sell_overnight)


## Only accepts items that are actually sellable, on top of whatever
## restriction its own StorageItemData already defines (a Shipping Bin
## still uses StorageItemData for slot_count/category config — no new
## data type needed) — otherwise the bin would happily hold junk with
## nothing to show for it come morning.
func accepts(item_id: String) -> bool:
	if not super.accepts(item_id):
		return false
	var def: ItemData = InventoryManager.item_defs.get(item_id)
	return def != null and def.sell_price > 0


func _sell_overnight() -> void:
	var total_earned := 0
	var total_items := 0

	for i in slots.size():
		var slot: Dictionary = slots[i]
		if slot["item_id"] == "":
			continue
		var def: ItemData = InventoryManager.item_defs.get(slot["item_id"])
		if def == null or def.sell_price <= 0:
			continue  # shouldn't normally happen given accepts() above, but stay safe if sell_price changes after deposit
		total_earned += def.sell_price * int(slot["quantity"])
		total_items += int(slot["quantity"])
		slots[i] = {"item_id": "", "quantity": 0}

	if total_earned <= 0:
		return

	EconomyManager.add_currency(total_earned)
	contents_changed.emit()
	NotificationManager.notify("Shipped %d item(s) overnight for %d gold." % [total_items, total_earned], "info")
	print("ShippingBin: sold %d item(s) for %d gold." % [total_items, total_earned])


func get_save_data() -> Dictionary:
	var data := super.get_save_data()
	data["persistent_type"] = "shipping_bin"
	return data
