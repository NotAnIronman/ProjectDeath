extends Node

@export var grass_mesh: Mesh
@export var grass_material: Material
@export var cluster_radius: float = 2.0
@export var regrow_seconds: float = 45.0
@export var cut_radius: float = 1.5

const GRASS_DATA_PATH := "res://data/grass/"
const HIDDEN_SCALE := 0.0001

class Cluster:
	var key: Vector2i
	var center := Vector3.ZERO
	var instance_indices: Array[int] = []
	var cut := false
	var regrow_remaining := 0.0

var _data_paths: Dictionary = {}
var _pending_roots: Dictionary = {} # coord -> weak cell root
var _multimesh_by_cell: Dictionary = {}
var _clusters_by_cell: Dictionary = {}
var _cluster_grid_by_cell: Dictionary = {}
var _original_transforms_by_cell: Dictionary = {}
var _saved_cut_state: Dictionary = {}


func _ready() -> void:
	_discover_grass_data()
	WorldManager.cell_loaded.connect(_on_cell_loaded)
	WorldManager.cell_unloaded.connect(_on_cell_unloaded)
	WorldManager.world_shutdown.connect(_on_world_shutdown)
	set_process(false)


func _discover_grass_data() -> void:
	_data_paths.clear()
	var dir := DirAccess.open(GRASS_DATA_PATH)
	if dir == null:
		return
	for file_name in dir.get_files():
		if not file_name.begins_with("grass_") or not file_name.ends_with(".tres"):
			continue
		var pieces := file_name.trim_prefix("grass_").trim_suffix(".tres").split("_")
		if pieces.size() == 2 and pieces[0].is_valid_int() and pieces[1].is_valid_int():
			_data_paths[Vector2i(int(pieces[0]), int(pieces[1]))] = GRASS_DATA_PATH.path_join(file_name)


func _process(delta: float) -> void:
	_poll_pending_loads()
	var any_regrowing := false
	for cell_coord in _clusters_by_cell:
		for cluster in _clusters_by_cell[cell_coord]:
			if not cluster.cut:
				continue
			cluster.regrow_remaining -= delta
			if cluster.regrow_remaining <= 0.0:
				_regrow_cluster(cell_coord, cluster)
			else:
				any_regrowing = true
	if _pending_roots.is_empty() and not any_regrowing:
		set_process(false)


func _on_cell_loaded(cell_coord: Vector2i, cell_root: Node) -> void:
	if not _data_paths.has(cell_coord) or grass_mesh == null:
		return
	WorldManager.mark_cell_layer_pending(cell_coord, "grass")
	var path: String = _data_paths[cell_coord]
	var error := ResourceLoader.load_threaded_request(path)
	var status := ResourceLoader.load_threaded_get_status(path)
	if error != OK and status != ResourceLoader.THREAD_LOAD_IN_PROGRESS and status != ResourceLoader.THREAD_LOAD_LOADED:
		push_error("GrassManager: failed to request %s (error %d)." % [path, error])
		WorldManager.mark_cell_layer_ready(cell_coord, "grass")
		return
	_pending_roots[cell_coord] = weakref(cell_root)
	set_process(true)


func _poll_pending_loads() -> void:
	for coord in _pending_roots.keys().duplicate():
		var path: String = _data_paths[coord]
		var status := ResourceLoader.load_threaded_get_status(path)
		if status == ResourceLoader.THREAD_LOAD_FAILED or status == ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
			_pending_roots.erase(coord)
			WorldManager.mark_cell_layer_ready(coord, "grass")
			continue
		if status != ResourceLoader.THREAD_LOAD_LOADED:
			continue
		var root_ref: WeakRef = _pending_roots[coord]
		_pending_roots.erase(coord)
		var root: Node = root_ref.get_ref()
		if root == null:
			WorldManager.mark_cell_layer_ready(coord, "grass")
			continue
		var data := ResourceLoader.load_threaded_get(path) as GrassCellData
		if data != null:
			_create_grass(coord, root, data)
		WorldManager.mark_cell_layer_ready(coord, "grass")
		break # at most one large MultiMesh activation per frame


func _create_grass(coord: Vector2i, root: Node, data: GrassCellData) -> void:
	if data.transforms.is_empty():
		return
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = grass_mesh
	mm.instance_count = data.transforms.size()
	if data.multimesh_buffer.size() == data.transforms.size() * 12:
		mm.buffer = data.multimesh_buffer
	else:
		for i in data.transforms.size():
			mm.set_instance_transform(i, data.transforms[i])
	var bounds := data.position_aabb
	if bounds.size == Vector3.ZERO:
		bounds = AABB(data.transforms[0].origin, Vector3.ZERO)
		for transform in data.transforms:
			bounds = bounds.expand(transform.origin)
	var mesh_size := grass_mesh.get_aabb().size
	bounds = bounds.grow(maxf(mesh_size.x, maxf(mesh_size.y, mesh_size.z)))
	mm.custom_aabb = bounds

	var instance := MultiMeshInstance3D.new()
	instance.name = "Grass"
	instance.multimesh = mm
	instance.material_override = grass_material
	root.add_child(instance)

	_multimesh_by_cell[coord] = instance
	_original_transforms_by_cell[coord] = data.transforms
	var built := _clusters_from_baked_data(data) if _has_valid_baked_clusters(data) else _build_clusters(data.transforms)
	_clusters_by_cell[coord] = built[0]
	_cluster_grid_by_cell[coord] = built[1]
	_apply_saved_cut_state(coord)


func _has_valid_baked_clusters(data: GrassCellData) -> bool:
	return data.cluster_radius == cluster_radius \
		and data.cluster_keys.size() == data.cluster_centers.size() \
		and data.cluster_keys.size() == data.cluster_instance_indices.size() \
		and not data.cluster_keys.is_empty()


func _clusters_from_baked_data(data: GrassCellData) -> Array:
	var clusters: Array[Cluster] = []
	var grid: Dictionary = {}
	for index in data.cluster_keys.size():
		var cluster := Cluster.new()
		cluster.key = data.cluster_keys[index]
		cluster.center = data.cluster_centers[index]
		for instance_index in data.cluster_instance_indices[index]:
			cluster.instance_indices.append(instance_index)
		clusters.append(cluster)
		grid[cluster.key] = cluster
	return [clusters, grid]


func _build_clusters(transforms: Array[Transform3D]) -> Array:
	var grid: Dictionary = {}
	for i in transforms.size():
		var position := transforms[i].origin
		var key := Vector2i(floori(position.x / cluster_radius), floori(position.z / cluster_radius))
		if not grid.has(key):
			var cluster := Cluster.new()
			cluster.key = key
			grid[key] = cluster
		var cluster: Cluster = grid[key]
		cluster.center += position
		cluster.instance_indices.append(i)
	var clusters: Array[Cluster] = []
	for key in grid:
		var cluster: Cluster = grid[key]
		cluster.center /= float(cluster.instance_indices.size())
		clusters.append(cluster)
	return [clusters, grid]


func cut_at(world_position: Vector3) -> bool:
	var cell_coord := WorldManager.world_to_cell(world_position)
	for dx in range(-1, 2):
		for dz in range(-1, 2):
			var coord := cell_coord + Vector2i(dx, dz)
			var grid: Dictionary = _cluster_grid_by_cell.get(coord, {})
			if grid.is_empty():
				continue
			var base_key := Vector2i(floori(world_position.x / cluster_radius), floori(world_position.z / cluster_radius))
			var key_radius := ceili(cut_radius / cluster_radius)
			for kx in range(-key_radius, key_radius + 1):
				for kz in range(-key_radius, key_radius + 1):
					var cluster: Cluster = grid.get(base_key + Vector2i(kx, kz))
					if cluster != null and not cluster.cut and cluster.center.distance_squared_to(world_position) <= cut_radius * cut_radius:
						_cut_cluster(coord, cluster)
						return true
	return false


func _cut_cluster(coord: Vector2i, cluster: Cluster) -> void:
	cluster.cut = true
	cluster.regrow_remaining = regrow_seconds
	var instance: MultiMeshInstance3D = _multimesh_by_cell.get(coord)
	if instance == null:
		return
	for index in cluster.instance_indices:
		var transform := instance.multimesh.get_instance_transform(index)
		transform.basis = transform.basis.scaled(Vector3.ONE * HIDDEN_SCALE)
		instance.multimesh.set_instance_transform(index, transform)
	set_process(true)


func _regrow_cluster(coord: Vector2i, cluster: Cluster) -> void:
	cluster.cut = false
	cluster.regrow_remaining = 0.0
	var instance: MultiMeshInstance3D = _multimesh_by_cell.get(coord)
	var originals: Variant = _original_transforms_by_cell.get(coord)
	if instance == null or originals == null:
		return
	for index in cluster.instance_indices:
		instance.multimesh.set_instance_transform(index, originals[index])


func _on_cell_unloaded(coord: Vector2i) -> void:
	_capture_active_cut_state(coord)
	_pending_roots.erase(coord)
	_multimesh_by_cell.erase(coord)
	_clusters_by_cell.erase(coord)
	_cluster_grid_by_cell.erase(coord)
	_original_transforms_by_cell.erase(coord)


func _capture_active_cut_state(coord: Vector2i) -> void:
	if not _clusters_by_cell.has(coord):
		return
	var records: Dictionary = {}
	for cluster in _clusters_by_cell[coord]:
		if cluster.cut:
			records["%d,%d" % [cluster.key.x, cluster.key.y]] = {
				"remaining": cluster.regrow_remaining,
				"captured_world_seconds": DayNightManager.get_world_elapsed_seconds()
			}
	if records.is_empty():
		_saved_cut_state.erase(coord)
	else:
		_saved_cut_state[coord] = records


func _apply_saved_cut_state(coord: Vector2i) -> void:
	var records: Dictionary = _saved_cut_state.get(coord, {})
	var grid: Dictionary = _cluster_grid_by_cell.get(coord, {})
	var now := DayNightManager.get_world_elapsed_seconds()
	for key_string in records:
		var pieces := String(key_string).split(",")
		if pieces.size() != 2:
			continue
		var cluster: Cluster = grid.get(Vector2i(int(pieces[0]), int(pieces[1])))
		if cluster == null:
			continue
		var record: Dictionary = records[key_string]
		var remaining := float(record.get("remaining", 0.0)) - maxf(0.0, now - float(record.get("captured_world_seconds", now)))
		if remaining > 0.0:
			_cut_cluster(coord, cluster)
			cluster.regrow_remaining = remaining
	_saved_cut_state.erase(coord)


func get_save_data() -> Dictionary:
	for coord in _clusters_by_cell:
		_capture_active_cut_state(coord)
	var serialized: Dictionary = {}
	for coord in _saved_cut_state:
		serialized["%d,%d" % [coord.x, coord.y]] = _saved_cut_state[coord]
	return {"cells": serialized}


func load_save_data(data: Dictionary) -> void:
	for coord in _clusters_by_cell:
		for cluster in _clusters_by_cell[coord]:
			if cluster.cut:
				_regrow_cluster(coord, cluster)
	_saved_cut_state.clear()
	for coord_string in data.get("cells", {}):
		var pieces := String(coord_string).split(",")
		if pieces.size() == 2:
			_saved_cut_state[Vector2i(int(pieces[0]), int(pieces[1]))] = data["cells"][coord_string]
	for coord in _clusters_by_cell:
		_apply_saved_cut_state(coord)


func _on_world_shutdown() -> void:
	_pending_roots.clear()
	_saved_cut_state.clear()
	_multimesh_by_cell.clear()
	_clusters_by_cell.clear()
	_cluster_grid_by_cell.clear()
	_original_transforms_by_cell.clear()
	set_process(false)
