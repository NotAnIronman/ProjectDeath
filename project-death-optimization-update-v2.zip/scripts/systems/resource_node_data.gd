extends Resource
class_name ResourceNodeData

## Full definition of a gatherable world resource — a tree, a rock, a
## fishing spot, etc. Create one .tres per node type in
## res://resources/<Category>/tres/. Adding a new gatherable resource =
## making a new .tres file, no code changes required. This is the
## gathering-skill equivalent of CropData — deliberately similar shape,
## since "wait/act, get yield, gain XP" is the same core loop either way,
## just without the plant/decay lifecycle farming has.

@export var id: String = ""
@export var display_name: String = ""
@export_multiline var description: String = ""

## Which skill this node trains, and the minimum level required to
## successfully gather it. e.g. skill_id = "woodcutting", required_level = 15
## for a hardier tree type.
@export var skill_id: String = ""
@export var required_level: int = 1

## Must match a ToolData.tool_type exactly, e.g. "woodcutting". The player
## needs a tool of this type selected in their hotbar to attempt gathering.
@export var required_tool_type: String = ""

## Minimum ToolData.tool_tier required, checked as tool.tool_tier >=
## min_tool_tier. Default 0 means ANY tier works — most nodes should
## probably leave this alone and gate difficulty purely through
## required_level instead. Only raise this for nodes that specifically
## need a better tool regardless of skill level (e.g. a rock too hard
## for a bronze pickaxe to even dent).
@export var min_tool_tier: int = 0

## Base XP granted per successful gather, before any future multipliers.
@export var base_xp: float = 10.0

## What gathering yields. Keyed by item id -> quantity range.
## e.g. {"wood_log": Vector2i(1, 3)}
@export var yield_table: Dictionary = {}

## How long (seconds) the node stays Depleted before becoming Mature
## (harvestable) again.
@export var respawn_time: float = 30.0

## --- Visuals — same two-option pattern as DecayStage: a plain mesh, OR
## a composite scene for multi-part models. stage_scene takes priority
## over the mesh if both are set. ---
@export var mature_mesh: Mesh
@export var mature_scene: PackedScene
@export var depleted_mesh: Mesh
@export var depleted_scene: PackedScene

## Optional collision metadata baked by content tools. A zero size keeps the
## legacy visual-AABB fallback for existing resources.
@export var collision_size: Vector3 = Vector3.ZERO
@export var collision_center: Vector3 = Vector3.ZERO
