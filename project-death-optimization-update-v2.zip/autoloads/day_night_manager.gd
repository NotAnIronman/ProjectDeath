extends Node

## AUTOLOAD "DayNightManager".
##
## Core time system: a 24-hour cycle (in-game hours, not real minutes),
## night/day state, moon phase, and the sleep-to-advance-time mechanic the
## design doc calls for ("player sleeps during the day, plays at night").
## Also drives lighting directly (rotates/recolors whatever DirectionalLight3D
## it finds in the scene) so the day/night state is immediately visible,
## not just a number ticking in the background.
##
## SCOPE — this is the CORE time system + the one thing that's actually
## visible/tangible today (lighting). Everything the design doc lists that
## depends on a system which doesn't exist yet is exposed as a clean hook
## (a public property or signal) rather than faked:
##   - NPC schedules, shops, festivals — no NPC/shop/festival system exists.
##     is_night()/time_of_day are public and ready for those to read once
##     they exist.
##   - Dangerous creatures, spirit encounters — no encounter system exists.
##     night_started/day_started signals are ready to drive spawn logic.
##   - Weather interactions — no weather system exists yet.
##   - Crop growth / magical effects tied to moonlight — Crop's growth
##     timer doesn't currently read anything external; get_growth_multiplier()
##     below is a ready hook (defaults to 1.0, i.e. no effect yet) rather
##     than silently rewiring Crop's math to something undocumented.
##   - Calendar page (Grim-oir) — still a placeholder; this system is the
##     prerequisite for it, not the calendar itself. A calendar needs
##     seasons/named days on top of this raw time system.
##
## SLEEP: call sleep() to skip straight to the next night (per the design
## doc's reversed schedule — day is for sleeping, not playing). No bed
## object exists yet, so sleep() is exposed as a plain method other
## systems (a future Bed placeable, or a debug hotkey for now) can call
## directly, same as every other "system built, trigger not wired up yet"
## pattern this project already uses.

signal night_started()
signal day_started()
signal moon_phase_changed(phase: int)
signal time_changed(hour: float)  ## emitted only when the displayed in-game minute changes

const HOURS_PER_MOON_PHASE := 24.0 * 3.0  ## a new moon phase every 3 in-game days
const MOON_PHASE_COUNT := 8  ## new, waxing crescent, first quarter, waxing gibbous, full, waning gibbous, last quarter, waning crescent
const NIGHT_START_HOUR := 19.0
const NIGHT_END_HOUR := 6.0

## How many real-world seconds one full in-game day (24 hours) takes.
## Tune freely — nothing else depends on the exact number.
@export var real_seconds_per_day: float = 24.0 * 60.0

var time_of_day: float = 8.0  ## in-game hours, 0.0-24.0, starts mid-morning
var total_elapsed_days: float = 0.0
var _is_night: bool = false
var moon_phase: int = 0
var total_elapsed_world_seconds: float = 0.0

var _light: DirectionalLight3D = null
var _last_emitted_minute: int = -1


func _ready() -> void:
	call_deferred("_find_light")
	_update_night_state(true)  # establish initial state without firing a spurious transition signal


## Call any time the actual game world (re)loads — see WorldManager's
## reinitialize() for why this is needed now that MainMenu is the boot
## scene instead of World.tscn.
func reinitialize() -> void:
	_find_light()


func _find_light() -> void:
	_light = _find_directional_light_recursive(get_tree().current_scene)
	if _light == null:
		push_warning("DayNightManager: no DirectionalLight3D found in the scene — time still advances, but nothing will visibly light up/darken.")
	else:
		# Explicitly enabled rather than assumed — this is the actual fix
		# for "objects aren't casting shadows": don't rely on however the
		# light happened to be configured in the scene, guarantee it here.
		_light.shadow_enabled = true
	_apply_lighting()


func _find_directional_light_recursive(node: Node) -> DirectionalLight3D:
	if node is DirectionalLight3D:
		return node
	for child in node.get_children():
		var found: DirectionalLight3D = _find_directional_light_recursive(child)
		if found:
			return found
	return null


func _process(delta: float) -> void:
	if not WorldManager.is_world_ready():
		return
	if real_seconds_per_day <= 0.0:
		return
	var hours_per_second: float = 24.0 / real_seconds_per_day
	time_of_day += delta * hours_per_second
	total_elapsed_world_seconds += delta
	if time_of_day >= 24.0:
		time_of_day -= 24.0
		total_elapsed_days += 1.0

	_update_night_state(false)
	_update_moon_phase()
	_apply_lighting()
	var displayed_minute := floori(time_of_day * 60.0)
	if displayed_minute != _last_emitted_minute:
		_last_emitted_minute = displayed_minute
		time_changed.emit(time_of_day)


func _update_night_state(silent: bool) -> void:
	var now_is_night: bool = time_of_day >= NIGHT_START_HOUR or time_of_day < NIGHT_END_HOUR
	if now_is_night == _is_night:
		return
	_is_night = now_is_night
	if silent:
		return
	if _is_night:
		night_started.emit()
	else:
		day_started.emit()


func _update_moon_phase() -> void:
	var total_hours: float = total_elapsed_days * 24.0 + time_of_day
	var new_phase: int = int(fmod(total_hours, HOURS_PER_MOON_PHASE * MOON_PHASE_COUNT) / HOURS_PER_MOON_PHASE)
	if new_phase != moon_phase:
		moon_phase = new_phase
		moon_phase_changed.emit(moon_phase)


## Rotates the sun through a full arc across the day and recolors it —
## warm low-angle light at dawn/dusk, neutral bright at midday, dim cool
## blue moonlight at night. This is the main visible output of this whole
## system right now.
func _apply_lighting() -> void:
	if _light == null:
		return

	# 0.0 at midnight, 1.0 at noon, back to 0.0 at midnight — a simple
	# sine-based day arc rather than a literal orbit, good enough without
	# needing a real sky/sun path asset.
	var day_fraction: float = time_of_day / 24.0
	var sun_angle: float = (day_fraction - 0.25) * TAU  # sun rises ~06:00, peaks ~12:00, sets ~18:00
	# Fixed diagonal yaw (45°) combined with the day-arc pitch — without
	# this, the light only ever swept in a straight N-S line (shadows
	# always pointing the same single compass direction), reading as
	# vertical rather than the diagonal sweep that actually looks like a
	# sun crossing the sky at an angle.
	_light.rotation = Vector3(-sun_angle, deg_to_rad(45.0), 0.0)

	if _is_night:
		_light.light_color = Color(0.55, 0.6, 0.85)  # cool moonlight
		_light.light_energy = 0.25
	else:
		var noon_closeness: float = 1.0 - absf(day_fraction - 0.5) * 2.0  # 1.0 at noon, 0.0 at sunrise/sunset
		_light.light_color = Color(1.0, 0.85, 0.65).lerp(Color(1.0, 0.97, 0.92), clampf(noon_closeness, 0.0, 1.0))
		_light.light_energy = lerpf(0.4, 1.1, clampf(noon_closeness, 0.0, 1.0))


func is_night() -> bool:
	return _is_night


## Hook for Crop (or anything else) to read — 1.0 = no effect. Not wired
## into Crop's actual growth math yet (that would be changing an existing,
## working system without you having decided the exact rule you want —
## e.g. "grows faster under a full moon" vs "only grows at night at all").
## Once you know the rule, this is a one-line call from crop.gd.
func get_growth_multiplier() -> float:
	return 1.0


## Skips straight to the next night — the "sleep" mechanic. No bed object
## exists yet to call this from; wire it to one (or a debug hotkey) when
## ready. Always advances at least a few hours even if already night, so
## sleeping at 8pm doesn't do nothing.
## Skips straight to the next night — the "sleep" mechanic. Pure
## arithmetic, deliberately no loop: the old version compared time_of_day
## (which always wraps back to 0-24) against a target that could exceed
## 24, which meant it could never terminate once that happened — an
## infinite-loop freeze on the second call. Fixed by working in
## "total hours since game start" (a value that only ever goes up) and
## converting back to time_of_day/total_elapsed_days at the very end.
func sleep() -> void:
	var current_total_hours: float = total_elapsed_days * 24.0 + time_of_day
	var target_total_hours: float = floor(current_total_hours / 24.0) * 24.0 + NIGHT_START_HOUR
	if target_total_hours <= current_total_hours:
		target_total_hours += 24.0  # already at/past tonight's start — go to TOMORROW night instead

	var skipped_hours := target_total_hours - current_total_hours
	total_elapsed_world_seconds += skipped_hours / 24.0 * real_seconds_per_day
	total_elapsed_days = floor(target_total_hours / 24.0)
	time_of_day = fmod(target_total_hours, 24.0)

	_update_night_state(false)
	_update_moon_phase()
	_apply_lighting()
	_last_emitted_minute = floori(time_of_day * 60.0)
	time_changed.emit(time_of_day)


func get_world_elapsed_seconds() -> float:
	return total_elapsed_world_seconds


func get_seconds_until_next_day() -> float:
	return maxf(0.0, (24.0 - time_of_day) / 24.0 * real_seconds_per_day)


## --- Save/Load ---

func get_save_data() -> Dictionary:
	return {
		"time_of_day": time_of_day,
		"total_elapsed_days": total_elapsed_days,
		"total_elapsed_world_seconds": total_elapsed_world_seconds,
	}


func load_save_data(data: Dictionary) -> void:
	time_of_day = data.get("time_of_day", 8.0)
	total_elapsed_days = data.get("total_elapsed_days", 0.0)
	total_elapsed_world_seconds = data.get(
		"total_elapsed_world_seconds",
		(total_elapsed_days + time_of_day / 24.0) * real_seconds_per_day
	)
	_last_emitted_minute = floori(time_of_day * 60.0)
	_update_night_state(true)
	_update_moon_phase()
	_apply_lighting()
