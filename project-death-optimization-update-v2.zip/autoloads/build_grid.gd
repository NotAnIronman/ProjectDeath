extends Node

## AUTOLOAD — register in Project Settings > Globals, name it "BuildGrid".
## The source of truth for all grid-based placement: terrain tiles, cliffs,
## walls, and (via a finer sub-grid) furniture. Converts between world
## position and grid cell coordinates, and tracks what's occupying each cell
## so placement/terraforming can check for collisions before committing.
##
## Two coordinate systems on purpose:
##   STRUCTURAL grid (CELL_SIZE = 1.0)  — terrain, cliffs, walls, floors.
##     Matches Kenney's kit exactly, confirmed by measuring the actual models.
##   DECOR sub-grid (DECOR_CELL_SIZE = 0.25) — furniture/decor placement,
##     since those models are NOT uniformly sized and forcing them onto a
##     1-unit grid would look wrong. Finer granularity, freer placement,
##     but still intentional/snapped rather than pixel-perfect freeform.

const CELL_SIZE: float = 1.0
const ELEVATION_STEP: float = 1.0
const DECOR_CELL_SIZE: float = 0.25

## Vector3i(x, elevation_level, z) -> occupying object (Node3D)
var _structural_occupancy: Dictionary = {}

## Vector3i using DECOR_CELL_SIZE units -> occupying object (Node3D)
var _decor_occupancy: Dictionary = {}


## --- Structural grid (terrain/cliffs/walls) ---

func world_to_structural_cell(world_pos: Vector3) -> Vector3i:
	return Vector3i(
		roundi(world_pos.x / CELL_SIZE),
		roundi(world_pos.y / ELEVATION_STEP),
		roundi(world_pos.z / CELL_SIZE)
	)


func structural_cell_to_world(cell: Vector3i) -> Vector3:
	return Vector3(cell.x * CELL_SIZE, cell.y * ELEVATION_STEP, cell.z * CELL_SIZE)


func is_structural_cell_free(cell: Vector3i) -> bool:
	if _structural_occupancy.has(cell) and not is_instance_valid(_structural_occupancy[cell]):
		_structural_occupancy.erase(cell)
	return not _structural_occupancy.has(cell)


## footprint_cells lets multi-tile pieces (e.g. a 2x1 wall section) occupy
## more than one cell — pass the list of cells it covers. For a simple 1x1
## piece, just pass [cell].
func place_structural(_cell: Vector3i, footprint_cells: Array[Vector3i], object: Node3D) -> bool:
	for c in footprint_cells:
		if not is_structural_cell_free(c):
			return false
	for c in footprint_cells:
		_structural_occupancy[c] = object
	return true


func remove_structural(footprint_cells: Array[Vector3i]) -> void:
	for c in footprint_cells:
		_structural_occupancy.erase(c)


func get_structural_occupant(cell: Vector3i) -> Node3D:
	is_structural_cell_free(cell)
	return _structural_occupancy.get(cell, null)


## Returns every unique placed object currently tracked (deduplicated —
## multi-cell footprints have the same object referenced by several cells).
## Used by SaveManager to serialize placed decor/structures.
func get_all_placed_objects() -> Array[Node3D]:
	var seen: Dictionary = {}
	for obj in _structural_occupancy.values():
		if is_instance_valid(obj):
			seen[obj] = true
	for obj in _decor_occupancy.values():
		if is_instance_valid(obj):
			seen[obj] = true
	var result: Array[Node3D] = []
	for obj in seen.keys():
		result.append(obj)
	return result


## Frees every currently placed object and clears all occupancy state.
## Used by SaveManager right before restoring a save, so loading doesn't
## end up with duplicates stacked on top of freshly-loaded objects.
func clear_all_placed_objects() -> void:
	for obj in get_all_placed_objects():
		obj.queue_free()
	_structural_occupancy.clear()
	_decor_occupancy.clear()


## --- Decor sub-grid (furniture) ---

func world_to_decor_cell(world_pos: Vector3) -> Vector3i:
	return Vector3i(
		roundi(world_pos.x / DECOR_CELL_SIZE),
		roundi(world_pos.y / DECOR_CELL_SIZE),
		roundi(world_pos.z / DECOR_CELL_SIZE)
	)


func decor_cell_to_world(cell: Vector3i) -> Vector3:
	return Vector3(cell.x * DECOR_CELL_SIZE, cell.y * DECOR_CELL_SIZE, cell.z * DECOR_CELL_SIZE)


## Snaps an arbitrary world position onto the decor sub-grid — this is what
## a furniture drag-placement preview would call every frame.
func snap_to_decor_grid(world_pos: Vector3) -> Vector3:
	return decor_cell_to_world(world_to_decor_cell(world_pos))


func is_decor_cell_free(cell: Vector3i) -> bool:
	if _decor_occupancy.has(cell) and not is_instance_valid(_decor_occupancy[cell]):
		_decor_occupancy.erase(cell)
	return not _decor_occupancy.has(cell)


func place_decor(footprint_cells: Array[Vector3i], object: Node3D) -> bool:
	for c in footprint_cells:
		if not is_decor_cell_free(c):
			return false
	for c in footprint_cells:
		_decor_occupancy[c] = object
	return true


func remove_decor(footprint_cells: Array[Vector3i]) -> void:
	for c in footprint_cells:
		_decor_occupancy.erase(c)


## Snaps a rotation (radians) to the nearest 90-degree increment — standard
## for both structural pieces and furniture.
func snap_rotation_90(rotation_y_radians: float) -> float:
	var deg: float = rad_to_deg(rotation_y_radians)
	var snapped_deg: float = round(deg / 90.0) * 90.0
	return deg_to_rad(snapped_deg)
