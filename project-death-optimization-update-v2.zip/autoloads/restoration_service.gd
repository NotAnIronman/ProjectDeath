extends Node

## One atomic restoration transaction shared by world and farm interactions.
## Returns an empty string on success or a user-facing failure reason.

func try_restore(position: Vector3, patch_id: String, tool: RestorationToolData) -> String:
	if tool == null:
		return "Equip a restoration tool."
	if not SkillManager.meets_requirement("spiritkeeping", tool.required_spiritkeeping_level):
		return "Restoring this ground requires Spiritkeeping level %d." % tool.required_spiritkeeping_level
	if tool.cost_item_id != "" and not InventoryManager.has_item(tool.cost_item_id, tool.cost_item_amount):
		return "Restoring this ground requires %d x %s." % [tool.cost_item_amount, tool.cost_item_id]
	if tool.cost_item_id != "" and not InventoryManager.remove_item(tool.cost_item_id, tool.cost_item_amount):
		return "The restoration cost could not be consumed."

	TerrainRestoration.restore_at(position, patch_id, tool.restored_texture_id, tool.restore_radius)
	SkillManager.add_xp("spiritkeeping", tool.xp_granted)
	return ""
