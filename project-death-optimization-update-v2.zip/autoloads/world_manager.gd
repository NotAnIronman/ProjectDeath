extends Node

## Streams non-terrain world content around the player.
##
## Persistent data is authoritative. Loaded cell roots are temporary
## presentation and may be discarded at any time without losing state.

signal cell_loaded(cell_coord: Vector2i, cell_root: Node)
signal cell_content_ready(cell_coord: Vector2i, cell_root: Node)
signal cell_unloaded(cell_coord: Vector2i)
signal world_ready()
signal world_shutdown()

const CELL_SIZE := 100.0
const LOAD_RADIUS_CELLS := 1
const UNLOAD_RADIUS_CELLS := 2
const CELLS_PATH := "res://scenes/world/cells/"
const MAX_CONCURRENT_LOADS := 2
const MAX_INSTANTIATIONS_PER_FRAME := 1
const MAX_ACTIVATION_BUDGET_MS := 2.0

var load_radius_cells: int = LOAD_RADIUS_CELLS
var unload_radius_cells: int = UNLOAD_RADIUS_CELLS
var debug_overlay_enabled: bool = false

## Vector2i -> logical Node3D root. A root exists even when the cell has no
## authored scene, allowing grass/ambient systems to stream independently.
var _active_cells: Dictionary = {}
## Vector2i -> state records captured when the cell was last unloaded.
var _cell_state: Dictionary = {}
## Vector2i -> scene path discovered once at world initialization.
var _scene_paths: Dictionary = {}
var _load_queue: Array[Vector2i] = []
var _threaded_loads: Dictionary = {} # Vector2i -> scene path
var _legacy_state_by_id: Dictionary = {}
var _content_ready_cells: Dictionary = {}
var _pending_cell_layers: Dictionary = {}

var _player: Node3D = null
var _cells_root: Node3D = null
var _current_cell := Vector2i(2147483647, 2147483647)
var _session_ready := false
var _streaming_active := false
var _debug_overlay: MeshInstance3D = null
var _debug_overlay_cell := Vector2i(2147483647, 2147483647)
var _debug_overlay_radius := -1


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	call_deferred("_connect_world_signals")


func _connect_world_signals() -> void:
	if not DayNightManager.day_started.is_connected(_on_unloaded_day_started):
		DayNightManager.day_started.connect(_on_unloaded_day_started)


func reinitialize() -> void:
	shutdown_world()
	_cell_state.clear()
	_legacy_state_by_id.clear()
	_player = get_tree().get_first_node_in_group("player") as Node3D
	if _player == null or get_tree().current_scene == null:
		push_warning("WorldManager: no active gameplay player; streaming remains disabled.")
		return

	_discover_cell_scenes()
	_cells_root = Node3D.new()
	_cells_root.name = "StreamedCells"
	get_tree().current_scene.add_child(_cells_root)
	_current_cell = world_to_cell(_player.global_position)
	_streaming_active = true
	_refresh_desired_cells(_current_cell)
	_check_initial_neighborhood_ready()


func shutdown_world() -> void:
	_session_ready = false
	_streaming_active = false
	_clear_debug_overlay()
	_load_queue.clear()
	_threaded_loads.clear()
	_content_ready_cells.clear()
	_pending_cell_layers.clear()
	for coord in _active_cells.keys().duplicate():
		_unload_cell(coord)
	_active_cells.clear()
	if is_instance_valid(_cells_root):
		_cells_root.queue_free()
	_cells_root = null
	_player = null
	_current_cell = Vector2i(2147483647, 2147483647)
	world_shutdown.emit()


func is_world_ready() -> bool:
	return _session_ready and is_instance_valid(_player) and is_instance_valid(_cells_root)


func get_player() -> Node3D:
	return _player if is_instance_valid(_player) else null


func refresh_streaming_neighborhood() -> void:
	if not _streaming_active or not is_instance_valid(_player) or not is_instance_valid(_cells_root):
		return
	load_radius_cells = maxi(0, load_radius_cells)
	unload_radius_cells = maxi(load_radius_cells, unload_radius_cells)
	_refresh_desired_cells(_current_cell)
	refresh_debug_overlay()


func force_reload_all_cells() -> void:
	if not _streaming_active or not is_instance_valid(_cells_root):
		return
	for coord in _active_cells.keys().duplicate():
		_unload_cell(coord)
	_session_ready = false
	_refresh_desired_cells(_current_cell)
	_check_initial_neighborhood_ready()


func set_debug_overlay_enabled(enabled: bool) -> void:
	debug_overlay_enabled = enabled
	if enabled:
		refresh_debug_overlay()
	else:
		_clear_debug_overlay()


func refresh_debug_overlay() -> void:
	if not debug_overlay_enabled:
		_clear_debug_overlay()
		return
	if not is_instance_valid(_player) or not is_instance_valid(_cells_root):
		return
	if (
		is_instance_valid(_debug_overlay)
		and _debug_overlay_cell == _current_cell
		and _debug_overlay_radius == unload_radius_cells
	):
		return

	_debug_overlay_cell = _current_cell
	_debug_overlay_radius = unload_radius_cells
	if not is_instance_valid(_debug_overlay):
		_debug_overlay = MeshInstance3D.new()
		_debug_overlay.name = "WorldStreamingDebugOverlay"
		_cells_root.add_child(_debug_overlay)

	var radius := maxi(0, unload_radius_cells)
	var minimum_x := float(_current_cell.x - radius) * CELL_SIZE
	var maximum_x := float(_current_cell.x + radius + 1) * CELL_SIZE
	var minimum_z := float(_current_cell.y - radius) * CELL_SIZE
	var maximum_z := float(_current_cell.y + radius + 1) * CELL_SIZE
	var line_y := _player.global_position.y + 0.1
	var mesh := ImmediateMesh.new()
	mesh.surface_begin(Mesh.PRIMITIVE_LINES)
	for grid_x in range(_current_cell.x - radius, _current_cell.x + radius + 2):
		var world_x := float(grid_x) * CELL_SIZE
		mesh.surface_add_vertex(Vector3(world_x, line_y, minimum_z))
		mesh.surface_add_vertex(Vector3(world_x, line_y, maximum_z))
	for grid_z in range(_current_cell.y - radius, _current_cell.y + radius + 2):
		var world_z := float(grid_z) * CELL_SIZE
		mesh.surface_add_vertex(Vector3(minimum_x, line_y, world_z))
		mesh.surface_add_vertex(Vector3(maximum_x, line_y, world_z))
	mesh.surface_end()

	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = Color(0.15, 0.9, 1.0, 0.85)
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.no_depth_test = true
	mesh.surface_set_material(0, material)
	_debug_overlay.mesh = mesh


func get_debug_snapshot() -> Dictionary:
	var loaded_cells: Array[Vector2i] = []
	for coord: Vector2i in _active_cells:
		loaded_cells.append(coord)
	loaded_cells.sort_custom(func(a: Vector2i, b: Vector2i) -> bool:
		return a.x < b.x or (a.x == b.x and a.y < b.y)
	)
	return {
		"current_cell": _current_cell,
		"loaded_cells": loaded_cells,
		"loaded_count": loaded_cells.size(),
		"pending_load_count": _load_queue.size() + _threaded_loads.size(),
		"cached_unloaded_count": maxi(0, _cell_state.size() - loaded_cells.size()),
		"streamed_node_count": _count_streamed_nodes(),
	}


func _count_streamed_nodes() -> int:
	var count := 0
	var pending: Array[Node] = []
	for root: Node in _active_cells.values():
		pending.append(root)
	while not pending.is_empty():
		var node: Node = pending.pop_back()
		count += 1
		pending.append_array(node.get_children())
	return count


func _clear_debug_overlay() -> void:
	if is_instance_valid(_debug_overlay):
		_debug_overlay.queue_free()
	_debug_overlay = null
	_debug_overlay_cell = Vector2i(2147483647, 2147483647)
	_debug_overlay_radius = -1


func _process(_delta: float) -> void:
	if not _streaming_active or not is_instance_valid(_player) or not is_instance_valid(_cells_root):
		return

	var new_cell := world_to_cell(_player.global_position)
	if new_cell != _current_cell:
		_current_cell = new_cell
		_refresh_desired_cells(new_cell)

	_start_queued_loads()
	_activate_ready_loads()


func _discover_cell_scenes() -> void:
	_scene_paths.clear()
	var dir := DirAccess.open(CELLS_PATH)
	if dir == null:
		return
	for file_name in dir.get_files():
		var coord: Variant = _parse_coord(file_name, "cell_", ".tscn")
		if coord != null:
			_scene_paths[coord] = CELLS_PATH.path_join(file_name)


func _parse_coord(file_name: String, prefix: String, suffix: String) -> Variant:
	if not file_name.begins_with(prefix) or not file_name.ends_with(suffix):
		return null
	var pieces := file_name.trim_prefix(prefix).trim_suffix(suffix).split("_")
	if pieces.size() != 2 or not pieces[0].is_valid_int() or not pieces[1].is_valid_int():
		return null
	return Vector2i(int(pieces[0]), int(pieces[1]))


func _refresh_desired_cells(center: Vector2i) -> void:
	for coord in _active_cells.keys().duplicate():
		if _cell_distance(coord, center) > unload_radius_cells:
			_unload_cell(coord)

	var desired: Array[Vector2i] = []
	for dx in range(-load_radius_cells, load_radius_cells + 1):
		for dz in range(-load_radius_cells, load_radius_cells + 1):
			desired.append(center + Vector2i(dx, dz))
	var movement := Vector2.ZERO
	if _player is CharacterBody3D:
		var body := _player as CharacterBody3D
		movement = Vector2(body.velocity.x, body.velocity.z).normalized()
	desired.sort_custom(func(a: Vector2i, b: Vector2i) -> bool:
		return _load_priority(a, center, movement) < _load_priority(b, center, movement)
	)

	for coord in desired:
		if not _active_cells.has(coord):
			_activate_logical_cell(coord)


func _load_priority(coord: Vector2i, center: Vector2i, movement: Vector2) -> float:
	var offset := Vector2(coord - center)
	return float(_cell_distance(coord, center)) * 100.0 - offset.dot(movement) * 10.0


func _activate_logical_cell(coord: Vector2i) -> void:
	var root := Node3D.new()
	root.name = "Cell_%d_%d" % [coord.x, coord.y]
	_cells_root.add_child(root)
	_active_cells[coord] = root
	cell_loaded.emit(coord, root)

	if _scene_paths.has(coord):
		_load_queue.append(coord)
	else:
		_apply_cell_state(root, _cell_state.get(coord, {}))
		_content_ready_cells[coord] = true
		cell_content_ready.emit(coord, root)
		_check_initial_neighborhood_ready()


func _start_queued_loads() -> void:
	while _threaded_loads.size() < MAX_CONCURRENT_LOADS and not _load_queue.is_empty():
		var coord: Vector2i = _load_queue.pop_front()
		if not _active_cells.has(coord) or _threaded_loads.has(coord):
			continue
		var path: String = _scene_paths[coord]
		var error := ResourceLoader.load_threaded_request(path)
		var status := ResourceLoader.load_threaded_get_status(path)
		if error == OK or status == ResourceLoader.THREAD_LOAD_IN_PROGRESS or status == ResourceLoader.THREAD_LOAD_LOADED:
			_threaded_loads[coord] = path
		else:
			push_error("WorldManager: threaded load request failed for %s (error %d)." % [path, error])
			_content_ready_cells[coord] = true
			_check_initial_neighborhood_ready()


func _activate_ready_loads() -> void:
	var activated := 0
	var started_usec := Time.get_ticks_usec()
	for coord in _threaded_loads.keys().duplicate():
		if activated >= MAX_INSTANTIATIONS_PER_FRAME:
			break
		if (Time.get_ticks_usec() - started_usec) / 1000.0 >= MAX_ACTIVATION_BUDGET_MS:
			break
		var path: String = _threaded_loads[coord]
		var status := ResourceLoader.load_threaded_get_status(path)
		if status == ResourceLoader.THREAD_LOAD_FAILED or status == ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
			push_error("WorldManager: failed loading %s." % path)
			_threaded_loads.erase(coord)
			_content_ready_cells[coord] = true
			_check_initial_neighborhood_ready()
			continue
		if status != ResourceLoader.THREAD_LOAD_LOADED:
			continue

		var packed := ResourceLoader.load_threaded_get(path) as PackedScene
		_threaded_loads.erase(coord)
		if not _active_cells.has(coord):
			continue # player moved away while IO was in flight
		if packed == null:
			push_error("WorldManager: %s did not resolve to a PackedScene." % path)
			_content_ready_cells[coord] = true
			_check_initial_neighborhood_ready()
			continue

		var root: Node = _active_cells[coord]
		var content := packed.instantiate()
		content.name = "AuthoredContent"
		root.add_child(content)
		_apply_cell_state(root, _cell_state.get(coord, {}))
		_content_ready_cells[coord] = true
		cell_content_ready.emit(coord, root)
		activated += 1
		_check_initial_neighborhood_ready()


func _unload_cell(coord: Vector2i) -> void:
	if not _active_cells.has(coord):
		return
	_load_queue.erase(coord)
	_content_ready_cells.erase(coord)
	_pending_cell_layers.erase(coord)
	var root: Node = _active_cells[coord]
	_cell_state[coord] = _capture_cell_state(root)
	_active_cells.erase(coord)
	# Emit while the root is still valid so cell-scoped systems can snapshot.
	cell_unloaded.emit(coord)
	if is_instance_valid(root):
		root.queue_free()


func _check_initial_neighborhood_ready() -> void:
	if _session_ready or not _streaming_active:
		return
	for dx in range(-load_radius_cells, load_radius_cells + 1):
		for dz in range(-load_radius_cells, load_radius_cells + 1):
			if not _content_ready_cells.has(_current_cell + Vector2i(dx, dz)):
				return
			if not _pending_cell_layers.get(_current_cell + Vector2i(dx, dz), {}).is_empty():
				return
	_session_ready = true
	world_ready.emit()


func mark_cell_layer_pending(coord: Vector2i, layer_name: String) -> void:
	if not _pending_cell_layers.has(coord):
		_pending_cell_layers[coord] = {}
	_pending_cell_layers[coord][layer_name] = true


func mark_cell_layer_ready(coord: Vector2i, layer_name: String) -> void:
	if _pending_cell_layers.has(coord):
		_pending_cell_layers[coord].erase(layer_name)
		if _pending_cell_layers[coord].is_empty():
			_pending_cell_layers.erase(coord)
	_check_initial_neighborhood_ready()


func world_to_cell(position: Vector3) -> Vector2i:
	return Vector2i(floori(position.x / CELL_SIZE), floori(position.z / CELL_SIZE))


func _cell_distance(a: Vector2i, b: Vector2i) -> int:
	return maxi(absi(a.x - b.x), absi(a.y - b.y))


func adopt_node_to_cell(node: Node3D) -> bool:
	if not is_world_ready() or not is_instance_valid(node):
		return false
	var coord := world_to_cell(node.global_position)
	var root: Node = _active_cells.get(coord)
	if root == null:
		return false
	if node.get_parent() != root:
		node.reparent(root, true)
	return true


func _capture_cell_state(root: Node) -> Dictionary:
	var state: Dictionary = {}
	_capture_recursive(root, root, state)
	return state


func _capture_recursive(node: Node, root: Node, state: Dictionary) -> void:
	if node != root and node.has_method("get_save_data"):
		var key := _persistent_key(node, root)
		state[key] = {
			"data": node.get_save_data(),
			"captured_world_seconds": DayNightManager.get_world_elapsed_seconds()
		}
	for child in node.get_children():
		_capture_recursive(child, root, state)


func _persistent_key(node: Node, root: Node) -> String:
	if node.has_method("get_persistent_id"):
		var persistent_id: String = node.get_persistent_id()
		if persistent_id != "":
			return "id:" + persistent_id
	return "path:" + str(root.get_path_to(node))


func _apply_cell_state(root: Node, state: Dictionary) -> void:
	var nodes_by_key: Dictionary = {}
	_index_persistent_nodes(root, root, nodes_by_key)
	var now := DayNightManager.get_world_elapsed_seconds()

	for key in state:
		var record: Dictionary = state[key]
		var data: Dictionary = record.get("data", record) # version-1 compatibility
		var node: Node = nodes_by_key.get(key)
		if node == null and key.begins_with("path:"):
			node = root.get_node_or_null(NodePath(key.trim_prefix("path:")))
		if node == null and key.begins_with("id:placed_") and data.has("source_item_id"):
			node = _instantiate_saved_placeable(root, data)
		if node == null:
			continue
		var elapsed := maxf(0.0, now - float(record.get("captured_world_seconds", now)))
		if node.has_method("load_save_data_with_elapsed"):
			node.load_save_data_with_elapsed(data, elapsed)
		elif node.has_method("load_save_data"):
			node.load_save_data(data)
	for persistent_id in _legacy_state_by_id.keys().duplicate():
		var node: Node = nodes_by_key.get("id:" + String(persistent_id))
		if node != null and node.has_method("load_save_data"):
			node.load_save_data(_legacy_state_by_id[persistent_id])
			_legacy_state_by_id.erase(persistent_id)


func _index_persistent_nodes(node: Node, root: Node, result: Dictionary) -> void:
	if node != root and node.has_method("get_save_data"):
		result[_persistent_key(node, root)] = node
	for child in node.get_children():
		_index_persistent_nodes(child, root, result)


func _instantiate_saved_placeable(root: Node, data: Dictionary) -> Node:
	var item_id: String = data.get("source_item_id", "")
	var definition: ItemData = InventoryManager.item_defs.get(item_id)
	if definition == null or definition.placed_scene == null:
		push_warning("WorldManager: cannot restore placeable for item '%s'." % item_id)
		return null
	var instance := definition.placed_scene.instantiate()
	root.add_child(instance)
	return instance


func get_save_data() -> Dictionary:
	var snapshot := _cell_state.duplicate(true)
	for coord in _active_cells:
		snapshot[coord] = _capture_cell_state(_active_cells[coord])
	var serialized: Dictionary = {}
	for coord in snapshot:
		serialized["%d,%d" % [coord.x, coord.y]] = snapshot[coord]
	return {"cells": serialized}


func load_save_data(data: Dictionary) -> void:
	for coord in _active_cells:
		_remove_dynamic_placeables(_active_cells[coord])
	_cell_state.clear()
	var serialized: Dictionary = data.get("cells", {})
	for coord_key in serialized:
		var pieces := String(coord_key).split(",")
		if pieces.size() == 2 and pieces[0].is_valid_int() and pieces[1].is_valid_int():
			_cell_state[Vector2i(int(pieces[0]), int(pieces[1]))] = serialized[coord_key]
	for coord in _active_cells:
		_apply_cell_state(_active_cells[coord], _cell_state.get(coord, {}))


func _remove_dynamic_placeables(node: Node) -> void:
	for child in node.get_children().duplicate():
		_remove_dynamic_placeables(child)
	if node is Placeable and node.get_persistent_id().begins_with("placed_"):
		node.release_placement()
		node.free()


func load_legacy_entity_states(states_by_id: Dictionary) -> void:
	_legacy_state_by_id.merge(states_by_id, true)
	for coord in _active_cells:
		_apply_cell_state(_active_cells[coord], _cell_state.get(coord, {}))


func queue_legacy_placeable(data: Dictionary) -> void:
	var position_data: Dictionary = data.get("position", {})
	var position := Vector3(position_data.get("x", 0.0), position_data.get("y", 0.0), position_data.get("z", 0.0))
	var coord := world_to_cell(position)
	if not _cell_state.has(coord):
		_cell_state[coord] = {}
	var migrated := data.duplicate(true)
	var persistent_id: String = migrated.get("persistent_id", "")
	if persistent_id == "":
		persistent_id = "placed_migrated_%s" % str(migrated).sha256_text().substr(0, 16)
		migrated["persistent_id"] = persistent_id
	_cell_state[coord]["id:" + persistent_id] = {
		"data": migrated,
		"captured_world_seconds": DayNightManager.get_world_elapsed_seconds()
	}
	if _active_cells.has(coord):
		_apply_cell_state(_active_cells[coord], _cell_state[coord])


func _on_unloaded_day_started() -> void:
	# Loaded ShippingBins receive the signal themselves. Reconcile stored bins
	# here so selling does not depend on presentation being instantiated.
	for coord in _cell_state:
		var records: Dictionary = _cell_state[coord]
		for key in records:
			var record: Dictionary = records[key]
			var data: Dictionary = record.get("data", {})
			if data.get("persistent_type", "") != "shipping_bin":
				continue
			var earned := 0
			for slot in data.get("slots", []):
				var definition: ItemData = InventoryManager.item_defs.get(slot.get("item_id", ""))
				if definition != null and definition.sell_price > 0:
					earned += definition.sell_price * int(slot.get("quantity", 0))
			if earned > 0:
				EconomyManager.add_currency(earned)
				data["slots"] = []
				record["data"] = data
