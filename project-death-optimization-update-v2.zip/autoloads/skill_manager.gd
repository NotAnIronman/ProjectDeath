extends Node

## AUTOLOAD — register this as a singleton named "SkillManager" in
## Project Settings > Autoload. Owns all skill XP/level state for the player.
## Any system (crops, cooking, herbalism) calls SkillManager.add_xp(...) —
## nothing else should mutate skill state directly.

## Emitted whenever XP is granted, even if it doesn't cause a level-up.
## UI can hook this to show floating "+12 Farming XP" popups.
signal xp_granted(skill_id: String, amount: int, new_total: int)

## Emitted specifically on level-up, so UI can show a celebration/unlock toast.
signal leveled_up(skill_id: String, new_level: int)

## skill_id -> SkillData resource. Populate this in _ready() by loading
## every .tres in res://resources/skills/, so adding a new skill file
## registers it automatically with zero code changes.
var skill_defs: Dictionary = {}

## skill_id -> current total XP (int). This is the actual save-relevant state.
var skill_xp: Dictionary = {}

## skill_id -> Array[SkillPerkData]. Populated from res://resources/skills/perks/,
## same auto-scan-a-folder convention as everything else — add a perk by
## dropping in a .tres, no code changes.
var perk_defs: Dictionary = {}
var _modifier_cache: Dictionary = {}

const SKILLS_PATH := "res://resources/skills/"
const PERKS_PATH := "res://resources/skills/perks/"


func _ready() -> void:
	_load_all_skill_defs()
	_load_all_perk_defs()
	print("SkillManager loaded skills: ", skill_defs.keys())


func _load_all_skill_defs() -> void:
	var dir := DirAccess.open(SKILLS_PATH)
	if dir == null:
		push_warning("SkillManager: no resources/skills/ folder found yet — add .tres skill files.")
		return

	dir.list_dir_begin()
	var file_name := dir.get_next()
	while file_name != "":
		if file_name.ends_with(".tres"):
			var skill: SkillData = load(SKILLS_PATH + file_name)
			if skill and skill.id != "":
				skill_defs[skill.id] = skill
				if not skill_xp.has(skill.id):
					skill_xp[skill.id] = 0
		file_name = dir.get_next()
	dir.list_dir_end()


func _load_all_perk_defs() -> void:
	if not DirAccess.dir_exists_absolute(PERKS_PATH):
		return  # no perks authored yet — not an error, just nothing to load
	_scan_perks_recursive(PERKS_PATH)


func _scan_perks_recursive(path: String) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return

	dir.list_dir_begin()
	var entry_name := dir.get_next()
	while entry_name != "":
		if entry_name.begins_with("."):
			entry_name = dir.get_next()
			continue
		var full_path := path.path_join(entry_name)
		if dir.current_is_dir():
			_scan_perks_recursive(full_path)
		elif entry_name.ends_with(".tres"):
			var perk: SkillPerkData = load(full_path)
			if perk and perk.skill_id != "":
				if not perk_defs.has(perk.skill_id):
					perk_defs[perk.skill_id] = []
				perk_defs[perk.skill_id].append(perk)
		entry_name = dir.get_next()
	dir.list_dir_end()


## Total bonus for `modifier_key` across every perk the player has
## actually unlocked (current level >= that perk's required_level), no
## matter which skill it came from. 0.0 if nothing applies — always safe
## to add straight onto a base value with no special-casing needed at the
## call site (see Crop._process()/ResourceNode._harvest() for real usage).
func get_modifier_total(modifier_key: String) -> float:
	if _modifier_cache.has(modifier_key):
		return _modifier_cache[modifier_key]
	var total := 0.0
	for skill_id in perk_defs:
		var current_level := get_level(skill_id)
		for perk in perk_defs[skill_id]:
			if perk.modifier_key == modifier_key and current_level >= perk.required_level:
				total += perk.modifier_value
	_modifier_cache[modifier_key] = total
	return total


## Every perk for a skill, unlocked or not — for UI display (e.g. "next
## perk at level 15").
func get_all_perks(skill_id: String) -> Array:
	return perk_defs.get(skill_id, [])


func get_unlocked_perks(skill_id: String) -> Array:
	var result: Array = []
	var current_level := get_level(skill_id)
	for perk in perk_defs.get(skill_id, []):
		if current_level >= perk.required_level:
			result.append(perk)
	return result


## Call this from anywhere (crop harvesting, cooking, herbalism crafting) to grant XP.
func add_xp(skill_id: String, amount: int) -> void:
	if not skill_defs.has(skill_id):
		push_warning("SkillManager: tried to add XP to unknown skill '%s'" % skill_id)
		return

	var skill: SkillData = skill_defs[skill_id]
	var old_level := skill.level_for_xp(skill_xp[skill_id])

	skill_xp[skill_id] += amount
	var new_total: int = skill_xp[skill_id]

	xp_granted.emit(skill_id, amount, new_total)

	var new_level := skill.level_for_xp(new_total)
	if new_level > old_level:
		_modifier_cache.clear()
		leveled_up.emit(skill_id, new_level)


func get_level(skill_id: String) -> int:
	if not skill_defs.has(skill_id):
		return 0
	return skill_defs[skill_id].level_for_xp(skill_xp.get(skill_id, 0))


func get_xp(skill_id: String) -> int:
	return skill_xp.get(skill_id, 0)


func meets_requirement(skill_id: String, required_level: int) -> bool:
	return get_level(skill_id) >= required_level


## --- Save/Load hooks — wire these into your SaveManager later ---

func get_save_data() -> Dictionary:
	return {"skill_xp": skill_xp}


func load_save_data(data: Dictionary) -> void:
	if data.has("skill_xp"):
		skill_xp = data["skill_xp"]
		_modifier_cache.clear()


func reset_state() -> void:
	for skill_id in skill_defs:
		skill_xp[skill_id] = 0
	_modifier_cache.clear()
