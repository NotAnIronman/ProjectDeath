extends Node

## AUTOLOAD — register in Project Settings > Globals, name it "SettingsManager".
## Owns display/audio settings and persists them to their own file
## (user://settings.cfg), separate from SaveManager's game-progress save —
## these are machine/preference settings, not game state, so they
## shouldn't reset when the player starts a new game.
##
## Defaults to the user's actual desktop resolution on first run (no
## settings file yet), rather than a hardcoded guess.

const SETTINGS_PATH := "user://settings.cfg"

## A small set of common resolution options to offer in the dropdown.
## "Native" always maps to whatever the user's actual screen size is.
const RESOLUTION_OPTIONS: Array[Vector2i] = [
	Vector2i(1280, 720),
	Vector2i(1600, 900),
	Vector2i(1920, 1080),
	Vector2i(2560, 1440),
	Vector2i(3840, 2160),
]

signal settings_changed()

var resolution: Vector2i
var fullscreen: bool = false
var field_of_view: float = 70.0
var master_volume: float = 1.0
var music_volume: float = 1.0
var sfx_volume: float = 1.0
var autosave_enabled: bool = true
var autosave_interval_minutes: float = 5.0
var _save_timer: Timer


func _ready() -> void:
	var native_size := DisplayServer.screen_get_size()
	resolution = native_size  # sensible default before any settings file exists

	load_settings()
	apply_all()
	_save_timer = Timer.new()
	_save_timer.one_shot = true
	_save_timer.wait_time = 0.35
	_save_timer.timeout.connect(save_settings)
	add_child(_save_timer)


## --- Applying settings to the actual engine state ---

func apply_all() -> void:
	apply_resolution()
	apply_fullscreen()
	apply_fov()
	apply_volume("Master", master_volume)
	apply_volume("Music", music_volume)
	apply_volume("SFX", sfx_volume)


func apply_resolution() -> void:
	if fullscreen:
		return  # window size is irrelevant in fullscreen, avoid fighting the OS
	DisplayServer.window_set_size(resolution)
	# Center the window on screen after resizing.
	var screen_size := DisplayServer.screen_get_size()
	@warning_ignore("integer_division")
	DisplayServer.window_set_position((screen_size - resolution) / 2)


func apply_fullscreen() -> void:
	if fullscreen:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
		apply_resolution()


func apply_fov() -> void:
	var rig := get_tree().get_first_node_in_group("camera_rig")
	if rig:
		rig.field_of_view = field_of_view


## Sets a named audio bus's volume from a 0.0-1.0 linear value.
## Safe to call even if the bus doesn't exist yet (e.g. no audio system
## built out yet) — just warns instead of crashing, so this is ready to
## use the moment you add Master/Music/SFX buses.
func apply_volume(bus_name: String, linear_value: float) -> void:
	var bus_index := AudioServer.get_bus_index(bus_name)
	if bus_index == -1:
		return  # bus doesn't exist yet — silently skip, not an error
	var db := linear_to_db(clamp(linear_value, 0.0, 1.0))
	AudioServer.set_bus_volume_db(bus_index, db)


## --- Setters used by the Settings UI — each applies immediately and saves ---

func set_resolution(new_resolution: Vector2i) -> void:
	resolution = new_resolution
	apply_resolution()
	_schedule_save()
	settings_changed.emit()


func set_fullscreen(enabled: bool) -> void:
	fullscreen = enabled
	apply_fullscreen()
	_schedule_save()
	settings_changed.emit()


func set_field_of_view(value: float) -> void:
	field_of_view = value
	apply_fov()
	_schedule_save()
	settings_changed.emit()


func set_master_volume(value: float) -> void:
	master_volume = value
	apply_volume("Master", value)
	_schedule_save()
	settings_changed.emit()


func set_music_volume(value: float) -> void:
	music_volume = value
	apply_volume("Music", value)
	_schedule_save()
	settings_changed.emit()


func set_sfx_volume(value: float) -> void:
	sfx_volume = value
	apply_volume("SFX", value)
	_schedule_save()
	settings_changed.emit()


func set_autosave_enabled(enabled: bool) -> void:
	autosave_enabled = enabled
	_schedule_save()
	settings_changed.emit()


func set_autosave_interval_minutes(minutes: float) -> void:
	autosave_interval_minutes = maxf(minutes, 1.0)  # guard against 0/negative producing a save-every-frame loop
	_schedule_save()
	settings_changed.emit()


func _schedule_save() -> void:
	if _save_timer == null:
		return
	_save_timer.start()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST and _save_timer != null and not _save_timer.is_stopped():
		save_settings()


## --- Persistence ---

func save_settings() -> void:
	var config := ConfigFile.new()
	config.set_value("video", "resolution_x", resolution.x)
	config.set_value("video", "resolution_y", resolution.y)
	config.set_value("video", "fullscreen", fullscreen)
	config.set_value("video", "field_of_view", field_of_view)
	config.set_value("audio", "master_volume", master_volume)
	config.set_value("audio", "music_volume", music_volume)
	config.set_value("audio", "sfx_volume", sfx_volume)
	config.set_value("gameplay", "autosave_enabled", autosave_enabled)
	config.set_value("gameplay", "autosave_interval_minutes", autosave_interval_minutes)
	config.save(SETTINGS_PATH)


func load_settings() -> void:
	var config := ConfigFile.new()
	var err := config.load(SETTINGS_PATH)
	if err != OK:
		return  # no settings file yet — keep the defaults already set in _ready()

	var res_x: int = config.get_value("video", "resolution_x", resolution.x)
	var res_y: int = config.get_value("video", "resolution_y", resolution.y)
	resolution = Vector2i(res_x, res_y)
	fullscreen = config.get_value("video", "fullscreen", false)
	field_of_view = config.get_value("video", "field_of_view", 70.0)
	master_volume = config.get_value("audio", "master_volume", 1.0)
	music_volume = config.get_value("audio", "music_volume", 1.0)
	sfx_volume = config.get_value("audio", "sfx_volume", 1.0)
	autosave_enabled = config.get_value("gameplay", "autosave_enabled", true)
	autosave_interval_minutes = config.get_value("gameplay", "autosave_interval_minutes", 5.0)
