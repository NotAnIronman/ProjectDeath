extends Node

## AUTOLOAD "AutoSaveManager".
##
## Periodically calls SaveManager.save_game() in the background. Enabled
## state and interval are player-configurable preferences, owned by
## SettingsManager (autosave_enabled / autosave_interval_minutes) — same
## place every other player preference lives, persisted the same way,
## rather than a separate settings store just for this.
##
## Manual saves (F5, pause menu, etc.) are completely untouched by this —
## they still just call SaveManager.save_game() directly, same as always.
## This only adds a background trigger on top.
##
## SAFETY: if a skip condition is true right when a save is due, this
## doesn't just wait a full extra interval — it retries every
## RETRY_DELAY_SECONDS until it's actually safe, then saves and resets the
## normal timer from that point. _is_safe_to_autosave() is the extension
## point for future "don't autosave right now" conditions (combat,
## cutscenes, dialogue...) once those systems exist — it only checks for
## an open blocking menu today, since nothing else exists yet to check.
##
## VISUAL INDICATOR: this doesn't own any UI itself — it relies on
## SaveManager's existing game_saved signal, which already fires for both
## manual and automatic saves. See ui_layer.gd for the on-screen indicator
## hooked to that signal.

const RETRY_DELAY_SECONDS := 5.0

var _timer: float = 0.0
var _retry_pending: bool = false


func _ready() -> void:
	WorldManager.world_shutdown.connect(reset_timer)


func _process(delta: float) -> void:
	if not SettingsManager.autosave_enabled or not WorldManager.is_world_ready():
		return

	_timer += delta
	var interval_seconds: float = SettingsManager.autosave_interval_minutes * 60.0

	if _timer >= interval_seconds:
		_try_autosave()


func _try_autosave() -> void:
	if not _is_safe_to_autosave():
		if not _retry_pending:
			_retry_pending = true
			await get_tree().create_timer(RETRY_DELAY_SECONDS).timeout
			_retry_pending = false
			_try_autosave()
		return

	_timer = 0.0
	SaveManager.save_game()


func _is_safe_to_autosave() -> bool:
	if not WorldManager.is_world_ready():
		return false
	var ui_layer := get_tree().get_first_node_in_group("ui_layer")
	if ui_layer and ui_layer.has_method("is_blocking_gameplay") and ui_layer.is_blocking_gameplay():
		return false
	return true


## Manually trigger an autosave-style save right now and reset the timer —
## exposed so future systems (finishing a quest, leaving an area, etc.)
## can piggyback on the same save call without waiting for the interval,
## instead of duplicating a call to SaveManager directly.
func trigger_now() -> void:
	if not WorldManager.is_world_ready():
		return
	_timer = 0.0
	SaveManager.save_game()


func reset_timer() -> void:
	_timer = 0.0
	_retry_pending = false
