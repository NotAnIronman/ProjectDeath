extends Control

## The game's entry point (set as run/main_scene in Project Settings).
## Built entirely in code, same pattern as UILayer, rather than a
## hand-built scene tree — keeps everything in one place to read/edit.
##
## "Continue" doesn't load the save directly from here — you can't safely
## await across a scene change on a node about to be freed. Instead it
## sets SaveManager.pending_continue_load = true and changes scene;
## GlobalHotkeys (which genuinely gets a fresh _ready() every time
## World.tscn loads) picks that flag up and calls SaveManager.load_game()
## once the world's own systems have finished their own deferred setup.
## See save_manager.gd / global_hotkeys.gd for the other half of this.

const WORLD_SCENE_PATH := "res://scenes/world/World.tscn"

var _button_container: VBoxContainer
var _settings_panel: PanelContainer
var _continue_button: Button
var _confirm_dialog: ConfirmationDialog


func _ready() -> void:
	_build_background()
	_build_title()
	_build_buttons()
	_build_settings_panel()
	_build_confirm_dialog()


func _build_background() -> void:
	var bg := ColorRect.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.color = Color(0.08, 0.09, 0.07)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)


func _build_title() -> void:
	var anchor := CenterContainer.new()
	anchor.set_anchors_preset(Control.PRESET_TOP_WIDE)
	anchor.position.y = 90
	add_child(anchor)

	var title := Label.new()
	title.text = "Project Death"
	title.add_theme_font_size_override("font_size", 42)
	title.modulate = Color(0.9, 0.85, 0.7)
	anchor.add_child(title)


func _build_buttons() -> void:
	var anchor := CenterContainer.new()
	anchor.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(anchor)

	_button_container = VBoxContainer.new()
	_button_container.add_theme_constant_override("separation", 10)
	_button_container.custom_minimum_size = Vector2(220, 0)
	anchor.add_child(_button_container)

	var new_game_button := Button.new()
	new_game_button.text = "New Game"
	new_game_button.pressed.connect(_on_new_game_pressed)
	_button_container.add_child(new_game_button)

	_continue_button = Button.new()
	_continue_button.text = "Continue"
	_continue_button.disabled = not SaveManager.has_save_file()
	_continue_button.pressed.connect(_on_continue_pressed)
	_button_container.add_child(_continue_button)

	var settings_button := Button.new()
	settings_button.text = "Settings"
	settings_button.pressed.connect(func(): _settings_panel.visible = true)
	_button_container.add_child(settings_button)

	var quit_button := Button.new()
	quit_button.text = "Quit"
	quit_button.pressed.connect(func(): get_tree().quit())
	_button_container.add_child(quit_button)


func _on_new_game_pressed() -> void:
	if SaveManager.has_save_file():
		_confirm_dialog.popup_centered()
	else:
		_start_new_game()


func _start_new_game() -> void:
	SaveManager.delete_save_file()
	SaveManager.pending_continue_load = false
	SaveManager.pending_new_game = true
	get_tree().change_scene_to_file(WORLD_SCENE_PATH)


func _on_continue_pressed() -> void:
	SaveManager.pending_new_game = false
	SaveManager.pending_continue_load = true
	get_tree().change_scene_to_file(WORLD_SCENE_PATH)


func _build_confirm_dialog() -> void:
	_confirm_dialog = ConfirmationDialog.new()
	_confirm_dialog.dialog_text = "Starting a new game will erase your existing save. Continue?"
	_confirm_dialog.confirmed.connect(_start_new_game)
	add_child(_confirm_dialog)


## --- Settings sub-view — reuses SettingsManager directly, same values
## the in-game pause menu's settings panel reads/writes, just a separate
## small UI here rather than trying to share one Control tree across two
## completely different scenes (main menu exists before World.tscn is
## even loaded). ---

func _build_settings_panel() -> void:
	var anchor := CenterContainer.new()
	anchor.set_anchors_preset(Control.PRESET_FULL_RECT)
	# This wrapper stays visible (only _settings_panel itself toggles) and
	# was built after the buttons, so it sat on top and silently ate every
	# click across the whole screen even with nothing visible there —
	# IGNORE lets clicks pass through to whatever's actually underneath.
	anchor.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(anchor)

	_settings_panel = PanelContainer.new()
	_settings_panel.custom_minimum_size = Vector2(360, 320)
	_settings_panel.visible = false
	anchor.add_child(_settings_panel)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 20)
	margin.add_theme_constant_override("margin_right", 20)
	margin.add_theme_constant_override("margin_top", 20)
	margin.add_theme_constant_override("margin_bottom", 20)
	_settings_panel.add_child(margin)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	margin.add_child(vbox)

	var title := Label.new()
	title.text = "Settings"
	title.add_theme_font_size_override("font_size", 18)
	vbox.add_child(title)
	vbox.add_child(HSeparator.new())

	_add_volume_slider(vbox, "Master Volume", SettingsManager.master_volume, SettingsManager.set_master_volume)
	_add_volume_slider(vbox, "Music Volume", SettingsManager.music_volume, SettingsManager.set_music_volume)
	_add_volume_slider(vbox, "SFX Volume", SettingsManager.sfx_volume, SettingsManager.set_sfx_volume)

	var fullscreen_row := HBoxContainer.new()
	vbox.add_child(fullscreen_row)
	var fullscreen_label := Label.new()
	fullscreen_label.text = "Fullscreen"
	fullscreen_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	fullscreen_row.add_child(fullscreen_label)
	var fullscreen_check := CheckBox.new()
	fullscreen_check.button_pressed = SettingsManager.fullscreen
	fullscreen_check.toggled.connect(SettingsManager.set_fullscreen)
	fullscreen_row.add_child(fullscreen_check)

	var autosave_row := HBoxContainer.new()
	vbox.add_child(autosave_row)
	var autosave_label := Label.new()
	autosave_label.text = "Auto-Save"
	autosave_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	autosave_row.add_child(autosave_label)
	var autosave_check := CheckBox.new()
	autosave_check.button_pressed = SettingsManager.autosave_enabled
	autosave_check.toggled.connect(SettingsManager.set_autosave_enabled)
	autosave_row.add_child(autosave_check)

	var close_button := Button.new()
	close_button.text = "Close"
	close_button.pressed.connect(func(): _settings_panel.visible = false)
	vbox.add_child(close_button)


func _add_volume_slider(parent: VBoxContainer, label_text: String, initial_value: float, on_change: Callable) -> void:
	var row := VBoxContainer.new()
	row.add_theme_constant_override("separation", 2)
	parent.add_child(row)

	var label := Label.new()
	label.text = label_text
	label.add_theme_font_size_override("font_size", 12)
	row.add_child(label)

	var slider := HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.05
	slider.value = initial_value
	slider.value_changed.connect(on_change)
	row.add_child(slider)
