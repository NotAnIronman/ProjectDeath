extends CanvasLayer
class_name UILayer

## Attach to a CanvasLayer in your World scene. Builds the whole HUD +
## pause menu + tab menu in code at runtime.
##
## Actual item/slot data lives in InventorySlotManager (autoload) — this
## script only builds/refreshes the visual InventorySlotUI widgets that
## display it, plus the pause/tab menu chrome.
##
## Controls:
##   Scroll wheel (no Ctrl) — cycle hotbar selection
##   Tab                    — open/close the multi-tab menu
##   Esc                    — close tab menu if open, else toggle pause menu

const SLOT_ICON_SIZE: float = 34.0
const SLOT_SIZE: float = 52.0
const INVENTORY_COLUMNS: int = 7
const INVENTORY_ROWS: int = 4

enum Tab { INVENTORY, SKILLS, RECIPES, ACHIEVEMENTS, COLLECTION_LOG, RELATIONSHIPS, QUESTS, CALENDAR }

var _hotbar_slot_widgets: Array[InventorySlotUI] = []
var _inventory_slot_widgets: Array[InventorySlotUI] = []
var hotbar_hover_label: Label

var tab_menu: PanelContainer
var _tab_buttons: Dictionary = {}
var _tab_pages: Dictionary = {}
var _current_tab: Tab = Tab.INVENTORY

var pause_menu: PanelContainer
var settings_panel: PanelContainer
var decorate_banner: PanelContainer
var decorate_mode_pill: Label
var decorate_banner_label: Label
var rotation_display_label: Label
var save_indicator: Label
var _save_indicator_tween: Tween

var notification_layer: NotificationLayer

var _achievements_header_label: Label
var _achievements_list_container: VBoxContainer

var storage_panel: StoragePanel
var _tab_menu_screen_anchor: Control

var shop_panel: ShopPanel

var _skill_bars: Dictionary = {}
var _skill_labels: Dictionary = {}
var _skill_perk_labels: Dictionary = {}
var _cached_player: Node3D
var _last_cursor_item_id := ""
var _last_cursor_quantity := -1


const STORAGE_AUTO_CLOSE_DISTANCE := 3.5

## Independent CanvasLayers (like the debug spawner) that build their own
## panel outside UILayer's own tree add that panel to this group to opt
## into is_blocking_gameplay()/is_any_menu_open() checks — lets UILayer
## stay unaware of exactly which debug/tool panels exist.
const BLOCKING_UI_GROUP := "blocking_ui_panels"

func _ready() -> void:
	add_to_group("ui_layer")
	process_mode = Node.PROCESS_MODE_ALWAYS
	get_viewport().size_changed.connect(_update_tile_layout)  # keep tiles correctly placed if the window is resized while one's open

	_build_hotbar()
	_build_tab_menu()
	_build_pause_menu()
	_build_decorate_banner()
	_build_save_indicator()
	_build_clock()
	_build_cursor_held_display()

	InventorySlotManager.slot_changed.connect(_on_slot_changed)
	InventorySlotManager.selection_changed.connect(_on_selection_changed)
	SkillManager.xp_granted.connect(_on_xp_granted)
	SkillManager.leveled_up.connect(_on_leveled_up)
	SaveManager.game_saved.connect(_on_game_saved)
	AchievementManager.achievement_completed.connect(_on_achievement_completed)
	notification_layer = NotificationLayer.new()
	add_child(notification_layer)
	notification_layer.build()

	storage_panel = StoragePanel.new()
	add_child(storage_panel)
	storage_panel.build(self)

	shop_panel = ShopPanel.new()
	add_child(shop_panel)
	shop_panel.build(self)

	_refresh_all_hotbar_slots()
	_refresh_all_inventory_slots()
	_refresh_all_skills()

	call_deferred("_wire_decorate_mode_signal")


func _wire_decorate_mode_signal() -> void:
	var player := get_tree().get_first_node_in_group("player")
	if player:
		_cached_player = player
		player.decorate_mode_changed.connect(_on_decorate_mode_changed)
		player.rotation_changed.connect(_on_rotation_changed)


## Storage and shop panels do NOT block movement/gameplay — you should be
## able to walk around (and walk away, auto-closing them) while either is
## open, since interacting with both is entirely mouse-driven. tab_menu
## and pause_menu keep their existing blocking behavior.
func _process(_delta: float) -> void:
	if _last_cursor_item_id != InventorySlotUI.held_item_id or _last_cursor_quantity != InventorySlotUI.held_quantity:
		_last_cursor_item_id = InventorySlotUI.held_item_id
		_last_cursor_quantity = InventorySlotUI.held_quantity
		_update_cursor_held_display()

	var player := _cached_player
	if player == null:
		return

	var current_storage := storage_panel.get_current_container()
	if storage_panel.visible and current_storage != null:
		if not is_instance_valid(current_storage):
			close_storage()
		elif player.global_position.distance_to(current_storage.global_position) > STORAGE_AUTO_CLOSE_DISTANCE:
			close_storage()

	var current_shop := shop_panel.get_current_shop()
	if shop_panel.visible and current_shop != null:
		if not is_instance_valid(current_shop):
			close_shop()
		elif player.global_position.distance_to(current_shop.global_position) > STORAGE_AUTO_CLOSE_DISTANCE:
			close_shop()


func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_ESCAPE:
			var player := get_tree().get_first_node_in_group("player")
			if player and player.is_building():
				return  # let Player's own Escape handler cancel build mode instead
			if settings_panel.visible:
				_close_settings_panel()
			elif storage_panel.visible:
				close_storage()
			elif shop_panel.visible:
				close_shop()
			elif tab_menu.visible:
				_close_tab_menu()
			else:
				_toggle_pause_menu()
		elif event.keycode == KEY_TAB:
			_toggle_tab_menu()
		elif tab_menu.visible and (event.keycode == KEY_Q or event.keycode == KEY_BRACKETLEFT):
			_cycle_tab_page(-1)
		elif tab_menu.visible and (event.keycode == KEY_E or event.keycode == KEY_BRACKETRIGHT):
			_cycle_tab_page(1)
		elif event.keycode >= KEY_1 and event.keycode <= KEY_9:
			# Number row selects that hotbar slot directly (1 = slot 0, etc).
			# Ignored past HOTBAR_SIZE in case the hotbar ever shrinks below 9.
			var index: int = int(event.keycode) - int(KEY_1)
			if index < InventorySlotManager.HOTBAR_SIZE:
				InventorySlotManager.select_hotbar_index(index)

	if event is InputEventMouseButton and event.pressed and not event.ctrl_pressed and not Input.is_key_pressed(KEY_R):
		if is_any_menu_open():
			return
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			InventorySlotManager.cycle_hotbar_selection(-1)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			InventorySlotManager.cycle_hotbar_selection(1)


## --- Hotbar (always visible, bottom-center, fixed 7 slots) ---

func _build_hotbar() -> void:
	var screen_anchor := CenterContainer.new()
	screen_anchor.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	screen_anchor.position.y = -76
	screen_anchor.custom_minimum_size = Vector2(0, 60)
	screen_anchor.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(screen_anchor)

	var vbox := VBoxContainer.new()
	vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	screen_anchor.add_child(vbox)

	hotbar_hover_label = Label.new()
	hotbar_hover_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hotbar_hover_label.add_theme_font_size_override("font_size", 14)
	hotbar_hover_label.text = " "  # always reserves its line, avoids layout jump
	vbox.add_child(hotbar_hover_label)

	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 4)
	vbox.add_child(row)

	for i in InventorySlotManager.HOTBAR_SIZE:
		var slot := InventorySlotUI.new()
		slot.custom_minimum_size = Vector2(SLOT_SIZE, SLOT_SIZE)
		slot.setup(InventorySlotManager.SlotType.HOTBAR, i, true, SLOT_ICON_SIZE)
		slot.hovered_item_changed.connect(_on_hotbar_hover_changed)
		row.add_child(slot)
		_hotbar_slot_widgets.append(slot)


func _on_hotbar_hover_changed(item_name: String) -> void:
	if item_name != "":
		hotbar_hover_label.text = item_name
	else:
		_refresh_hotbar_label_to_selected()


## Shows the currently selected hotbar item's name — this is the default
## state of the label whenever the mouse isn't actively hovering a slot.
func _refresh_hotbar_label_to_selected() -> void:
	var item_id := InventorySlotManager.get_selected_hotbar_item_id()
	hotbar_hover_label.text = _get_item_display_name(item_id) if item_id != "" else " "


func _get_item_display_name(item_id: String) -> String:
	if item_id == "":
		return ""
	var def: ItemData = InventoryManager.item_defs.get(item_id)
	return def.display_name if def else item_id


func _refresh_all_hotbar_slots() -> void:
	for slot in _hotbar_slot_widgets:
		slot.refresh()


func _on_slot_changed(slot_type: InventorySlotManager.SlotType, index: int) -> void:
	if slot_type == InventorySlotManager.SlotType.HOTBAR:
		_hotbar_slot_widgets[index].refresh()
		if index == InventorySlotManager.selected_hotbar_index:
			_refresh_hotbar_label_to_selected()
	else:
		_inventory_slot_widgets[index].refresh()


func _on_selection_changed(_index: int) -> void:
	for slot in _hotbar_slot_widgets:
		slot.refresh()
	_refresh_hotbar_label_to_selected()


## Called by Player when planting.
func get_selected_hotbar_item_id() -> String:
	return InventorySlotManager.get_selected_hotbar_item_id()


## --- Tab menu / "Grim-oir" (Tab key) ---
## Styled and navigated like a reference tome: bookmark tabs protrude from
## the left edge (not buttons across the top), pages crossfade instead of
## snapping, and the last page you had open stays open next time (for
## this play session — not persisted across a full restart, since that's
## a minor convenience rather than something save data needs to carry).
##
## IMPORTANT: the actual PAGE CONTENT builders (_build_inventory_page,
## _build_skills_page, _build_achievements_page, _build_placeholder_page,
## the new _build_collection_log_page) are unchanged / called exactly the
## same way as before — only the outer chrome (navigation + styling +
## transitions) changed. None of those systems needed to know this
## happened.

const BOOKMARK_COLORS := {
	Tab.INVENTORY: Color(0.55, 0.45, 0.25),
	Tab.SKILLS: Color(0.35, 0.5, 0.3),
	Tab.RECIPES: Color(0.5, 0.3, 0.25),
	Tab.ACHIEVEMENTS: Color(0.6, 0.5, 0.15),
	Tab.COLLECTION_LOG: Color(0.3, 0.4, 0.5),
	Tab.RELATIONSHIPS: Color(0.55, 0.3, 0.4),
	Tab.QUESTS: Color(0.4, 0.35, 0.55),
	Tab.CALENDAR: Color(0.3, 0.45, 0.45),
}
const TAB_LABELS := {
	Tab.INVENTORY: "Inventory",
	Tab.SKILLS: "Levels",
	Tab.RECIPES: "Recipes",
	Tab.ACHIEVEMENTS: "Tasks",
	Tab.COLLECTION_LOG: "Collection",
	Tab.RELATIONSHIPS: "Relationships",
	Tab.QUESTS: "Quests",
	Tab.CALENDAR: "Calendar",
}
const TAB_ORDER := [Tab.INVENTORY, Tab.SKILLS, Tab.COLLECTION_LOG, Tab.RECIPES, Tab.ACHIEVEMENTS, Tab.RELATIONSHIPS, Tab.QUESTS, Tab.CALENDAR]

var _page_title_label: Label
var _page_crossfade_tween: Tween


func _build_tab_menu() -> void:
	_tab_menu_screen_anchor = Control.new()
	_tab_menu_screen_anchor.set_anchors_preset(Control.PRESET_FULL_RECT)
	_tab_menu_screen_anchor.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_tab_menu_screen_anchor)

	tab_menu = PanelContainer.new()
	tab_menu.custom_minimum_size = Vector2(720, 460)
	tab_menu.visible = false
	var book_style := StyleBoxFlat.new()
	book_style.bg_color = Color(0.14, 0.1, 0.07, 0.97)
	book_style.set_border_width_all(2)
	book_style.border_color = Color(0.5, 0.38, 0.2, 0.8)
	book_style.set_corner_radius_all(6)
	book_style.corner_radius_top_left = 2
	book_style.corner_radius_bottom_left = 2
	tab_menu.add_theme_stylebox_override("panel", book_style)
	_tab_menu_screen_anchor.add_child(tab_menu)
	_register_tile_panel(tab_menu)

	var outer_hbox := HBoxContainer.new()
	outer_hbox.add_theme_constant_override("separation", 0)
	tab_menu.add_child(outer_hbox)

	var bookmark_strip := VBoxContainer.new()
	bookmark_strip.add_theme_constant_override("separation", 3)
	var strip_margin := MarginContainer.new()
	strip_margin.add_theme_constant_override("margin_top", 16)
	strip_margin.add_child(bookmark_strip)
	outer_hbox.add_child(strip_margin)

	for tab in TAB_ORDER:
		_add_tab_button(bookmark_strip, TAB_LABELS[tab], tab)

	var content_margin := MarginContainer.new()
	content_margin.add_theme_constant_override("margin_left", 4)
	content_margin.add_theme_constant_override("margin_right", 18)
	content_margin.add_theme_constant_override("margin_top", 18)
	content_margin.add_theme_constant_override("margin_bottom", 18)
	content_margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	outer_hbox.add_child(content_margin)

	var content_vbox := VBoxContainer.new()
	content_vbox.add_theme_constant_override("separation", 8)
	content_margin.add_child(content_vbox)

	_page_title_label = Label.new()
	_page_title_label.add_theme_font_size_override("font_size", 20)
	_page_title_label.modulate = Color(0.95, 0.88, 0.7)
	content_vbox.add_child(_page_title_label)
	content_vbox.add_child(HSeparator.new())

	var page_container := Control.new()
	page_container.custom_minimum_size = Vector2(0, 370)
	page_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content_vbox.add_child(page_container)

	_tab_pages[Tab.INVENTORY] = _build_inventory_page(page_container)
	_tab_pages[Tab.SKILLS] = _build_skills_page(page_container)
	_tab_pages[Tab.RECIPES] = _build_placeholder_page(page_container, "No recipes yet — cooking and herbalism systems coming soon.")
	_tab_pages[Tab.ACHIEVEMENTS] = _build_achievements_page(page_container)
	_tab_pages[Tab.COLLECTION_LOG] = _build_collection_log_page(page_container)
	_tab_pages[Tab.RELATIONSHIPS] = _build_placeholder_page(page_container, "No one to write about yet — NPCs haven't arrived in this world.")
	_tab_pages[Tab.QUESTS] = _build_placeholder_page(page_container, "No quests yet — the quest system hasn't been built.")
	_tab_pages[Tab.CALENDAR] = _build_placeholder_page(page_container, "The calendar has no pages yet — it needs the day/night and season systems first.")

	_switch_tab(Tab.INVENTORY, false)


## `tab` here is a bookmark on the side, not a top button — still functions
## identically (press = switch page), just laid out/styled differently.
func _add_tab_button(parent: VBoxContainer, label: String, tab: Tab) -> void:
	var btn := Button.new()
	btn.text = label
	btn.toggle_mode = true
	btn.custom_minimum_size = Vector2(120, 34)
	btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
	# Without this, VBoxContainer stretches every child to match the
	# widest one — which silently ate the whole "selected tab is wider"
	# effect, since all buttons rendered at the same width regardless of
	# their own custom_minimum_size. This makes each button keep its own
	# width instead.
	btn.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN

	var accent: Color = BOOKMARK_COLORS.get(tab, Color(0.4, 0.4, 0.4))
	var normal_style := StyleBoxFlat.new()
	normal_style.bg_color = Color(accent.r, accent.g, accent.b, 0.35)
	normal_style.set_corner_radius_all(3)
	normal_style.corner_radius_top_left = 0
	normal_style.corner_radius_bottom_left = 0
	normal_style.content_margin_left = 10

	var selected_style := normal_style.duplicate()
	selected_style.bg_color = Color(accent.r, accent.g, accent.b, 0.85)
	# The selected bookmark "protrudes" further into the content area than
	# the others, same visual idea as a real book's tabs — the currently
	# open one sticks out past its neighbors.
	btn.add_theme_stylebox_override("normal", normal_style)
	btn.add_theme_stylebox_override("hover", selected_style)
	btn.set_meta("normal_style", normal_style)
	btn.set_meta("selected_style", selected_style)

	btn.pressed.connect(func(): _switch_tab(tab))
	parent.add_child(btn)
	_tab_buttons[tab] = btn


func _cycle_tab_page(direction: int) -> void:
	var current_index: int = TAB_ORDER.find(_current_tab)
	if current_index == -1:
		current_index = 0
	var next_index: int = (current_index + direction + TAB_ORDER.size()) % TAB_ORDER.size()
	_switch_tab(TAB_ORDER[next_index])


func _switch_tab(tab: Tab, animate: bool = true) -> void:
	var previous_tab := _current_tab
	_current_tab = tab
	_page_title_label.text = TAB_LABELS.get(tab, "")
	if tab == Tab.COLLECTION_LOG and not _collection_log_built:
		_collection_log_built = true
		_refresh_collection_log_page()

	for t in _tab_buttons.keys():
		var btn: Button = _tab_buttons[t]
		btn.button_pressed = (t == tab)
		var style: StyleBoxFlat = btn.get_meta("selected_style") if t == tab else btn.get_meta("normal_style")
		btn.add_theme_stylebox_override("pressed", style)
		btn.add_theme_stylebox_override("normal", style)
		btn.custom_minimum_size.x = 132 if t == tab else 120  # the protrusion mentioned above

	if not animate or previous_tab == tab or not _tab_pages.has(previous_tab):
		for t in _tab_pages.keys():
			_tab_pages[t].visible = (t == tab)
		return

	# Crossfade: fade the old page out, THEN swap visibility, THEN fade
	# the new one in — a real page-turn is a nicer effect long-term, but
	# needs actual page-curl art; this reads as an intentional transition
	# rather than an instant snap in the meantime.
	if _page_crossfade_tween and _page_crossfade_tween.is_valid():
		_page_crossfade_tween.kill()

	var old_page: Control = _tab_pages[previous_tab]
	var new_page: Control = _tab_pages[tab]
	new_page.modulate.a = 0.0

	_page_crossfade_tween = create_tween()
	_page_crossfade_tween.tween_property(old_page, "modulate:a", 0.0, 0.1)
	_page_crossfade_tween.tween_callback(func():
		for t in _tab_pages.keys():
			_tab_pages[t].visible = (t == tab)
		old_page.modulate.a = 1.0
	)
	_page_crossfade_tween.tween_property(new_page, "modulate:a", 1.0, 0.12)


## Positions `panel` (a fixed-size PanelContainer, unaffected by screen
## resolution) centered on a FRACTION of the screen (0.0-1.0 in each axis)
## rather than a raw pixel offset — this is what keeps it correctly
## on-screen and proportionally placed at any window size, instead of a
## fixed pixel offset that's fine at one resolution and pushes the panel
## off-edge at another.
## --- Tiling layout for dockable panels (tab_menu, storage_panel) ---
## "Tile manager" style: however many of these panels are open right now
## evenly split the screen into that many columns (1 open = full-width
## slot = centered; 2 open = two half-width slots, one panel centered in
## each), and each panel SMOOTHLY animates to its slot's center rather
## than snapping. Anchors are fixed at top-left for every tile panel,
## permanently — position is always a plain pixel Vector2 with no
## anchor-point ambiguity, which is what the previous fraction-anchor
## approach got subtly wrong (it centered each panel's TOP-LEFT CORNER on
## the target fraction instead of centering the panel itself, which is
## exactly the "stuck in a corner" bug).

const TILE_ANIMATION_DURATION := 0.28

var _tile_panels: Array[Control] = []
var _tile_tweens: Dictionary = {}  # Control -> Tween


func _register_tile_panel(panel: Control) -> void:
	panel.set_anchors_preset(Control.PRESET_TOP_LEFT)
	_tile_panels.append(panel)


## Public entry points for extracted panel scripts (StoragePanel, ShopPanel)
## that live in their own files now but still need to participate in the
## shared tile layout — the layout system itself stays centralized here
## since it's inherently a cross-panel concern, not something any single
## panel could own on its own.
func register_tile_panel(panel: Control) -> void:
	_register_tile_panel(panel)


func request_tile_layout() -> void:
	_update_tile_layout()


func _update_tile_layout() -> void:
	var viewport_size: Vector2 = get_viewport().get_visible_rect().size
	var open_panels: Array[Control] = []
	for panel in _tile_panels:
		if panel.visible:
			open_panels.append(panel)

	if open_panels.is_empty():
		return

	var slot_width: float = viewport_size.x / open_panels.size()
	for i in open_panels.size():
		var panel := open_panels[i]
		var slot_center_x: float = slot_width * i + slot_width / 2.0
		var target_x: float = slot_center_x - panel.custom_minimum_size.x / 2.0
		var target_y: float = (viewport_size.y - panel.custom_minimum_size.y) / 2.0
		_animate_panel_to(panel, Vector2(target_x, target_y))


func _animate_panel_to(panel: Control, target_position: Vector2) -> void:
	if _tile_tweens.has(panel) and _tile_tweens[panel].is_valid():
		_tile_tweens[panel].kill()
	var tween := create_tween()
	tween.set_ease(Tween.EASE_OUT)
	tween.set_trans(Tween.TRANS_CUBIC)
	tween.tween_property(panel, "position", target_position, TILE_ANIMATION_DURATION)
	_tile_tweens[panel] = tween


func _toggle_tab_menu() -> void:
	if pause_menu.visible:
		return
	tab_menu.visible = not tab_menu.visible
	_update_tile_layout()


func _close_tab_menu() -> void:
	InventorySlotUI.cancel_held_payload()
	tab_menu.visible = false
	_update_tile_layout()


## Storage does NOT block movement/gameplay — you should be able to walk
## around (and walk away, auto-closing it — see _process) while a chest is
## open, since interacting with it is entirely mouse-driven. tab_menu and
## pause_menu keep their existing blocking behavior; only storage_panel
## was removed from this check.
func is_blocking_gameplay() -> bool:
	if tab_menu.visible or pause_menu.visible:
		return true
	for node in get_tree().get_nodes_in_group(BLOCKING_UI_GROUP):
		if node is CanvasItem and node.visible:
			return true
	return false


## Broader than is_blocking_gameplay() on purpose — used for things that
## should stop the moment ANY menu is open, even ones (storage, shop)
## that deliberately don't block movement. Scroll wheel cycling the
## hotbar while you're scrolling a chest's contents or the debug spawner
## list is exactly the case this exists for.
func is_any_menu_open() -> bool:
	return is_blocking_gameplay() or storage_panel.visible or shop_panel.visible


## --- Inventory tab page: fixed 7x4 grid, separate from the hotbar ---

func _build_inventory_page(parent: Control) -> Control:
	var page_vbox := VBoxContainer.new()
	page_vbox.set_anchors_preset(Control.PRESET_FULL_RECT)
	page_vbox.add_theme_constant_override("separation", 6)
	parent.add_child(page_vbox)

	var toolbar := HBoxContainer.new()
	toolbar.alignment = BoxContainer.ALIGNMENT_END
	page_vbox.add_child(toolbar)

	var sort_button := Button.new()
	sort_button.text = "Sort"
	sort_button.pressed.connect(func():
		InventorySlotManager.sort_main_slots()
		_refresh_all_inventory_slots()
	)
	toolbar.add_child(sort_button)

	var center := CenterContainer.new()
	center.size_flags_vertical = Control.SIZE_EXPAND_FILL
	page_vbox.add_child(center)

	var grid := GridContainer.new()
	grid.columns = INVENTORY_COLUMNS
	grid.add_theme_constant_override("h_separation", 6)
	grid.add_theme_constant_override("v_separation", 6)
	center.add_child(grid)

	for i in InventorySlotManager.MAIN_SIZE:
		var slot := InventorySlotUI.new()
		slot.custom_minimum_size = Vector2(SLOT_SIZE, SLOT_SIZE)
		slot.setup(InventorySlotManager.SlotType.MAIN, i, false, SLOT_ICON_SIZE)
		grid.add_child(slot)
		_inventory_slot_widgets.append(slot)

	return page_vbox


func _refresh_all_inventory_slots() -> void:
	for slot in _inventory_slot_widgets:
		slot.refresh()


## --- Skills tab page ---

func _build_skills_page(parent: Control) -> Control:
	var scroll := ScrollContainer.new()
	scroll.set_anchors_preset(Control.PRESET_FULL_RECT)
	parent.add_child(scroll)

	var skill_list := VBoxContainer.new()
	skill_list.add_theme_constant_override("separation", 8)
	scroll.add_child(skill_list)

	for skill_id in SkillManager.skill_defs.keys():
		_add_skill_row(skill_list, skill_id)

	return scroll


func _add_skill_row(skill_list: VBoxContainer, skill_id: String) -> void:
	var def: SkillData = SkillManager.skill_defs[skill_id]
	var level := SkillManager.get_level(skill_id)
	var xp := SkillManager.get_xp(skill_id)
	var progress := def.get_level_progress(xp)

	var row := VBoxContainer.new()
	skill_list.add_child(row)

	var label := Label.new()
	label.text = "%s — Lv %d" % [def.display_name, level]
	row.add_child(label)
	_skill_labels[skill_id] = label

	var bar := ProgressBar.new()
	bar.custom_minimum_size = Vector2(0, 8)
	bar.show_percentage = false
	if progress.y > 0:
		bar.max_value = progress.y
		bar.value = progress.x
	else:
		bar.max_value = 1
		bar.value = 1
	row.add_child(bar)
	_skill_bars[skill_id] = bar

	var perk_label := Label.new()
	perk_label.add_theme_font_size_override("font_size", 11)
	perk_label.modulate = Color(1, 1, 1, 0.55)
	row.add_child(perk_label)
	_skill_perk_labels[skill_id] = perk_label
	_update_skill_perk_label(skill_id)


## Shows the next LOCKED perk for this skill, if any — a quick concrete
## reason to keep using a skill beyond "the number goes up."
func _update_skill_perk_label(skill_id: String) -> void:
	if not _skill_perk_labels.has(skill_id):
		return
	var current_level := SkillManager.get_level(skill_id)
	var next_perk: SkillPerkData = null
	for perk in SkillManager.get_all_perks(skill_id):
		if perk.required_level > current_level:
			if next_perk == null or perk.required_level < next_perk.required_level:
				next_perk = perk

	if next_perk:
		_skill_perk_labels[skill_id].text = "Next: %s at level %d — %s" % [next_perk.display_name, next_perk.required_level, next_perk.description]
	elif not SkillManager.get_all_perks(skill_id).is_empty():
		_skill_perk_labels[skill_id].text = "All perks unlocked."
	else:
		_skill_perk_labels[skill_id].text = ""


func _refresh_all_skills() -> void:
	for skill_id in SkillManager.skill_defs.keys():
		_on_xp_granted(skill_id, 0, SkillManager.get_xp(skill_id))


func _on_xp_granted(skill_id: String, _amount: int, _new_total: int) -> void:
	if not _skill_labels.has(skill_id):
		return
	_update_skill_perk_label(skill_id)
	var def: SkillData = SkillManager.skill_defs[skill_id]
	var level := SkillManager.get_level(skill_id)
	var xp := SkillManager.get_xp(skill_id)
	var progress := def.get_level_progress(xp)

	_skill_labels[skill_id].text = "%s — Lv %d" % [def.display_name, level]
	var bar: ProgressBar = _skill_bars[skill_id]
	if progress.y > 0:
		bar.max_value = progress.y
		bar.value = progress.x
	else:
		bar.max_value = 1
		bar.value = 1


func _on_leveled_up(skill_id: String, new_level: int) -> void:
	print("Level up! %s is now level %d" % [skill_id, new_level])


## --- Decorate mode banner (top-center, shown while Placing/Picking Up) ---
## Deliberately a single compact pill rather than a paragraph of controls —
## new players don't need every hotkey spelled out up front, and a smaller
## banner leaves room for other top-of-screen UI (debug tools, notifications)
## without overlapping it.

func _build_decorate_banner() -> void:
	var screen_anchor := CenterContainer.new()
	screen_anchor.set_anchors_preset(Control.PRESET_TOP_WIDE)
	screen_anchor.position.y = 10
	screen_anchor.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(screen_anchor)

	decorate_banner = PanelContainer.new()
	decorate_banner.visible = false
	var banner_style := StyleBoxFlat.new()
	banner_style.bg_color = Color(0.08, 0.08, 0.08, 0.75)
	banner_style.set_corner_radius_all(10)
	banner_style.set_border_width_all(1)
	banner_style.border_color = Color(1, 1, 1, 0.15)
	banner_style.content_margin_left = 12
	banner_style.content_margin_right = 12
	banner_style.content_margin_top = 5
	banner_style.content_margin_bottom = 5
	decorate_banner.add_theme_stylebox_override("panel", banner_style)
	screen_anchor.add_child(decorate_banner)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	decorate_banner.add_child(row)

	decorate_mode_pill = Label.new()
	decorate_mode_pill.add_theme_font_size_override("font_size", 13)
	row.add_child(decorate_mode_pill)

	row.add_child(VSeparator.new())

	decorate_banner_label = Label.new()
	decorate_banner_label.add_theme_font_size_override("font_size", 12)
	decorate_banner_label.modulate = Color(1, 1, 1, 0.7)
	row.add_child(decorate_banner_label)

	row.add_child(VSeparator.new())

	rotation_display_label = Label.new()
	rotation_display_label.add_theme_font_size_override("font_size", 12)
	rotation_display_label.text = "0°"
	row.add_child(rotation_display_label)


func _on_decorate_mode_changed(active: bool, mode: String) -> void:
	decorate_banner.visible = active
	if not active:
		return

	# Short, glanceable key hints instead of full sentences — the goal is
	# "readable in half a second", not a complete manual.
	if mode == "placing":
		decorate_mode_pill.text = "PLACING"
		decorate_mode_pill.modulate = Color(0.55, 1.0, 0.6)
		decorate_banner_label.text = "Click Place  ·  R+Scroll Rotate  ·  Scroll Switch  ·  Esc Exit"
	elif mode == "picking_up":
		decorate_mode_pill.text = "PICKUP"
		decorate_mode_pill.modulate = Color(1.0, 0.75, 0.4)
		decorate_banner_label.text = "Click Pick Up  ·  R+Scroll Rotate  ·  Esc Exit"


func _on_rotation_changed(degrees: float) -> void:
	rotation_display_label.text = "%d°" % roundi(degrees)


## --- Save indicator (bottom-corner, shown briefly on every save) ---
## Fires for BOTH manual saves (F5, pause menu) and AutoSaveManager's
## background saves — they both just call SaveManager.save_game(), which
## emits the one signal this listens to. No separate "autosave indicator"
## needed.

## --- Clock (top-right corner, always visible) ---

var clock_label: Label

## --- Cursor-held item (shift-click split-and-carry — see InventorySlotUI) ---

var _cursor_held_icon: TextureRect
var _cursor_held_qty_label: Label

func _build_cursor_held_display() -> void:
	_cursor_held_icon = TextureRect.new()
	_cursor_held_icon.custom_minimum_size = Vector2(36, 36)
	_cursor_held_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_cursor_held_icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_cursor_held_icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_cursor_held_icon.set_anchors_preset(Control.PRESET_TOP_LEFT)
	_cursor_held_icon.visible = false
	add_child(_cursor_held_icon)

	_cursor_held_qty_label = Label.new()
	_cursor_held_qty_label.add_theme_font_size_override("font_size", 12)
	_cursor_held_qty_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_cursor_held_icon.add_child(_cursor_held_qty_label)


func _update_cursor_held_display() -> void:
	if InventorySlotUI.held_item_id == "":
		_cursor_held_icon.visible = false
		return

	_cursor_held_icon.visible = true
	_cursor_held_icon.position = get_viewport().get_mouse_position() + Vector2(10, 10)
	var def: ItemData = InventoryManager.item_defs.get(InventorySlotUI.held_item_id)
	_cursor_held_icon.texture = def.icon if def else null
	_cursor_held_qty_label.text = str(InventorySlotUI.held_quantity)


func _build_clock() -> void:
	var anchor := Control.new()
	anchor.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	anchor.position = Vector2(-16, 12)
	anchor.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(anchor)

	clock_label = Label.new()
	clock_label.add_theme_font_size_override("font_size", 13)
	clock_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	clock_label.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	clock_label.position = Vector2(-220, 0)
	clock_label.size = Vector2(220, 20)
	anchor.add_child(clock_label)

	DayNightManager.time_changed.connect(_on_time_changed)
	_on_time_changed(DayNightManager.time_of_day)

	EconomyManager.currency_changed.connect(_on_currency_changed)
	_on_currency_changed(EconomyManager.currency)


func _on_currency_changed(new_total: int) -> void:
	clock_label.text = _format_clock() + "   %d gold" % new_total


func _format_clock() -> String:
	var hour: float = DayNightManager.time_of_day
	var h: int = int(hour)
	var m: int = int((hour - h) * 60.0)
	var suffix: String = "AM" if h < 12 else "PM"
	var display_h: int = h % 12
	if display_h == 0:
		display_h = 12
	var phase_text: String = "Night" if DayNightManager.is_night() else "Day"
	return "%d:%02d %s — %s" % [display_h, m, suffix, phase_text]


func _on_time_changed(_hour: float) -> void:
	clock_label.text = _format_clock() + "   %d gold" % EconomyManager.currency


func _build_save_indicator() -> void:
	var anchor := Control.new()
	anchor.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	anchor.position = Vector2(-16, -16)
	anchor.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(anchor)

	save_indicator = Label.new()
	save_indicator.text = "Saved"
	save_indicator.add_theme_font_size_override("font_size", 13)
	save_indicator.modulate = Color(1, 1, 1, 0.0)  # starts invisible
	save_indicator.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	# Anchor its own bottom-right corner to the anchor point rather than
	# top-left, so it doesn't drift off-screen if the text length changes.
	save_indicator.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	save_indicator.position = Vector2(-140, -24)
	save_indicator.size = Vector2(140, 24)
	anchor.add_child(save_indicator)


func _on_game_saved() -> void:
	if save_indicator == null:
		return
	if _save_indicator_tween and _save_indicator_tween.is_valid():
		_save_indicator_tween.kill()  # cancel any in-flight fade so rapid saves don't fight each other
	save_indicator.modulate.a = 1.0
	_save_indicator_tween = create_tween()
	_save_indicator_tween.tween_interval(1.2)
	_save_indicator_tween.tween_property(save_indicator, "modulate:a", 0.0, 0.6)


## --- Simple placeholder pages (Recipes, Achievements) ---

func _build_placeholder_page(parent: Control, message: String) -> Control:
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	parent.add_child(center)

	var label := Label.new()
	label.text = message
	label.modulate = Color(1, 1, 1, 0.6)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD
	label.custom_minimum_size = Vector2(400, 0)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	center.add_child(label)

	return center


## --- Collection Log page ---
## Every item in InventoryManager.item_defs IS an entry automatically —
## nothing separate to author per item. Undiscovered items show a
## silhouette + "???"; discovered ones (CollectionLogManager.is_discovered,
## true the moment you've ever held one) show whatever's on that item's
## ItemData: name, description, icon, and the optional location_found/lore
## fields if they've been filled in.

var _collection_log_grid: GridContainer
var _collection_log_detail_name: Label
var _collection_log_detail_body: RichTextLabel
var _collection_log_count_label: Label
var _collection_log_selected_id: String = ""
var _collection_log_built := false

func _build_collection_log_page(parent: Control) -> Control:
	var hbox := HBoxContainer.new()
	hbox.set_anchors_preset(Control.PRESET_FULL_RECT)
	hbox.add_theme_constant_override("separation", 12)
	parent.add_child(hbox)

	var left_vbox := VBoxContainer.new()
	left_vbox.custom_minimum_size = Vector2(280, 0)
	hbox.add_child(left_vbox)

	_collection_log_count_label = Label.new()
	_collection_log_count_label.add_theme_font_size_override("font_size", 12)
	_collection_log_count_label.modulate = Color(1, 1, 1, 0.6)
	left_vbox.add_child(_collection_log_count_label)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	left_vbox.add_child(scroll)

	_collection_log_grid = GridContainer.new()
	_collection_log_grid.columns = 6
	_collection_log_grid.add_theme_constant_override("h_separation", 3)
	_collection_log_grid.add_theme_constant_override("v_separation", 3)
	scroll.add_child(_collection_log_grid)

	hbox.add_child(VSeparator.new())

	var detail_vbox := VBoxContainer.new()
	detail_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hbox.add_child(detail_vbox)

	_collection_log_detail_name = Label.new()
	_collection_log_detail_name.add_theme_font_size_override("font_size", 16)
	detail_vbox.add_child(_collection_log_detail_name)

	_collection_log_detail_body = RichTextLabel.new()
	_collection_log_detail_body.bbcode_enabled = true
	_collection_log_detail_body.fit_content = true
	_collection_log_detail_body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_collection_log_detail_body.add_theme_font_size_override("normal_font_size", 12)
	detail_vbox.add_child(_collection_log_detail_body)

	CollectionLogManager.item_discovered.connect(func(_id):
		if _collection_log_built:
			_refresh_collection_log_page()
	)
	_collection_log_count_label.text = "Open this page to load the collection."

	return hbox


func _refresh_collection_log_page() -> void:
	if _collection_log_grid == null:
		return

	for child in _collection_log_grid.get_children():
		child.queue_free()

	var all_ids: Array = InventoryManager.item_defs.keys()
	_collection_log_count_label.text = "%d / %d Discovered" % [CollectionLogManager.get_discovered_count(), all_ids.size()]

	for item_id in all_ids:
		var discovered: bool = CollectionLogManager.is_discovered(item_id)
		var def: ItemData = InventoryManager.item_defs[item_id]

		var btn := TextureButton.new()
		btn.custom_minimum_size = Vector2(40, 40)
		btn.ignore_texture_size = true
		btn.stretch_mode = TextureButton.STRETCH_KEEP_ASPECT_CENTERED
		if discovered and def.icon:
			btn.texture_normal = def.icon
			btn.modulate = Color.WHITE
		else:
			btn.texture_normal = def.icon  # still show the silhouette shape if there's an icon...
			btn.modulate = Color(0, 0, 0, 0.85) if def.icon else Color(1, 1, 1, 0.2)  # ...just rendered as a dark silhouette instead of full color
		btn.pressed.connect(func(): _select_collection_log_entry(item_id))
		_collection_log_grid.add_child(btn)

	if _collection_log_selected_id != "":
		_select_collection_log_entry(_collection_log_selected_id)
	else:
		_collection_log_detail_name.text = "Select an entry"
		_collection_log_detail_body.text = ""


func _select_collection_log_entry(item_id: String) -> void:
	_collection_log_selected_id = item_id
	var def: ItemData = InventoryManager.item_defs.get(item_id)
	if def == null:
		return

	if not CollectionLogManager.is_discovered(item_id):
		_collection_log_detail_name.text = "???"
		_collection_log_detail_body.text = "[i]An unidentified item. You'll need to find one to learn more.[/i]"
		return

	_collection_log_detail_name.text = def.display_name
	var body := def.description if def.description != "" else "[i]No description recorded yet.[/i]"
	if def.location_found != "":
		body += "\n\n[b]Found:[/b] %s" % def.location_found
	if def.lore != "":
		body += "\n\n[i]%s[/i]" % def.lore
	_collection_log_detail_body.text = body


## --- Achievements page ---

func _build_achievements_page(parent: Control) -> Control:
	var scroll := ScrollContainer.new()
	scroll.set_anchors_preset(Control.PRESET_FULL_RECT)
	parent.add_child(scroll)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 6)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(vbox)

	_achievements_header_label = Label.new()
	_achievements_header_label.add_theme_font_size_override("font_size", 15)
	vbox.add_child(_achievements_header_label)
	vbox.add_child(HSeparator.new())

	_achievements_list_container = vbox
	_refresh_achievements_page()

	return scroll


func _refresh_achievements_page() -> void:
	if _achievements_header_label == null:
		return

	_achievements_header_label.text = "Completion: %d%%" % roundi(AchievementManager.get_completion_percentage())

	# Clear everything after the header + separator (first two children).
	for i in range(_achievements_list_container.get_child_count() - 1, 1, -1):
		_achievements_list_container.get_child(i).queue_free()

	var by_category: Dictionary = {}
	for id in AchievementManager.achievement_defs:
		var def: AchievementData = AchievementManager.achievement_defs[id]
		if not by_category.has(def.category):
			by_category[def.category] = []
		by_category[def.category].append(def)

	var category_names: Array = AchievementData.Category.keys()
	for category in by_category:
		var category_label := Label.new()
		category_label.text = String(category_names[category]).capitalize()
		category_label.add_theme_font_size_override("font_size", 13)
		category_label.modulate = Color(1, 1, 1, 0.7)
		_achievements_list_container.add_child(category_label)

		for def in by_category[category]:
			_achievements_list_container.add_child(_build_achievement_row(def))


func _build_achievement_row(def: AchievementData) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)

	var is_done: bool = AchievementManager.completed.get(def.id, false)
	var hide_details: bool = def.hidden and not is_done

	var check := Label.new()
	check.text = "✓" if is_done else "○"
	check.modulate = Color(0.5, 1.0, 0.6) if is_done else Color(1, 1, 1, 0.4)
	check.custom_minimum_size = Vector2(20, 0)
	row.add_child(check)

	var text_vbox := VBoxContainer.new()
	text_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(text_vbox)

	var name_label := Label.new()
	name_label.text = "???" if hide_details else def.display_name
	name_label.add_theme_font_size_override("font_size", 13)
	text_vbox.add_child(name_label)

	var desc_label := Label.new()
	desc_label.text = "A hidden achievement." if hide_details else def.description
	desc_label.add_theme_font_size_override("font_size", 11)
	desc_label.modulate = Color(1, 1, 1, 0.6)
	desc_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	text_vbox.add_child(desc_label)

	if not is_done and not hide_details and def.condition_target_amount > 1:
		var progress_label := Label.new()
		var current: int = AchievementManager.progress.get(def.id, 0)
		progress_label.text = "%d / %d" % [mini(current, def.condition_target_amount), def.condition_target_amount]
		progress_label.add_theme_font_size_override("font_size", 11)
		progress_label.modulate = Color(1, 1, 1, 0.5)
		text_vbox.add_child(progress_label)

	return row


func _on_achievement_completed(def: AchievementData) -> void:
	_refresh_achievements_page()
	# Popup itself is handled independently by NotificationLayer, which
	# also listens to this same signal.


## --- Storage panel (StoragePanel, scripts/ui/storage_panel.gd) ---
## These stay as thin wrappers rather than being removed outright —
## StorageContainer.interact() calls ui.open_storage(self) directly and
## has no reason to know the actual panel got extracted into its own file.

func open_storage(container: StorageContainer) -> void:
	storage_panel.open(container)


func close_storage() -> void:
	InventorySlotUI.cancel_held_payload()
	storage_panel.close()


## --- Shop panel (ShopPanel, scripts/ui/shop_panel.gd) ---
## Same reasoning as storage above — TradingPost.interact() calls these
## directly by name.

func open_shop(shop: TradingPost) -> void:
	shop_panel.open(shop)


func close_shop() -> void:
	InventorySlotUI.cancel_held_payload()
	shop_panel.close()


## --- Pause menu ---

func _build_pause_menu() -> void:
	var screen_anchor := CenterContainer.new()
	screen_anchor.set_anchors_preset(Control.PRESET_FULL_RECT)
	screen_anchor.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(screen_anchor)

	pause_menu = PanelContainer.new()
	pause_menu.custom_minimum_size = Vector2(280, 0)
	pause_menu.visible = false
	screen_anchor.add_child(pause_menu)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 20)
	margin.add_theme_constant_override("margin_right", 20)
	margin.add_theme_constant_override("margin_top", 20)
	margin.add_theme_constant_override("margin_bottom", 20)
	pause_menu.add_child(margin)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	margin.add_child(vbox)

	var title := Label.new()
	title.text = "Paused"
	title.add_theme_font_size_override("font_size", 22)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)

	vbox.add_child(HSeparator.new())

	var resume_btn := Button.new()
	resume_btn.text = "Resume"
	resume_btn.pressed.connect(_toggle_pause_menu)
	vbox.add_child(resume_btn)

	var save_btn := Button.new()
	save_btn.text = "Save Game"
	save_btn.pressed.connect(func(): SaveManager.save_game())
	vbox.add_child(save_btn)

	var load_btn := Button.new()
	load_btn.text = "Load Game"
	load_btn.pressed.connect(func():
		SaveManager.load_game()
		_refresh_all_hotbar_slots()
		_refresh_all_inventory_slots()
		_refresh_all_skills()
	)
	vbox.add_child(load_btn)

	vbox.add_child(HSeparator.new())

	var settings_btn := Button.new()
	settings_btn.text = "Settings"
	settings_btn.pressed.connect(_open_settings_panel)
	vbox.add_child(settings_btn)

	vbox.add_child(HSeparator.new())

	var quit_btn := Button.new()
	quit_btn.text = "Quit to Desktop"
	quit_btn.pressed.connect(func(): get_tree().quit())
	vbox.add_child(quit_btn)

	_build_settings_panel(screen_anchor)


func _toggle_pause_menu() -> void:
	pause_menu.visible = not pause_menu.visible
	get_tree().paused = pause_menu.visible
	if pause_menu.visible:
		tab_menu.visible = false
	else:
		settings_panel.visible = false
	_update_tile_layout()


## --- Settings panel (Video + Audio), opened from the pause menu ---

func _build_settings_panel(screen_anchor: CenterContainer) -> void:
	settings_panel = PanelContainer.new()
	settings_panel.custom_minimum_size = Vector2(340, 0)
	settings_panel.visible = false
	screen_anchor.add_child(settings_panel)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 20)
	margin.add_theme_constant_override("margin_right", 20)
	margin.add_theme_constant_override("margin_top", 20)
	margin.add_theme_constant_override("margin_bottom", 20)
	settings_panel.add_child(margin)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	margin.add_child(vbox)

	var title := Label.new()
	title.text = "Settings"
	title.add_theme_font_size_override("font_size", 22)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)

	vbox.add_child(HSeparator.new())

	# --- Video section ---
	var video_label := Label.new()
	video_label.text = "Video"
	video_label.add_theme_font_size_override("font_size", 16)
	vbox.add_child(video_label)

	var res_label := Label.new()
	res_label.text = "Resolution"
	vbox.add_child(res_label)

	var res_dropdown := OptionButton.new()
	var native_size := DisplayServer.screen_get_size()
	res_dropdown.add_item("Native (%dx%d)" % [native_size.x, native_size.y])
	var option_resolutions: Array[Vector2i] = [native_size]
	for res in SettingsManager.RESOLUTION_OPTIONS:
		res_dropdown.add_item("%dx%d" % [res.x, res.y])
		option_resolutions.append(res)

	var current_index := option_resolutions.find(SettingsManager.resolution)
	res_dropdown.selected = current_index if current_index != -1 else 0
	res_dropdown.item_selected.connect(func(idx: int):
		SettingsManager.set_resolution(option_resolutions[idx])
	)
	vbox.add_child(res_dropdown)

	var fullscreen_check := CheckBox.new()
	fullscreen_check.text = "Fullscreen"
	fullscreen_check.button_pressed = SettingsManager.fullscreen
	fullscreen_check.toggled.connect(func(pressed: bool):
		SettingsManager.set_fullscreen(pressed)
		res_dropdown.disabled = pressed  # resolution is moot in fullscreen
	)
	res_dropdown.disabled = SettingsManager.fullscreen
	vbox.add_child(fullscreen_check)

	var fov_label := Label.new()
	fov_label.text = "Field of View"
	vbox.add_child(fov_label)

	var fov_slider := HSlider.new()
	fov_slider.min_value = 40
	fov_slider.max_value = 100
	fov_slider.step = 1
	fov_slider.value = SettingsManager.field_of_view
	fov_slider.value_changed.connect(func(value: float): SettingsManager.set_field_of_view(value))
	vbox.add_child(fov_slider)

	vbox.add_child(HSeparator.new())

	# --- Audio section ---
	# Master always works out of the box. Music/SFX sliders are ready to go
	# the moment you add "Music" and "SFX" buses in Project Settings > Audio
	# — until then they're harmless no-ops (SettingsManager checks the bus
	# exists before applying).
	var audio_label := Label.new()
	audio_label.text = "Audio"
	audio_label.add_theme_font_size_override("font_size", 16)
	vbox.add_child(audio_label)

	_add_volume_slider(vbox, "Master Volume", SettingsManager.master_volume, func(v): SettingsManager.set_master_volume(v))
	_add_volume_slider(vbox, "Music Volume", SettingsManager.music_volume, func(v): SettingsManager.set_music_volume(v))
	_add_volume_slider(vbox, "SFX Volume", SettingsManager.sfx_volume, func(v): SettingsManager.set_sfx_volume(v))

	vbox.add_child(HSeparator.new())

	var back_btn := Button.new()
	back_btn.text = "Back"
	back_btn.pressed.connect(_close_settings_panel)
	vbox.add_child(back_btn)


func _add_volume_slider(parent: VBoxContainer, label_text: String, initial_value: float, on_change: Callable) -> void:
	var label := Label.new()
	label.text = label_text
	parent.add_child(label)

	var slider := HSlider.new()
	slider.min_value = 0
	slider.max_value = 100
	slider.step = 1
	slider.value = initial_value * 100.0
	slider.value_changed.connect(func(value: float): on_change.call(value / 100.0))
	parent.add_child(slider)


func _open_settings_panel() -> void:
	pause_menu.visible = false
	settings_panel.visible = true


func _close_settings_panel() -> void:
	settings_panel.visible = false
	pause_menu.visible = true
