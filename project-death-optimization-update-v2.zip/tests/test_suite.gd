extends RefCounted
class_name TestSuite

## All the actual test logic lives here, independent of how it gets run.
## Two thin front-ends call into this:
##   - tests/test_runner.gd        (extends SceneTree) — CLI/headless
##   - tests/test_runner_scene.gd  (extends Node)       — run inside the
##     editor via TestRunnerScene.tscn, no terminal needed
##
## See tests/README.md for how to run either one.
##
## SAFE TO RE-RUN: every test either restores the state it changed (e.g.
## the inventory tests add then remove the same amount) or only touches
## in-memory data. Nothing in here calls SaveManager.save_game()/load_game()
## against your real user://savegame.json — save/load correctness is
## tested by round-tripping each manager's get_save_data()/load_save_data()
## in memory instead, so running this never overwrites (or requires) an
## actual save file.

var _pass_count := 0
var _fail_count := 0
var _current_suite := ""


## Runs every suite and returns the number of failed checks (0 = all green).
func run() -> int:
	print("\n=== Project Death — Integration Tests ===\n")

	_run_suite("SkillManager", _test_skill_manager)
	_run_suite("InventoryManager", _test_inventory_manager)
	_run_suite("InventorySlotManager", _test_inventory_slots)
	_run_suite("BuildGrid", _test_build_grid)
	_run_suite("World streaming data contracts", _test_world_streaming_contracts)
	_run_suite("CropData / DecayStage", _test_crop_data)
	_run_suite("CropDatabase", _test_crop_database)
	_run_suite("Save/Load round-trip (in-memory, no disk writes)", _test_save_load_round_trip)
	_run_suite("Content integrity", _test_content_integrity)

	print("\n=== Results: %d passed, %d failed ===\n" % [_pass_count, _fail_count])
	return _fail_count


## --- Tiny assertion helpers ---

func _run_suite(suite_name: String, fn: Callable) -> void:
	_current_suite = suite_name
	print("--- %s ---" % suite_name)
	fn.call()


func _check(condition: bool, message: String) -> void:
	if condition:
		_pass_count += 1
	else:
		_fail_count += 1
		print("  [FAIL] %s :: %s" % [_current_suite, message])


func _check_eq(actual: Variant, expected: Variant, message: String) -> void:
	_check(actual == expected, "%s (expected %s, got %s)" % [message, expected, actual])


## --- SkillManager ---
## Covers the exact "add a new skill .tres, does it Just Work" contract the
## whole skill system is built on, plus the level math every skill shares.

func _test_skill_manager() -> void:
	# This list is a deliberate roster check, not an accident-proof one —
	# update it whenever a skill is intentionally added/removed/renamed.
	# Its job is to catch an *unintentional* loss (a bad merge, a moved/
	# deleted .tres) the same way it just caught "husbandry" quietly
	# becoming "spiritkeeping" without this list being updated to match.
	var expected_skills := ["mining", "farming", "fishing", "woodcutting", "spiritkeeping", "cooking", "foraging", "herbalism"]
	for skill_id in expected_skills:
		_check(SkillManager.skill_defs.has(skill_id), "skill '%s' auto-loaded from resources/skills/" % skill_id)

	if not SkillManager.skill_defs.has("mining"):
		return  # nothing further is safe to test without this

	var skill: SkillData = SkillManager.skill_defs["mining"]
	_check_eq(skill.level_for_xp(0), 1, "level 1 at 0 XP")
	_check(skill.xp_for_level(1) == 0, "0 XP required to reach level 1")
	_check(skill.xp_for_level(10) > skill.xp_for_level(5), "XP curve is monotonically increasing")

	# Round-trip the curve: level_for_xp(xp_for_level(N)) should land on
	# exactly N (or higher, never lower) for several sample levels — this
	# is the check that would have caught an off-by-one in the curve math.
	for level in [2, 10, 25, 50]:
		if level > skill.max_level:
			continue
		var xp_needed := skill.xp_for_level(level)
		_check(skill.level_for_xp(xp_needed) >= level, "reaching level %d's XP threshold reports level >= %d" % [level, level])

	# add_xp / signals / meets_requirement, using a scratch skill_id-free
	# path: read current state, apply a delta, verify, then put it back.
	var starting_xp := SkillManager.get_xp("mining")
	var granted_signal := {"fired": false, "amount": 0}
	var leveled_signal := {"fired": false}
	var xp_callable := func(id, amount, _total):
		if id == "mining":
			granted_signal.fired = true
			granted_signal.amount = amount
	var level_callable := func(id, _new_level):
		if id == "mining":
			leveled_signal.fired = true
	SkillManager.xp_granted.connect(xp_callable)
	SkillManager.leveled_up.connect(level_callable)

	SkillManager.add_xp("mining", 50)
	_check_eq(SkillManager.get_xp("mining"), starting_xp + 50, "add_xp increases total by the granted amount")
	_check(granted_signal.fired and granted_signal.amount == 50, "xp_granted signal fires with correct amount")

	# Push well past the level-1 threshold to force at least one level-up,
	# then restore the original total so this test doesn't permanently
	# inflate the (in-memory-only) skill state for the rest of the run.
	SkillManager.add_xp("mining", int(skill.xp_for_level(5)))
	_check(leveled_signal.fired, "leveled_up signal fires once a threshold is crossed")
	_check(SkillManager.meets_requirement("mining", 2), "meets_requirement true once level threshold is reached")

	SkillManager.skill_xp["mining"] = starting_xp  # restore
	SkillManager.xp_granted.disconnect(xp_callable)
	SkillManager.leveled_up.disconnect(level_callable)

	_check_eq(SkillManager.meets_requirement("totally_unknown_skill", 1), false, "unknown skill never meets a requirement")


## --- InventoryManager ---

func _test_inventory_manager() -> void:
	_check(SkillManager.skill_defs.size() > 0, "sanity: SkillManager ran before this suite")  # ordering guard
	_check(InventoryManager.item_defs.size() > 0, "at least one ItemData auto-loaded from resources/")

	var ids: Array = InventoryManager.item_defs.keys()
	if ids.is_empty():
		return
	var test_id: String = ids[0]
	var starting := InventoryManager.get_count(test_id)

	var new_total := InventoryManager.add_item(test_id, 5)
	_check_eq(new_total, starting + 5, "add_item returns the new total")
	_check(InventoryManager.has_item(test_id, starting + 5), "has_item true at exact count")
	_check(not InventoryManager.has_item(test_id, starting + 6), "has_item false one above count")

	var had_enough := InventoryManager.remove_item(test_id, 5)
	_check(had_enough, "remove_item reports success when enough was available")
	_check_eq(InventoryManager.get_count(test_id), starting, "count restored after add+remove of the same amount")

	_check_eq(InventoryManager.add_item("this_item_id_should_never_exist", 1), -1, "add_item on an unknown id returns -1")
	_check_eq(InventoryManager.add_item(test_id, 0), -1, "zero-quantity add is rejected")
	_check(not InventoryManager.remove_item(test_id, -1), "negative removal is rejected")

	var over_removed := InventoryManager.remove_item(test_id, 999999)
	_check(not over_removed, "remove_item reports failure when not enough was available")
	_check_eq(InventoryManager.get_count(test_id), starting, "failed over-removal is atomic and leaves the count unchanged")


## --- InventorySlotManager ---

func _test_inventory_slots() -> void:
	_check_eq(InventorySlotManager.hotbar_slots.size(), InventorySlotManager.HOTBAR_SIZE, "hotbar has HOTBAR_SIZE slots")
	_check_eq(InventorySlotManager.main_slots.size(), InventorySlotManager.MAIN_SIZE, "main inventory has MAIN_SIZE slots")

	var starting_index := InventorySlotManager.selected_hotbar_index
	InventorySlotManager.select_hotbar_index(-1)
	_check_eq(InventorySlotManager.selected_hotbar_index, 0, "select_hotbar_index clamps below range to 0")
	InventorySlotManager.select_hotbar_index(9999)
	_check_eq(InventorySlotManager.selected_hotbar_index, InventorySlotManager.HOTBAR_SIZE - 1, "select_hotbar_index clamps above range to the last slot")

	InventorySlotManager.select_hotbar_index(0)
	InventorySlotManager.cycle_hotbar_selection(-1)
	_check_eq(InventorySlotManager.selected_hotbar_index, InventorySlotManager.HOTBAR_SIZE - 1, "cycling left from slot 0 wraps to the last slot")
	InventorySlotManager.cycle_hotbar_selection(1)
	_check_eq(InventorySlotManager.selected_hotbar_index, 0, "cycling right from the last slot wraps back to 0")
	InventorySlotManager.select_hotbar_index(starting_index)  # restore

	# Reconciliation: adding through InventoryManager should land the
	# quantity somewhere in the slots, and removing it should clear it back
	# out again — this is the sync path every gather/harvest/place action
	# depends on, so a regression here is silent but game-breaking.
	var ids: Array = InventoryManager.item_defs.keys()
	if ids.is_empty():
		return
	var test_id: String = ids[0]
	var total_in_slots_before := _count_item_across_all_slots(test_id)

	InventoryManager.add_item(test_id, 3)
	_check_eq(_count_item_across_all_slots(test_id), total_in_slots_before + 3, "slots gained exactly what was added")

	InventoryManager.remove_item(test_id, 3)
	_check_eq(_count_item_across_all_slots(test_id), total_in_slots_before, "slots lost exactly what was removed")


func _count_item_across_all_slots(item_id: String) -> int:
	var total := 0
	for slot in InventorySlotManager.hotbar_slots:
		if slot["item_id"] == item_id:
			total += slot["quantity"]
	for slot in InventorySlotManager.main_slots:
		if slot["item_id"] == item_id:
			total += slot["quantity"]
	return total


## --- BuildGrid ---

func _test_build_grid() -> void:
	var world_pos := Vector3(1.125, 0.0, -2.375)
	var cell := BuildGrid.world_to_decor_cell(world_pos)
	var back_to_world := BuildGrid.decor_cell_to_world(cell)
	_check(back_to_world.distance_to(world_pos) <= BuildGrid.DECOR_CELL_SIZE, "decor cell round-trip stays within one cell of the original position")

	var snapped := BuildGrid.snap_to_decor_grid(world_pos)
	_check_eq(fmod(snapped.x, BuildGrid.DECOR_CELL_SIZE), 0.0, "snapped X lands exactly on the decor grid")

	var probe := Node3D.new()
	var cells: Array[Vector3i] = [cell]
	_check(BuildGrid.is_decor_cell_free(cell), "test cell starts free (no leftover state from a previous run)")

	var placed := BuildGrid.place_decor(cells, probe)
	_check(placed, "place_decor succeeds on a free cell")
	_check(not BuildGrid.is_decor_cell_free(cell), "cell reports occupied after placing")

	var probe_two := Node3D.new()
	var placed_again := BuildGrid.place_decor(cells, probe_two)
	_check(not placed_again, "place_decor refuses an already-occupied cell")
	probe_two.free()

	BuildGrid.remove_decor(cells)
	_check(BuildGrid.is_decor_cell_free(cell), "cell frees up after remove_decor")
	probe.free()

	var rot := BuildGrid.snap_rotation_90(deg_to_rad(46.0))
	_check(is_equal_approx(rad_to_deg(rot), 90.0), "rotation snap rounds 46° up to 90°")

	var stale_probe := Node3D.new()
	BuildGrid.place_decor(cells, stale_probe)
	stale_probe.free()
	_check(BuildGrid.is_decor_cell_free(cell), "freed occupants are purged lazily instead of blocking the grid forever")


func _test_world_streaming_contracts() -> void:
	_check_eq(WorldManager.world_to_cell(Vector3(0.0, 0.0, 0.0)), Vector2i.ZERO, "world origin maps to cell 0,0")
	_check_eq(WorldManager.world_to_cell(Vector3(-0.01, 0.0, -100.01)), Vector2i(-1, -2), "negative coordinates use floor-based cell mapping")
	var serialized := WorldManager.get_save_data()
	_check(serialized.has("cells") and serialized["cells"] is Dictionary, "world state serializes with JSON-safe string cell keys")
	_check(JSON.stringify(serialized) != "", "world-state snapshot is JSON serializable")


## --- CropData / DecayStage ---
## Loads a real crop resource and checks the stage-lookup math every
## planted crop in the game relies on.

func _test_crop_data() -> void:
	var crop_path := "res://resources/Farming/crops/mugwart.tres"
	if not ResourceLoader.exists(crop_path):
		print("  [SKIP] %s not found — adjust the path in test_suite.gd if crops moved." % crop_path)
		return

	var crop: CropData = load(crop_path)
	_check(crop.stages.size() > 0, "crop has at least one stage")
	if crop.stages.is_empty():
		return

	_check_eq(crop.get_stage_index_at_time(0.0), 0, "time 0 is always stage 0")

	var expected_total := 0.0
	for stage in crop.stages:
		expected_total += stage.duration
	_check_eq(crop.get_total_lifetime(), expected_total, "get_total_lifetime matches the sum of every stage's duration")

	_check_eq(crop.get_stage_index_at_time(expected_total + 1.0), -1, "time past the last stage returns -1 (fully decayed)")
	_check(crop.get_stage_at_time(expected_total + 1.0) == null, "get_stage_at_time returns null once fully decayed")

	# Every non-final stage should hand off cleanly to the next one — no
	# gaps or overlaps in the accumulated-duration math.
	var running := 0.0
	for i in crop.stages.size():
		running += crop.stages[i].duration
		if i < crop.stages.size() - 1:
			_check_eq(crop.get_stage_index_at_time(running - 0.001), i, "just before stage %d ends, still reports stage %d" % [i, i])
			_check_eq(crop.get_stage_index_at_time(running + 0.001), i + 1, "just after stage %d ends, reports stage %d" % [i, i + 1])


## --- CropDatabase ---
## CropDatabase is what SaveManager uses to turn a saved crop_id string
## back into a real CropData when restoring a FarmPlot — if this is empty
## or missing an id, a saved crop silently fails to come back on load
## (FarmPlot.load_save_data just push_warnings and leaves the plot empty).

func _test_crop_database() -> void:
	_check(CropDatabase.crop_defs.size() > 0, "at least one CropData auto-loaded into CropDatabase")

	var crop_path := "res://resources/Farming/crops/mugwart.tres"
	if not ResourceLoader.exists(crop_path):
		return  # already reported as a [SKIP] by _test_crop_data
	var direct_load: CropData = load(crop_path)
	var from_database := CropDatabase.get_crop(direct_load.id)
	_check(from_database == direct_load, "CropDatabase.get_crop('%s') returns the same resource loading the file directly does" % direct_load.id)

	_check(CropDatabase.get_crop("this_crop_id_should_never_exist") == null, "get_crop returns null for an unknown id, not an error")


## --- Save/Load round-trip (in-memory only — see file header) ---

func _test_save_load_round_trip() -> void:
	var skill_snapshot: Dictionary = SkillManager.get_save_data()
	var skill_restore: Dictionary = skill_snapshot.duplicate(true)
	SkillManager.load_save_data(skill_snapshot)
	_check_eq(SkillManager.get_save_data(), skill_restore, "SkillManager save->load->save is stable")

	var inv_snapshot: Dictionary = InventoryManager.get_save_data()
	var inv_restore: Dictionary = inv_snapshot.duplicate(true)
	InventoryManager.load_save_data(inv_snapshot)
	_check_eq(InventoryManager.get_save_data(), inv_restore, "InventoryManager save->load->save is stable")

	var slots_snapshot: Dictionary = InventorySlotManager.get_save_data()
	InventorySlotManager.load_save_data(slots_snapshot)
	var slots_restored: Dictionary = InventorySlotManager.get_save_data()
	_check_eq(slots_restored["selected_hotbar_index"], slots_snapshot["selected_hotbar_index"], "InventorySlotManager selection survives a round trip")
	_check_eq(slots_restored["hotbar_slots"].size(), slots_snapshot["hotbar_slots"].size(), "InventorySlotManager hotbar slot count survives a round trip")


## --- Content integrity ---
## Catches the class of bug that never crashes, just silently fails in
## play — a typo'd skill_id, a seed pointing at nothing, a tool_type that
## doesn't match any resource node that wants it. Cheap to run, high value
## as more skills/items/nodes get added.

func _test_content_integrity() -> void:
	for item_id in InventoryManager.item_defs.keys():
		var def: ItemData = InventoryManager.item_defs[item_id]

		if def is SeedData:
			var seed: SeedData = def
			_check(seed.crop_data != null, "seed '%s' has crop_data assigned" % item_id)
			if seed.crop_data:
				_check(SkillManager.skill_defs.has(seed.crop_data.skill_id), "seed '%s': crop skill_id '%s' exists in SkillManager" % [item_id, seed.crop_data.skill_id])

		if def is ToolData:
			var tool: ToolData = def
			_check(tool.tool_type != "", "tool '%s' has a non-empty tool_type" % item_id)

	# Scan for ResourceNodeData resources directly (they aren't reachable
	# through InventoryManager the way seeds/tools are, since they're
	# assigned per-scene rather than held in inventory) and cross-check
	# each against SkillManager + the loaded ToolData set.
	var known_tool_types := {}
	for item_id in InventoryManager.item_defs.keys():
		var def: ItemData = InventoryManager.item_defs[item_id]
		if def is ToolData:
			known_tool_types[def.tool_type] = true

	var node_data_resources := _find_resource_node_data_files("res://resources/")
	_check(node_data_resources.size() > 0, "at least one ResourceNodeData found under res://resources/")
	for path in node_data_resources:
		var node_data: ResourceNodeData = load(path)
		_check(SkillManager.skill_defs.has(node_data.skill_id), "%s: skill_id '%s' exists in SkillManager" % [path, node_data.skill_id])
		_check(known_tool_types.has(node_data.required_tool_type), "%s: required_tool_type '%s' matches a loaded ToolData" % [path, node_data.required_tool_type])


func _find_resource_node_data_files(path: String) -> Array[String]:
	var result: Array[String] = []
	var dir := DirAccess.open(path)
	if dir == null:
		return result

	dir.list_dir_begin()
	var entry_name := dir.get_next()
	while entry_name != "":
		if entry_name.begins_with("."):
			entry_name = dir.get_next()
			continue
		var full_path := path.path_join(entry_name)
		if dir.current_is_dir():
			result.append_array(_find_resource_node_data_files(full_path))
		elif entry_name.ends_with(".tres"):
			var resource: Resource = load(full_path)
			if resource is ResourceNodeData:
				result.append(full_path)
		entry_name = dir.get_next()
	dir.list_dir_end()
	return result
