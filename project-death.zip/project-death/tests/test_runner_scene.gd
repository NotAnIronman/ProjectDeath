extends Node

## In-editor front-end — no terminal/CLI needed. Actual test logic lives in
## tests/test_suite.gd — see that file's header for what's covered.
##
## RUN IT:
##   1. Open tests/TestRunnerScene.tscn in the editor.
##   2. Make sure it's the currently-focused/open scene tab.
##   3. Press F6 (Run Current Scene) — or the "Run Current Scene" button
##      in the top-right toolbar.
##   4. Read the Output panel at the bottom of the editor. Every failure
##      prints a "[FAIL]" line; the last line is a pass/fail summary.
##
## This scene doesn't close itself when done (unlike the CLI runner, which
## exits with a status code) — just stop the running scene from the editor
## once you've read the output.

func _ready() -> void:
	# Deferred so every autoload's own _ready() has definitely finished
	# before the suite starts touching them.
	call_deferred("_go")


func _go() -> void:
	var suite := TestSuite.new()
	var fail_count := suite.run()
	if fail_count > 0:
		print("Done — %d failure(s) above. Stop the scene when you're finished reading." % fail_count)
	else:
		print("Done — everything passed. Stop the scene when you're finished reading.")
