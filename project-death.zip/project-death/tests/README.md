# Integration tests

`tests/test_suite.gd` is a small, dependency-free test suite — no GUT or
other addon required, just GDScript exercising the real autoload singletons
the same way the actual game does. Two ways to run it; pick whichever's
easier:

## Option A — inside the editor, no terminal needed

1. Open `tests/TestRunnerScene.tscn`.
2. With that scene tab focused, press **F6** (Run Current Scene), or use
   the "Run Current Scene" button in the editor's top-right toolbar.
3. Read the **Output** panel at the bottom of the editor. Every failing
   check prints a `[FAIL]` line; the last line is a pass/fail summary.
4. Stop the running scene once you're done reading (it doesn't auto-close).

This is the path to use if `godot`/`godot4` isn't on your PATH, or you just
don't want to deal with a terminal.

## Option B — headless CLI

```
godot4 --headless --script res://tests/test_runner.gd
```

(Substitute whatever your Godot 4 binary is actually called.)

**If you get `command not found`:** the engine isn't on your shell's PATH,
which is normal if you didn't install it through a package manager. Find it
first:

- **Arch / pacman:** `pacman -Qs godot` — if that returns nothing, it's not
  installed as a pacman package.
- **Flatpak:** `flatpak list | grep -i godot`. If it shows up, run it as
  `flatpak run org.godotengine.Godot --headless --script res://tests/test_runner.gd`
  from inside the project folder (flatpak needs filesystem permission to see
  your project — if it can't find `res://tests/...`, add `--path .` after
  `Godot`, or grant the flatpak access to wherever the project lives).
- **Downloaded manually (zip/AppImage):** it's just a binary sitting
  wherever you put it — `find ~ -maxdepth 4 -iname "*godot*" -type f
  2>/dev/null` to locate it, then either call it by full path or symlink it
  onto your PATH, e.g. `ln -s /path/to/Godot_v4.x-stable_linux.x86_64
  ~/.local/bin/godot4` (make sure `~/.local/bin` is on your PATH).

Once found, run it by full path if you don't want to bother with a symlink:
```
/full/path/to/Godot_v4.x-stable_linux.x86_64 --headless --script res://tests/test_runner.gd
```

Exits with code `0` (all green) or `1` (something's broken) — safe to wire
into a pre-commit hook or CI job once you've got the path sorted out.

## What it covers

- **SkillManager** — every skill `.tres` (including Cooking/Foraging/
  Herbalism) auto-loads correctly, the XP curve is monotonic and round-trips,
  `add_xp`/`leveled_up`/`meets_requirement` all behave.
- **InventoryManager** — add/remove/has_item math, unknown-item handling.
- **InventorySlotManager** — hotbar selection clamping/wrapping, and that
  slots stay in sync with InventoryManager's totals.
- **BuildGrid** — grid cell round-tripping, occupancy tracking, rotation
  snapping.
- **CropData / DecayStage** — stage-lookup-by-elapsed-time math (the thing
  every planted crop's lifecycle depends on).
- **Save/Load round-trip** — each manager's `get_save_data()` /
  `load_save_data()` is exercised in memory. This deliberately never calls
  `SaveManager.save_game()`/`load_game()`, so **running this suite never
  touches your real `user://savegame.json`**, in either option above.
- **Content integrity** — every seed has valid `crop_data`, every seed/tree/
  rock/fishing-spot's `skill_id` actually exists in `SkillManager`, and every
  resource node's `required_tool_type` matches a tool that actually exists.
  This is the category of bug that doesn't crash, it just quietly does
  nothing in-game — a typo'd skill_id, a seed with no crop assigned, a
  gathering node no tool can ever satisfy. Worth running any time a new
  skill, item, seed, or resource node gets added.

## Adding tests for new systems

All the actual test logic lives in `tests/test_suite.gd` — both run
options are thin front-ends over it, so you only ever need to edit one
file. Follow the existing pattern: one `_test_*` function per suite,
registered in `run()`, using `_check()` / `_check_eq()`. When Cooking and
Herbalism get real recipe/brewing logic (not just the skill definitions
that exist today), add a suite for them here the same way — that's the
whole point of keeping this around instead of testing by hand each time.
