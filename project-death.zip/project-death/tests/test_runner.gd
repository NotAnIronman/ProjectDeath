extends SceneTree

## CLI/headless front-end. Actual test logic lives in tests/test_suite.gd —
## see that file's header for what's covered.
##
## RUN IT (from the project root, headless, no editor window):
##   godot4 --headless --script res://tests/test_runner.gd
## (swap "godot4" for whatever your Godot 4 binary/alias is called — if
## "godot"/"godot4" isn't found, see tests/README.md for how to locate it,
## or just use tests/TestRunnerScene.tscn instead, no terminal required)
##
## Exits with code 0 if everything passed, 1 if anything failed — safe to
## wire into a pre-commit hook or CI job as new skills/systems land.

func _initialize() -> void:
	# Autoloads are already in the tree and _ready by the time _initialize()
	# runs (they're set up during engine bootstrap, before control passes to
	# a custom main-loop script). call_deferred is just an extra safety
	# margin so this runs at idle time rather than mid-bootstrap.
	call_deferred("_go")


func _go() -> void:
	var suite := TestSuite.new()
	var fail_count := suite.run()
	quit(1 if fail_count > 0 else 0)
