extends Node

## AUTOLOAD "LuckManager".
##
## A daily luck forecast (classic farming-sim staple) that actually
## biases outcomes rather than just being flavor text — every yield roll
## in the game (crop harvest, resource node gathering) should go through
## roll_yield() below instead of calling randi_range() directly, so a
## lucky day is something you FEEL in your basket at the end of it, not
## just a number in a corner of the screen.
##
## Deliberately does NOT touch fishing bite rate, shop deals, or anything
## else those systems don't exist yet — see the roadmap's "blocked"
## notes. This ships scoped to the two yield-roll call sites that exist
## today (Crop.harvest(), ResourceNode._harvest()) and is trivially
## reusable by any future one that also rolls a Vector2i range.

signal luck_changed(luck: int)

const MIN_LUCK: int = -2
const MAX_LUCK: int = 2

## Weighted so most days are near-neutral and the extremes are rare —
## same "mostly ordinary, occasionally special" shape every farming sim
## with a luck stat uses. Index i corresponds to luck value (i + MIN_LUCK).
const LUCK_WEIGHTS: Array[int] = [1, 3, 6, 3, 1]  ## -2, -1, 0, 1, 2

const LUCK_LABELS: Dictionary = {
	-2: "Very Unlucky",
	-1: "Unlucky",
	0: "Neutral",
	1: "Lucky",
	2: "Very Lucky",
}

## Chance PER POINT of luck magnitude that any single yield roll gets
## nudged by 1. So Very Lucky (luck=2) has a 2 * 12% = 24% chance any
## given roll comes back one higher than it otherwise would have; Neutral
## never nudges anything.
const NUDGE_CHANCE_PER_POINT: float = 0.12

var current_luck: int = 0


func _ready() -> void:
	DayNightManager.day_started.connect(_on_day_started)


func _on_day_started() -> void:
	current_luck = _roll_weighted_luck()
	luck_changed.emit(current_luck)
	NotificationManager.notify("Today's luck: %s." % get_luck_label(), "info")


func _roll_weighted_luck() -> int:
	var total_weight := 0
	for weight in LUCK_WEIGHTS:
		total_weight += weight
	var roll := randi_range(1, total_weight)
	var accumulated := 0
	for i in LUCK_WEIGHTS.size():
		accumulated += LUCK_WEIGHTS[i]
		if roll <= accumulated:
			return i + MIN_LUCK
	return 0  # unreachable given the weights sum correctly, but stay safe


func get_luck_label() -> String:
	return LUCK_LABELS.get(current_luck, "Neutral")


## Debug-only: forces today's luck directly, bypassing the daily roll —
## used by the debug menu's Time & Weather tab to test yield-roll bias at
## each extreme without waiting for the right day to roll naturally.
func debug_set_luck(luck: int) -> void:
	current_luck = clampi(luck, MIN_LUCK, MAX_LUCK)
	luck_changed.emit(current_luck)


## Drop-in replacement for `randi_range(min_qty, max_qty)` at any yield
## roll site. Result is always clamped to be >= 0 regardless of luck.
func roll_yield(min_qty: int, max_qty: int) -> int:
	var qty := randi_range(min_qty, max_qty)
	if current_luck != 0:
		var nudge_chance: float = NUDGE_CHANCE_PER_POINT * absi(current_luck)
		if randf() < nudge_chance:
			qty += 1 if current_luck > 0 else -1
	return maxi(0, qty)


func get_save_data() -> Dictionary:
	return {"current_luck": current_luck}


func load_save_data(data: Dictionary) -> void:
	current_luck = clampi(int(data.get("current_luck", 0)), MIN_LUCK, MAX_LUCK)
