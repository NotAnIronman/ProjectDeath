extends Node

## AUTOLOAD "QuestManager".
##
## Owns quest progress (active_quests: quest_id -> current step index,
## completed_quests: a set) and listens for every signal a QuestStepData
## step type can complete from — dialogue starting, a specific dialogue
## choice, a successful craft, a location trigger, a use-item-at-location
## interaction, or a generic reported custom action. See QuestStepData's
## own header for exactly what each step type checks.
##
## A quest never auto-starts on its own — see DialogueManager.choose(),
## which calls start_quest() when a dialogue choice's dict has a
## "starts_quest" key. Starting a quest is just another authored side
## effect of a dialogue choice, same building-block philosophy as
## everything else here, rather than a special "quest giver" concept.

signal quest_started(quest_id: String)
signal quest_step_advanced(quest_id: String, step_index: int)
signal quest_completed(quest_id: String)

const QUESTS_PATH := "res://resources/Quests/"

var quest_defs: Dictionary = {}       ## quest_id -> QuestData
var active_quests: Dictionary = {}    ## quest_id -> current_step_index (int)
var completed_quests: Dictionary = {} ## quest_id -> true

## quest_id -> float (DayNightManager.total_elapsed_days at the moment
## the CURRENT step became active) — only meaningful for WAIT_TIME steps,
## but recorded for every step regardless, since which step is "current"
## changes constantly and this needs to always reflect the right moment.
var _step_start_day: Dictionary = {}

var _quest_paths: Dictionary = {}     ## quest_id -> resource path, for duplicate-id error messages only


func _ready() -> void:
	_load_all_quest_defs()
	DialogueManager.dialogue_started.connect(_on_dialogue_started)
	DialogueManager.choice_selected.connect(_on_choice_selected)
	RecipeDatabase.item_crafted.connect(_on_item_crafted)
	DayNightManager.day_started.connect(_on_day_started)


## BUGFIX: was a flat, single-level scan. Now recursive — matches your
## new per-quest folder layout (Quests/<Region>/<Tier>/<QuestName>/...)
## and every other recursive-scan tool in this project (see
## scripts/editor_tools/build_item_catalog.gd for the pattern this
## mirrors). Duplicate quest ids are reported with BOTH file paths
## rather than silently letting the second one win — same reasoning as
## that tool.
func _load_all_quest_defs() -> void:
	_scan_for_quests(QUESTS_PATH)
	print("QuestManager loaded quests: ", quest_defs.keys())


func _scan_for_quests(path: String) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		if path == QUESTS_PATH:
			push_warning("QuestManager: no %s folder found." % QUESTS_PATH)
		return
	for sub_dir in dir.get_directories():
		_scan_for_quests(path.path_join(sub_dir))
	for file_name in dir.get_files():
		if not file_name.ends_with(".tres"):
			continue
		var resource_path := path.path_join(file_name)
		var quest := load(resource_path) as QuestData
		if quest == null or quest.id == "":
			continue
		if quest_defs.has(quest.id):
			push_error("QuestManager: duplicate quest id '%s' — %s and %s" % [quest.id, resource_path, _quest_paths.get(quest.id, "?")])
			continue
		quest_defs[quest.id] = quest
		_quest_paths[quest.id] = resource_path


## --- Starting / progressing / completing ---

## Called by SaveManager right after quest state is loaded from a save
## OR reset for a new game — NOT from _ready(), since QuestManager's own
## load_save_data() runs after _ready() and would silently overwrite
## anything an earlier auto-start attempt had done. start_quest() already
## no-ops for anything already active/completed, so this is safe to call
## on every load/new-game regardless of whether a given quest is new to
## this save or has been around for a while.
func check_auto_start_quests() -> void:
	for quest_id in quest_defs:
		if quest_defs[quest_id].auto_start:
			start_quest(quest_id)


func start_quest(quest_id: String) -> bool:
	if active_quests.has(quest_id) or completed_quests.has(quest_id):
		return false
	var quest: QuestData = quest_defs.get(quest_id)
	if quest == null:
		push_warning("QuestManager: no quest with id '%s'." % quest_id)
		return false
	if quest.required_quest_id != "" and not completed_quests.has(quest.required_quest_id):
		return false
	if quest.steps.is_empty():
		push_warning("QuestManager: quest '%s' has no steps, refusing to start." % quest_id)
		return false

	active_quests[quest_id] = 0
	_step_start_day[quest_id] = DayNightManager.total_elapsed_days
	quest_started.emit(quest_id)
	NotificationManager.notify("Quest started: %s" % quest.display_name, "info")

	# A quest started from its OWN dedicated opening line (e.g. Bob's
	# "bob_intro", tagged quest_id=bob_farming_intro) with a first step of
	# "talk to this same NPC" has that step already trivially satisfied —
	# we're mid that exact conversation right now, and TALK_TO_NPC only
	# ever completes on dialogue_started, which already fired before the
	# quest existed to react to it. Without this, the player would need
	# to walk away and re-initiate the exact same conversation just to
	# satisfy a step that's already obviously done.
	#
	# BUGFIX: this used to fire for ANY conversation with the right NPC,
	# not specifically one that's actually about this quest. Starting a
	# quest from an unrelated general conversation (a "Just talk" hub
	# option offering several different quests) would silently
	# auto-complete step 1 and set its flag — which then made that
	# quest's OWN intended opening content (its real entry point)
	# permanently ineligible, since the flag it just set was exactly what
	# gated that entry point. The player would skip content they were
	# meant to see, with no indication anything had been skipped.
	# is_current_line_an_entry_point_for_quest() requires the CURRENT
	# line to literally be an entry point authored FOR this quest — true
	# for Bob's own opening line, false for an unrelated general greeting
	# that merely offers to start it.
	var first_step: QuestStepData = quest.steps[0]
	if first_step.step_type == QuestStepData.StepType.TALK_TO_NPC \
	and DialogueManager.is_active() and first_step.target_id == DialogueManager.get_active_npc_id() \
	and DialogueManager.is_current_line_an_entry_point_for_quest(quest_id):
		_complete_current_step(quest_id)

	return true


func get_current_step(quest_id: String) -> QuestStepData:
	if not active_quests.has(quest_id):
		return null
	var quest: QuestData = quest_defs.get(quest_id)
	var step_index: int = active_quests[quest_id]
	if quest == null or step_index >= quest.steps.size():
		return null
	return quest.steps[step_index]


func _complete_current_step(quest_id: String) -> void:
	var step := get_current_step(quest_id)
	if step == null:
		return
	var quest: QuestData = quest_defs[quest_id]
	var step_index: int = active_quests[quest_id]

	for entry in step.items_removed:
		InventoryManager.remove_item(entry.get("item_id", ""), int(entry.get("quantity", 0)))
	for entry in step.items_given:
		InventoryManager.try_add_item(entry.get("item_id", ""), int(entry.get("quantity", 0)))
	if step.sets_flag != "":
		DialogueManager.set_flag(step.sets_flag)
	if step.cutscene_id != "":
		# Documented hook, not a fake implementation — see QuestStepData's
		# own comment on cutscene_id for why this stays a log line rather
		# than pretending a cutscene system exists.
		print("QuestManager: step wants cutscene '%s' — no cutscene system exists yet, skipping." % step.cutscene_id)

	var next_index := step_index + 1
	if next_index >= quest.steps.size():
		_complete_quest(quest_id)
	else:
		active_quests[quest_id] = next_index
		_step_start_day[quest_id] = DayNightManager.total_elapsed_days
		quest_step_advanced.emit(quest_id, next_index)
		# BUGFIX: this used to be silent — only quest START and quest
		# COMPLETE notified the player, every step in between only ever
		# showed up if you happened to open the journal. The quest LOG
		# page already updates live via the quest_step_advanced signal;
		# this just also surfaces it as a toast, same as everything else
		# that changes quest state.
		var next_step: QuestStepData = quest.steps[next_index]
		if next_step.log_description != "":
			NotificationManager.notify("Quest updated: %s" % next_step.log_description, "info")


func _complete_quest(quest_id: String) -> void:
	var quest: QuestData = quest_defs[quest_id]
	active_quests.erase(quest_id)
	completed_quests[quest_id] = true

	for skill_id in quest.reward_xp:
		SkillManager.add_xp(skill_id, int(quest.reward_xp[skill_id]))
	for entry in quest.reward_items:
		InventoryManager.try_add_item(entry.get("item_id", ""), int(entry.get("quantity", 0)))

	quest_completed.emit(quest_id)
	NotificationManager.notify("Quest complete: %s" % quest.display_name, "success")


## --- Completion hooks, one per QuestStepData.StepType ---

func _on_dialogue_started(npc_id: String) -> void:
	var quest_id := _find_active_quest_at(QuestStepData.StepType.TALK_TO_NPC, npc_id)
	if quest_id != "":
		_complete_current_step(quest_id)


func _on_choice_selected(npc_id: String, line_id: String, choice_index: int, choice_data: DialogueChoiceData) -> void:
	var quest_id := _find_active_quest_for_dialogue_choice(npc_id, line_id, choice_index)
	if quest_id != "":
		_complete_current_step(quest_id)
		return

	if choice_data.is_give_item:
		quest_id = _find_active_quest_at(QuestStepData.StepType.GIVE_ITEM_TO_NPC, npc_id)
		if quest_id == "":
			return
		var step := get_current_step(quest_id)
		if InventoryManager.has_item(step.item_id, step.item_amount):
			InventoryManager.remove_item(step.item_id, step.item_amount)
			_complete_current_step(quest_id)
		else:
			NotificationManager.notify("You don't have that to give.", "warning")


func _on_item_crafted(recipe_id: String, _output_item_id: String) -> void:
	var quest_id := _find_active_quest_at(QuestStepData.StepType.CRAFT_ITEM, recipe_id)
	if quest_id != "":
		_complete_current_step(quest_id)


## Call from QuestLocationMarker when the player enters its area.
func report_location_reached(location_id: String) -> void:
	var quest_id := _find_active_quest_at(QuestStepData.StepType.GO_TO_LOCATION, location_id)
	print("QuestManager: report_location_reached('%s') — matching active quest: '%s'" % [location_id, quest_id if quest_id != "" else "(none)"])
	if quest_id != "":
		_complete_current_step(quest_id)


## Call from QuestLocationMarker.interact() with whatever item is
## currently selected in the player's hotbar.
func report_item_used_at_location(location_id: String, item_id_used: String) -> void:
	var quest_id := _find_active_quest_at(QuestStepData.StepType.USE_ITEM_AT_LOCATION, location_id)
	if quest_id == "":
		return
	var step := get_current_step(quest_id)
	if step.item_id != item_id_used:
		return
	if step.item_amount > 0 and not InventoryManager.has_item(step.item_id, step.item_amount):
		return
	_complete_current_step(quest_id)


## The catch-all for "Do action U" — call from wherever makes sense once
## that action exists, same pattern as AchievementManager.report_custom_progress().
func report_custom_action(action_id: String) -> void:
	var quest_id := _find_active_quest_at(QuestStepData.StepType.CUSTOM_ACTION, action_id)
	if quest_id != "":
		_complete_current_step(quest_id)


## Lets a caller (QuestLocationMarker, for USE_ITEM_AT_LOCATION) check
## what an active step actually wants BEFORE attempting anything, so it
## can give specific feedback ("you need the Watering Can") instead of
## the completion check just silently failing with nothing shown.
func get_active_step_at(step_type: QuestStepData.StepType, target_id: String) -> QuestStepData:
	var quest_id := _find_active_quest_at(step_type, target_id)
	return get_current_step(quest_id) if quest_id != "" else null


func _find_active_quest_at(step_type: QuestStepData.StepType, target_id: String) -> String:
	for quest_id in active_quests:
		var step := get_current_step(quest_id)
		if step and step.step_type == step_type and step.target_id == target_id:
			return quest_id
	return ""


func _find_active_quest_for_dialogue_choice(npc_id: String, line_id: String, choice_index: int) -> String:
	for quest_id in active_quests:
		var step := get_current_step(quest_id)
		if step and step.step_type == QuestStepData.StepType.DIALOGUE_CHOICE \
		and step.target_id == npc_id and step.dialogue_line_id == line_id and step.choice_index == choice_index:
			return quest_id
	return ""


func _on_day_started() -> void:
	# .keys() snapshots the current quest ids before iterating — a quest
	# COMPLETING mid-loop (via _complete_current_step below) can remove
	# itself from active_quests, which would corrupt a live iteration
	# over the dictionary directly.
	for quest_id in active_quests.keys():
		var step := get_current_step(quest_id)
		if step == null or step.step_type != QuestStepData.StepType.WAIT_TIME:
			continue
		var started_day: float = _step_start_day.get(quest_id, DayNightManager.total_elapsed_days)
		if DayNightManager.total_elapsed_days - started_day >= step.wait_days:
			_complete_current_step(quest_id)


func get_save_data() -> Dictionary:
	return {
		"active_quests": active_quests,
		"completed_quests": completed_quests,
		"step_start_day": _step_start_day,
	}


func load_save_data(data: Dictionary) -> void:
	active_quests = data.get("active_quests", {})
	completed_quests = data.get("completed_quests", {})
	_step_start_day = data.get("step_start_day", {})
