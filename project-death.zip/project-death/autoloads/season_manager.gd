extends Node

## AUTOLOAD "SeasonManager".
##
## DayNightManager's own header comment names this exact gap: "Calendar
## page (Grim-oir) — still a placeholder; this system is the prerequisite
## for it, not the calendar itself. A calendar needs seasons/named days on
## top of this raw time system." This is that layer.
##
## Deliberately holds NO separate save state — season/day-of-season/year
## are all pure functions of DayNightManager.total_elapsed_days, which is
## already saved. That means there's nothing to get out of sync, nothing
## new for SaveManager to wire up, and loading an old save automatically
## produces the correct season with zero migration work.
##
## SCOPE: calendar math only, plus the one real gameplay hook available
## today — WeatherManager reads current_season() to vary rain odds. Actual
## per-season CONTENT (crops restricted to a season, festivals, NPC
## schedules) all needs systems that don't exist yet and stays off this
## file on purpose — see the roadmap doc's "blocked" notes for why those
## aren't picked up yet.

signal season_changed(season: Season, year: int)

enum Season { SPRING, SUMMER, FALL, WINTER }

## Kept short on purpose so a season change is something you'll actually
## see while testing live, not something you'd wait 11 real-world hours
## for at the default 24-real-minutes-per-day pace. Tune freely later —
## nothing else hardcodes this number, everything reads through the
## functions below.
const DAYS_PER_SEASON: int = 7

const SEASON_NAMES: Dictionary = {
	Season.SPRING: "Spring",
	Season.SUMMER: "Summer",
	Season.FALL: "Fall",
	Season.WINTER: "Winter",
}

var _last_known_season: Season = Season.SPRING


func _ready() -> void:
	DayNightManager.day_started.connect(_on_day_started)
	_last_known_season = current_season()


func _on_day_started() -> void:
	var season := current_season()
	if season != _last_known_season:
		_last_known_season = season
		season_changed.emit(season, current_year())
		NotificationManager.notify("%s has arrived." % SEASON_NAMES[season], "info")


## --- Pure calendar math — all derived from DayNightManager, nothing cached ---

func current_season() -> Season:
	var total_days: int = int(DayNightManager.total_elapsed_days)
	@warning_ignore("integer_division")  # truncation is the point — bucketing days into seasons
	return ((total_days / DAYS_PER_SEASON) % 4) as Season


## 1-indexed day within the current season (1..DAYS_PER_SEASON), matching
## how a player thinks about it ("Day 3 of Spring") rather than a raw
## 0-indexed offset.
func current_day_of_season() -> int:
	var total_days: int = int(DayNightManager.total_elapsed_days)
	return (total_days % DAYS_PER_SEASON) + 1


## 1-indexed year, so a fresh save starts on "Year 1" rather than "Year 0".
func current_year() -> int:
	var total_days: int = int(DayNightManager.total_elapsed_days)
	@warning_ignore("integer_division")  # truncation is the point — bucketing days into years
	return (total_days / (DAYS_PER_SEASON * 4)) + 1


func get_season_name(season: Season) -> String:
	return SEASON_NAMES.get(season, "Unknown")


func get_current_season_name() -> String:
	return get_season_name(current_season())


## e.g. "Spring, Day 3, Year 1" — the one-line summary both the Calendar
## page and anything else (a future quest deadline, a save-file listing)
## can just drop in without reimplementing the formatting.
func get_display_string() -> String:
	return "%s, Day %d, Year %d" % [get_current_season_name(), current_day_of_season(), current_year()]
