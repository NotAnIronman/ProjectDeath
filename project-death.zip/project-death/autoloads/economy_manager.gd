extends Node

## AUTOLOAD "EconomyManager".
##
## Owns the player's primary currency. Deliberately its own autoload
## rather than folded into InventoryManager — currency isn't an item (no
## item_id, no stack, no slot, no category), it's a single running number.
## Same one-clear-owner-per-concern division every other autoload in this
## project already follows.

signal currency_changed(new_total: int)

var currency: int = 666


func add_currency(amount: int) -> void:
	if amount <= 0:
		return
	currency += amount
	currency_changed.emit(currency)


## Returns true if the deduction succeeded (i.e. the player could afford
## it). Never goes negative — check has_currency() first if you need to
## know in advance rather than react after the fact.
func remove_currency(amount: int) -> bool:
	if amount <= 0 or currency < amount:
		return false
	currency -= amount
	currency_changed.emit(currency)
	return true


func has_currency(amount: int) -> bool:
	return currency >= amount


## --- Save/Load ---

func get_save_data() -> Dictionary:
	return {"currency": currency}


func load_save_data(data: Dictionary) -> void:
	currency = data.get("currency", 0)
	currency_changed.emit(currency)
