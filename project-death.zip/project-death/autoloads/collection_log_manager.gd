extends Node

## AUTOLOAD "CollectionLogManager".
##
## Tracks which items have EVER been collected at least once, across the
## whole game — this is what drives the Collection Log page's progressive
## reveal (silhouette + "???" before discovery, full details after).
##
## Deliberately does NOT need a separate authored entry per collectible —
## every item already in InventoryManager.item_defs IS a Collection Log
## entry automatically. "Revealed" info is whatever's already on that
## item's ItemData (display_name, description, icon, location_found, lore
## — see the new optional fields added to item_data.gd). Nothing to author
## twice; filling in an item's lore fields is the only content work this
## page needs.
##
## Same "lifetime, listen to item_added" pattern as AchievementManager's
## ITEM_COLLECTED_TOTAL — reuses the exact hook, just tracks presence
## rather than a running count.

signal item_discovered(item_id: String)

var discovered_items: Dictionary = {}  # item_id -> true


func _ready() -> void:
	InventoryManager.item_added.connect(_on_item_added)


func _on_item_added(item_id: String, _amount: int, _new_total: int) -> void:
	if discovered_items.has(item_id):
		return
	discovered_items[item_id] = true
	item_discovered.emit(item_id)


func is_discovered(item_id: String) -> bool:
	return discovered_items.has(item_id)


func get_discovered_count() -> int:
	return discovered_items.size()


## --- Save/Load ---

func get_save_data() -> Dictionary:
	return {"discovered_items": discovered_items.keys()}


func load_save_data(data: Dictionary) -> void:
	discovered_items.clear()
	for item_id in data.get("discovered_items", []):
		discovered_items[item_id] = true
