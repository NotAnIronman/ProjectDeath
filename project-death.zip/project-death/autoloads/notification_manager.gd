extends Node

## AUTOLOAD "NotificationManager".
##
## Generic "toast" notification broadcast — call notify() from ANYWHERE
## (any autoload, any gameplay script) to show a transient on-screen
## message, without the caller needing any UI reference at all. UILayer
## listens to notification_requested and owns the actual visual
## queue/stacking/fade — this autoload only owns "something happened,
## broadcast it," same split as AchievementManager owning completion
## logic while UILayer owns the popup that reacts to it.
##
## HOOKED UP TO (all confirmed safe against firing during save-file
## load-replay, not just live gameplay — see comments below):
##   - SkillManager.leveled_up — load_save_data() sets skill_xp directly,
##     never calls add_xp(), so no signal fires on load.
##   - DayNightManager.night_started/day_started — load_save_data() calls
##     _update_night_state(true), which explicitly suppresses the signal.
##   - CollectionLogManager.item_discovered — load_save_data() populates
##     discovered_items directly, never emits.
##
## DELIBERATELY NOT HOOKED UP: TerrainRestoration.patch_restored. That
## signal DOES fire once per patch during load_save_data()'s replay (by
## design — see its own header comment), so a save with many restored
## patches would spam a notification per patch immediately on load.
## Fixing that would mean changing TerrainRestoration's signal-emission
## behavior — working, tested code — just for this. Worth doing once you
## want ground-restoration notifications specifically; not bundled into
## this pass.
##
## ALSO NOT TOUCHED: the achievement completion popup already has its own
## working, confirmed-good popup (UILayer._show_achievement_popup) — left
## completely alone rather than migrated to this, no reason to risk
## something you already said looks great.

signal notification_requested(message: String, category: String)

## category is a loose hint for visual styling (color-coding) — "info"
## (default), "levelup", "world". Not validated/enforced, just a tag
## UILayer can key off; add more as needed without changing this file.
func notify(message: String, category: String = "info") -> void:
	notification_requested.emit(message, category)


func _ready() -> void:
	SkillManager.leveled_up.connect(_on_leveled_up)
	CollectionLogManager.item_discovered.connect(_on_item_discovered)
	call_deferred("_connect_deferred_signals")


func _connect_deferred_signals() -> void:
	DayNightManager.night_started.connect(func(): notify("Night falls.", "world"))
	DayNightManager.day_started.connect(func(): notify("A new day dawns.", "world"))


func _on_leveled_up(skill_id: String, new_level: int) -> void:
	notify("%s leveled up to %d!" % [skill_id.capitalize(), new_level], "levelup")


func _on_item_discovered(item_id: String) -> void:
	var def: ItemData = InventoryManager.item_defs.get(item_id)
	var display_name: String = def.display_name if def else item_id
	notify("Discovered: %s" % display_name, "info")
