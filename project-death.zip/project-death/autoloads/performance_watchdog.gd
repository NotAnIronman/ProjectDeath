extends Node

## AUTOLOAD "PerformanceWatchdog" — DEBUG DIAGNOSTIC, always on.
##
## Rather than guess at what's causing the reported lag spike when
## walking into new chunks, this watches every frame for a real stutter
## and logs exactly what the streaming systems were doing at that
## instant — correlate this output against WorldManager's/GrassManager's
## own "loaded cell X" print lines (already in the console) to see
## whether a spike lines up with a cell load, a grass MultiMesh
## activation, or something else (Terrain3D's own region collision
## generation is a strong candidate — that's engine-level, outside these
## scripts, and known to be a real cost in Terrain3D generally — but
## this gives real evidence either way instead of a guess).
##
## Cheap enough to leave on permanently — one float compare per frame,
## same "always-available debug tooling" reasoning as the rest of this
## project's debug systems.

const SPIKE_THRESHOLD_MS: float = 50.0  ## below ~20fps momentarily — the point a stutter is actually noticeable
const MIN_SECONDS_BETWEEN_LOGS: float = 0.25  ## avoid spamming the console if several frames in a row are slow

var _seconds_since_last_log: float = 999.0


func _process(delta: float) -> void:
	if not WorldManager.is_world_ready():
		return  # skip startup noise (asset loading, shader compilation, etc.) — not what's being investigated
	_seconds_since_last_log += delta
	var frame_ms := delta * 1000.0
	if frame_ms < SPIKE_THRESHOLD_MS or _seconds_since_last_log < MIN_SECONDS_BETWEEN_LOGS:
		return
	_seconds_since_last_log = 0.0

	var snapshot: Dictionary = WorldManager.get_debug_snapshot()
	print("PerformanceWatchdog: SPIKE %.1fms | cell %s | loaded cells %d | pending loads %d | streamed nodes %d | static mem %.1f MB | engine objects %d | draw calls %d" % [
		frame_ms,
		snapshot.get("current_cell", "?"),
		snapshot.get("loaded_count", -1),
		snapshot.get("pending_load_count", -1),
		snapshot.get("streamed_node_count", -1),
		Performance.get_monitor(Performance.MEMORY_STATIC) / 1048576.0,
		Performance.get_monitor(Performance.OBJECT_COUNT),
		Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME),
	])
