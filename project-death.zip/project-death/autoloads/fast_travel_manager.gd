extends Node

## AUTOLOAD "FastTravelManager".
##
## Physical in-world landmarks — place a Waypoint Beacon (a placeable
## item, like any other furniture), and it registers itself here
## automatically. See scripts/building/waypoint_beacon.gd for the
## placeable side of this.
##
## PERSISTENCE: this DOES save its own state (a past version of this
## file deliberately didn't, reasoning that a beacon's existence was
## already captured by the normal Placeable save contract — that
## reasoning was wrong in practice: this registry is only ever populated
## when a beacon's commit_placement() actually runs, which only happens
## when its cell is loaded. A beacon whose cell simply hadn't streamed
## in yet this session — including right after loading a save far from
## where it's placed — would be invisible to fast travel despite
## definitely existing, which defeats the entire point of a fast-travel
## system for a large streamed world. Saving the registry directly means
## every beacon you've ever placed is known and travel-able from the
## moment a save loads, regardless of what's currently streamed in.
## Loaded beacons still re-register on commit_placement() and simply
## overwrite with fresh data — harmless, self-correcting, never a
## conflict between the two sources.
##
## Also owns the safe-teleport logic used by beacon travel — see
## travel_to() below, which spawns above the target and lets real
## gravity/collision settle the player rather than trusting an
## instantaneous raycast against a destination that may not have
## finished streaming its collision in yet.

signal beacons_changed()

## How far in front of a beacon (along its own local forward) the player
## lands, so they spawn beside it rather than inside/on top of it.
const SPAWN_OFFSET_DISTANCE: float = 1.75

## persistent_id (from Placeable) -> {"name": String, "position": Vector3, "rotation_y": float}
var beacons: Dictionary = {}


func register_beacon(persistent_id: String, beacon_name: String, position: Vector3, rotation_y: float) -> void:
	beacons[persistent_id] = {"name": beacon_name, "position": position, "rotation_y": rotation_y}
	beacons_changed.emit()


## BUGFIX (see header): only ever called from WaypointBeacon.pick_up(),
## meaning genuine player pickup — NOT from a cell merely streaming out.
func unregister_beacon(persistent_id: String) -> void:
	if beacons.erase(persistent_id):
		beacons_changed.emit()


func rename_beacon(persistent_id: String, new_name: String) -> void:
	if not beacons.has(persistent_id):
		return
	var trimmed := new_name.strip_edges()
	if trimmed == "":
		return
	beacons[persistent_id]["name"] = trimmed
	beacons_changed.emit()


## Returns all beacons EXCEPT the one the player is currently at (if
## `exclude_id` is passed) — travelling from a beacon to itself isn't a
## real option, so the Map page doesn't need to show it as one.
func get_travel_targets(exclude_id: String = "") -> Array:
	var result: Array = []
	for persistent_id in beacons:
		if persistent_id != exclude_id:
			result.append(persistent_id)
	result.sort_custom(func(a, b): return beacons[a]["name"] < beacons[b]["name"])
	return result


## BUGFIX: this used to raycast for ground height IMMEDIATELY on
## arrival. For a nearby/already-loaded destination that's fine, but for
## a far-away beacon whose region hadn't streamed its collision in yet,
## the raycast could miss entirely (or hit stale geometry), dropping the
## player through the world — exactly why spam-clicking travel "worked":
## each click re-tried a little later, after more of the destination had
## a chance to load. Instead of trying to time that precisely, spawn
## safely ABOVE the beacon's own recorded ground height (trustworthy —
## the beacon is physically standing on real ground where it was placed)
## and let normal gravity + collision settle the player once things
## finish streaming in, same as literally anywhere else falling works.
## No timing assumptions required either way.
const SAFE_DROP_HEIGHT: float = 4.0

func travel_to(persistent_id: String) -> bool:
	if not beacons.has(persistent_id):
		return false
	var player := WorldManager.get_player()
	if player == null:
		return false

	var entry: Dictionary = beacons[persistent_id]
	var beacon_position: Vector3 = entry["position"]
	var rotation_y: float = entry.get("rotation_y", 0.0)

	# Land just in front of the beacon along ITS OWN facing (local +Z,
	# rotated with it) rather than on top of it — rotating a placed
	# beacon in build mode now directly controls which direction the
	# player lands facing, which is the whole point of exposing this.
	var forward: Vector3 = Basis(Vector3.UP, rotation_y) * Vector3(0, 0, 1)
	var target_xz := beacon_position + forward * SPAWN_OFFSET_DISTANCE

	if player is CharacterBody3D:
		(player as CharacterBody3D).velocity = Vector3.ZERO  # stop any residual fall/jump velocity carrying over into the new location
	player.global_position = Vector3(target_xz.x, beacon_position.y + SAFE_DROP_HEIGHT, target_xz.z)

	NotificationManager.notify("Traveled to '%s'." % entry["name"], "info")
	return true


func get_save_data() -> Dictionary:
	var serialized: Dictionary = {}
	for persistent_id in beacons:
		var entry: Dictionary = beacons[persistent_id]
		var pos: Vector3 = entry["position"]
		serialized[persistent_id] = {
			"name": entry["name"],
			"rotation_y": entry.get("rotation_y", 0.0),
			"x": pos.x, "y": pos.y, "z": pos.z,
		}
	return {"beacons": serialized}


func load_save_data(data: Dictionary) -> void:
	beacons.clear()
	var serialized: Dictionary = data.get("beacons", {})
	for persistent_id in serialized:
		var entry: Dictionary = serialized[persistent_id]
		beacons[persistent_id] = {
			"name": entry.get("name", "Beacon"),
			"position": Vector3(entry.get("x", 0.0), entry.get("y", 0.0), entry.get("z", 0.0)),
			"rotation_y": entry.get("rotation_y", 0.0),
		}
	beacons_changed.emit()
