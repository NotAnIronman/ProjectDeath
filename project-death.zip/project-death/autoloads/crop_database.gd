extends Node

## AUTOLOAD — register in Project Settings > Globals, name it "CropDatabase".
## Loads every CropData .tres from res://resources/Farming/crops/ and indexes
## it by id, so SaveManager (and anything else) can look up a CropData from a
## saved string id when restoring state. Same load-all-from-folder pattern as
## SkillManager/InventoryManager.

var crop_defs: Dictionary = {}

const CROPS_PATH := "res://resources/Farming/crops/"


func _ready() -> void:
	_load_all_crop_defs()
	print("CropDatabase loaded crops: ", crop_defs.keys())


func _load_all_crop_defs() -> void:
	var dir := DirAccess.open(CROPS_PATH)
	if dir == null:
		push_warning("CropDatabase: no resources/crops/ folder found.")
		return

	dir.list_dir_begin()
	var file_name := dir.get_next()
	while file_name != "":
		if file_name.ends_with(".tres"):
			var crop: CropData = load(CROPS_PATH + file_name)
			if crop and crop.id != "":
				crop_defs[crop.id] = crop
		file_name = dir.get_next()
	dir.list_dir_end()


func get_crop(id: String) -> CropData:
	return crop_defs.get(id, null)
