extends Node

## AUTOLOAD "WeatherManager".
##
## DayNightManager's own header comment explicitly calls out weather as a
## clean layer meant to sit on top of it ("Weather interactions — no
## weather system exists yet") — this is that layer. Rolls one of a small
## set of weather types each time a new day starts, and (for RAIN) skips
## the player having to water every plot that morning — a classic, well-
## understood farming-sim payoff: rain matters because it visibly saves
## you time, not because of any particle effects.
##
## SCOPE: deliberately just "does it rain today, and does that auto-water
## crops" — no wind, no storms, no snow. Rain odds vary by season (see
## RAIN_CHANCE_BY_SEASON below) now that SeasonManager exists.

signal weather_changed(weather: WeatherType)

enum WeatherType { CLEAR, RAIN }

## Rain odds by season. SeasonManager didn't exist when this system
## shipped, so it launched with one flat chance for every day — now that
## it does, this is the natural place to read it. Winter stays mostly
## clear (no snow mechanic exists to make winter precipitation meaningful
## yet — see the roadmap's "blocked" notes), not because winter rain
## would be wrong, but because "it rains" with no visual distinction from
## any other rain would be a confusing, unearned reskin.
const RAIN_CHANCE_BY_SEASON: Dictionary = {
	SeasonManager.Season.SPRING: 0.4,
	SeasonManager.Season.SUMMER: 0.15,
	SeasonManager.Season.FALL: 0.3,
	SeasonManager.Season.WINTER: 0.05,
}

var current_weather: WeatherType = WeatherType.CLEAR


func _ready() -> void:
	DayNightManager.day_started.connect(_on_day_started)


func _on_day_started() -> void:
	var rain_chance: float = RAIN_CHANCE_BY_SEASON.get(SeasonManager.current_season(), 0.3)
	current_weather = WeatherType.RAIN if randf() < rain_chance else WeatherType.CLEAR
	weather_changed.emit(current_weather)

	if current_weather == WeatherType.RAIN:
		_water_all_loaded_crops()
		NotificationManager.notify("It's raining today — your crops are watered.", "info")


func is_raining() -> bool:
	return current_weather == WeatherType.RAIN


## Debug-only: forces today's weather directly, bypassing the daily roll —
## used by the debug menu's Time & Weather tab to test rain's auto-water
## behavior on demand instead of waiting for a lucky roll.
func debug_set_weather(weather: WeatherType) -> void:
	current_weather = weather
	weather_changed.emit(current_weather)
	if current_weather == WeatherType.RAIN:
		_water_all_loaded_crops()


## Waters every FarmPlot currently in the scene tree, same "farm_plots"
## group FarmPlot.water(radius) already uses for its own sprinkler-style
## radius watering — reusing that group rather than introducing a second
## way to find plots.
##
## SCOPE NOTE: only affects currently LOADED cells. A plot in an unloaded
## cell simply won't have gotten today's rain until the player streams
## back near it — no worse than before this system existed (nothing
## watered it either way), and not worth the complexity of patching
## WorldManager's cached-but-unloaded cell state for a once-a-day
## convenience feature. Revisit only if this turns out to feel bad in
## actual play, not preemptively.
func _water_all_loaded_crops() -> void:
	var watered_count := 0
	for plot in get_tree().get_nodes_in_group("farm_plots"):
		if plot.has_method("water"):
			plot.water()
			watered_count += 1
	print("WeatherManager: rain watered %d loaded farm plot(s)." % watered_count)


func get_save_data() -> Dictionary:
	return {"current_weather": int(current_weather)}


func load_save_data(data: Dictionary) -> void:
	var raw: int = int(data.get("current_weather", WeatherType.CLEAR))
	current_weather = clampi(raw, WeatherType.CLEAR, WeatherType.RAIN) as WeatherType
