extends Node

## AUTOLOAD — register in Project Settings > Globals, name it "RecipeDatabase".
## Loads every RecipeData .tres from res://resources/Crafting/recipes/ and
## indexes it by id. Same load-all-from-folder pattern as CropDatabase/
## SkillManager/InventoryManager.
##
## Also owns the actual crafting ACTION (can_craft/craft), not just the
## data lookup — there's no separate "CraftingManager" autoload, since
## the logic is small enough (check inputs available, consume, grant
## output) that a second autoload just to hold two functions would be
## friction without benefit. If crafting grows real complexity later
## (timed crafting, station requirements, queueing), that's the moment to
## split it out — not before.

signal item_crafted(recipe_id: String, output_item_id: String)  ## emitted on successful craft — lets QuestManager (or anything else) hook a CRAFT_ITEM quest step without this file needing to know about quests

var recipe_defs: Dictionary = {}

const RECIPES_PATH := "res://resources/Crafting/recipes/"


func _ready() -> void:
	_load_all_recipe_defs()
	print("RecipeDatabase loaded recipes: ", recipe_defs.keys())


func _load_all_recipe_defs() -> void:
	var dir := DirAccess.open(RECIPES_PATH)
	if dir == null:
		push_warning("RecipeDatabase: no resources/Crafting/recipes/ folder found.")
		return

	dir.list_dir_begin()
	var file_name := dir.get_next()
	while file_name != "":
		if file_name.ends_with(".tres"):
			var recipe: RecipeData = load(RECIPES_PATH + file_name)
			if recipe and recipe.id != "":
				recipe_defs[recipe.id] = recipe
		file_name = dir.get_next()
	dir.list_dir_end()


func get_recipe(id: String) -> RecipeData:
	return recipe_defs.get(id, null)


## All recipes, alphabetical by display name — the only ordering the
## Recipes page needs for v1 (no categories/tabs within crafting yet;
## add that once there are enough recipes for a flat list to feel
## cluttered, not preemptively).
func get_all_recipes() -> Array[RecipeData]:
	var result: Array[RecipeData] = []
	for recipe_id in recipe_defs:
		result.append(recipe_defs[recipe_id])
	result.sort_custom(func(a: RecipeData, b: RecipeData) -> bool:
		return a.display_name < b.display_name
	)
	return result


## Whether the player currently holds every ingredient this recipe needs
## AND meets its skill requirement (if any). See is_unlocked()/can_craft()
## below for checking these two conditions separately — a UI wants to
## show "locked" differently from "missing ingredients."
func can_craft(recipe: RecipeData) -> bool:
	if recipe == null:
		return false
	if not is_unlocked(recipe):
		return false
	for entry in recipe.inputs:
		var item_id: String = entry.get("item_id", "")
		var quantity: int = int(entry.get("quantity", 0))
		if not InventoryManager.has_item(item_id, quantity):
			return false
	return true


## Whether the player's skill level is high enough to craft this recipe
## at all, independent of whether they currently have the ingredients.
## A recipe with an empty required_skill_id is always unlocked — that's
## every recipe shipped before this check existed, so adding this never
## silently re-locks existing content.
func is_unlocked(recipe: RecipeData) -> bool:
	if recipe == null:
		return false
	if recipe.required_skill_id == "":
		return true
	return SkillManager.meets_requirement(recipe.required_skill_id, recipe.required_level)


## Attempts to craft one instance of `recipe_id`. Returns true on success.
## Atomic in the sense that matters to the player: ingredients are only
## ever consumed if the craft actually succeeds — checked BEFORE removing
## anything, same "verify first, then mutate" shape as TradingPost.buy().
func craft(recipe_id: String) -> bool:
	var recipe := get_recipe(recipe_id)
	if recipe == null or not can_craft(recipe):
		return false

	if InventorySlotManager.get_add_capacity(recipe.output_item_id) < recipe.output_quantity:
		return false  # inventory's full — don't consume ingredients for a craft that can't deliver its output

	for entry in recipe.inputs:
		InventoryManager.remove_item(entry.get("item_id", ""), int(entry.get("quantity", 0)))

	var accepted := InventoryManager.try_add_item(recipe.output_item_id, recipe.output_quantity)
	if accepted != recipe.output_quantity:
		# Shouldn't happen given the capacity check above (nothing else
		# consumes slot space between the check and here on the main
		# thread), but stay honest in the logs if it ever does rather
		# than silently under-delivering.
		push_warning("RecipeDatabase: '%s' output only partially fit (%d/%d) after consuming inputs." % [recipe_id, accepted, recipe.output_quantity])

	print("Crafted: %s" % recipe_id)
	item_crafted.emit(recipe_id, recipe.output_item_id)
	return true
