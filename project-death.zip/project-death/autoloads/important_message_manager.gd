extends Node

## AUTOLOAD "ImportantMessageManager".
##
## For messages that matter more than a toast and NEED to actually be
## seen — the player must confirm before continuing, same as a real
## conversation blocks movement. Deliberately NOT built on top of
## DialogueManager: an important message isn't a conversation with an
## NPC, so it shouldn't touch flags, quest hooks, or any of that state —
## it's visually consistent with dialogue (same panel styling/position
## convention), not mechanically the same system.
##
## Queue-based — call show_message() as many times as you want, even
## while one is already showing; they display one at a time in order
## rather than overwriting or getting dropped.

signal message_shown(text: String)
signal message_dismissed()

var _queue: Array[String] = []
var _current: String = ""


func show_message(text: String) -> void:
	if text == "":
		return
	_queue.append(text)
	if _current == "":
		_advance()


func is_active() -> bool:
	return _current != ""


func get_current_message() -> String:
	return _current


## Called by the UI when the player confirms/dismisses the current message.
func confirm() -> void:
	if _current == "":
		return
	_current = ""
	message_dismissed.emit()
	_advance()


func _advance() -> void:
	if _queue.is_empty():
		return
	_current = _queue.pop_front()
	message_shown.emit(_current)
