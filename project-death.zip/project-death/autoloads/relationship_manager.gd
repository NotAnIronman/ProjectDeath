extends Node

## AUTOLOAD "RelationshipManager".
##
## A per-NPC integer score, moved by DialogueChoiceData.relationship_delta
## the moment a choice with a nonzero delta is picked (see DialogueManager.
## choose()). Deliberately just a score, not a whole standalone system —
## the actual DEPTH of relationships (gift preferences, birthdays, events
## at certain thresholds) is real future content this hooks into cleanly
## rather than tries to fake here; see get_tier() for the one piece of
## interpretation this file does own.

signal relationship_changed(npc_id: String, new_score: int)

const TIER_THRESHOLDS := [
	[-999999, -20, "Hostile"],
	[-19, -1, "Cold"],
	[0, 19, "Neutral"],
	[20, 49, "Friendly"],
	[50, 99, "Close"],
	[100, 999999, "Beloved"],
]

var scores: Dictionary = {}  ## npc_id -> int


func get_score(npc_id: String) -> int:
	return scores.get(npc_id, 0)


func add(npc_id: String, delta: int) -> void:
	if npc_id == "" or delta == 0:
		return
	scores[npc_id] = get_score(npc_id) + delta
	relationship_changed.emit(npc_id, scores[npc_id])


func get_tier(npc_id: String) -> String:
	var score := get_score(npc_id)
	for entry in TIER_THRESHOLDS:
		if score >= entry[0] and score <= entry[1]:
			return entry[2]
	return "Neutral"


func get_save_data() -> Dictionary:
	return {"scores": scores}


func load_save_data(data: Dictionary) -> void:
	scores = data.get("scores", {})
