extends Node

## AUTOLOAD "DialogueManager".
##
## Drives one conversation at a time (start_dialogue -> a sequence of
## _show_line/choose calls -> end_dialogue). Owns `flags`, a simple
## String->true set that's the entire "based on certain factors"
## mechanism this whole system leans on: QuestStepData.sets_flag and
## DialogueLine choice dicts set flags, DialogueLine.required_flag/
## required_flag_absent and DialogueTreeData.entry_points read them. No
## bespoke condition types needed per situation — everything reduces to
## "is this flag set."
##
## UI-agnostic on purpose: this owns conversation STATE and LOGIC only.
## scripts/ui/dialogue_panel.gd listens to the signals below and is the
## only thing that knows how a line/choice actually gets drawn — swap
## the UI entirely (a different panel style, a fully voiced cutscene
## presentation, whatever) without touching this file.

signal dialogue_started(npc_id: String)
signal dialogue_line_shown(npc_id: String, line: DialogueLine)
signal choice_selected(npc_id: String, line_id: String, choice_index: int, choice_data: DialogueChoiceData)
signal dialogue_ended(npc_id: String)

const TREES_PATH := "res://resources/Quests/"

var trees: Dictionary = {}  ## npc_id -> DialogueTreeData
var flags: Dictionary = {}  ## String -> true (absence = not set)

## "npc_id|line_id|choice_index" -> true, once a choice has ever been
## picked. DialoguePanel reads this to grey out choices already taken —
## see choice #1 in the design discussion this came from. Deliberately
## "picked at least once", not a deeper "every reachable line down this
## path has also been fully exhausted" check — that's a real, harder
## graph-reachability question that's a reasonable future refinement,
## not needed to deliver most of the value here.
var visited_choices: Dictionary = {}

var _active_npc_id: String = ""
var _active_line: DialogueLine = null
var _tree_paths: Dictionary = {}  ## npc_id -> resource path, for duplicate-id error messages only


func _ready() -> void:
	_load_all_trees()


## BUGFIX: was a flat, single-level scan of a dedicated Dialogue/trees/
## folder. Now recursive under the same Quests/ root QuestManager scans —
## dialogue trees live INSIDE each quest's own folder now (see your new
## per-quest layout), not off in a parallel folder tree you'd have to
## keep in sync by hand. Filename/exact subfolder placement inside a
## quest folder doesn't matter — only that it's a DialogueTreeData
## resource somewhere under Quests/.
func _load_all_trees() -> void:
	_scan_for_trees(TREES_PATH)
	print("DialogueManager loaded dialogue trees: ", trees.keys())


func _scan_for_trees(path: String) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		if path == TREES_PATH:
			push_warning("DialogueManager: no %s folder found." % TREES_PATH)
		return
	for sub_dir in dir.get_directories():
		_scan_for_trees(path.path_join(sub_dir))
	for file_name in dir.get_files():
		if not file_name.ends_with(".tres"):
			continue
		var resource_path := path.path_join(file_name)
		var tree := load(resource_path) as DialogueTreeData
		if tree == null or tree.npc_id == "":
			continue
		# BUGFIX (architectural, not a patch): this used to be an error
		# on a second tree sharing an npc_id — meaning an NPC involved in
		# multiple quests was forced into either one ever-growing shared
		# file, or a manual "attach to existing" workaround. Now MERGES:
		# each quest keeps its own self-contained dialogue.tres (easy to
		# find, easy to edit in isolation), and every tree sharing an
		# npc_id contributes its lines/entry_points to that NPC at
		# runtime. Line ids need to stay unique ACROSS a shared NPC's
		# trees for this to work cleanly — the "QuestName_LineName"
		# convention already in use naturally avoids collisions between
		# different quests' content.
		if trees.has(tree.npc_id):
			var existing: DialogueTreeData = trees[tree.npc_id]
			for line in tree.lines:
				if existing.get_line(line.id) != null:
					push_warning("DialogueManager: line id '%s' exists in both %s and %s — the one from %s wins, the other is unreachable. Line ids need to stay unique across every tree sharing an npc_id." % [line.id, _tree_paths.get(tree.npc_id, "?"), resource_path, _tree_paths.get(tree.npc_id, "?")])
					continue
				existing.lines.append(line)
			for entry in tree.entry_points:
				existing.entry_points.append(entry)
			continue
		trees[tree.npc_id] = tree
		_tree_paths[tree.npc_id] = resource_path


func has_tree(npc_id: String) -> bool:
	return trees.has(npc_id)


func set_flag(flag: String, value: bool = true) -> void:
	if flag == "":
		return
	if value:
		flags[flag] = true
	else:
		flags.erase(flag)


func has_flag(flag: String) -> bool:
	return flag == "" or flags.get(flag, false)


func _flag_requirements_met(required_flag: String, required_flag_absent: String) -> bool:
	if required_flag != "" and not flags.get(required_flag, false):
		return false
	if required_flag_absent != "" and flags.get(required_flag_absent, false):
		return false
	return true


## Returns true on success. False (with a warning) if this npc_id has no
## dialogue tree at all, has one but nothing in it is currently eligible
## to start from (an authoring gap — always leave one unconditional
## catch-all entry point per NPC to prevent this), OR a conversation is
## already active — a second start_dialogue() call while one's in
## progress used to silently stomp the first (whoever called it last
## effectively hijacked the conversation), which is exactly the kind of
## thing "multiple people talking at once" surfaces. This doesn't yet
## solve NPC-to-NPC ambient conversations not involving the player at
## all — that's a genuinely separate system (its own display, doesn't
## route through this single-slot state) — but it does guarantee two
## THINGS can't corrupt each other trying to talk to the player at once.
func start_dialogue(npc_id: String) -> bool:
	if is_active():
		push_warning("DialogueManager: tried to start a conversation with '%s' while already talking to '%s'." % [npc_id, _active_npc_id])
		return false

	var tree: DialogueTreeData = trees.get(npc_id)
	if tree == null:
		push_warning("DialogueManager: no dialogue tree for npc_id '%s'." % npc_id)
		return false

	# Group every ELIGIBLE entry by which quest it belongs to (entry.
	# quest_id — "" means general/not quest-specific), keeping only the
	# most specific eligible one PER quest. This is what makes multiple
	# simultaneously-relevant quests for the same NPC actually reachable
	# — the old "single overall winner" approach meant two independently
	# eligible quests could never both be reachable; whichever tree
	# happened to scan first would permanently shadow the other for the
	# whole session, which is exactly what was happening with Example
	# Quest always winning over The Last Sprout.
	var best_by_quest: Dictionary = {}  ## quest_id ("" = general) -> {"start_line_id": String, "specificity": int}
	for entry in tree.entry_points:
		if not _flag_requirements_met(entry.get("required_flag", ""), entry.get("required_flag_absent", "")):
			continue
		var candidate_id: String = entry.get("start_line_id", "")
		var candidate_line := tree.get_line(candidate_id)
		if candidate_line == null:
			continue
		if not _flag_requirements_met(candidate_line.required_flag, candidate_line.required_flag_absent):
			continue

		var quest_key: String = entry.get("quest_id", "")
		if quest_key != "" and not _quest_is_relevant_to_npc(quest_key, npc_id):
			continue  # tagged for a quest that isn't currently asking the player to talk to THIS npc — not a real topic right now

		var specificity := 0
		if entry.get("required_flag", "") != "":
			specificity += 1
		if entry.get("required_flag_absent", "") != "":
			specificity += 1
		if candidate_line.required_flag != "":
			specificity += 1
		if candidate_line.required_flag_absent != "":
			specificity += 1

		if not best_by_quest.has(quest_key) or specificity > best_by_quest[quest_key]["specificity"]:
			best_by_quest[quest_key] = {"start_line_id": candidate_id, "specificity": specificity}

	if best_by_quest.is_empty():
		push_warning("DialogueManager: no eligible entry point for npc_id '%s' — add an unconditional catch-all entry." % npc_id)
		return false

	_active_npc_id = npc_id
	dialogue_started.emit(npc_id)

	if best_by_quest.size() == 1:
		# Only one topic relevant right now — behave exactly as before,
		# no menu needed for the common case.
		_show_line(best_by_quest.values()[0]["start_line_id"])
	else:
		_show_hub_menu(best_by_quest)
	return true


## True if `quest_id` is currently active AND its CURRENT step is
## specifically asking the player to interact with THIS npc right now —
## not just "this NPC appears somewhere in the quest", which would make
## stale/future topics show up before they're relevant.
func _quest_is_relevant_to_npc(quest_id: String, npc_id: String) -> bool:
	if not QuestManager.active_quests.has(quest_id):
		return false
	var step := QuestManager.get_current_step(quest_id)
	if step == null or step.target_id != npc_id:
		return false
	return step.step_type == QuestStepData.StepType.TALK_TO_NPC \
		or step.step_type == QuestStepData.StepType.DIALOGUE_CHOICE \
		or step.step_type == QuestStepData.StepType.GIVE_ITEM_TO_NPC


## Synthesizes a DialogueLine on the fly (deliberately NOT added to
## tree.lines — it's pure runtime UI, nothing to save) offering one
## choice per relevant topic. Each choice's next_line_id points at a
## REAL authored line, so choose() needs zero special-casing — it just
## looks up tree.lines exactly like any other choice.
func _show_hub_menu(best_by_quest: Dictionary) -> void:
	var hub_line := DialogueLine.new()
	hub_line.id = "__hub__"
	hub_line.text = "What would you like to talk about?"

	for quest_key in best_by_quest:
		var choice := DialogueChoiceData.new()
		if quest_key == "":
			choice.text = "Just talk"
		else:
			var quest: QuestData = QuestManager.quest_defs.get(quest_key)
			choice.text = "Talk about %s" % (quest.display_name if quest else quest_key)
		choice.next_line_id = best_by_quest[quest_key]["start_line_id"]
		hub_line.choices.append(choice)

	var nevermind := DialogueChoiceData.new()
	nevermind.text = "Nevermind"
	nevermind.next_line_id = ""
	hub_line.choices.append(nevermind)

	_active_line = hub_line
	dialogue_line_shown.emit(_active_npc_id, hub_line)


func _show_line(line_id: String) -> void:
	var tree: DialogueTreeData = trees.get(_active_npc_id)
	var line: DialogueLine = tree.get_line(line_id) if tree else null
	if line == null:
		end_dialogue()
		return
	if not _flag_requirements_met(line.required_flag, line.required_flag_absent):
		# An authored branch pointed here that's no longer eligible given
		# current flags — end gracefully rather than show something that
		# contradicts the player's actual progress.
		end_dialogue()
		return
	_active_line = line
	dialogue_line_shown.emit(_active_npc_id, line)


## Call from the UI when the player picks choice index `choice_index` on
## the currently-shown line.
func choose(choice_index: int) -> void:
	if _active_line == null or choice_index < 0 or choice_index >= _active_line.choices.size():
		return
	var choice: DialogueChoiceData = _active_line.choices[choice_index]

	# Defense in depth — DialoguePanel already disables a skill-gated
	# choice's button, but re-checking here means choose() is safe to
	# call from anywhere (a future automated test, a different UI) without
	# relying on whichever caller remembered to check first.
	if choice.required_skill_id != "" and not SkillManager.meets_requirement(choice.required_skill_id, choice.required_skill_level):
		return

	visited_choices["%s|%s|%d" % [_active_npc_id, _active_line.id, choice_index]] = true

	choice_selected.emit(_active_npc_id, _active_line.id, choice_index, choice)

	if choice.sets_flag != "":
		set_flag(choice.sets_flag)
	if choice.starts_quest != "":
		QuestManager.start_quest(choice.starts_quest)
	if choice.relationship_delta != 0:
		RelationshipManager.add(_active_npc_id, choice.relationship_delta)

	if choice.next_line_id == "":
		end_dialogue()
	else:
		_show_line(choice.next_line_id)


func is_choice_visited(npc_id: String, line_id: String, choice_index: int) -> bool:
	return visited_choices.has("%s|%s|%d" % [npc_id, line_id, choice_index])


## Call from the UI for a line with NO choices (a plain "Continue" prompt).
func advance() -> void:
	if _active_line == null or not _active_line.choices.is_empty():
		return
	if _active_line.next_line_id == "":
		end_dialogue()
	else:
		_show_line(_active_line.next_line_id)


func end_dialogue() -> void:
	if _active_npc_id == "":
		return
	var npc_id := _active_npc_id
	_active_npc_id = ""
	_active_line = null
	dialogue_ended.emit(npc_id)


func is_active() -> bool:
	return _active_npc_id != ""


func get_active_npc_id() -> String:
	return _active_npc_id


## True if the CURRENTLY SHOWING line is literally the entry point
## authored FOR this specific quest_id (e.g. Bob's own "bob_intro" line,
## tagged quest_id=bob_farming_intro) — as opposed to some unrelated/
## general conversation that merely happens to also start this quest via
## a choice's starts_quest field (e.g. a "Just talk" default greeting
## offering several different quests). QuestManager uses this to decide
## whether "the player is already mid-conversation with the right NPC"
## also means "mid the RIGHT conversation" — those are different things
## once general/hub-menu conversations exist, and conflating them used
## to silently skip a quest's own intended opening content whenever it
## was accepted from an unrelated general chat instead of its own line.
func is_current_line_an_entry_point_for_quest(quest_id: String) -> bool:
	if not is_active() or _active_line == null:
		return false
	var tree: DialogueTreeData = trees.get(_active_npc_id)
	if tree == null:
		return false
	for entry in tree.entry_points:
		if entry.get("quest_id", "") == quest_id and entry.get("start_line_id", "") == _active_line.id:
			return true
	return false


func get_save_data() -> Dictionary:
	return {"flags": flags, "visited_choices": visited_choices}


func load_save_data(data: Dictionary) -> void:
	flags = data.get("flags", {})
	visited_choices = data.get("visited_choices", {})
