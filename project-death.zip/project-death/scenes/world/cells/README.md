# World cells

WorldManager (autoloads/world_manager.gd) streams these in/out based on
player distance. The terrain itself is NOT split this way — Terrain3D
stays one continuous node in World.tscn, always loaded. This folder holds
hand-placed content: buildings, decor, resource nodes, FarmPlots, NPCs —
anything you'd otherwise be putting directly into World.tscn.

## DO NOT hand-edit files in this folder

You can't see neighboring content while a cell is open in isolation, which
makes spotting boundary issues (an object straddling a cell edge, spacing
that looks fine alone but wrong next to its neighbor) basically impossible.
Instead:

## The actual workflow

1. In World.tscn, find (or create) a `Node3D` named **`WorldContent`** with
   `scripts/systems/world_content_staging.gd` attached.
2. Place and edit ALL cell-able content as children of `WorldContent` —
   same as placing anything directly into the world. Because it's all one
   normal scene, you see everything at once: full spatial context, no
   boundaries, easy to catch something that would straddle a cell edge.
3. When you want to test how it actually streams, run
   `scripts/editor_tools/split_world_into_cells.gd` (open it in the Script
   Editor, File > Run, or the toolbar play button). This regenerates every
   `cell_<x>_<z>.tscn` file in this folder from WorldContent's current
   children — bucketed automatically by each object's real world position,
   using the same CELL_SIZE as WorldManager. No manual math, no cut/paste,
   no naming mistakes.
4. Run the game normally. `WorldContent`'s children never appear at
   runtime (the staging script frees them immediately) — only the
   freshly-generated cells stream in, exactly like the real player will
   experience it.

Re-running the split tool is always safe — it's a full regenerate, not an
incremental merge, so there's never a stale cell file left over as long as
you re-run after editing WorldContent.

## Objects near a cell boundary

A node is assigned entirely to whichever cell its own position falls in —
there's no partial splitting of one object across two cells. A large
object sitting right on a boundary will pop in/out as a whole piece at
that cell's load/unload distance. For anything large enough that this
would be noticeable (a big building), keep CELL_SIZE comfortably bigger
than your largest single structure, or nudge its position away from a
boundary.
