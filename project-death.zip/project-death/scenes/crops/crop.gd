extends Node3D
class_name Crop

## Attach this to the root Node3D of your Crop.tscn scene.
## Scene structure expected:
##   Crop (Node3D, this script)
##     ├── MeshInstance3D   (name it exactly "MeshInstance3D" — used for
##     │                     simple single-piece stages via mesh_override)
##     └── CompositeRoot     (Node3D, name it exactly "CompositeRoot" — empty
##                           container used for multi-part stages via stage_scene)

## Assign the specific plant species this instance represents.
## In-game you'll typically set this via code when planting (Crop.new setup),
## but it's exported too so you can test a single crop directly in the editor.
@export var crop_data: CropData

signal stage_changed(new_stage: DecayStage, stage_index: int)
signal fully_decayed()
signal removed_after_final_harvest()
signal watered_changed(is_watered: bool)

var elapsed_time: float = 0.0
var current_stage_index: int = -1
var is_active: bool = true  # false once fully decayed and no longer ticking
var is_watered: bool = false  # unwatered crops don't grow — resets every new day (see DayNightManager.day_started)
var growth_multiplier: float = 1.0  # set once via fertilize(), stays for the rest of this crop's life
var _cached_skill_growth_bonus: float = 0.0

@onready var mesh_instance: MeshInstance3D = $MeshInstance3D
@onready var composite_root: Node3D = $CompositeRoot


func _ready() -> void:
	if crop_data == null:
		push_warning("Crop: no CropData assigned, nothing will happen.")
		set_process(false)
		return
	var initial_stage := crop_data.get_stage_index_at_time(elapsed_time)
	if initial_stage == -1 or not is_active:
		_apply_stage(crop_data.stages.size() - 1)
		_on_fully_decayed()
	else:
		_apply_stage(initial_stage)
	DayNightManager.day_started.connect(_on_new_day)
	set_process(is_watered and is_active)


func _on_new_day() -> void:
	if is_watered:
		is_watered = false
		watered_changed.emit(false)
	set_process(false)


## Call from FarmPlot when the player uses a watering can on this crop.
## No-op if already watered today (no downside to trying twice).
func water() -> void:
	if is_watered:
		return
	is_watered = true
	_cached_skill_growth_bonus = SkillManager.get_modifier_total("farming_growth_speed")
	set_process(is_active)
	watered_changed.emit(true)


## Call from FarmPlot when the player uses fertilizer on this crop. Unlike
## watering, this is a ONE-TIME effect that lasts the crop's whole
## remaining life (matches "soil additive," not a daily-refresh thing) —
## calling it again on an already-fertilized crop is a no-op rather than
## stacking multipliers.
var _fertilized: bool = false
func fertilize(multiplier: float) -> void:
	if _fertilized:
		return
	_fertilized = true
	growth_multiplier = multiplier


func _process(delta: float) -> void:
	if not is_active or crop_data == null:
		return
	if not is_watered:
		return  # unwatered today — doesn't decay either, just holds in place

	elapsed_time += delta * growth_multiplier * (1.0 + _cached_skill_growth_bonus)
	var new_index := crop_data.get_stage_index_at_time(elapsed_time)

	if new_index != current_stage_index:
		if new_index == -1:
			_on_fully_decayed()
		else:
			_apply_stage(new_index)

func _apply_stage(index: int) -> void:
	current_stage_index = index
	var stage: DecayStage = crop_data.stages[index]

	print("Crop '%s' entering stage: %s (harvestable: %s)" % [crop_data.display_name, stage.stage_name, stage.is_harvestable])

	# Clear whatever composite parts existed for the previous stage.
	for child in composite_root.get_children():
		child.queue_free()

	if stage.stage_scene:
		# Composite multi-part model — instantiate the whole grouped scene
		# and hide the simple single-mesh path.
		mesh_instance.visible = false
		var instance := stage.stage_scene.instantiate()
		composite_root.add_child(instance)
	else:
		# Simple single-piece model — use the plain MeshInstance3D.
		mesh_instance.visible = true
		if stage.mesh_override:
			mesh_instance.mesh = stage.mesh_override
		if stage.material_override:
			mesh_instance.material_override = stage.material_override

	stage_changed.emit(stage, index)


func _on_fully_decayed() -> void:
	is_active = false
	set_process(false)
	fully_decayed.emit()
	# Design decision left open: does the crop vanish, collapse to compost,
	# or just sit there as a harvestable husk forever? Wire that up here later.


## Returns the DecayStage the crop is currently in, or null if inactive/unset.
func get_current_stage() -> DecayStage:
	if crop_data == null or current_stage_index < 0 or current_stage_index >= crop_data.stages.size():
		return null
	return crop_data.stages[current_stage_index]


## Call this from player interaction code (e.g. "E to harvest").
## Adds yielded items directly to InventoryManager and returns a Dictionary
## of {item_id: quantity} actually granted, or an empty Dictionary if the
## crop wasn't harvestable at this stage.
## If this harvest happens at the crop's FINAL stage, the crop vanishes
## afterward (removed_after_final_harvest signal + queue_free), leaving
## the plot empty and ready to replant.
func harvest() -> Dictionary:
	var stage := get_current_stage()
	if stage == null or not stage.is_harvestable:
		return {}

	# Roll actual yield quantities from the stage's yield_table (item_id -> Vector2i range).
	var result: Dictionary = {}
	for item_id in stage.yield_table.keys():
		var yield_range: Vector2i = stage.yield_table[item_id]
		var qty := LuckManager.roll_yield(yield_range.x, yield_range.y)
		if qty > 0:
			result[item_id] = qty
	if not InventorySlotManager.can_accept_batch(result):
		NotificationManager.notify("Not enough inventory space to harvest this crop.", "warning")
		return {}
	for item_id in result:
		InventoryManager.try_add_item(item_id, result[item_id])

	# Grant XP: base_xp * this stage's multiplier (rewards waiting for DYING/DECAYED stages).
	var xp_amount := int(crop_data.base_xp * stage.xp_multiplier)
	SkillManager.add_xp(crop_data.skill_id, xp_amount)

	# If this was the final stage in the crop's lifecycle, the plant is spent —
	# vanish completely so the plot can be replanted.
	var is_final_stage := current_stage_index == crop_data.stages.size() - 1
	if is_final_stage:
		is_active = false
		removed_after_final_harvest.emit()
		queue_free()

	return result


## Call this when planting a new crop dynamically (e.g. from a farm plot script)
## instead of setting crop_data in the editor.
func setup(data: CropData) -> void:
	crop_data = data
	elapsed_time = 0.0
	is_active = true
	is_watered = false
	growth_multiplier = 1.0
	_fertilized = false
	if is_inside_tree():
		_apply_stage(0)
		set_process(false)


## Call this instead of setup() when restoring a crop from a save file —
## jumps straight to the correct elapsed time and stage instead of starting fresh.
func setup_from_save(data: CropData, saved_elapsed_time: float, saved_is_watered: bool = false, saved_growth_multiplier: float = 1.0) -> void:
	crop_data = data
	elapsed_time = saved_elapsed_time
	is_active = true
	is_watered = saved_is_watered
	growth_multiplier = saved_growth_multiplier
	_cached_skill_growth_bonus = SkillManager.get_modifier_total("farming_growth_speed")
	_fertilized = saved_growth_multiplier != 1.0

	var stage_index := data.get_stage_index_at_time(elapsed_time)
	if stage_index == -1:
		# Saved at a point past the final stage's duration — clamp to the
		# last stage rather than treating it as "fully decayed and gone",
		# since the player hasn't harvested it yet and shouldn't lose it
		# just from time passing while the game was closed.
		stage_index = data.stages.size() - 1
	if is_inside_tree():
		_apply_stage(stage_index)
		set_process(is_watered)


func advance_while_unloaded(seconds: float) -> void:
	if not is_active or not is_watered or seconds <= 0.0:
		return
	elapsed_time += seconds * growth_multiplier * (1.0 + _cached_skill_growth_bonus)
	var stage_index := crop_data.get_stage_index_at_time(elapsed_time)
	if stage_index == -1:
		_on_fully_decayed()
	elif is_inside_tree():
		_apply_stage(stage_index)
