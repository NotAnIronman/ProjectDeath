extends CharacterBody3D
class_name Player

## Basic top-down/fixed-camera style controller (Animal Crossing-esque).
## No jumping-focused design, simple 4-directional movement mapped onto the XZ plane.
##
## Player now only owns: movement, camera wiring, nearby-interactable
## tracking (E to interact), and the held-item hand model. Decorate Mode's
## two sub-modes live in their own components (added as children below):
##   - PlayerBuildMode   (scripts/building/player_build_mode.gd)  — "Placing"
##   - PlayerPickupMode  (scripts/building/player_pickup_mode.gd) — "Pickup"
## Player still decides WHICH sub-mode should be active (via
## _refresh_decorate_target) and owns the public signals UILayer listens to,
## but the actual placing/picking-up logic lives in those components.
##
## Scene structure expected:
##   Player (CharacterBody3D, this script)
##     ├── <your player mesh/model, no animations yet — that's fine>
##     ├── CollisionShape3D
##     ├── InteractionArea (Area3D)
##     │     └── CollisionShape3D (SphereShape3D recommended, radius ~2)
##     ├── SelectionIndicator (Node3D) -- spawned/managed by this script,
##     │     see setup notes below.
##     └── HandPoint (Node3D) -- position this manually in the editor to
##           sit wherever your model's hand actually is. Whatever's
##           selected in the hotbar gets instantiated here automatically
##           (see ItemData.held_model). Once you add animations, reparent
##           this to the actual hand bone instead — everything else here
##           keeps working unchanged.

## Emitted whenever Decorate Mode changes state, so UILayer can show/hide
## the on-screen mode banner reactively instead of polling every frame.
## mode is "" when inactive, "placing" or "picking_up" otherwise.
signal decorate_mode_changed(active: bool, mode: String)
## Emitted whenever the current rotation (of the ghost or a targeted
## pickup object) changes, so UI can show the live degree value.
signal rotation_changed(degrees: float)

@export var move_speed: float = 5.0
@export var gravity: float = 20.0
@export var jump_velocity: float = 8.0

## Assign your selection-a.obj / selection-b.obj meshes here.
## Selection A = shown over an EMPTY plot (plantable).
## Selection B = shown over a HARVESTABLE crop.
@export var selection_mesh_empty: Mesh
@export var selection_mesh_harvestable: Mesh

@onready var interaction_area: Area3D = $InteractionArea
@onready var selection_indicator: MeshInstance3D = $SelectionIndicator
@onready var hand_point: Node3D = $HandPoint

var _nearby_interactables: Array[Node] = []
var _current_target: Node = null
var _camera_rig: Node3D = null
var _ui_layer: Node = null
var _held_item_instance: Node3D = null
var _held_item_id: String = ""

var _decorate_mode_requested: bool = false  # true from the moment B is pressed until fully exited

## --- Decorate Mode sub-components (see class doc above) ---
@onready var build_mode: PlayerBuildMode = $PlayerBuildMode
@onready var pickup_mode: PlayerPickupMode = $PlayerPickupMode


func _ready() -> void:
	# Make sure the player physically collides with placed decor/furniture
	# (layer 3 = bitmask value 4, matching batch_generate_items.gd's
	# StaticBody3D collision_layer). Uses bitwise OR so it adds this layer
	# without overwriting whatever else you've configured in the Inspector.
	collision_mask |= 4

	build_mode.setup(self)

	pickup_mode.setup(self)

	interaction_area.body_entered.connect(_on_area_body_entered)
	interaction_area.body_exited.connect(_on_area_body_exited)
	interaction_area.area_entered.connect(_on_area_area_entered)
	interaction_area.area_exited.connect(_on_area_area_exited)
	selection_indicator.visible = false
	selection_indicator.top_level = true

	# Deferred so this runs AFTER every node's _ready() has fired, including
	# CameraRig's — otherwise if Player is above CameraRig in the tree,
	# the "camera_rig" group might not be populated yet when we look for it.
	call_deferred("_wire_camera_rig")


func _wire_camera_rig() -> void:
	_camera_rig = get_tree().get_first_node_in_group("camera_rig")
	if _camera_rig:
		_camera_rig.set_follow_target(self)
	else:
		push_warning("Player: no node in group 'camera_rig' found — camera won't follow.")
	_ui_layer = get_tree().get_first_node_in_group("ui_layer")

	# Held item tracking — update whenever the hotbar selection changes,
	# or whenever the currently-selected slot's contents change (e.g. the
	# held item runs out and the slot empties).
	InventorySlotManager.selection_changed.connect(func(_i):
		_update_held_item()
		_refresh_decorate_target()
	)
	InventorySlotManager.slot_changed.connect(_on_inventory_slot_changed)
	_update_held_item()


func _on_inventory_slot_changed(slot_type: InventorySlotManager.SlotType, index: int) -> void:
	if slot_type == InventorySlotManager.SlotType.HOTBAR and index == InventorySlotManager.selected_hotbar_index:
		_update_held_item()
		_refresh_decorate_target()


func _physics_process(delta: float) -> void:
	if not WorldManager.is_world_ready():
		velocity = Vector3.ZERO
		return
	_handle_movement(delta)
	if not is_building():
		_update_target()


func _handle_movement(delta: float) -> void:
	if _ui_layer and _ui_layer.is_blocking_gameplay():
		velocity.x = 0
		velocity.z = 0
		if not is_on_floor():
			velocity.y -= gravity * delta
		else:
			velocity.y = 0
		move_and_slide()
		return

	var input_dir := Vector2.ZERO
	input_dir.x = Input.get_axis("move_left", "move_right")
	input_dir.y = Input.get_axis("move_forward", "move_back")

	var direction := Vector3(input_dir.x, 0, input_dir.y)
	if direction.length() > 0:
		direction = direction.normalized()

		# Rotate input by the camera's current yaw so "right" always means
		# screen-right, not world-right — otherwise controls feel inverted
		# after the camera does a 180-degree view swap.
		if _camera_rig:
			direction = direction.rotated(Vector3.UP, _camera_rig.rotation.y)

		velocity.x = direction.x * move_speed
		velocity.z = direction.z * move_speed
		# Face movement direction — simple snap-look, swap for smooth rotation/animation later.
		look_at(global_position + direction, Vector3.UP)
	else:
		velocity.x = 0
		velocity.z = 0

	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		velocity.y = 0
		if Input.is_action_just_pressed("ui_accept"):
			velocity.y = jump_velocity

	move_and_slide()


func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_E:
			if _ui_layer and _ui_layer.is_blocking_gameplay():
				return
			if is_building():
				return
			_try_interact()
		elif event.keycode == KEY_B:
			if _ui_layer and _ui_layer.is_blocking_gameplay():
				return
			_handle_build_key()
		elif event.keycode == KEY_ESCAPE and is_building():
			_exit_decorate_mode()
			get_viewport().set_input_as_handled()

	if event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_LEFT:
			if build_mode.is_active:
				build_mode.confirm()
				_after_build_confirm()
			elif pickup_mode.is_active:
				pickup_mode.try_pickup()
		elif event.button_index == MOUSE_BUTTON_RIGHT:
			if _ui_layer and _ui_layer.is_blocking_gameplay():
				return
			if is_building():
				return
			_try_use_restoration_tool()
		elif Input.is_key_pressed(KEY_R) and (event.button_index == MOUSE_BUTTON_WHEEL_UP or event.button_index == MOUSE_BUTTON_WHEEL_DOWN):
			var consumed := false
			if build_mode.is_active:
				consumed = build_mode.handle_scroll_rotate(event)
			elif pickup_mode.is_active:
				consumed = pickup_mode.handle_scroll_rotate(event)
			# Consumed by rotation — stop this scroll from also cycling the
			# hotbar (UILayer separately checks Input.is_key_pressed(KEY_R)
			# too, but this is a clean belt-and-suspenders guard).
			if consumed:
				get_viewport().set_input_as_handled()


## B toggles Decorate Mode on/off entirely. Which sub-mode (Placing vs
## Pickup) is active is decided automatically and kept in sync live as
## the player scrolls the hotbar — see _refresh_decorate_target().
func _handle_build_key() -> void:
	if is_building():
		_exit_decorate_mode()
	else:
		_decorate_mode_requested = true
		_refresh_decorate_target()


## Right-click while holding a RestorationToolData item (e.g. the Spirit
## Trowel) restores withered ground at the player's position — this used
## to be the T debug hotkey; now it's a real interaction, usable anywhere
## in the open world. This is intentionally separate from
## FarmPlot._try_restore_from_player_selection() (same underlying logic,
## duplicated rather than shared) since that one is specifically about
## unlocking a plot for planting via E-interact, while this is a general
## world action via right-click — different triggers, different contexts,
## worth keeping distinct even though the core steps mirror each other.
func _try_use_restoration_tool() -> void:
	var item_id := InventorySlotManager.get_selected_hotbar_item_id()
	if item_id == "":
		return
	var def: ItemData = InventoryManager.item_defs.get(item_id)
	if not (def is RestorationToolData):
		return
	var tool_def: RestorationToolData = def

	var patch_id := "world_restore_%d" % Time.get_ticks_usec()
	var failure := RestorationService.try_restore(global_position, patch_id, tool_def)
	print(failure if failure != "" else "The ground stirs — restored.")


## The single source of truth for "what should decorate mode be doing
## right now" — called on entry (B), and automatically whenever the
## hotbar selection or the selected slot's contents change. This is what
## makes scrolling swap the placed item live, and what makes running out
## of an item (or having nothing selected) fall through to Pickup Mode
## without needing a separate key.
func _refresh_decorate_target() -> void:
	if not is_building() and not _decorate_mode_requested:
		return  # not in decorate mode at all, nothing to refresh

	var item_id := InventorySlotManager.get_selected_hotbar_item_id()
	var def: ItemData = InventoryManager.item_defs.get(item_id) if item_id != "" else null

	if def != null and def.is_placeable and def.placed_scene != null and InventoryManager.has_item(item_id, 1):
		if build_mode.is_placing_item(item_id):
			return  # already placing exactly this item, nothing to do
		if pickup_mode.is_active:
			pickup_mode.stop()
		build_mode.start(item_id, def)
	else:
		if pickup_mode.is_active:
			return  # already in pickup mode, nothing to do
		if build_mode.is_active:
			build_mode.stop()
		pickup_mode.start()


## After a successful (or failed) placement, decide what decorate mode
## should do next — same reactive logic as everything else, so running out
## of an item mid-placement falls straight through to Pickup Mode.
func _after_build_confirm() -> void:
	_refresh_decorate_target()


## --- Interaction target tracking ---
## NOTE: FarmPlot needs an Area3D child (not just the Node3D root) for this
## to detect it — see FarmPlot scene setup notes in chat.

func _on_area_body_entered(body: Node) -> void:
	if body.is_in_group("interactables"):
		_nearby_interactables.append(body)


func _on_area_body_exited(body: Node) -> void:
	_nearby_interactables.erase(body)
	if _current_target == body:
		_current_target = null


func _on_area_area_entered(area: Area3D) -> void:
	# Support FarmPlots whose detectable region is an Area3D child rather
	# than the physical body itself.
	var owner_node := area.get_parent()
	if owner_node and owner_node.is_in_group("interactables"):
		_nearby_interactables.append(owner_node)


func _on_area_area_exited(area: Area3D) -> void:
	var owner_node := area.get_parent()
	if owner_node:
		_nearby_interactables.erase(owner_node)
		if _current_target == owner_node:
			_current_target = null


func _update_target() -> void:
	# Clean up any freed nodes (e.g. a Crop that queue_free'd itself).
	for index in range(_nearby_interactables.size() - 1, -1, -1):
		if not is_instance_valid(_nearby_interactables[index]):
			_nearby_interactables.remove_at(index)

	if _nearby_interactables.is_empty():
		_current_target = null
		selection_indicator.visible = false
		return

	# Pick nearest by distance.
	var nearest: Node = null
	var nearest_dist := INF
	for candidate in _nearby_interactables:
		if not (candidate is Node3D):
			continue
		var dist: float = global_position.distance_squared_to(candidate.global_position)
		if dist < nearest_dist:
			nearest_dist = dist
			nearest = candidate

	_current_target = nearest
	_update_selection_indicator()


func _update_selection_indicator() -> void:
	if _current_target == null:
		selection_indicator.visible = false
		return

	selection_indicator.visible = true
	selection_indicator.global_position = _current_target.global_position

	# BUGFIX: mesh used to only ever get assigned inside the FarmPlot
	# branch below — every other interactable type (NPC, ResourceNode,
	# StorageContainer, TradingPost, WaypointBeacon, QuestLocationMarker)
	# left `mesh` untouched, which meant either a null mesh (invisible
	# despite visible=true, on a fresh session that hadn't targeted a
	# FarmPlot yet) or a stuck stale farm-plot-shaped indicator after the
	# first one ever was. selection_mesh_empty now doubles as the generic
	# "something's targeted" shape for anything that isn't a FarmPlot.
	if _current_target is FarmPlot:
		var plot: FarmPlot = _current_target
		if plot.is_harvestable():
			selection_indicator.mesh = selection_mesh_harvestable
		else:
			selection_indicator.mesh = selection_mesh_empty
	else:
		selection_indicator.mesh = selection_mesh_empty


func _try_interact() -> void:
	if _current_target == null:
		print("Nothing nearby to interact with.")
		return

	if _current_target.has_method("interact"):
		_current_target.interact(self)
	else:
		push_warning("Target has no interact() method.")


## --- Seed selection ---
## Actual selection now lives in UILayer's hotbar (scroll wheel to cycle,
## see ui_layer.gd). This just reads whatever's currently selected there
## and validates it's actually a plantable seed you still have in stock.

## Called by FarmPlot when the player interacts with an empty plot.
## Returns the currently selected seed's item_id, or "" if the hotbar
## selection isn't a seed, or you're out of it.
func get_selected_seed_id() -> String:
	if _ui_layer == null:
		return ""

	var item_id: String = _ui_layer.get_selected_hotbar_item_id()
	if item_id == "":
		return ""

	var def: ItemData = InventoryManager.item_defs.get(item_id)
	if not (def is SeedData):
		return ""  # selected hotbar item isn't a seed — nothing to plant

	if not InventoryManager.has_item(item_id, 1):
		return ""

	return item_id


## --- Held item (hand point) ---

## Updates whatever's shown at the hand point to match the currently
## selected hotbar item's held_model. Safe to call repeatedly — it only
## actually swaps the instance when the item has changed.
func _update_held_item() -> void:
	var item_id := InventorySlotManager.get_selected_hotbar_item_id()

	if item_id == _held_item_id:
		return  # nothing changed, avoid needless re-instantiation

	_held_item_id = item_id

	if _held_item_instance:
		_held_item_instance.queue_free()
		_held_item_instance = null

	if item_id == "":
		return  # empty-handed

	var def: ItemData = InventoryManager.item_defs.get(item_id)
	if def == null:
		return  # unknown item — stay empty-handed

	var scene_to_hold: PackedScene = def.held_model
	var scale_to_apply: float = 1.0  # a custom held_model is assumed already sized correctly on its own
	if scene_to_hold == null:
		if def.is_placeable and def.placed_scene:
			scene_to_hold = def.placed_scene
			scale_to_apply = def.held_scale
		else:
			return  # no held representation at all — stay empty-handed

	_held_item_instance = scene_to_hold.instantiate()
	hand_point.add_child(_held_item_instance)
	_held_item_instance.position = def.held_model_offset
	_held_item_instance.rotation_degrees = def.held_model_rotation_degrees
	_held_item_instance.scale = Vector3.ONE * scale_to_apply
	_disable_collision_recursive(_held_item_instance)


## Held models should never physically collide with anything — this
## matters most for items that reuse a Placeable's placed_scene as their
## held_model too (see held_model's doc comment for when that's a good
## idea): a StorageContainer/TradingPost's real collision shape has no
## business existing on something glued to the player's hand. Handles
## both Placeable's own set_collision_enabled() (if present) and any
## plain CollisionShape3D/CollisionObject3D found some other way, so this
## is safe regardless of how a given held model happens to be built.
func _disable_collision_recursive(node: Node) -> void:
	if node.has_method("set_collision_enabled"):
		node.set_collision_enabled(false)
	if node is CollisionObject3D:
		node.collision_layer = 0
		node.collision_mask = 0
	for child in node.get_children():
		_disable_collision_recursive(child)


## --- Decorate Mode (public API used by UILayer) ---

## Called by UILayer to avoid opening the pause menu (or triggering
## movement/interact) on the same input used to cancel build/pickup mode.
func is_building() -> bool:
	return build_mode.is_active or pickup_mode.is_active


## Fully exits Decorate Mode — whichever sub-mode is currently active.
func _exit_decorate_mode() -> void:
	_decorate_mode_requested = false
	build_mode.stop()
	pickup_mode.stop()
	selection_indicator.visible = false
	decorate_mode_changed.emit(false, "")
