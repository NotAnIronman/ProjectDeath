@tool
extends Node3D
class_name ResourceNode

## Attach to the root Node3D of a resource node scene (tree, rock, fishing
## spot). Scene structure expected — same dual-visual pattern as Crop.gd:
##   ResourceNode (Node3D, this script)
##     ├── MeshInstance3D   (name it exactly "MeshInstance3D" — used for
##     │                     simple single-piece stages via mature_mesh/
##     │                     depleted_mesh)
##     └── CompositeRoot     (Node3D, name it exactly "CompositeRoot" —
##                           empty container used for multi-part stages
##                           via mature_scene/depleted_scene)
##
## @tool: this script also runs its VISUAL logic inside the editor, so you
## can see the actual mesh while placing instances instead of an empty
## gizmo — makes positioning far easier. Gameplay logic (timers, XP,
## inventory, interaction zone) is guarded to only run in-game.
##
## Unlike Crop, this doesn't get consumed on final harvest — it just goes
## Mature -> Depleted -> (after respawn_time) back to Mature, looping
## indefinitely. Doesn't need "planting" either; place instances directly
## in the world (or scatter them procedurally later).

enum NodeState { MATURE, DEPLETED }

@export var node_data: ResourceNodeData:
	set(value):
		node_data = value
		if is_inside_tree():
			_apply_state(NodeState.MATURE)

## Radius of the auto-created interaction zone, used for E-key detection.
@export var interaction_radius: float = 2.0
@export var persistent_id: String = ""

signal harvested(node_data: ResourceNodeData)
signal depleted()
signal respawned()

var state: NodeState = NodeState.MATURE
var _respawn_elapsed: float = 0.0

@onready var mesh_instance: MeshInstance3D = $MeshInstance3D
@onready var composite_root: Node3D = $CompositeRoot


func _ready() -> void:
	if node_data == null:
		if not Engine.is_editor_hint():
			push_warning("ResourceNode: no ResourceNodeData assigned.")
		return

	_apply_state(NodeState.MATURE)

	if Engine.is_editor_hint():
		return  # everything below is gameplay-only, skip in the editor

	add_to_group("interactables")
	_create_interaction_zone()
	_create_collision()
	set_process(false)


func _create_interaction_zone() -> void:
	var area := Area3D.new()
	add_child(area)

	var shape := CollisionShape3D.new()
	var sphere := SphereShape3D.new()
	sphere.radius = interaction_radius
	shape.shape = sphere
	area.add_child(shape)


## Stable box collision sized to the MATURE visual's bounding box, created
## once and left unchanged across Mature/Depleted state swaps. Deliberately
## approximate (a real tree isn't a box) — good enough to stop the player
## walking through it without needing to regenerate collision every time
## the mesh changes, which would cause popping.
func _create_collision() -> void:
	var aabb: Variant = _compute_aabb_for_collision()
	if aabb == null:
		return
	var box_aabb: AABB = aabb

	var static_body := StaticBody3D.new()
	add_child(static_body)

	var collision_shape := CollisionShape3D.new()
	var box_shape := BoxShape3D.new()
	box_shape.size = box_aabb.size
	collision_shape.shape = box_shape
	collision_shape.position = box_aabb.get_center()
	static_body.add_child(collision_shape)


func _compute_aabb_for_collision() -> Variant:
	if node_data.collision_size != Vector3.ZERO:
		return AABB(node_data.collision_center - node_data.collision_size * 0.5, node_data.collision_size)
	if node_data.mature_mesh:
		return node_data.mature_mesh.get_aabb()
	if node_data.mature_scene:
		var temp := node_data.mature_scene.instantiate()
		add_child(temp)
		var world_aabb: Variant = MeshUtils.compute_world_aabb(temp)
		temp.queue_free()
		if world_aabb == null:
			return null
		var aabb: AABB = world_aabb
		return global_transform.affine_inverse() * aabb
	return null


func _process(delta: float) -> void:
	if Engine.is_editor_hint():
		return
	if state != NodeState.DEPLETED or node_data == null:
		return
	_respawn_elapsed += delta
	if _respawn_elapsed >= node_data.respawn_time:
		_apply_state(NodeState.MATURE)
		respawned.emit()


func _apply_state(new_state: NodeState) -> void:
	state = new_state
	_respawn_elapsed = 0.0
	if not Engine.is_editor_hint():
		set_process(new_state == NodeState.DEPLETED)

	if composite_root == null or mesh_instance == null:
		return  # not ready yet (e.g. called from the node_data setter before _ready)

	for child in composite_root.get_children():
		child.queue_free()

	var use_scene: PackedScene = node_data.mature_scene if new_state == NodeState.MATURE else node_data.depleted_scene
	var use_mesh: Mesh = node_data.mature_mesh if new_state == NodeState.MATURE else node_data.depleted_mesh

	if use_scene:
		mesh_instance.visible = false
		var instance := use_scene.instantiate()
		composite_root.add_child(instance)
	else:
		mesh_instance.visible = true
		if use_mesh:
			mesh_instance.mesh = use_mesh


func is_harvestable() -> bool:
	return state == NodeState.MATURE


## Called by Player when this is the nearest interactable and the
## interact key is pressed. Handles the full tool + level check, prints
## clear feedback either way.
func interact(player: Node) -> void:
	if node_data == null:
		return

	if not is_harvestable():
		print("%s hasn't respawned yet." % node_data.display_name)
		return

	var selected_item_id: String = InventorySlotManager.get_selected_hotbar_item_id()
	var tool_def: ItemData = InventoryManager.item_defs.get(selected_item_id) if selected_item_id != "" else null

	if not (tool_def is ToolData) or tool_def.tool_type != node_data.required_tool_type:
		print("You need a %s equipped to gather %s." % [node_data.required_tool_type, node_data.display_name])
		return

	if tool_def.tool_tier < node_data.min_tool_tier:
		print("Your tool isn't strong enough for %s (needs tier %d, yours is tier %d)." % [
			node_data.display_name, node_data.min_tool_tier, tool_def.tool_tier
		])
		return

	if not SkillManager.meets_requirement(node_data.skill_id, node_data.required_level):
		print("Requires %s level %d (you are level %d)." % [
			node_data.skill_id, node_data.required_level,
			SkillManager.get_level(node_data.skill_id)
		])
		return

	_harvest()


func _harvest() -> void:
	var yield_bonus: float = SkillManager.get_modifier_total(node_data.skill_id + "_yield_bonus")
	var rolled_yields: Dictionary = {}
	for item_id in node_data.yield_table.keys():
		var yield_range: Vector2i = node_data.yield_table[item_id]
		var qty := LuckManager.roll_yield(yield_range.x, yield_range.y)
		qty = int(round(qty * (1.0 + yield_bonus)))
		if qty > 0:
			rolled_yields[item_id] = qty
	if not InventorySlotManager.can_accept_batch(rolled_yields):
		NotificationManager.notify("Not enough inventory space to gather this.", "warning")
		return
	for item_id in rolled_yields:
		InventoryManager.try_add_item(item_id, rolled_yields[item_id])

	SkillManager.add_xp(node_data.skill_id, int(node_data.base_xp))

	harvested.emit(node_data)
	_apply_state(NodeState.DEPLETED)
	depleted.emit()


func get_persistent_id() -> String:
	if persistent_id != "":
		return persistent_id
	if node_data == null:
		return ""
	var position_key := "%d_%d_%d" % [
		roundi(global_position.x * 100.0),
		roundi(global_position.y * 100.0),
		roundi(global_position.z * 100.0)
	]
	return "resource_%s_%s" % [node_data.id, position_key]


func get_save_data() -> Dictionary:
	return {
		"state": int(state),
		"respawn_elapsed": _respawn_elapsed
	}


func load_save_data(data: Dictionary) -> void:
	load_save_data_with_elapsed(data, 0.0)


func load_save_data_with_elapsed(data: Dictionary, unloaded_seconds: float) -> void:
	var saved_state := int(data.get("state", NodeState.MATURE))
	if saved_state == NodeState.DEPLETED:
		var elapsed := float(data.get("respawn_elapsed", 0.0)) + unloaded_seconds
		if node_data != null and elapsed >= node_data.respawn_time:
			_apply_state(NodeState.MATURE)
		else:
			_apply_state(NodeState.DEPLETED)
			_respawn_elapsed = elapsed
	else:
		_apply_state(NodeState.MATURE)
