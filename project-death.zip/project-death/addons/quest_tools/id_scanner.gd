@tool
extends RefCounted
class_name QuestToolsIDScanner

## Scans the project for every kind of id the dropdown fields need to
## offer. Deliberately a SEPARATE scan from generate_id_registry.gd/
## validate_quests_and_dialogue.gd rather than sharing code with them —
## this one needs to stay fast enough to re-run every time you click a
## different resource in the Inspector, and keeping it independent means
## a bug here can't break those tools (or vice versa).
##
## Owned by IDFieldInspectorPlugin, which calls refresh() once per newly-
## inspected relevant object — see that file for exactly when.

const QUESTS_ROOT := "res://resources/Quests/"
const RECIPES_ROOT := "res://resources/Crafting/recipes/"
const ITEM_CATALOG_PATH := "res://data/item_catalog.json"
const ITEMS_ROOT := "res://resources/"

var npc_ids: Array[String] = []
var location_ids: Array[String] = []
var flag_ids: Array[String] = []
var quest_ids: Array[String] = []
var item_ids: Array[String] = []
var recipe_ids: Array[String] = []
var skill_ids: Array[String] = []

## npc_id -> Array[String] of that NPC's dialogue line ids, for the
## (currently unused, see id_field_inspector_plugin.gd's own note on
## next_line_id) future line-id dropdown.
var lines_by_npc: Dictionary = {}


func refresh() -> void:
	var npc_set: Dictionary = {}
	var location_set: Dictionary = {}
	var flag_set: Dictionary = {}
	var quest_set: Dictionary = {}
	lines_by_npc.clear()

	_scan_quests_root(QUESTS_ROOT, npc_set, location_set, flag_set, quest_set)
	_scan_scenes_for_locations("res://", location_set, npc_set)

	npc_ids = _sorted_keys(npc_set)
	location_ids = _sorted_keys(location_set)
	flag_ids = _sorted_keys(flag_set)
	quest_ids = _sorted_keys(quest_set)
	item_ids = _load_item_ids()
	recipe_ids = _load_recipe_ids()
	skill_ids = _load_skill_ids()


func _sorted_keys(d: Dictionary) -> Array[String]:
	var keys: Array[String] = []
	for k in d.keys():
		keys.append(k)
	keys.sort()
	return keys


func _scan_quests_root(path: String, npc_set: Dictionary, location_set: Dictionary, flag_set: Dictionary, quest_set: Dictionary) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return
	for sub_dir in dir.get_directories():
		_scan_quests_root(path.path_join(sub_dir), npc_set, location_set, flag_set, quest_set)
	for file_name in dir.get_files():
		if not file_name.ends_with(".tres"):
			continue
		var resource := load(path.path_join(file_name))
		if resource is QuestData:
			if resource.id != "":
				quest_set[resource.id] = true
			for step in resource.steps:
				if step.sets_flag != "":
					flag_set[step.sets_flag] = true
				match step.step_type:
					QuestStepData.StepType.TALK_TO_NPC, QuestStepData.StepType.DIALOGUE_CHOICE, QuestStepData.StepType.GIVE_ITEM_TO_NPC:
						if step.target_id != "":
							npc_set[step.target_id] = true
					QuestStepData.StepType.GO_TO_LOCATION, QuestStepData.StepType.USE_ITEM_AT_LOCATION:
						if step.target_id != "":
							location_set[step.target_id] = true
		elif resource is DialogueTreeData:
			if resource.npc_id != "":
				npc_set[resource.npc_id] = true
			var line_ids: Array[String] = []
			for line in resource.lines:
				if line.id != "":
					line_ids.append(line.id)
				if line.required_flag != "":
					flag_set[line.required_flag] = true
				if line.required_flag_absent != "":
					flag_set[line.required_flag_absent] = true
				for choice in line.choices:
					if choice.sets_flag != "":
						flag_set[choice.sets_flag] = true
					if choice.starts_quest != "":
						quest_set[choice.starts_quest] = true
			if resource.npc_id != "":
				lines_by_npc[resource.npc_id] = line_ids


func _scan_scenes_for_locations(path: String, location_set: Dictionary, npc_set: Dictionary) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return
	for sub_dir in dir.get_directories():
		if sub_dir.begins_with("."):
			continue
		_scan_scenes_for_locations(path.path_join(sub_dir), location_set, npc_set)
	for file_name in dir.get_files():
		if not file_name.ends_with(".tscn"):
			continue
		var text := FileAccess.get_file_as_string(path.path_join(file_name))
		for found_id in _extract_quoted_values(text, "location_id"):
			location_set[found_id] = true
		for found_id in _extract_quoted_values(text, "npc_id"):
			npc_set[found_id] = true


func _extract_quoted_values(text: String, property_name: String) -> Array[String]:
	var results: Array[String] = []
	var search_from := 0
	var needle := property_name + " = \""
	while true:
		var start := text.find(needle, search_from)
		if start == -1:
			break
		var value_start := start + needle.length()
		var value_end := text.find("\"", value_start)
		if value_end == -1:
			break
		results.append(text.substr(value_start, value_end - value_start))
		search_from = value_end + 1
	return results


func _load_item_ids() -> Array[String]:
	var result: Dictionary = {}
	if FileAccess.file_exists(ITEM_CATALOG_PATH):
		var file := FileAccess.open(ITEM_CATALOG_PATH, FileAccess.READ)
		var paths: Variant = JSON.parse_string(file.get_as_text())
		file.close()
		if paths is Array:
			for item_path in paths:
				var item := load(item_path)
				if item is ItemData and item.id != "":
					result[item.id] = true
			return _sorted_keys(result)
	_scan_for_items(ITEMS_ROOT, result)
	return _sorted_keys(result)


func _scan_for_items(path: String, result: Dictionary) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return
	for sub_dir in dir.get_directories():
		_scan_for_items(path.path_join(sub_dir), result)
	for file_name in dir.get_files():
		if not file_name.ends_with(".tres"):
			continue
		var resource := load(path.path_join(file_name))
		if resource is ItemData and resource.id != "":
			result[resource.id] = true


func _load_recipe_ids() -> Array[String]:
	var result: Dictionary = {}
	var dir := DirAccess.open(RECIPES_ROOT)
	if dir:
		for file_name in dir.get_files():
			if not file_name.ends_with(".tres"):
				continue
			var recipe := load(RECIPES_ROOT.path_join(file_name)) as RecipeData
			if recipe and recipe.id != "":
				result[recipe.id] = true
	return _sorted_keys(result)


## Skills are a small, fixed set authored directly here rather than
## re-scanning SkillManager's own folder — matches the 8 real skill ids
## already in the project (herbalism, woodcutting, spiritkeeping, mining,
## foraging, farming, fishing, cooking). Update this list if a new skill
## is ever added — it's one line, and avoids this tool needing to know
## SkillData's exact resource folder path independently.
func _load_skill_ids() -> Array[String]:
	return ["herbalism", "woodcutting", "spiritkeeping", "mining", "foraging", "farming", "fishing", "cooking"]
