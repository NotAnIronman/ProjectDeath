@tool
extends EditorInspectorPlugin
class_name IDFieldInspectorPlugin

## THE actual field-to-source mapping. To add dropdown support for a new
## field on a new type: add a case below. That's the whole integration —
## IDPickerProperty and QuestToolsIDScanner don't need to know this type
## exists.
##
## Deliberately does NOT cover Array[Dictionary]-shaped fields (like
## RecipeData.inputs, CropData.yield_table) — Godot's Inspector doesn't
## expose individual Dictionary keys as separately-hookable properties
## the way it does real Resource fields. DialogueLine.choices got
## converted from Array[Dictionary] to Array[DialogueChoiceData]
## specifically to get around this (see that file's header) — the same
## conversion is the way to bring dropdown support to any other
## Dictionary-array field later, not a limitation of this plugin itself.

var scanner: QuestToolsIDScanner = QuestToolsIDScanner.new()


func _can_handle(object: Object) -> bool:
	var handled := object is QuestStepData or object is DialogueLine or object is DialogueChoiceData \
		or object is RecipeData or object is ResourceNodeData or object is CropData or object is QuestData
	if handled:
		scanner.refresh()
	return handled


func _parse_property(object: Object, _type: Variant.Type, name: String, _hint_type: PropertyHint, _hint_string: String, _usage_flags: int, _wide: bool) -> bool:
	if object is QuestStepData:
		return _handle_quest_step(object, name)
	if object is DialogueLine:
		return _handle_dialogue_line(name)
	if object is DialogueChoiceData:
		return _handle_dialogue_choice(name)
	if object is RecipeData:
		return _handle_recipe(name)
	if (object is ResourceNodeData or object is CropData) and name == "skill_id":
		add_property_editor(name, IDPickerProperty.new(true, func(): return scanner.skill_ids))
		return true
	if object is QuestData and name == "required_quest_id":
		add_property_editor(name, IDPickerProperty.new(false, func(): return scanner.quest_ids))
		return true
	return false


func _handle_quest_step(object: QuestStepData, name: String) -> bool:
	if name == "target_id":
		# Contextual on the sibling step_type field — recomputed fresh
		# every time the picker opens, so changing step_type and then
		# opening target_id's picker always offers the right list without
		# needing to close/reopen the Inspector.
		var get_options := func() -> Array:
			match object.step_type:
				QuestStepData.StepType.TALK_TO_NPC, QuestStepData.StepType.DIALOGUE_CHOICE, QuestStepData.StepType.GIVE_ITEM_TO_NPC:
					return scanner.npc_ids
				QuestStepData.StepType.CRAFT_ITEM:
					return scanner.recipe_ids
				QuestStepData.StepType.GO_TO_LOCATION, QuestStepData.StepType.USE_ITEM_AT_LOCATION:
					return scanner.location_ids
				_:
					return []  # CUSTOM_ACTION — arbitrary by design, stays plain text (handled by not intercepting this property at all... but target_id is always intercepted; empty options just means the picker has nothing to offer, LineEdit still fully usable)
		add_property_editor(name, IDPickerProperty.new(false, get_options))
		return true
	if name == "item_id":
		add_property_editor(name, IDPickerProperty.new(true, func(): return scanner.item_ids))
		return true
	if name == "sets_flag":
		add_property_editor(name, IDPickerProperty.new(false, func(): return scanner.flag_ids))
		return true
	return false


func _handle_dialogue_line(name: String) -> bool:
	if name == "required_flag" or name == "required_flag_absent":
		add_property_editor(name, IDPickerProperty.new(false, func(): return scanner.flag_ids))
		return true
	# next_line_id is intentionally NOT handled here — it needs to know
	# which OTHER lines exist in the SAME DialogueTreeData, but a nested
	# DialogueLine sub-resource's _parse_property call only receives the
	# DialogueLine itself, not its owning tree. Solvable (watching
	# EditorInterface's inspector for the top-level edited object and
	# caching "current tree" separately), just genuinely more work than
	# the rest of this pass — a real, scoped-out follow-up, not silently
	# dropped.
	return false


func _handle_dialogue_choice(name: String) -> bool:
	if name == "sets_flag":
		add_property_editor(name, IDPickerProperty.new(false, func(): return scanner.flag_ids))
		return true
	if name == "starts_quest":
		add_property_editor(name, IDPickerProperty.new(false, func(): return scanner.quest_ids))
		return true
	if name == "required_skill_id":
		add_property_editor(name, IDPickerProperty.new(true, func(): return scanner.skill_ids))
		return true
	# next_line_id: same limitation as DialogueLine's, see above.
	return false


func _handle_recipe(name: String) -> bool:
	if name == "output_item_id":
		add_property_editor(name, IDPickerProperty.new(true, func(): return scanner.item_ids))
		return true
	if name == "required_skill_id":
		add_property_editor(name, IDPickerProperty.new(true, func(): return scanner.skill_ids))
		return true
	return false
