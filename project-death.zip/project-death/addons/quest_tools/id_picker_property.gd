@tool
extends EditorProperty
class_name IDPickerProperty

## Reusable dropdown/picker for a single String property, used by
## IDFieldInspectorPlugin for every field listed there. Two modes:
##
##   strict=true  -> a plain OptionButton showing EXACTLY the known
##                   values. For items/recipes/skills — closed sets
##                   defined by content that exists independently of the
##                   field being edited, so there's nothing to "type new"
##                   here; you'd create the ItemData/RecipeData first.
##
##   strict=false -> a LineEdit (still fully free-typeable — many of
##                   these ids, like a new flag or a new NPC, get
##                   INVENTED as you author content, so a picker that
##                   only offers existing values would be actively in
##                   the way) plus a small "▾" button offering known
##                   values as one-click fills.
##
## `get_options` is a Callable (() -> Array[String]) rather than a fixed
## list, called fresh every time the picker opens — this is what makes
## QuestStepData.target_id's options correctly follow its sibling
## step_type field (a Craft Item step offers recipe ids, a Go To
## Location step offers location ids, etc.) without this widget needing
## to know anything about that logic itself.

var _strict: bool
var _get_options: Callable

var _line_edit: LineEdit
var _option_button: OptionButton
var _picker_button: MenuButton
var _updating := false


func _init(strict: bool, get_options: Callable) -> void:
	_strict = strict
	_get_options = get_options

	if _strict:
		_option_button = OptionButton.new()
		_option_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		_option_button.item_selected.connect(_on_option_selected)
		add_child(_option_button)
		add_focusable(_option_button)
	else:
		var hbox := HBoxContainer.new()

		_line_edit = LineEdit.new()
		_line_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		_line_edit.text_changed.connect(_on_line_edit_changed)
		hbox.add_child(_line_edit)

		_picker_button = MenuButton.new()
		_picker_button.text = "▾"
		_picker_button.tooltip_text = "Pick from known values"
		_picker_button.custom_minimum_size = Vector2(28, 0)
		_picker_button.get_popup().about_to_popup.connect(_populate_popup)
		_picker_button.get_popup().id_pressed.connect(_on_popup_id_pressed)
		hbox.add_child(_picker_button)

		add_child(hbox)
		add_focusable(_line_edit)


## Called by the engine to sync the DISPLAYED value with the actual
## underlying property — e.g. after an undo/redo, or the value changing
## for a reason other than this widget. Never call emit_changed() from in
## here, or every external update would loop back into another edit.
func _update_property() -> void:
	var current_value = get_edited_object().get(get_edited_property())
	if current_value == null:
		current_value = ""
	_updating = true
	if _strict:
		_refresh_option_button(String(current_value))
	else:
		if _line_edit.text != current_value:
			_line_edit.text = current_value
	_updating = false


func _refresh_option_button(current_value: String) -> void:
	_option_button.clear()
	var options: Array = _get_options.call()
	var selected_index := -1
	for i in options.size():
		_option_button.add_item(options[i])
		if options[i] == current_value:
			selected_index = i

	if selected_index == -1 and current_value != "":
		# Current value isn't in the known list (stale/renamed/typo'd
		# elsewhere) — show it anyway rather than silently swapping to
		# something else the author didn't choose.
		_option_button.add_item(current_value + "  (not found)")
		selected_index = _option_button.item_count - 1
	elif selected_index == -1:
		_option_button.add_item("(none)")
		selected_index = 0
	_option_button.select(selected_index)


func _on_option_selected(index: int) -> void:
	if _updating:
		return
	var text := _option_button.get_item_text(index)
	text = text.replace("  (not found)", "")
	if text == "(none)":
		text = ""
	emit_changed(get_edited_property(), text)


func _on_line_edit_changed(new_text: String) -> void:
	if _updating:
		return
	emit_changed(get_edited_property(), new_text)


func _populate_popup() -> void:
	var popup := _picker_button.get_popup()
	popup.clear()
	var options: Array = _get_options.call()
	for i in options.size():
		popup.add_item(options[i], i)
	if options.is_empty():
		popup.add_item("(nothing found yet — run generate_id_registry.gd or check spelling)", -1)


func _on_popup_id_pressed(id: int) -> void:
	if id < 0:
		return
	var options: Array = _get_options.call()
	if id < options.size():
		_line_edit.text = options[id]
		emit_changed(get_edited_property(), options[id])
