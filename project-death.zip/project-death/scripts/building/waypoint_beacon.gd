extends Placeable
class_name WaypointBeacon

## A physical fast-travel landmark. Place it like any other furniture
## (inherits ALL of Placeable unchanged — build mode, grid tracking,
## pickup), and it registers itself with FastTravelManager the moment
## it's placed/loaded. Interact (E) opens the book straight to the Map
## page, where you can travel to any OTHER beacon you've placed.
##
## Deliberately NOT a menu-driven "type a name, bookmark anywhere"
## system — a beacon has to physically exist somewhere you actually
## walked to and placed. See FastTravelManager's own header for the
## full reasoning.

@export var beacon_name: String = "Beacon"


func _ready() -> void:
	add_to_group("interactables")
	add_to_group("waypoint_beacons")


## Called by Player's ambient interaction (same path as FarmPlot/
## ResourceNode/StorageContainer/TradingPost).
func interact(_player: Node) -> void:
	var ui := get_tree().get_first_node_in_group("ui_layer")
	if ui and ui.has_method("open_map_page"):
		ui.open_map_page(self)
	else:
		push_warning("WaypointBeacon: no UILayer with open_map_page() found.")


## Overridden rather than connected via a signal — commit_placement() is
## the one guaranteed call point for both "just placed by the player" AND
## "restored from a save", so registering here (instead of duplicating
## the same registration call in two different places) can't drift out
## of sync between those two paths.
##
## FastTravelManager is the single source of truth for a beacon's name —
## if it already knows about this persistent_id, that name always wins
## here. beacon_name's own current value (its @export default, "Beacon")
## is only ever used as a fallback for a beacon FastTravelManager has
## genuinely never seen before.
func commit_placement() -> bool:
	var success := super.commit_placement()
	if success:
		if FastTravelManager.beacons.has(persistent_id):
			beacon_name = FastTravelManager.beacons[persistent_id]["name"]
		FastTravelManager.register_beacon(persistent_id, beacon_name, global_position, rotation.y)
	return success


## BUGFIX: this used to unregister from release_placement(), but
## Placeable._exit_tree() calls release_placement() for ANY reason the
## node leaves the tree — including a cell simply streaming OUT of load
## range, which happens constantly during normal play and has nothing to
## do with the beacon actually being removed. That made every beacon
## vanish from the fast-travel list the moment you walked far enough
## away from it, defeating the entire point of fast travel. pick_up() is
## the one call point that means "the player genuinely picked this up" —
## unregistering here instead means a beacon now stays known/travel-able
## for the rest of the game regardless of whether its cell happens to be
## loaded at the moment, exactly like a real landmark should.
func pick_up() -> bool:
	var success := super.pick_up()
	if success and persistent_id != "":
		FastTravelManager.unregister_beacon(persistent_id)
	return success


## BUGFIX (names not surviving a save/load): get_save_data()/load_save_data()
## USED to independently read/write beacon_name as part of this node's own
## Placeable save data (the normal per-object save contract every other
## Placeable uses). That meant a rename via the Map page only ever updated
## FastTravelManager's copy — this node's OWN save data still captured
## whatever beacon_name was at the LAST time its cell unloaded, which could
## easily be from before the rename. Loading that stale data back into
## beacon_name, even though commit_placement() right afterward pulls the
## correct name from FastTravelManager if it has one, meant there was a
## window where a stale value existed and an extra dependency on that
## correction running in every single code path. Simplest truly-safe fix:
## stop writing beacon_name into this node's own save data entirely, so
## there is exactly ONE place a beacon's name is ever persisted —
## FastTravelManager's own save data — and nothing else can ever inject a
## competing stale copy. No get_save_data()/load_save_data() overrides
## needed here anymore; this node just inherits Placeable's plain versions
## and commit_placement() (above) handles the name entirely on its own.
