@tool
extends EditorScript

## Run this (open in the Script editor, press Run ▶) any time you want a
## health check on every quest and dialogue tree in the project. Prints
## one line per problem found, with the exact file it's in — same
## push_error-with-file-path convention as build_item_catalog.gd.
##
## Everything here is a STATIC cross-reference check: does the thing an
## id points at actually exist somewhere? It can't verify a quest is fun
## or a branch reads naturally — that's still on you to playtest — but
## it turns "silently doesn't work" into "here's exactly what's wrong
## and where," which is the actual authoring pain at content-scale.
##
## Checks performed:
##   - Every NPC-targeting step (Talk/Dialogue Choice/Give Item) points
##     at an npc_id that has a real DialogueTreeData.
##   - Every Craft Item step points at a real recipe id.
##   - Every location-targeting step (Go To/Use Item At) points at a
##     location_id actually placed as a QuestLocationMarker somewhere in
##     a .tscn file.
##   - Every item_id referenced anywhere (items_given/items_removed/
##     item_id fields) is a real item.
##   - Every Dialogue Choice step's (dialogue_line_id, choice_index)
##     points at a line/choice that actually exists on that NPC.
##   - Every dialogue line's next_line_id / choice next_line_id points at
##     a line that exists in the SAME tree (no dead links).
##   - (Warning only) every npc_id with a dialogue tree is actually
##     placed as an NPC somewhere — an authored tree nobody can reach.
##   - (Warning only) every flag that's READ (required_flag/
##     required_flag_absent) is also SET somewhere — a flag nothing ever
##     sets can never become true.

const QUESTS_ROOT := "res://resources/Quests/"
const RECIPES_ROOT := "res://resources/Crafting/recipes/"
const ITEM_CATALOG_PATH := "res://data/item_catalog.json"

var _error_count := 0
var _warning_count := 0

var _quests: Array[QuestData] = []
var _quest_paths: Dictionary = {}      ## QuestData -> path (for error messages)
var _trees_by_npc: Dictionary = {}     ## npc_id -> DialogueTreeData
var _tree_paths: Dictionary = {}       ## npc_id -> path
var _known_item_ids: Dictionary = {}
var _known_recipe_ids: Dictionary = {}
var _placed_location_ids: Dictionary = {}
var _placed_npc_ids: Dictionary = {}
var _flags_set: Dictionary = {}
var _flags_read: Dictionary = {}       ## flag -> first path that reads it, for the warning message


func _run() -> void:
	_error_count = 0
	_warning_count = 0

	_load_known_items()
	_load_known_recipes()
	_scan_quests_and_trees(QUESTS_ROOT)
	_scan_scenes_for_placed_ids("res://")

	for quest in _quests:
		_validate_quest(quest)
	for npc_id in _trees_by_npc:
		_validate_tree(_trees_by_npc[npc_id])

	for flag in _flags_read:
		if not _flags_set.has(flag):
			_warn("flag '%s' is checked but never set anywhere — this branch can never trigger. First checked in: %s" % [flag, _flags_read[flag]])

	print("validate_quests_and_dialogue: %d quest(s), %d dialogue tree(s) checked — %d error(s), %d warning(s)." % [
		_quests.size(), _trees_by_npc.size(), _error_count, _warning_count
	])


func _error(message: String) -> void:
	_error_count += 1
	push_error("[Quest Validator] " + message)


func _warn(message: String) -> void:
	_warning_count += 1
	push_warning("[Quest Validator] " + message)


## --- Loading everything to cross-reference against ---

func _load_known_items() -> void:
	if FileAccess.file_exists(ITEM_CATALOG_PATH):
		var file := FileAccess.open(ITEM_CATALOG_PATH, FileAccess.READ)
		var paths: Variant = JSON.parse_string(file.get_as_text())
		file.close()
		if paths is Array:
			for item_path in paths:
				var item := load(item_path)
				if item is ItemData and item.id != "":
					_known_item_ids[item.id] = true
			return
	# No catalog built yet — fall back to a full scan, same as
	# InventoryManager itself does when the catalog is missing.
	_scan_for_items("res://resources/")


func _scan_for_items(path: String) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return
	for sub_dir in dir.get_directories():
		_scan_for_items(path.path_join(sub_dir))
	for file_name in dir.get_files():
		if not file_name.ends_with(".tres"):
			continue
		var resource := load(path.path_join(file_name))
		if resource is ItemData and resource.id != "":
			_known_item_ids[resource.id] = true


func _load_known_recipes() -> void:
	var dir := DirAccess.open(RECIPES_ROOT)
	if dir == null:
		return
	for file_name in dir.get_files():
		if not file_name.ends_with(".tres"):
			continue
		var recipe := load(RECIPES_ROOT.path_join(file_name)) as RecipeData
		if recipe and recipe.id != "":
			_known_recipe_ids[recipe.id] = true


func _scan_quests_and_trees(path: String) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return
	for sub_dir in dir.get_directories():
		_scan_quests_and_trees(path.path_join(sub_dir))
	for file_name in dir.get_files():
		if not file_name.ends_with(".tres"):
			continue
		var resource_path := path.path_join(file_name)
		var resource := load(resource_path)
		if resource is QuestData:
			_quests.append(resource)
			_quest_paths[resource] = resource_path
		elif resource is DialogueTreeData and resource.npc_id != "":
			_trees_by_npc[resource.npc_id] = resource
			_tree_paths[resource.npc_id] = resource_path


## Reads .tscn files as plain text for location_id/npc_id occurrences —
## a QuestLocationMarker/NPC only exists as a placed scene instance, not
## a standalone Resource, so there's nothing to load() the normal way.
func _scan_scenes_for_placed_ids(path: String) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return
	for sub_dir in dir.get_directories():
		if sub_dir.begins_with("."):
			continue
		_scan_scenes_for_placed_ids(path.path_join(sub_dir))
	for file_name in dir.get_files():
		if not file_name.ends_with(".tscn"):
			continue
		var text := FileAccess.get_file_as_string(path.path_join(file_name))
		for found_id in _extract_quoted_values(text, "location_id"):
			_placed_location_ids[found_id] = true
		for found_id in _extract_quoted_values(text, "npc_id"):
			_placed_npc_ids[found_id] = true


func _extract_quoted_values(text: String, property_name: String) -> Array[String]:
	var results: Array[String] = []
	var search_from := 0
	var needle := property_name + " = \""
	while true:
		var start := text.find(needle, search_from)
		if start == -1:
			break
		var value_start := start + needle.length()
		var value_end := text.find("\"", value_start)
		if value_end == -1:
			break
		results.append(text.substr(value_start, value_end - value_start))
		search_from = value_end + 1
	return results


## --- The actual checks ---

func _validate_quest(quest: QuestData) -> void:
	var path: String = _quest_paths[quest]
	if quest.id == "":
		_error("%s: QuestData has no id." % path)

	for i in quest.steps.size():
		var step: QuestStepData = quest.steps[i]
		var where := "%s (step %d, %s)" % [path, i + 1, QuestStepData.StepType.keys()[step.step_type]]

		for entry in step.items_given:
			_check_item_id(entry.get("item_id", ""), where)
		for entry in step.items_removed:
			_check_item_id(entry.get("item_id", ""), where)
		if step.sets_flag != "":
			_flags_set[step.sets_flag] = true

		match step.step_type:
			QuestStepData.StepType.TALK_TO_NPC:
				_check_npc_id(step.target_id, where)
			QuestStepData.StepType.DIALOGUE_CHOICE:
				_check_dialogue_choice(step.target_id, step.dialogue_line_id, step.choice_index, where)
			QuestStepData.StepType.GIVE_ITEM_TO_NPC:
				_check_npc_id(step.target_id, where)
				_check_item_id(step.item_id, where)
			QuestStepData.StepType.CRAFT_ITEM:
				if not _known_recipe_ids.has(step.target_id):
					_error("%s: no recipe with id '%s'." % [where, step.target_id])
			QuestStepData.StepType.GO_TO_LOCATION, QuestStepData.StepType.USE_ITEM_AT_LOCATION:
				if not _placed_location_ids.has(step.target_id):
					_error("%s: no QuestLocationMarker placed anywhere with location_id '%s'." % [where, step.target_id])
				if step.step_type == QuestStepData.StepType.USE_ITEM_AT_LOCATION:
					_check_item_id(step.item_id, where)
			QuestStepData.StepType.CUSTOM_ACTION:
				pass  # nothing to cross-reference — reported from arbitrary game code by design


func _check_item_id(item_id: String, where: String) -> void:
	if item_id != "" and not _known_item_ids.has(item_id):
		_error("%s: no item with id '%s'." % [where, item_id])


func _check_npc_id(npc_id: String, where: String) -> void:
	if npc_id == "":
		return
	if not _trees_by_npc.has(npc_id):
		_error("%s: no DialogueTreeData with npc_id '%s'." % [where, npc_id])


func _check_dialogue_choice(npc_id: String, line_id: String, choice_index: int, where: String) -> void:
	var tree: DialogueTreeData = _trees_by_npc.get(npc_id)
	if tree == null:
		_error("%s: no DialogueTreeData with npc_id '%s'." % [where, npc_id])
		return
	var line := tree.get_line(line_id)
	if line == null:
		_error("%s: npc '%s' has no dialogue line with id '%s'." % [where, npc_id, line_id])
		return
	if choice_index < 0 or choice_index >= line.choices.size():
		_error("%s: line '%s' on npc '%s' only has %d choice(s), but choice_index is %d." % [where, line_id, npc_id, line.choices.size(), choice_index])


func _validate_tree(tree: DialogueTreeData) -> void:
	var path: String = _tree_paths[tree.npc_id]

	if not _placed_npc_ids.has(tree.npc_id):
		_warn("%s: npc_id '%s' has a dialogue tree but isn't placed as an NPC anywhere — unreachable." % [path, tree.npc_id])

	if tree.entry_points.is_empty():
		_error("%s: no entry_points at all — this NPC can never start a conversation." % path)
	var has_unconditional_entry := false
	for entry in tree.entry_points:
		if entry.get("required_flag", "") == "" and entry.get("required_flag_absent", "") == "":
			has_unconditional_entry = true
		_check_line_exists(tree, entry.get("start_line_id", ""), path, "an entry point")
		if entry.get("required_flag", "") != "":
			_flags_read[entry["required_flag"]] = path
		if entry.get("required_flag_absent", "") != "":
			_flags_read[entry["required_flag_absent"]] = path
	if not has_unconditional_entry:
		_warn("%s: every entry point is flag-gated — if none apply yet, this NPC can't start a conversation. Consider an unconditional catch-all." % path)

	for line in tree.lines:
		if line.required_flag != "":
			_flags_read[line.required_flag] = path
		if line.required_flag_absent != "":
			_flags_read[line.required_flag_absent] = path
		if line.choices.is_empty():
			if line.next_line_id != "":
				_check_line_exists(tree, line.next_line_id, path, "line '%s'" % line.id)
		else:
			for choice in line.choices:
				if choice.sets_flag != "":
					_flags_set[choice.sets_flag] = true
				var next_id: String = choice.next_line_id
				if next_id != "":
					_check_line_exists(tree, next_id, path, "a choice on line '%s'" % line.id)


func _check_line_exists(tree: DialogueTreeData, line_id: String, path: String, context: String) -> void:
	if line_id == "":
		return
	if tree.get_line(line_id) == null:
		_error("%s: %s points at line '%s', which doesn't exist in this tree." % [path, context, line_id])
