@tool
extends EditorScript

## ONE-OFF EDITOR TOOL — not part of the game, never runs at runtime.
##
## HOW TO USE:
##   1. Open your library source scene (e.g. EnvironmentLibrarySource.tscn)
##      in the editor so it's the currently active/edited scene.
##   2. Open this script in the Script editor (double-click it in FileSystem).
##   3. Go to File > Run (or press Ctrl+Shift+X) with THIS script open.
##   4. Every MeshInstance3D in the currently open scene gets a
##      StaticBody3D + CollisionShape3D (trimesh) added as its child,
##      automatically — no manual per-node clicking needed.
##   5. Save the scene (Ctrl+S) afterward to keep the changes.
##
## Safe to re-run — it skips any MeshInstance3D that already has a
## StaticBody3D child, so running it twice won't create duplicates.

func _run() -> void:
	var scene_root := get_editor_interface().get_edited_scene_root()
	if scene_root == null:
		push_error("BatchAddCollision: no scene is currently open in the editor.")
		return

	var count := 0
	count = _process_node(scene_root, count)

	print("BatchAddCollision: added collision to %d mesh(es)." % count)
	print("Don't forget to save the scene (Ctrl+S) to keep these changes.")


func _process_node(node: Node, count: int) -> int:
	if node is MeshInstance3D:
		count = _add_collision_if_missing(node, count)

	for child in node.get_children():
		count = _process_node(child, count)

	return count


func _add_collision_if_missing(mesh_instance: MeshInstance3D, count: int) -> int:
	# Skip if it already has a StaticBody3D child (avoids duplicates on re-run).
	for child in mesh_instance.get_children():
		if child is StaticBody3D:
			return count

	if mesh_instance.mesh == null:
		push_warning("Skipping '%s' — no mesh assigned." % mesh_instance.name)
		return count

	var shape := mesh_instance.mesh.create_trimesh_shape()
	if shape == null:
		push_warning("Skipping '%s' — couldn't generate a trimesh shape." % mesh_instance.name)
		return count

	var static_body := StaticBody3D.new()
	static_body.name = "StaticBody3D"

	var collision_shape := CollisionShape3D.new()
	collision_shape.name = "CollisionShape3D"
	collision_shape.shape = shape

	mesh_instance.add_child(static_body)
	static_body.add_child(collision_shape)

	# Set owner so the new nodes actually get saved as part of the scene file
	# (required for anything added via script — without this they'd vanish
	# on save/reload).
	var scene_root := get_editor_interface().get_edited_scene_root()
	static_body.owner = scene_root
	collision_shape.owner = scene_root

	return count + 1
