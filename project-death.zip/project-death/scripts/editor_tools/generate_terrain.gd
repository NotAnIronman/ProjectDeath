@tool
extends EditorScript

## ONE-OFF EDITOR TOOL — generates a rough Minecraft-style heightmap terrain
## onto a GridMap using Perlin/simplex noise, purely as a placeholder so you
## can visualize scale/features before building a real hand-crafted map.
## Deliberately simple: flat ground tile + stacked cliff-block "columns" per
## height level, no smooth edge/corner pieces — blocky on purpose.
##
## HOW TO USE:
##   1. Select your GridMap node in the scene (the one with your terrain
##      MeshLibrary assigned) so it's the current editor selection.
##   2. Adjust the CONFIG section below if needed (item names must match
##      what's actually in your MeshLibrary — this defaults to the ones
##      found in Mesh_Library_Env.tres: "GroundGrass" and "CliffBlockStone").
##   3. Open this script, File > Run (Ctrl+Shift+X).
##   4. Save the scene afterward (Ctrl+S) to keep the generated cells.
##
## Safe to re-run — clears the GridMap first, so re-running with a new seed
## regenerates cleanly instead of stacking on top of the previous run.

# --- CONFIG ---
const WIDTH: int = 60          # cells along X
const DEPTH: int = 60          # cells along Z
const MAX_HEIGHT: int = 6      # tallest possible stack, in cells
const NOISE_SEED: int = 12345  # change this to get a different layout
const NOISE_FREQUENCY: float = 0.05  # lower = broader/smoother hills, higher = choppier

const GROUND_ITEM_NAME: String = "GroundGrass"
const CLIFF_ITEM_NAME: String = "CliffBlockStone"


func _run() -> void:
	var gridmap := _get_selected_gridmap()
	if gridmap == null:
		push_error("TerrainGenerator: select a GridMap node in the scene first.")
		return

	var mesh_lib: MeshLibrary = gridmap.mesh_library
	if mesh_lib == null:
		push_error("TerrainGenerator: selected GridMap has no MeshLibrary assigned.")
		return

	var ground_id := _find_item_id(mesh_lib, GROUND_ITEM_NAME)
	var cliff_id := _find_item_id(mesh_lib, CLIFF_ITEM_NAME)

	if ground_id == -1:
		push_error("TerrainGenerator: item '%s' not found in the MeshLibrary." % GROUND_ITEM_NAME)
		return
	if cliff_id == -1:
		push_error("TerrainGenerator: item '%s' not found in the MeshLibrary." % CLIFF_ITEM_NAME)
		return

	gridmap.clear()

	var noise := FastNoiseLite.new()
	noise.seed = NOISE_SEED
	noise.frequency = NOISE_FREQUENCY
	noise.noise_type = FastNoiseLite.TYPE_PERLIN

	var placed := 0
	for x in WIDTH:
		for z in DEPTH:
			var n: float = noise.get_noise_2d(x, z)  # roughly -1..1
			var normalized: float = (n + 1.0) * 0.5   # 0..1
			var height: int = int(normalized * MAX_HEIGHT)

			var cell_x := x - WIDTH / 2
			var cell_z := z - DEPTH / 2

			# Ground tile always at the base.
			gridmap.set_cell_item(Vector3i(cell_x, 0, cell_z), ground_id)
			placed += 1

			# Stack plain cliff blocks upward for elevation — blocky/simple
			# on purpose, no directional edge pieces.
			for y in range(1, height + 1):
				gridmap.set_cell_item(Vector3i(cell_x, y, cell_z), cliff_id)
				placed += 1

	print("TerrainGenerator: placed %d cells across a %dx%d area (seed %d). Save the scene to keep it." % [placed, WIDTH, DEPTH, NOISE_SEED])


func _get_selected_gridmap() -> GridMap:
	var selection := get_editor_interface().get_selection().get_selected_nodes()
	for node in selection:
		if node is GridMap:
			return node
	return null


func _find_item_id(mesh_lib: MeshLibrary, item_name: String) -> int:
	for id in mesh_lib.get_item_list():
		if mesh_lib.get_item_name(id) == item_name:
			return id
	return -1
