@tool
extends EditorScript

## Run this (open in the Script editor, press Run ▶) any time you add,
## rename, or remove a quest, NPC, location, or flag. It scans the whole
## Quests/ tree and regenerates four plain constant files under
## res://scripts/generated/ — QuestIDs, NpcIDs, LocationIDs, FlagIDs.
##
## WHAT THIS SOLVES: referencing an id from GDSCRIPT CODE. Instead of
## typing "bob_farming_intro" by hand (and hoping you spelled it the same
## way everywhere), write QuestIDs.BOB_FARMING_INTRO — your editor
## autocompletes it, and a typo is now an undefined-identifier COMPILE
## ERROR instead of a silent runtime no-op three files away.
##
## WHAT THIS DOESN'T SOLVE: typing an id into a .tres file's Inspector
## field (target_id, sets_flag, npc_id, etc. are still plain text boxes —
## Godot's default Inspector doesn't autocomplete against arbitrary
## GDScript constants). validate_quests_and_dialogue.gd (the other new
## tool) is what catches a typo THERE — it cross-references every id
## actually used against every id that actually exists and tells you
## exactly which file has the mismatch. A custom Inspector dropdown for
## these specific fields is a real, buildable next step if the Inspector-
## typing side of this ever becomes the bigger pain — flagged, not built
## here, since it's a genuinely separate chunk of work from this file.

const QUESTS_ROOT := "res://resources/Quests/"
const OUTPUT_DIR := "res://scripts/generated/"

var quest_ids: Dictionary = {}     ## id -> true
var npc_ids: Dictionary = {}
var location_ids: Dictionary = {}
var flag_ids: Dictionary = {}


func _run() -> void:
	quest_ids.clear()
	npc_ids.clear()
	location_ids.clear()
	flag_ids.clear()

	_scan(QUESTS_ROOT)
	_scan_locations_from_scenes("res://")

	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(OUTPUT_DIR))
	_write_registry("QuestIDs", "quest_ids.gd", quest_ids)
	_write_registry("NpcIDs", "npc_ids.gd", npc_ids)
	_write_registry("LocationIDs", "location_ids.gd", location_ids)
	_write_registry("FlagIDs", "flag_ids.gd", flag_ids)

	print("generate_id_registry: %d quests, %d npcs, %d locations, %d flags." % [
		quest_ids.size(), npc_ids.size(), location_ids.size(), flag_ids.size()
	])


func _scan(path: String) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return
	for sub_dir in dir.get_directories():
		_scan(path.path_join(sub_dir))
	for file_name in dir.get_files():
		if not file_name.ends_with(".tres"):
			continue
		var resource := load(path.path_join(file_name))
		if resource is QuestData:
			_collect_from_quest(resource)
		elif resource is DialogueTreeData:
			_collect_from_tree(resource)


func _collect_from_quest(quest: QuestData) -> void:
	if quest.id != "":
		quest_ids[quest.id] = true
	for step in quest.steps:
		if step.sets_flag != "":
			flag_ids[step.sets_flag] = true
		match step.step_type:
			QuestStepData.StepType.GO_TO_LOCATION, QuestStepData.StepType.USE_ITEM_AT_LOCATION:
				if step.target_id != "":
					location_ids[step.target_id] = true
			QuestStepData.StepType.TALK_TO_NPC, QuestStepData.StepType.DIALOGUE_CHOICE, QuestStepData.StepType.GIVE_ITEM_TO_NPC:
				if step.target_id != "":
					npc_ids[step.target_id] = true


func _collect_from_tree(tree: DialogueTreeData) -> void:
	if tree.npc_id != "":
		npc_ids[tree.npc_id] = true
	for line in tree.lines:
		if line.required_flag != "":
			flag_ids[line.required_flag] = true
		if line.required_flag_absent != "":
			flag_ids[line.required_flag_absent] = true
		for choice in line.choices:
			if choice.sets_flag != "":
				flag_ids[choice.sets_flag] = true
	for entry in tree.entry_points:
		if entry.get("required_flag", "") != "":
			flag_ids[entry["required_flag"]] = true
		if entry.get("required_flag_absent", "") != "":
			flag_ids[entry["required_flag_absent"]] = true


## location_id only exists on placed SCENE instances (QuestLocationMarker),
## not on a standalone Resource — so this reads .tscn files as plain text
## rather than the Resource-loading approach above. Same pragmatic
## technique used for every "does X actually exist somewhere in the
## world" check this project does elsewhere.
func _scan_locations_from_scenes(path: String) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return
	for sub_dir in dir.get_directories():
		if sub_dir.begins_with("."):
			continue
		_scan_locations_from_scenes(path.path_join(sub_dir))
	for file_name in dir.get_files():
		if not file_name.ends_with(".tscn"):
			continue
		var text := FileAccess.get_file_as_string(path.path_join(file_name))
		for found_id in _extract_quoted_values(text, "location_id"):
			location_ids[found_id] = true


func _extract_quoted_values(text: String, property_name: String) -> Array[String]:
	var results: Array[String] = []
	var search_from := 0
	var needle := property_name + " = \""
	while true:
		var start := text.find(needle, search_from)
		if start == -1:
			break
		var value_start := start + needle.length()
		var value_end := text.find("\"", value_start)
		if value_end == -1:
			break
		results.append(text.substr(value_start, value_end - value_start))
		search_from = value_end + 1
	return results


func _write_registry(class_name_str: String, file_name: String, ids: Dictionary) -> void:
	var keys: Array = ids.keys()
	keys.sort()

	var lines: Array[String] = [
		"## AUTO-GENERATED by scripts/editor_tools/generate_id_registry.gd — do not hand-edit.",
		"## Run that tool any time you add/rename a quest, NPC, location, or flag.",
		"class_name " + class_name_str,
		"",
	]
	for id in keys:
		lines.append("const %s := \"%s\"" % [_to_constant_name(id), id])

	var file := FileAccess.open(OUTPUT_DIR.path_join(file_name), FileAccess.WRITE)
	if file == null:
		push_error("generate_id_registry: could not open %s for writing." % OUTPUT_DIR.path_join(file_name))
		return
	file.store_string("\n".join(lines) + "\n")
	file.close()


## "bob_farming_intro" -> "BOB_FARMING_INTRO". Any character outside
## [A-Z0-9_] becomes an underscore so an id with spaces/punctuation still
## produces a valid constant name instead of a parse error in the
## generated file. A leading digit also gets a "_" prefix, since GDScript
## identifiers can't start with one.
func _to_constant_name(id: String) -> String:
	var regex := RegEx.new()
	regex.compile("[^A-Z0-9_]")
	var result := regex.sub(id.to_upper(), "_", true)
	if result != "" and result[0].is_valid_int():
		result = "_" + result
	return result
