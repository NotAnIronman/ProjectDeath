extends RefCounted
class_name QuestBundle

## One quest folder: its QuestData (Steps/*.tres) and DialogueTreeData
## (Dialogue/*.tres). Loaded/saved as REAL Resource objects via
## ResourceLoader/ResourceSaver — since QuestBuilder shares the exact
## same script files at the exact same res:// paths as the game project
## (see scripts/systems/), these ARE the literal resource types the game
## loads. There is no translation layer; save() here writes the same
## file format the game already reads.

var quest_path: String = ""
var dialogue_path: String = ""
var quest: QuestData = null
var dialogue_tree: DialogueTreeData = null

## Node id ("step_0", "line_bob_intro", "choice_bob_intro_0") -> Vector2
## graph position. Saved as a sidecar JSON next to the quest file
## (quest.tres.layout.json) — deliberately NOT part of the actual
## game-facing .tres files, so the game/plugin never needs to know this
## exists, and a hand-edited .tres in the Godot Inspector never has to
## carry graph-editor-only data along with it.
var layout: Dictionary = {}


static func create_new(quest_folder: String, quest_id: String, display_name: String) -> QuestBundle:
	var bundle := QuestBundle.new()
	var steps_dir := quest_folder.path_join("Steps")
	var dialogue_dir := quest_folder.path_join("Dialogue")
	DirAccess.make_dir_recursive_absolute(steps_dir)
	DirAccess.make_dir_recursive_absolute(dialogue_dir)

	bundle.quest_path = steps_dir.path_join("quest.tres")
	bundle.dialogue_path = dialogue_dir.path_join("dialogue.tres")

	bundle.quest = QuestData.new()
	bundle.quest.id = quest_id
	bundle.quest.display_name = display_name

	bundle.dialogue_tree = DialogueTreeData.new()
	bundle.dialogue_tree.npc_id = quest_id  # sensible starting point, fully editable afterward

	return bundle


## Returns null (with an error printed) if quest_tres_path doesn't load
## as a real QuestData — most likely cause: the target project's copy of
## quest_step_data.gd/quest_data.gd has diverged from QuestBuilder's own
## copy under scripts/systems/. Keep those in sync by hand if the game's
## schema ever changes; there's no automatic sync (a small, deliberate
## trade-off for not needing a shared external dependency between two
## separate Godot projects).
static func open(quest_tres_path: String) -> QuestBundle:
	var bundle := QuestBundle.new()
	bundle.quest_path = quest_tres_path

	var loaded_quest: Variant = ResourceLoader.load(quest_tres_path, "", ResourceLoader.CACHE_MODE_IGNORE)
	if not (loaded_quest is QuestData):
		push_error("QuestBundle: '%s' did not load as a QuestData. Is scripts/systems/ in sync with the game project?" % quest_tres_path)
		return null
	bundle.quest = loaded_quest

	# Convention: Dialogue/dialogue.tres lives alongside Steps/quest.tres
	# in the same quest folder (NPCs/Dialogue/Steps/Locations layout).
	var quest_folder := quest_tres_path.get_base_dir().get_base_dir()
	var likely_dialogue_path := quest_folder.path_join("Dialogue/dialogue.tres")
	bundle.dialogue_path = likely_dialogue_path
	if FileAccess.file_exists(likely_dialogue_path):
		var loaded_tree: Variant = ResourceLoader.load(likely_dialogue_path, "", ResourceLoader.CACHE_MODE_IGNORE)
		if loaded_tree is DialogueTreeData:
			bundle.dialogue_tree = loaded_tree

	if bundle.dialogue_tree == null:
		bundle.dialogue_tree = DialogueTreeData.new()

	bundle._load_layout()
	return bundle


func save() -> bool:
	DirAccess.make_dir_recursive_absolute(quest_path.get_base_dir())
	var quest_err := ResourceSaver.save(quest, quest_path)
	if quest_err != OK:
		push_error("QuestBundle: failed to save quest to '%s' (error %d)." % [quest_path, quest_err])
		return false

	DirAccess.make_dir_recursive_absolute(dialogue_path.get_base_dir())
	var dialogue_err := ResourceSaver.save(dialogue_tree, dialogue_path)
	if dialogue_err != OK:
		push_error("QuestBundle: failed to save dialogue tree to '%s' (error %d)." % [dialogue_path, dialogue_err])
		return false

	_save_layout()
	return true


func _layout_path() -> String:
	return quest_path + ".layout.json"


func _load_layout() -> void:
	var path := _layout_path()
	if not FileAccess.file_exists(path):
		return
	var file := FileAccess.open(path, FileAccess.READ)
	var data: Variant = JSON.parse_string(file.get_as_text())
	file.close()
	if data is Dictionary:
		for key in data:
			var pos: Array = data[key]
			if pos.size() >= 2:
				layout[key] = Vector2(pos[0], pos[1])


func _save_layout() -> void:
	var data: Dictionary = {}
	for key in layout:
		var pos: Vector2 = layout[key]
		data[key] = [pos.x, pos.y]
	var file := FileAccess.open(_layout_path(), FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(data, "\t"))
		file.close()
