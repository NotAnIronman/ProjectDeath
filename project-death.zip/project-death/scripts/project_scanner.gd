extends RefCounted
class_name ProjectScanner

## Scans a TARGET GAME PROJECT folder (Project Death itself, pointed at
## via Settings) for every id QuestBuilder needs to offer as a
## suggestion: NPCs, locations, items, recipes, skills, flags, quests.
##
## Deliberately reads .tres/.tscn files as PLAIN TEXT (regex extraction)
## rather than using Godot's Resource loader — this is the same
## technique addons/quest_tools/id_scanner.gd uses in the game project
## itself, chosen here for an additional reason specific to QuestBuilder:
## raw file reads via FileAccess work reliably regardless of whether
## this app is running from source or as an exported standalone binary,
## whereas loading a foreign project's Resources through ResourceLoader
## is a shakier guarantee for a cross-project tool like this. This is
## also why it only needs to UNDERSTAND text patterns, not actually
## execute any of the game's scripts.

var npc_ids: Array[String] = []
var location_ids: Array[String] = []
var flag_ids: Array[String] = []
var quest_ids: Array[String] = []
var item_ids: Array[String] = []
var recipe_ids: Array[String] = []
var skill_ids: Array[String] = ["herbalism", "woodcutting", "spiritkeeping", "mining", "foraging", "farming", "fishing", "cooking"]


func scan(project_root: String) -> void:
	var npc_set: Dictionary = {}
	var location_set: Dictionary = {}
	var flag_set: Dictionary = {}
	var quest_set: Dictionary = {}
	var item_set: Dictionary = {}
	var recipe_set: Dictionary = {}

	_scan_quests(project_root.path_join("resources/Quests"), npc_set, location_set, flag_set, quest_set)
	_scan_for_id_field(project_root.path_join("resources/Crafting/recipes"), recipe_set)
	_scan_scenes_for_locations(project_root, location_set, npc_set)
	_scan_items(project_root, item_set)

	npc_ids = _sorted(npc_set)
	location_ids = _sorted(location_set)
	flag_ids = _sorted(flag_set)
	quest_ids = _sorted(quest_set)
	item_ids = _sorted(item_set)
	recipe_ids = _sorted(recipe_set)


func _sorted(d: Dictionary) -> Array[String]:
	var keys: Array[String] = []
	for k in d.keys():
		keys.append(k)
	keys.sort()
	return keys


## Scans every QuestData/DialogueTreeData-shaped .tres under Quests/,
## extracting the ids they reference (NOT loading them as real Resource
## objects — see this file's own header for why).
func _scan_quests(path: String, npc_set: Dictionary, location_set: Dictionary, flag_set: Dictionary, quest_set: Dictionary) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return
	for sub_dir in dir.get_directories():
		_scan_quests(path.path_join(sub_dir), npc_set, location_set, flag_set, quest_set)
	for file_name in dir.get_files():
		if not file_name.ends_with(".tres"):
			continue
		var text := FileAccess.get_file_as_string(path.path_join(file_name))
		if text.find("script_class=\"QuestData\"") != -1:
			for v in _extract_all(text, "id"):
				quest_set[v] = true
			for v in _extract_all(text, "target_id"):
				# Could be an npc, recipe, or location id depending on
				# step_type — offering it under both npc/location costs
				# nothing (an id that's actually a recipe just won't
				# match anything real when someone tries to use it there).
				npc_set[v] = true
				location_set[v] = true
			for v in _extract_all(text, "sets_flag"):
				flag_set[v] = true
		elif text.find("script_class=\"DialogueTreeData\"") != -1:
			for v in _extract_all(text, "npc_id"):
				npc_set[v] = true
			for v in _extract_all(text, "required_flag"):
				flag_set[v] = true
			for v in _extract_all(text, "required_flag_absent"):
				flag_set[v] = true
			for v in _extract_all(text, "sets_flag"):
				flag_set[v] = true
			for v in _extract_all(text, "starts_quest"):
				quest_set[v] = true


func _scan_scenes_for_locations(path: String, location_set: Dictionary, npc_set: Dictionary) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return
	for sub_dir in dir.get_directories():
		if sub_dir.begins_with("."):
			continue
		_scan_scenes_for_locations(path.path_join(sub_dir), location_set, npc_set)
	for file_name in dir.get_files():
		if not file_name.ends_with(".tscn"):
			continue
		var text := FileAccess.get_file_as_string(path.path_join(file_name))
		for v in _extract_all(text, "location_id"):
			location_set[v] = true
		for v in _extract_all(text, "npc_id"):
			npc_set[v] = true


## Prefers the game project's own prebuilt res://data/item_catalog.json
## (built by its build_item_catalog.gd tool) — pure JSON/text, no
## Resource loading needed, and it's already the authoritative list. Only
## falls back to a heuristic .tres scan if that catalog doesn't exist,
## since matching every ItemData SUBCLASS (CropData, SeedData, ToolData,
## StorageItemData, ...) by script name here would mean this file staying
## in lockstep with the game's class hierarchy — the catalog already
## solves that problem once, correctly, in the game project itself.
func _scan_items(project_root: String, item_set: Dictionary) -> void:
	var catalog_path := project_root.path_join("data/item_catalog.json")
	if FileAccess.file_exists(catalog_path):
		var file := FileAccess.open(catalog_path, FileAccess.READ)
		var paths: Variant = JSON.parse_string(file.get_as_text())
		file.close()
		if paths is Array:
			for item_path in paths:
				var full_path: String = project_root.path_join(String(item_path).trim_prefix("res://"))
				var text := FileAccess.get_file_as_string(full_path)
				var ids := _extract_all(text, "id")
				if not ids.is_empty():
					item_set[ids[0]] = true
			return

	push_warning("ProjectScanner: no item_catalog.json found — falling back to a slower heuristic scan. Run build_item_catalog.gd in the game project for a faster, more accurate scan next time.")
	_scan_items_heuristic(project_root.path_join("resources"), item_set)


func _scan_items_heuristic(path: String, item_set: Dictionary) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return
	for sub_dir in dir.get_directories():
		_scan_items_heuristic(path.path_join(sub_dir), item_set)
	for file_name in dir.get_files():
		if not file_name.ends_with(".tres"):
			continue
		var text := FileAccess.get_file_as_string(path.path_join(file_name))
		# Broad net: anything with both an id and a display_name field is
		# LIKELY an item (also matches a few non-item types, like quests —
		# an imperfect but honest fallback, hence the warning above
		# pointing at the real fix).
		if text.find("id = \"") != -1 and text.find("display_name = \"") != -1 and text.find("icon = ExtResource") != -1:
			var ids := _extract_all(text, "id")
			if not ids.is_empty():
				item_set[ids[0]] = true


func _scan_for_id_field(path: String, out_set: Dictionary) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return
	for file_name in dir.get_files():
		if not file_name.ends_with(".tres"):
			continue
		var text := FileAccess.get_file_as_string(path.path_join(file_name))
		for v in _extract_all(text, "id"):
			out_set[v] = true


## Line-anchored `key = "value"` extraction — matches the exact
## convention every .tres file in this project uses, and avoids the
## classic "target_id" containing "id" substring-match bug.
func _extract_all(text: String, key: String) -> Array[String]:
	var results: Array[String] = []
	var regex := RegEx.new()
	regex.compile("(?m)^" + key + " = \"([^\"]*)\"")
	for result in regex.search_all(text):
		var value := result.get_string(1)
		if value != "":
			results.append(value)
	return results
