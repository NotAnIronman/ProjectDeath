extends Node

## TEMPORARY DEBUG TOOL — attach this to any Node in World1.tscn.
## Gives the player some starter seeds on scene start so you can test
## planting without a shop/UI system yet. Delete this node (and script)
## once real seed acquisition (shop, gathering, quest rewards, etc) exists.

## Fill this with seed_id -> quantity, e.g. {"seed_dying_sage": 3, "seed_mugwort": 3}
@export var starting_seeds: Dictionary = {}


func _ready() -> void:
	for seed_id in starting_seeds.keys():
		var qty: int = starting_seeds[seed_id]
		InventoryManager.add_item(seed_id, qty)
	print("Debug starter seeds granted: ", starting_seeds)
