extends Control
class_name DebugTabQuests

## Live view of quest/dialogue state — every active quest's current
## step, completed quests, and every flag currently set. Built directly
## in response to needing to SEE this instead of guessing at it from
## symptoms — flags in particular are invisible anywhere else once set.

var _status_label: Label
var _quests_list: RichTextLabel
var _flags_list: RichTextLabel

var _refresh_timer: float = 0.0
const REFRESH_INTERVAL := 0.5


func _ready() -> void:
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	_build_ui()


func on_tab_shown() -> void:
	_refresh()


func _process(delta: float) -> void:
	if not is_visible_in_tree():
		return
	_refresh_timer += delta
	if _refresh_timer >= REFRESH_INTERVAL:
		_refresh_timer = 0.0
		_refresh()


func _build_ui() -> void:
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(vbox)

	_status_label = Label.new()
	_status_label.text = "..."
	_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	vbox.add_child(_status_label)
	vbox.add_child(HSeparator.new())

	var quests_header := Label.new()
	quests_header.text = "Quests"
	quests_header.add_theme_font_size_override("font_size", 14)
	vbox.add_child(quests_header)

	_quests_list = RichTextLabel.new()
	_quests_list.bbcode_enabled = true
	_quests_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_quests_list.custom_minimum_size = Vector2(0, 200)
	vbox.add_child(_quests_list)

	vbox.add_child(HSeparator.new())

	var flags_row := HBoxContainer.new()
	vbox.add_child(flags_row)

	var flags_header := Label.new()
	flags_header.text = "Flags currently set"
	flags_header.add_theme_font_size_override("font_size", 14)
	flags_header.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	flags_row.add_child(flags_header)

	var clear_all_button := Button.new()
	clear_all_button.text = "Clear ALL flags (debug only)"
	clear_all_button.tooltip_text = "Wipes every flag DialogueManager knows about. For testing dialogue branches from scratch — does NOT affect quest progress, items, or anything else."
	clear_all_button.pressed.connect(_on_clear_all_flags_pressed)
	flags_row.add_child(clear_all_button)

	_flags_list = RichTextLabel.new()
	_flags_list.bbcode_enabled = true
	_flags_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_flags_list.custom_minimum_size = Vector2(0, 200)
	vbox.add_child(_flags_list)


func _refresh() -> void:
	_status_label.text = "%d active quest(s), %d completed, %d flag(s) set." % [
		QuestManager.active_quests.size(), QuestManager.completed_quests.size(), DialogueManager.flags.size()
	]

	var quest_lines: Array[String] = []
	for quest_id in QuestManager.active_quests:
		var quest: QuestData = QuestManager.quest_defs.get(quest_id)
		var step := QuestManager.get_current_step(quest_id)
		var step_index: int = QuestManager.active_quests[quest_id]
		quest_lines.append("[color=#ffe699][b]%s[/b][/color] (active) — step %d/%d: %s" % [
			quest.display_name if quest else quest_id, step_index + 1,
			quest.steps.size() if quest else 0, step.log_description if step and step.log_description != "" else "..."
		])
	for quest_id in QuestManager.completed_quests:
		var quest: QuestData = QuestManager.quest_defs.get(quest_id)
		quest_lines.append("[color=#99e699]✓ %s[/color] (completed)" % (quest.display_name if quest else quest_id))
	_quests_list.text = "\n".join(quest_lines) if not quest_lines.is_empty() else "No quests active or completed yet."

	var flag_names: Array = DialogueManager.flags.keys()
	flag_names.sort()
	var flag_lines: Array[String] = []
	for flag_name in flag_names:
		flag_lines.append(String(flag_name))
	_flags_list.text = "\n".join(flag_lines) if not flag_lines.is_empty() else "No flags set yet."


func _on_clear_all_flags_pressed() -> void:
	DialogueManager.flags.clear()
	_refresh()
