extends Control
class_name DebugTabTimeWeather

## DEBUG TAB — "Time & Weather". Lets you skip days/seasons and force
## weather/luck directly instead of waiting real-world minutes per
## in-game day — exists specifically so Season Cycle, Weather, and Daily
## Luck can actually be tested live at the pace the rest of this project
## gets tested at, rather than requiring hours of idle waiting per test.

var _status_label: Label


func _ready() -> void:
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	_build_ui()


func on_tab_shown() -> void:
	_refresh()


func _build_ui() -> void:
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	add_child(vbox)

	_status_label = Label.new()
	_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	vbox.add_child(_status_label)
	vbox.add_child(HSeparator.new())

	# --- Day/Season skipping ---
	var day_row := HBoxContainer.new()
	day_row.add_theme_constant_override("separation", 8)
	vbox.add_child(day_row)

	var skip_day_btn := Button.new()
	skip_day_btn.text = "Skip to Next Day"
	skip_day_btn.pressed.connect(func():
		DayNightManager.debug_skip_to_next_day()
		_refresh()
	)
	day_row.add_child(skip_day_btn)

	var skip_season_btn := Button.new()
	skip_season_btn.text = "Skip 1 Season (%d days)" % SeasonManager.DAYS_PER_SEASON
	skip_season_btn.pressed.connect(func():
		for i in SeasonManager.DAYS_PER_SEASON:
			DayNightManager.debug_skip_to_next_day()
		_refresh()
	)
	day_row.add_child(skip_season_btn)

	vbox.add_child(HSeparator.new())

	# --- Weather forcing ---
	vbox.add_child(_label("Force Weather"))
	var weather_row := HBoxContainer.new()
	weather_row.add_theme_constant_override("separation", 8)
	vbox.add_child(weather_row)

	var clear_btn := Button.new()
	clear_btn.text = "☀ Clear"
	clear_btn.pressed.connect(func():
		WeatherManager.debug_set_weather(WeatherManager.WeatherType.CLEAR)
		_refresh()
	)
	weather_row.add_child(clear_btn)

	var rain_btn := Button.new()
	rain_btn.text = "🌧 Rain (auto-waters crops)"
	rain_btn.pressed.connect(func():
		WeatherManager.debug_set_weather(WeatherManager.WeatherType.RAIN)
		_refresh()
	)
	weather_row.add_child(rain_btn)

	vbox.add_child(HSeparator.new())

	# --- Luck forcing ---
	vbox.add_child(_label("Force Luck"))
	var luck_row := HBoxContainer.new()
	luck_row.add_theme_constant_override("separation", 6)
	vbox.add_child(luck_row)

	for luck_value in range(LuckManager.MIN_LUCK, LuckManager.MAX_LUCK + 1):
		var btn := Button.new()
		btn.text = LuckManager.LUCK_LABELS.get(luck_value, str(luck_value))
		btn.pressed.connect(func(value=luck_value):
			LuckManager.debug_set_luck(value)
			_refresh()
		)
		luck_row.add_child(btn)


func _label(text: String) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 12)
	l.modulate = Color(1, 1, 1, 0.6)
	return l


func _refresh() -> void:
	_status_label.text = (
		"%s\n" +
		"Weather: %s\n" +
		"Luck: %s"
	) % [
		SeasonManager.get_display_string(),
		"🌧 Rain" if WeatherManager.is_raining() else "☀ Clear",
		LuckManager.get_luck_label(),
	]
