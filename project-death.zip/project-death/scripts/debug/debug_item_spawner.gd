extends CanvasLayer
class_name DebugMenu

## PERMANENT DEBUG TOOL — attach to a Node in World.tscn (this is the same
## node/file the old standalone "Item Spawner" panel used; kept at this
## path/uid so the existing World.tscn wiring didn't need to change).
##
## Press F1 to toggle a tabbed debug panel. This is meant to be a
## permanent, ever-growing system through the rest of development, not a
## one-off tool — every new feature that needs a debug hook gets a new
## tab here rather than a one-off scattered debug script.
##
## ADDING A NEW TAB: create a Control script under scripts/debug/debug_tabs/
## that builds its own UI in _ready() (see debug_tab_items.gd or
## debug_tab_world_streaming.gd for the pattern), optionally implement
## on_tab_shown() if it needs to refresh when switched to, then add one
## line to TAB_SCRIPTS below. That's the entire integration — tabs don't
## need to know about each other or about DebugMenu's internals.

const TAB_SCRIPTS: Array[Dictionary] = [
	{"title": "Items", "script": preload("res://scripts/debug/debug_tabs/debug_tab_items.gd")},
	{"title": "World Streaming", "script": preload("res://scripts/debug/debug_tabs/debug_tab_world_streaming.gd")},
	{"title": "Time & Weather", "script": preload("res://scripts/debug/debug_tabs/debug_tab_time_weather.gd")},
	{"title": "Quests", "script": preload("res://scripts/debug/debug_tabs/debug_tab_quests.gd")},
]

var panel: PanelContainer
var tab_container: TabContainer
var _ui_layer: Node
var _tabs: Array[Control] = []


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build_ui()
	call_deferred("_wire_tile_system")


func _wire_tile_system() -> void:
	_ui_layer = get_tree().get_first_node_in_group("ui_layer")
	if _ui_layer and _ui_layer.has_method("register_tile_panel"):
		_ui_layer.register_tile_panel(panel)
	else:
		push_warning("DebugMenu: no UILayer found to register with the tile layout system — panel will just sit at its default position.")


func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_F1:
			panel.visible = not panel.visible
			if panel.visible:
				_on_tab_changed(tab_container.current_tab)
			_request_tile_layout()
		elif event.keycode == KEY_ESCAPE and panel.visible:
			panel.visible = false
			_request_tile_layout()
			get_viewport().set_input_as_handled()


func _request_tile_layout() -> void:
	if _ui_layer and _ui_layer.has_method("request_tile_layout"):
		_ui_layer.request_tile_layout()


func _build_ui() -> void:
	panel = PanelContainer.new()
	panel.custom_minimum_size = Vector2(620, 640)
	panel.visible = false
	add_child(panel)
	panel.add_to_group("blocking_ui_panels")  # see UILayer.BLOCKING_UI_GROUP

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 16)
	margin.add_theme_constant_override("margin_right", 16)
	margin.add_theme_constant_override("margin_top", 16)
	margin.add_theme_constant_override("margin_bottom", 16)
	panel.add_child(margin)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	margin.add_child(vbox)

	var title := Label.new()
	title.text = "Debug Menu (F1 to close)"
	title.add_theme_font_size_override("font_size", 18)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)

	tab_container = TabContainer.new()
	tab_container.custom_minimum_size = Vector2(580, 560)
	tab_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tab_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	tab_container.tab_changed.connect(_on_tab_changed)
	vbox.add_child(tab_container)

	for entry in TAB_SCRIPTS:
		var tab: Control = entry["script"].new()
		tab.name = entry["title"]
		tab.custom_minimum_size = Vector2(560, 520)
		tab_container.add_child(tab)
		_tabs.append(tab)


func _on_tab_changed(index: int) -> void:
	if index < 0 or index >= _tabs.size():
		return
	var tab := _tabs[index]
	if tab.has_method("on_tab_shown"):
		tab.on_tab_shown()
