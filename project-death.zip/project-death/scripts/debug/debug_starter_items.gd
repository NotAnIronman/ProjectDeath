extends Node

## TEMPORARY DEBUG TOOL — attach this to any Node in World.tscn.
## Gives the player starting items on scene start, for testing without a
## shop/gathering system yet. Works for ANY item type (seeds, tools,
## crop yields, anything with an ItemData resource) — not seed-specific.
## Delete this node (and script) once real item acquisition exists.
##
## Fill this with item_id -> quantity, e.g.
##   {"seed_dying_sage": 3, "shovel": 1, "mugwart_berries": 5}
##
## If an item doesn't show up, check the Output panel — this prints a
## clear reason for every failure (most commonly: the item_id doesn't
## exactly match the "Id" field on an ItemData .tres in resources/items/,
## or that .tres isn't in that folder at all).

@export var starting_items: Dictionary = {}


func _ready() -> void:
	# Deferred so InventoryManager/InventorySlotManager have both finished
	# their own _ready() (loading all ItemData defs) before we try adding.
	call_deferred("_grant_starting_items")


func _grant_starting_items() -> void:
	for item_id in starting_items.keys():
		var qty: int = starting_items[item_id]

		if not InventoryManager.item_defs.has(item_id):
			push_error("DebugStarterItems: '%s' FAILED — no ItemData with that exact id found in resources/items/. Check for typos or a misplaced .tres file." % item_id)
			continue

		var result := InventoryManager.add_item(item_id, qty)
		if result == -1:
			push_error("DebugStarterItems: '%s' FAILED to add (see InventoryManager warning above)." % item_id)
		else:
			var def: ItemData = InventoryManager.item_defs[item_id]
			print("DebugStarterItems: granted %d x %s" % [qty, def.display_name])
