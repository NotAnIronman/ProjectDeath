extends ItemData
class_name StorageItemData

## Defines a placeable storage container TYPE — a wooden crate, seed
## cabinet, potion shelf, etc. Placed/picked up exactly like any other
## placeable item (is_placeable=true + placed_scene, inherited from
## ItemData, same as every other piece of furniture) — this just adds the
## slot count and what it's allowed to hold.
##
## "Upgraded" storage (a bigger/better version of a container) = another
## StorageItemData .tres with a larger slot_count — same tiering pattern
## as RestorationToolData. There's no in-place "upgrade this specific
## placed crate" action yet — pick up the current one, place the new tier
## instead. A true in-place upgrade (keeping contents, swapping the type)
## is a reasonable follow-up once you know it's worth the extra UI.

## How many item slots this container has.
@export var slot_count: int = 12

## If non-empty, ONLY items in one of these categories can be deposited.
## Leave empty for no category restriction (still subject to seeds_only
## below if that's set).
@export var allowed_categories: Array[ItemData.ItemCategory] = []

## Special-cased rather than folded into allowed_categories, since seeds
## are their own ItemData subclass (SeedData) and aren't distinguished by
## ItemCategory alone in this project.
@export var seeds_only: bool = false
