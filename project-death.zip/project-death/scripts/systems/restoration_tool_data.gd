extends ItemData
class_name RestorationToolData

## An equippable tool that restores withered ground back to plantable
## soil when used on an unrestored FarmPlot. Player equips this in the
## hotbar and interacts with the plot the same "hold X, press E" way every
## other tool-gated interaction in the game already works — see
## FarmPlot._try_restore_from_player_selection().
##
## "Upgraded restoration methods" (per design doc) = create additional
## RestorationToolData .tres resources with a larger restore_radius,
## lower/no cost_item requirement, and/or a lower required_spiritkeeping_level
## — no code changes needed for a new tier, same pattern as adding a new
## crop or resource node.

## How large an area gets restored around the plot when used. Actual
## in-world radius — a FarmPlot's own footprint is small, so this mostly
## matters if you want one use to also restore ground beyond just this
## specific plot.
@export var restore_radius: float = 3.0

## Which texture the restored ground becomes — matches
## TerrainRestoration.GOOD_DIRT_TEXTURE_ID (0) by default; exposed here in
## case a future tool restores to a different ground type.
@export var restored_texture_id: int = 0

## Minimum Spiritkeeping level required to use this tool at all.
@export var required_spiritkeeping_level: int = 1

## Optional consumable cost beyond the tool itself, e.g. "purified_water".
## Leave empty for a tool that costs nothing extra to use (just needs to
## be equipped).
@export var cost_item_id: String = ""
@export var cost_item_amount: int = 1

## XP granted to Spiritkeeping on a successful restoration. Placeholder
## balance value — tune once you have a sense of your XP curve in practice.
@export var xp_granted: int = 10
