extends ItemData
class_name SeedData

## A specialized Item that can be planted. Create one .tres per seed in
## res://resources/items/ alongside your regular ItemData files — since this
## extends ItemData, InventoryManager's loader picks it up automatically,
## no changes needed there.
##
## Naming convention suggestion: "seed_<crop_id>.tres" e.g. "seed_dying_sage.tres"

## The CropData this seed grows into when planted.
@export var crop_data: CropData
