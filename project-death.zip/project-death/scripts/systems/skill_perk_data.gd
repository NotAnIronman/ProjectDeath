extends Resource
class_name SkillPerkData

## A bonus unlocked at a given level in a given skill. Deliberately
## generic — this system doesn't hardcode what a perk DOES; it just
## accumulates named modifier values that other systems opt into reading
## (see SkillManager.get_modifier_total()). Adding a new kind of perk
## EFFECT never needs new code here — only a new modifier_key that
## whatever system cares about it checks for.

@export var skill_id: String = ""
@export var required_level: int = 1
@export var display_name: String = ""
@export var description: String = ""

## The key other systems check via SkillManager.get_modifier_total(key).
## Establish your own naming convention as you add more — e.g.
## "farming_growth_speed", "mining_yield_bonus". Multiple perks (even
## across different skills) can share a key and their values just add
## together.
@export var modifier_key: String = ""

## Added to the running total for modifier_key once this perk is
## unlocked (current skill level >= required_level). Treat as a
## percentage bonus by convention (0.1 = +10%) unless a specific system
## documents otherwise — not enforced, just the pattern used so far.
@export var modifier_value: float = 0.0
