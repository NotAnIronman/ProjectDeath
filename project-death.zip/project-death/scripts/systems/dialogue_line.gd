extends Resource
class_name DialogueLine

## One line of dialogue within an NPC's DialogueTreeData. Referenced by
## id for branching — a line's choices point at OTHER lines by id.
## Deliberately a FLAT array of named nodes (see DialogueTreeData.lines),
## not a nested tree structure — adding, reordering, or rewiring lines is
## just editing this array and the id strings choices point at, nothing
## to restructure. This is also what keeps a tree sane at "thousands of
## lines" scale: every line is independently addressable and editable
## without touching its neighbors.

@export var id: String = ""
@export var speaker_override: String = ""  ## blank = use the NPC's own display name
@export_multiline var text: String = ""

## Only line eligible if this evaluates true. Blank = always eligible.
## See DialogueManager.flags — this is the "based on certain factors"
## mechanism: a quest step sets a flag on completion (QuestStepData.
## sets_flag), and a later line becomes reachable (or takes priority
## over an earlier one at the same entry point) because of it.
@export var required_flag: String = ""
@export var required_flag_absent: String = ""  ## only eligible if this flag is NOT set — for "haven't done X yet" branches

## Choices shown after this line, as an ordered Array[DialogueChoiceData]
## (was Array[Dictionary] — see that file's own header for why it changed).
## Leave this array EMPTY for a line that just auto-advances via
## next_line_id below (a plain "Continue" prompt) instead of real choices.
@export var choices: Array[DialogueChoiceData] = []

## Used only when choices is empty. Leave blank to end the conversation
## after this line.
@export var next_line_id: String = ""

## Documented hook, not built yet — no NPC animation system exists
## (NPCs are currently stationary meshes with no AnimationPlayer). Same
## "ship a real hook, not a fake system" pattern as QuestStepData.
## cutscene_id before a cutscene system existed. NPC.play_animation()
## currently just logs the request; once NPCs have real animation sets,
## this is the one place that needs to change to actually play them —
## every DialogueLine authored with an animation_id already stays correct.
@export var animation_id: String = ""
