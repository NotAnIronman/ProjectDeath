extends Resource
class_name QuestStepData

## One step in a quest. A QuestData holds an ordered Array[QuestStepData]
## — build a quest by stacking these in the Inspector, same "author
## content as .tres files, zero code changes" pattern as everything else
## in this project (RecipeData, AchievementData, CropData...).
##
## Every step type shares the same handful of generic fields below
## rather than each type getting its own Resource subclass — keeps quest
## authoring to ONE resource type to learn, and keeps QuestManager's
## completion-checking logic in one place instead of scattered across
## subclasses. See each StepType's own comment for exactly which fields
## it reads and what makes it complete.

enum StepType {
	TALK_TO_NPC,          ## target_id = npc_id. Completes the moment the player starts a conversation with that NPC.
	DIALOGUE_CHOICE,      ## target_id = npc_id, dialogue_line_id = which line the choice is made FROM, choice_index = which choice. Completes when that exact choice is picked.
	GIVE_ITEM_TO_NPC,     ## target_id = npc_id, item_id/item_amount = what to hand over. Completes via a dialogue choice flagged is_give_item=true (see DialogueLine) while this step is active — fails harmlessly (stays on this step, shows a notification) if the player doesn't actually have it.
	CRAFT_ITEM,           ## target_id = a RECIPE id (not the output item — a specific recipe, since two recipes could share an output). Completes when RecipeDatabase successfully crafts that recipe.
	GO_TO_LOCATION,       ## target_id = a QuestLocationMarker's location_id. Completes when the player enters that marker's area.
	USE_ITEM_AT_LOCATION, ## target_id = a QuestLocationMarker's location_id, item_id/item_amount = what must be selected/held. Completes by interacting (E) with that marker while holding it. Does NOT consume the item by itself — see items_removed below if a step should also spend it.
	CUSTOM_ACTION,        ## target_id = an arbitrary action id. Completes via QuestManager.report_custom_action(action_id) — the catch-all for "Do action U", called from wherever makes sense once that action exists, same pattern as AchievementManager.report_custom_progress().
	WAIT_TIME,            ## wait_days = how many in-game days must pass since this step became active. Completes automatically once DayNightManager.total_elapsed_days has advanced that far — checked once per real in-game day change, not every frame. target_id unused.
}

@export var step_type: StepType = StepType.TALK_TO_NPC

## --- Generic fields — meaning depends on step_type, see the enum comments above ---
@export var target_id: String = ""
@export var dialogue_line_id: String = ""  ## DIALOGUE_CHOICE only
@export var choice_index: int = 0          ## DIALOGUE_CHOICE only
@export var item_id: String = ""           ## GIVE_ITEM_TO_NPC / USE_ITEM_AT_LOCATION
@export var item_amount: int = 1
@export var wait_days: float = 1.0         ## WAIT_TIME only

## Free-text shown in the Quest Log while this step is active — e.g.
## "Talk to Bob" or "Bring 5 Wood to the farm". This is what the player
## reads; target_id/item_id above are what the game actually checks.
@export_multiline var log_description: String = ""

## --- Side effects applied the MOMENT this step completes, before
## advancing to the next one ---
@export var items_given: Array[Dictionary] = []    ## [{"item_id": String, "quantity": int}]
@export var items_removed: Array[Dictionary] = []  ## [{"item_id": String, "quantity": int}]

## Sets this flag in DialogueManager the moment this step completes — the
## mechanism that makes "Talk to Bob" show DIFFERENT dialogue on a later
## step than it did on step 1 (Bob's dialogue tree has entry points
## gated on flags earlier steps set). See DialogueTreeData/DialogueLine.
@export var sets_flag: String = ""

## Documented hook, not built yet — no cutscene system exists (same
## "ship a real hook, not a fake system" pattern as DayNightManager's
## weather/season hooks before those existed). QuestManager just logs
## that a cutscene was requested for now; once a cutscene system exists,
## this is where it plugs in.
@export var cutscene_id: String = ""
