extends Resource
class_name CropData

## Full definition of a plantable crop species.
## Create one .tres per plant in res://resources/crops/ — e.g. dying_sage.tres, husk_wheat.tres
## Adding a new crop to the game = making a new .tres file. No code changes required.

@export var id: String = ""
@export var display_name: String = ""
@export_multiline var description: String = ""

## Which skill governs this crop, and the minimum level required to plant it.
## e.g. skill_id = "farming", required_level = 15
@export var skill_id: String = "farming"
@export var required_level: int = 1

## The ordered life/decay arc. Index 0 should be StageType.GROWING (a seed/sprout stage),
## and the array should generally progress GROWING -> MATURE -> DYING -> DECAYED,
## but nothing stops you from designing weirder arcs (e.g. a crop with two DYING stages
## for a slow, multi-phase death — great for rare/high-level herbs).
@export var stages: Array[DecayStage] = []

## Base XP granted for a harvest action, before stage xp_multiplier is applied.
@export var base_xp: float = 10.0

## Placeholder Kenney model for the seed/planted-but-not-sprouted state.
@export var seed_mesh: Mesh

## --- Helper methods, used by the Crop scene script ---

## Total lifetime duration across all stages, useful for UI ("time until fully decayed").
func get_total_lifetime() -> float:
	var total := 0.0
	for stage in stages:
		total += stage.duration
	return total

## Returns the DecayStage at a given elapsed time, or null if past the final stage.
func get_stage_at_time(elapsed: float) -> DecayStage:
	var accumulated := 0.0
	for stage in stages:
		accumulated += stage.duration
		if elapsed < accumulated:
			return stage
	# Elapsed time exceeds all stages — crop has fully decayed away.
	return null

## Returns the index of the stage at a given elapsed time, or -1 if fully gone.
func get_stage_index_at_time(elapsed: float) -> int:
	var accumulated := 0.0
	for i in stages.size():
		accumulated += stages[i].duration
		if elapsed < accumulated:
			return i
	return -1
