extends RefCounted
class_name MeshUtils

## Small static helpers for combined mesh bounding boxes. Previously this
## logic was copy-pasted between player.gd and resource_node.gd — pulled
## out here so any future placeable/interactable can reuse it instead of
## re-implementing it a third time.


## Every MeshInstance3D found under `node`, recursively.
static func find_mesh_instances(node: Node) -> Array[MeshInstance3D]:
	var result: Array[MeshInstance3D] = []
	if node is MeshInstance3D:
		result.append(node)
	for child in node.get_children():
		result.append_array(find_mesh_instances(child))
	return result


## World-space AABB of every MeshInstance3D under `node`, combined. Returns
## null if the node has no meshes.
static func compute_world_aabb(node: Node3D) -> Variant:
	var combined := AABB()
	var first := true
	for mesh_instance in find_mesh_instances(node):
		var world_aabb: AABB = mesh_instance.global_transform * mesh_instance.get_aabb()
		if first:
			combined = world_aabb
			first = false
		else:
			combined = combined.merge(world_aabb)
	if first:
		return null
	return combined
