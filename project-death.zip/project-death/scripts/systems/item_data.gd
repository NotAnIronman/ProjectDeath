extends Resource
class_name ItemData

## Defines a single item type. Create one .tres per item in res://resources/items/
## Covers crop yields now, and will cover cooking/herbalism outputs later —
## one Item system for the whole game, so recipes/crafting can reference
## ingredients and outputs identically.

@export var id: String = ""
@export var display_name: String = ""
@export_multiline var description: String = ""
@export var icon: Texture2D

## How many of this item can stack in a single inventory slot.
@export var max_stack: int = 99

enum ItemCategory {
	CROP_YIELD,   ## raw harvest output (herbs, produce)
	INGREDIENT,   ## processed/refined input for recipes
	FOOD,         ## cooking output
	POTION,       ## herbalism output
	TOOL,         ## equippable tools (watering can, hoe, etc)
	MISC
}
@export var category: ItemCategory = ItemCategory.CROP_YIELD

## Optional 3D representation shown in the player's hand when this item is
## the selected hotbar slot. Leave BOTH this and held_scale's fallback
## unused for items that don't make sense to hold (most raw crop yields) —
## the player just appears empty-handed. Only set this for a CUSTOM held
## look that differs from the placed appearance; for most placeable items,
## leave this empty and let held_scale (below) generate a held look
## automatically from placed_scene — much less authoring for the common
## case. Build a custom one the same way as crop composite models: a
## small scene, root Node3D, with your mesh(es) as children, positioned
## for the hand point's local origin (0,0,0).
@export var held_model: PackedScene

## Fallback when held_model is empty and this item is placeable: shows
## placed_scene itself, scaled down to this fraction, instead of needing a
## second authored scene. 0.15 = 15%, a reasonable starting point for most
## props — tune per item if something still doesn't read well that small.
## Ignored entirely if held_model is explicitly set (a custom held model
## is assumed to already be sized correctly on its own).
@export_range(0.01, 1.0, 0.01) var held_scale: float = 0.15

## Fine-tuning offset applied to the held model relative to the hand point,
## in case a given item's model needs slight repositioning to look right
## in-grip without needing a different hand point per item.
@export var held_model_offset: Vector3 = Vector3.ZERO
@export var held_model_rotation_degrees: Vector3 = Vector3.ZERO

## --- Collection Log (optional flavor, shown once discovered) ---
## Leave blank until you have real content for it — the Collection Log
## page just omits a field if it's empty, rather than showing a blank line.
@export var location_found: String = ""
@export_multiline var lore: String = ""

## --- Economy (optional, 0 = not buyable/sellable until set) ---
@export var buy_price: int = 0   ## what it costs the player to buy this from a shop that stocks it
@export var sell_price: int = 0  ## what the player receives selling one to any shop

## --- Placement (furniture, decor) ---

## If true, this item can be placed into the world via build mode (hold it
## in the hotbar, press the place key). Picking the placed object back up
## returns it to the inventory as this same item.
@export var is_placeable: bool = false

## The actual scene instantiated into the world when placed. Its ROOT node
## must have Placeable.gd attached (see scripts/building/placeable.gd) —
## that's what makes it grid-tracked and pickup-able.
@export var placed_scene: PackedScene
