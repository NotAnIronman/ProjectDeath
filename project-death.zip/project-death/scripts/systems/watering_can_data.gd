extends ItemData
class_name WateringCanData

## An equippable tool that waters a planted crop when used on a growing
## FarmPlot. See FarmPlot._try_water_from_player_selection().
##
## "Upgraded" watering cans (per the design doc's tool-upgrade pattern) =
## another .tres with a larger water_radius (waters neighboring plots
## too) — no code changes needed, same tiering pattern as
## RestorationToolData/every other tool type in the project.

## How many ADDITIONAL neighboring plots get watered in one use, beyond
## the one directly interacted with. 0 = just this one plot (the basic
## can). Radius-based, same distance check FarmPlot itself doesn't need
## to know about — see UILayer/FarmPlot for the actual neighbor lookup
## once you want tiers that use this.
@export var water_radius: float = 0.0
