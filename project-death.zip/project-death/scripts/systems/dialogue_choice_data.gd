extends Resource
class_name DialogueChoiceData

## One choice a player can pick after a DialogueLine. Used to be a plain
## Dictionary ({"text":..., "next_line_id":..., ...}) — converted to a
## real typed Resource specifically so each field below is an actual
## @export String Godot's Inspector can be individually hooked with a
## dropdown (see addons/quest_tools/) — a Dictionary's keys aren't
## individually addressable that way, only a Resource's real properties
## are. This is also just a nicer authoring experience on its own even
## without the dropdown system: real fields with real names instead of
## a generic key/value dictionary editor.

@export var text: String = ""
@export var next_line_id: String = ""

## Sets this flag the moment this choice is picked (see DialogueManager.flags).
@export var sets_flag: String = ""

## Starts this quest the moment this choice is picked (see QuestManager.start_quest()).
@export var starts_quest: String = ""

## Marks this as the "hand over the quest item" choice for a
## GIVE_ITEM_TO_NPC step currently active with this NPC — picking it
## attempts the item transfer via QuestManager before continuing.
@export var is_give_item: bool = false

## Optional skill gate — leave required_skill_id empty for a choice
## that's always available. Checked via SkillManager.meets_requirement(),
## same mechanism RecipeData already uses for Recipe Unlocking. A gated
## choice still SHOWS (so the player knows it exists and what to work
## toward) but is disabled with a tooltip explaining why — same UX
## already established for locked recipes, not a new pattern.
@export var required_skill_id: String = ""
@export var required_skill_level: int = 0

## Added to RelationshipManager's score for this NPC the moment this
## choice is picked. Can be negative. 0 = no effect (most choices won't
## move the needle — reserve nonzero values for choices that actually
## say something about how the player treated this NPC).
@export var relationship_delta: int = 0
