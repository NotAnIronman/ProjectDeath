extends Resource
class_name SkillData

## A single skill definition (Farming, Herbalism, Cooking, etc).
## Create one .tres instance per skill in res://resources/skills/
## This is DATA, not logic — SkillManager (autoload) handles XP math and level-up events.

## Unique string ID used for save data and lookups. e.g. "farming", "herbalism"
@export var id: String = ""

## Display name shown in UI. e.g. "Farming"
@export var display_name: String = ""

## Optional icon for UI (Kenney has icon packs that work great as placeholders)
@export var icon: Texture2D

## Flavor text for the skill panel
@export_multiline var description: String = ""

## Max level this skill can reach. RuneScape-style default is 99, but keep it configurable.
@export var max_level: int = 99

## XP curve shape. We generate the XP table procedurally rather than hand-authoring
## 99 numbers — this keeps the curve tunable from one formula.
## xp_for_level(n) = base * (n ^ exponent)
@export var xp_curve_base: float = 50.0
@export var xp_curve_exponent: float = 2.2

## Returns total XP required to REACH a given level (level 1 = 0 XP always).
func xp_for_level(level: int) -> int:
	if level <= 1:
		return 0
	return int(xp_curve_base * pow(level, xp_curve_exponent))

## Given a total XP amount, returns what level that corresponds to.
func level_for_xp(xp: int) -> int:
	var level := 1
	while level < max_level and xp >= xp_for_level(level + 1):
		level += 1
	return level

## Returns (current_xp_into_level, xp_needed_for_next_level) for UI progress bars.
func get_level_progress(xp: int) -> Vector2i:
	var current_level := level_for_xp(xp)
	if current_level >= max_level:
		return Vector2i(0, 0) # maxed out
	var floor_xp := xp_for_level(current_level)
	var next_xp := xp_for_level(current_level + 1)
	return Vector2i(xp - floor_xp, next_xp - floor_xp)
