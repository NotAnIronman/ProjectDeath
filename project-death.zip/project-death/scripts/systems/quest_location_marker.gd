extends Node3D
class_name QuestLocationMarker

## A named location trigger for quest steps — GO_TO_LOCATION completes
## when the player enters its Area3D; USE_ITEM_AT_LOCATION completes by
## interacting (E) with it while holding the right item.
##
## Deliberately NOT a Placeable/purchasable item — this is a level-design
## tool the developer hand-places in a world/cell scene at meaningful
## spots (a farm plot, a cave entrance, wherever a quest step needs a
## "go here" target), not something the player buys or carries. Give it
## a unique location_id and reference that same string from a
## QuestStepData's target_id.
##
## Expects a child Area3D (for GO_TO_LOCATION's proximity detection) —
## add one with a CollisionShape3D sized to whatever radius makes sense
## for that specific location. Interaction (E, for USE_ITEM_AT_LOCATION)
## reuses the same ambient "interactables" group everything else does,
## so it needs a CollisionShape3D somewhere the player's own detection
## Area3D can reach — the same Area3D serves both purposes.

@export var location_id: String = ""

## Optional — if set, entering this marker's area starts this quest (if
## it isn't already active/completed), same "just another authored side
## effect" philosophy as DialogueChoiceData.starts_quest. This is what
## lets a quest begin by walking somewhere instead of needing a dialogue
## choice at all. Set directly on the placed marker instance in the
## Godot editor — QuestBuilder doesn't touch placed scene instances.
@export var starts_quest: String = ""


func _ready() -> void:
	add_to_group("interactables")
	var area := _find_area3d(self)
	if area:
		area.body_entered.connect(_on_body_entered)
		print("QuestLocationMarker '%s': ready, Area3D found and connected." % location_id)
	else:
		push_warning("QuestLocationMarker '%s': no Area3D child found — GO_TO_LOCATION triggering won't work, only E-interact will." % location_id)


func _find_area3d(node: Node) -> Area3D:
	for child in node.get_children():
		if child is Area3D:
			return child
		var found := _find_area3d(child)
		if found:
			return found
	return null


func _on_body_entered(body: Node3D) -> void:
	print("QuestLocationMarker '%s': body_entered fired — body='%s', in 'player' group: %s" % [location_id, body.name, body.is_in_group("player")])
	if not body.is_in_group("player"):
		return
	if starts_quest != "":
		QuestManager.start_quest(starts_quest)
	if location_id != "":
		QuestManager.report_location_reached(location_id)


## Called by Player's ambient interaction (same path as FarmPlot/
## ResourceNode/StorageContainer/TradingPost/WaypointBeacon).
##
## BUGFIX: this used to just call QuestManager.report_item_used_at_location()
## and rely on it silently no-op'ing if the wrong (or no) item was
## selected on the hotbar — meaning pressing E with the right item sitting
## unselected in your inventory looked EXACTLY like pressing E on
## something with no active quest step at all: nothing happened, no
## explanation. Now checks the active step directly first and tells the
## player specifically what's missing.
func interact(_player: Node) -> void:
	if location_id == "":
		return

	var step := QuestManager.get_active_step_at(QuestStepData.StepType.USE_ITEM_AT_LOCATION, location_id)
	if step == null:
		return  # no active quest step wants this location right now — genuinely nothing to do here, not an error

	var selected_item_id := InventorySlotManager.get_selected_hotbar_item_id()
	var wanted_name := _item_display_name(step.item_id)

	if selected_item_id == "":
		NotificationManager.notify("Select the %s first." % wanted_name, "warning")
		return
	if selected_item_id != step.item_id:
		NotificationManager.notify("You need to select the %s to use here." % wanted_name, "warning")
		return
	if step.item_amount > 0 and not InventoryManager.has_item(step.item_id, step.item_amount):
		NotificationManager.notify("You don't have enough %s." % wanted_name, "warning")
		return

	QuestManager.report_item_used_at_location(location_id, selected_item_id)


func _item_display_name(item_id: String) -> String:
	var def: ItemData = InventoryManager.item_defs.get(item_id)
	return def.display_name if def else item_id
