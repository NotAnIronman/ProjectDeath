extends ItemData
class_name ToolData

## A specialized Item that lets the player attempt gathering actions
## (chopping trees, mining rocks, fishing) when it's the selected hotbar
## item. Create one .tres per tool in res://resources/<Category>/tres/,
## alongside your regular ItemData files — since this extends ItemData,
## InventoryManager's loader picks it up automatically.
##
## IMPORTANT: tool_type identifies the SKILL/CATEGORY (e.g. "mining"),
## NOT the specific tool tier. Every tier of pickaxe — bronze, iron,
## steel, whatever — should share the exact same tool_type. Use tool_tier
## below to represent the upgrade progression instead. Checked with >=,
## so a higher-tier tool is always automatically usable anywhere a
## lower-tier one would work — no separate "backward compatibility" list
## to maintain per tool.

## Which gathering skill this tool is used for. Must exactly match a
## ResourceNodeData.required_tool_type string, e.g. "woodcutting",
## "mining", "fishing". SAME value across every tier of this tool type.
@export var tool_type: String = ""

## This tool's power level. Higher = better. A node's
## ResourceNodeData.min_tool_tier (default 0, meaning "any tier works")
## is checked as tool_tier >= min_tool_tier.
@export var tool_tier: int = 1
