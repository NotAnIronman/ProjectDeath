extends ItemData
class_name ShopItemData

## Defines a placeable shop TYPE — a general store, a seed merchant, etc.
## Placed/picked up exactly like storage or any other placeable (inherited
## is_placeable/placed_scene from ItemData, same pattern as everywhere else).
##
## Unlike StorageContainer, a shop's stock is STATIC data, not mutable
## player-owned state — so there's no extra save contract needed beyond
## whatever Placeable already provides (position/rotation). Nothing to
## persist here.
##
## A "second shop type" (a Seed Merchant vs a General Store) = another
## .tres with a different stock_item_ids list — no code changes.

## Which items this shop sells. Only items with buy_price > 0 on their own
## ItemData will actually show up as purchasable, even if listed here —
## set buy_price on the item itself, not here, since the price is a
## property of the ITEM (consistent everywhere it's sold), not the shop.
@export var stock_item_ids: Array[String] = []

## Shops always accept selling ANY item with sell_price > 0 — there's no
## per-shop sell restriction (a real design choice, not an oversight: a
## general store buying only some categories is a StorageContainer-style
## restriction, and would be easy to add here the same way if wanted —
## deliberately left simple for the first version).
