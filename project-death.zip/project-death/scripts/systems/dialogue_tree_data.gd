extends Resource
class_name DialogueTreeData

## The full dialogue content for ONE npc_id. Create one .tres per NPC in
## res://resources/Dialogue/trees/ — same load-all-from-folder pattern as
## everything else. All of an NPC's lines live in one flat array (see
## DialogueLine's own header for why that scales better than a nested
## tree at "thousands of lines" volume).

@export var npc_id: String = ""
@export var lines: Array[DialogueLine] = []

## Where a conversation with this NPC STARTS. Evaluated top-to-bottom,
## FIRST eligible entry wins — same required_flag/required_flag_absent
## gating as DialogueLine itself. This is what makes "Talk to Bob" open
## on a different line depending on quest progress: put the most
## specific/latest-game-state entries first, and a catch-all with no
## requirements LAST, so there's always a fallback and the conversation
## never fails to start.
## Each entry: {"start_line_id": String, "required_flag": String, "required_flag_absent": String}
@export var entry_points: Array[Dictionary] = []


func get_line(line_id: String) -> DialogueLine:
	for line in lines:
		if line.id == line_id:
			return line
	return null
