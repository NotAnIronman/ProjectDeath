extends Resource
class_name AchievementData

## Defines a single achievement. Create one .tres per achievement under
## res://resources/achievements/ — same auto-scan-a-folder pattern as
## skills/items, so adding more is purely a content task, no code changes.

enum Category {
	FARMING, EXPLORATION, RELATIONSHIPS, FISHING, CRAFTING, COOKING,
	COMBAT, COLLECTION, RESTORATION, SECRETS, STORY, FESTIVALS,
	TRADING, ECONOMY,
}

## How progress toward this achievement is automatically tracked. See
## AchievementManager for what listens to what. CUSTOM achievements need
## AchievementManager.report_custom_progress(condition_target_id, amount)
## called from wherever makes sense once the relevant system exists.
enum ConditionType {
	SKILL_LEVEL,           ## reach condition_target_amount in skill condition_target_id
	ITEM_COLLECTED_TOTAL,  ## lifetime total of item condition_target_id ever gained (not current inventory — selling/using never regresses this)
	GROUND_RESTORED_TOTAL, ## total distinct patches ever restored, across the whole game (condition_target_id ignored)
	CELLS_EXPLORED_TOTAL,  ## distinct WorldManager cells ever loaded while the player was in them (condition_target_id ignored)
	CUSTOM,                ## advanced manually via AchievementManager.report_custom_progress()
}

@export var id: String = ""
@export var display_name: String = ""
@export_multiline var description: String = ""
@export var category: Category = Category.FARMING

## If true, name/description show as "???" until completed — for genuine
## surprises rather than telegraphing exactly what to go do.
@export var hidden: bool = false

@export var condition_type: ConditionType = ConditionType.CUSTOM
@export var condition_target_id: String = ""
@export var condition_target_amount: int = 1

## Optional reward granted automatically on completion. Leave item_id
## empty for an achievement that's just a milestone with no item reward.
@export var reward_item_id: String = ""
@export var reward_item_amount: int = 0
