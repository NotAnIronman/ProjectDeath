extends Resource
class_name QuestData

## A whole quest. Create one .tres per quest in
## res://resources/Quests/definitions/ — same load-all-from-folder
## pattern as everything else. Adding a quest to the game = making a new
## .tres file with an ordered Array[QuestStepData]; no code changes.

@export var id: String = ""
@export var display_name: String = ""
@export_multiline var description: String = ""
@export var steps: Array[QuestStepData] = []

## Reward granted the moment the FINAL step completes.
@export var reward_xp: Dictionary = {}            ## {"skill_id": int}
@export var reward_items: Array[Dictionary] = []  ## [{"item_id": String, "quantity": int}]

## Optional prerequisite — this quest refuses to start (QuestManager.
## start_quest returns false) until the named quest is completed. Blank
## = no prerequisite, startable any time.
@export var required_quest_id: String = ""

## If true, this quest starts itself automatically — no dialogue choice
## or other trigger needed. Checked once by QuestManager on boot; safe
## to leave true across sessions since start_quest() already no-ops for
## a quest that's already active or completed.
@export var auto_start: bool = false
