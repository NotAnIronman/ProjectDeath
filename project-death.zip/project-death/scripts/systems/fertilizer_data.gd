extends ItemData
class_name FertilizerData

## A consumable used on a growing crop to boost its growth speed for the
## rest of its life (a one-time soil-additive effect, not a daily thing
## like watering — see Crop.fertilize()). Consumed on use, same as the
## restoration/watering tools' cost_item pattern elsewhere, just as the
## item itself rather than a separate cost field, since fertilizer IS the
## consumable here.
##
## "Higher tier" fertilizer = another .tres with a bigger growth_multiplier
## — same data-only tiering pattern as every other tool type in the project.

## Growth speed multiplier applied for the rest of the crop's life.
## 1.5 = 50% faster. Must be > 1.0 to have any real effect.
@export var growth_multiplier: float = 1.5
