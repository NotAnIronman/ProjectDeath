extends Resource
class_name DecayStage

## One stage in a crop's lifecycle, from seed to fully decayed.
## A CropData resource holds an ordered Array[DecayStage] — this is what lets
## every crop have a totally different life/death arc without new code.

enum StageType {
	GROWING,   ## still alive, not yet mature (not harvestable)
	MATURE,    ## alive and "ready" in the traditional sense (harvestable, but low value here)
	DYING,     ## actively decaying — this is where your game's core tension lives
	DECAYED    ## fully dead — may still be harvestable for late-stage materials, or may rot away
}

@export var stage_name: String = ""
@export var stage_type: StageType = StageType.GROWING

## How long (in-game minutes, or seconds — decide your TimeManager unit and stay consistent)
## the crop remains in this stage before advancing to the next one.
@export var duration: float = 60.0

## Visual swap for this stage — TWO OPTIONS, pick whichever fits the stage:
##
## OPTION A: mesh_override — for a simple single-piece model. Assign a Mesh
## resource directly (e.g. a Kenney .obj imported as a Mesh).
##
## OPTION B: stage_scene — for a COMPOSITE model made of multiple parts
## grouped together (e.g. several meshes positioned together as one plant).
## Build the group as its own scene (root Node3D with MeshInstance3D children
## positioned relative to each other), save it as a .tscn, and assign that
## scene here instead. If stage_scene is set, it takes priority over
## mesh_override for this stage.
@export var mesh_override: Mesh
@export var stage_scene: PackedScene
@export var material_override: Material

## Can the player harvest while the crop is in this stage?
@export var is_harvestable: bool = false

## What harvesting during THIS stage yields. Keyed by item ID -> quantity range.
## e.g. {"herb_dying_sage": Vector2i(1,3)}
## Empty dictionary = nothing yields at this stage (encourages waiting, per your core hook).
@export var yield_table: Dictionary = {}

## Bonus multiplier to XP granted for harvesting at this stage.
## Use this to reward patience — e.g. DYING stage might give 2x-3x the XP of MATURE.
@export var xp_multiplier: float = 1.0
