extends Resource
class_name RecipeData

## Defines one craftable recipe. Create one .tres per recipe in
## res://resources/Crafting/recipes/ — same load-all-from-folder pattern
## as everything else (CropDatabase, SkillManager, InventoryManager), so
## adding a new recipe is just adding a new .tres file, zero code changes.
##
## Deliberately references items by id only (output_item_id, and item_id
## inside each entry of `inputs`) rather than holding direct ItemData
## references — same reasoning as CropData's yield_table: keeps recipes
## decoupled from exactly where an item's .tres lives, and keeps this
## resource trivially serializable if recipes ever need to come from
## somewhere other than hand-authored .tres files (a future "learn a
## recipe from a book" drop, for instance).

@export var id: String = ""
@export var display_name: String = ""
@export_multiline var description: String = ""

## What crafting this recipe produces.
@export var output_item_id: String = ""
@export var output_quantity: int = 1

## What it costs. Same {item_id, quantity} shape used everywhere else a
## "stack" is represented (StorageContainer slots, InventorySlotManager) —
## no new convention to learn. Example:
##   [{"item_id": "copper_ore", "quantity": 15}, {"item_id": "iron_ore", "quantity": 5}]
@export var inputs: Array[Dictionary] = []

## --- Optional gating, for a future "Recipe Unlocking" pass ---
## Leave required_skill_id empty for a recipe that's always available
## (every recipe shipped at launch of this system is set up this way —
## gating recipes behind skill level is a deliberately separate follow-up,
## not bundled into "recipes exist and can be crafted" at all, to keep
## this v1 scoped to just cause-and-effect crafting). SkillManager.
## meets_requirement(required_skill_id, required_level) is the intended
## check once something actually sets required_skill_id.
@export var required_skill_id: String = ""
@export var required_level: int = 0
