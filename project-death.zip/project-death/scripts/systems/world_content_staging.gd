@tool
extends Node3D

## Editor-only staging area for cell content.
##
## Place/edit everything that should eventually live in a streamed cell
## (buildings, resource nodes, decor, FarmPlots) directly as a child of
## this node, in World.tscn, same as you always have. Because it's all one
## normal scene, you see EVERYTHING at once while editing — no cell
## boundaries, full context, easy to spot something straddling where a
## cell edge will eventually fall.
##
## This node's content is NEVER what actually runs in the shipped game —
## the instant the real game runs (not the editor), _ready() below frees
## every child immediately, before the first frame renders. Real runtime
## content comes entirely from the streamed cell scenes under
## scenes/world/cells/, generated FROM this node's current children by
## scripts/editor_tools/split_world_into_cells.gd.
##
## WORKFLOW:
##   1. Edit content here, in the editor, with full spatial context.
##   2. Run split_world_into_cells.gd (Script Editor > open it > File > Run,
##      or the little play-button in the script editor toolbar) whenever
##      you want to test how it actually streams. Safe to re-run anytime —
##      it fully regenerates every cell file from this node's current
##      state each time, so there's never a "stale cell file" to worry
##      about as long as you always re-run after editing.
##   3. Run the game normally to test streaming — this node's content
##      won't appear (see above), only the freshly-generated cells will.

func _ready() -> void:
	if not Engine.is_editor_hint():
		queue_free()
