extends GraphNode
class_name DialogueLineNode

## One DialogueLine as a graph node — shrink-to-fit, everything editable
## directly on the node (no separate always-visible properties panel).
## The line's text is an inline TextEdit; each choice is an inline
## LineEdit with its own output port. Less-common fields (id, speaker
## override, required flags, animation id, and per-choice skill/
## relationship/flag/quest fields) live behind a small "⚙" popup per
## row instead of being permanently visible — this is what keeps the
## node itself compact instead of every field taking up space whether
## you're using it or not.
##
## IMPORTANT structural rule, load-bearing for connection reliability:
## rebuild_ports() (which frees/recreates row Controls and reassigns
## slots) is called ONLY when the number of choices actually changes
## (add/remove). Any other edit (text, badges, popup fields) updates
## the EXISTING Controls in place and never touches ports/rows. Mixing
## "just updating a label" with "tearing down and rebuilding the row
## that owns a live connection" is exactly the kind of thing that can
## make connections behave unreliably, so those two operations are kept
## strictly separate here.

signal structure_changed(line)  ## fired only when choice COUNT changes — main.gd needs to redraw connections
signal delete_requested(line)  ## line: DialogueLine — user clicked the delete button on this node
signal id_changed(node, old_id, new_id)  ## node: DialogueLineNode (self) — the line's id field changed; main.gd needs to rename this GraphNode AND fix up every other reference to the old id (see main.gd's _on_line_id_changed for why this is a bigger deal than it sounds)
signal entry_point_toggled(node, is_entry)  ## node: DialogueLineNode (self), is_entry: bool

var is_entry_point: bool = false  ## set by main.gd from DialogueTreeData.entry_points when this node is created/refreshed — this node doesn't own entry_points data itself, just reflects it

var line: DialogueLine
var _text_edit: TextEdit
var _choice_rows: Array[Dictionary] = []  ## [{"container": Control, "line_edit": LineEdit, "badge_label": Label}]
var _scanner: ProjectScanner

const PORT_TYPE := 0
const PORT_COLOR := Color(0.5, 0.8, 1.0)


var _add_choice_button: Button


var _line_gear_button: Button


func setup(dialogue_line: DialogueLine, scanner: ProjectScanner) -> void:
	line = dialogue_line
	_scanner = scanner
	_update_title()

	var header_row := HBoxContainer.new()
	add_child(header_row)  # child 0 — owns the input port

	_line_gear_button = Button.new()
	_line_gear_button.text = "⚙"
	_line_gear_button.tooltip_text = "Line settings (id, speaker, flags, animation)"
	_line_gear_button.pressed.connect(_open_line_settings_popup)
	header_row.add_child(_line_gear_button)

	var delete_button := Button.new()
	delete_button.text = "✕ Delete Line"
	delete_button.pressed.connect(func(): delete_requested.emit(line))
	header_row.add_child(delete_button)

	set_slot(0, true, PORT_TYPE, PORT_COLOR, false, PORT_TYPE, PORT_COLOR)

	_text_edit = TextEdit.new()
	_text_edit.text = line.text
	_text_edit.custom_minimum_size = Vector2(220, 50)
	_text_edit.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	_text_edit.focus_exited.connect(func(): line.text = _text_edit.text)
	add_child(_text_edit)  # child 1 — no ports, just content

	_add_choice_button = Button.new()  # created ONCE — rebuild_ports() repositions it via move_child() rather than recreating it every time
	_add_choice_button.text = "+ Add Choice"
	_add_choice_button.pressed.connect(_on_add_choice_pressed)
	add_child(_add_choice_button)

	rebuild_ports()


## Called ONLY when choices are added or removed — see this file's own
## header for why content-only edits must never call this.
##
## BUGFIX: this used to recreate the "+ Add Choice" button on every call
## and rely on add_child()'s default append-to-end behavior for new rows
## — on a SECOND rebuild, the OLD button (not yet actually removed, since
## queue_free() defers to end of frame) and the old rows still occupying
## indices meant new rows landed in the wrong positions relative to what
## set_slot() expected, silently corrupting the row-index-to-port mapping.
## Every row is now explicitly move_child()'d to its exact target index,
## and the button is repositioned rather than recreated.
func rebuild_ports() -> void:
	for entry in _choice_rows:
		(entry["container"] as Control).queue_free()
	_choice_rows.clear()

	clear_all_slots()
	set_slot(0, true, PORT_TYPE, PORT_COLOR, false, PORT_TYPE, PORT_COLOR)

	if line.choices.is_empty():
		var row := _build_auto_continue_row()
		add_child(row)
		move_child(row, 2)
		_choice_rows.append({"container": row})
		set_slot(2, false, PORT_TYPE, PORT_COLOR, true, PORT_TYPE, PORT_COLOR)
	else:
		for i in line.choices.size():
			var row := _build_choice_row(line.choices[i], i)
			var container: Control = row["container"]
			add_child(container)
			move_child(container, 2 + i)
			_choice_rows.append(row)
			set_slot(2 + i, false, PORT_TYPE, PORT_COLOR, true, PORT_TYPE, PORT_COLOR)

	move_child(_add_choice_button, get_child_count() - 1)

	# WORKAROUND for a confirmed, still-open Godot engine bug
	# (godotengine/godot#100536): GraphNode doesn't automatically shrink
	# back down when its content gets smaller/removed — it only ever
	# grows. Forcing size to zero makes Godot recompute it from the
	# CURRENT children's actual minimum size on the next layout pass
	# (size is always clamped to at least the minimum, so this can't
	# make it too small, only correct).
	size = Vector2.ZERO


func set_entry_point_state(value: bool) -> void:
	is_entry_point = value
	_update_title()


func refresh_content() -> void:
	_update_title()
	if _text_edit.text != line.text:
		_text_edit.text = line.text
	for i in _choice_rows.size():
		var entry := _choice_rows[i]
		if entry.has("line_edit"):
			var le: LineEdit = entry["line_edit"]
			var expected := line.choices[i].text
			if le.text != expected:
				le.text = expected
			(entry["badge_label"] as Label).text = "  ".join(_build_badges(line.choices[i]))


func _build_auto_continue_row() -> Control:
	var label := Label.new()
	label.text = "→ continues to: %s" % (line.next_line_id if line.next_line_id != "" else "— drag a connection —")
	label.autowrap_mode = TextServer.AUTOWRAP_WORD
	return label


func _build_choice_row(choice: DialogueChoiceData, choice_index: int) -> Dictionary:
	var outer_vbox := VBoxContainer.new()

	var hbox := HBoxContainer.new()
	outer_vbox.add_child(hbox)

	var line_edit := LineEdit.new()
	line_edit.text = choice.text
	line_edit.custom_minimum_size = Vector2(160, 0)
	line_edit.placeholder_text = "(choice %d text)" % (choice_index + 1)
	line_edit.focus_exited.connect(func(): choice.text = line_edit.text)
	line_edit.text_submitted.connect(func(_v): choice.text = line_edit.text)
	hbox.add_child(line_edit)

	var gear_button := Button.new()
	gear_button.text = "⚙"
	gear_button.tooltip_text = "Choice settings (next line via connection, skill/relationship/flag/quest)"
	gear_button.pressed.connect(func(): _open_choice_settings_popup(choice, choice_index))
	hbox.add_child(gear_button)

	var remove_button := Button.new()
	remove_button.text = "✕"
	remove_button.pressed.connect(func(): _on_remove_choice_pressed(choice_index))
	hbox.add_child(remove_button)

	var badge_label := Label.new()
	badge_label.text = "  ".join(_build_badges(choice))
	badge_label.add_theme_font_size_override("font_size", 10)
	badge_label.modulate = Color(1, 0.85, 0.5)
	badge_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	outer_vbox.add_child(badge_label)

	return {"container": outer_vbox, "line_edit": line_edit, "badge_label": badge_label}


func _build_badges(choice: DialogueChoiceData) -> Array[String]:
	var badges: Array[String] = []
	if choice.required_skill_id != "":
		badges.append("📈 %s %d" % [choice.required_skill_id.capitalize(), choice.required_skill_level])
	if choice.relationship_delta != 0:
		badges.append("❤ %+d" % choice.relationship_delta)
	if choice.sets_flag != "":
		badges.append("🚩 %s" % choice.sets_flag)
	if choice.starts_quest != "":
		badges.append("📜 %s" % choice.starts_quest)
	if choice.is_give_item:
		badges.append("🎁")
	return badges


func _open_line_settings_popup() -> void:
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 6)
	FieldWidgets.add_text_field(content, "Line id", line.id, func(v):
		var old_id := line.id
		line.id = v
		_update_title()
		id_changed.emit(self, old_id, v)
	)
	FieldWidgets.add_bool_field(content, "★ Entry point (conversation can start here)", is_entry_point, func(v): entry_point_toggled.emit(self, v), "Unconditional entry point — the conversation starts here if no OTHER entry point with a required_flag is eligible. For multiple flag-gated entry points on the same NPC, you'll still need to edit entry_points directly on the DialogueTreeData for now.")
	FieldWidgets.add_text_field(content, "Speaker override (blank = NPC's name)", line.speaker_override, func(v): line.speaker_override = v)
	FieldWidgets.add_suggest_field(content, "Required flag", line.required_flag, func(): return _scanner.flag_ids, func(v): line.required_flag = v)
	FieldWidgets.add_suggest_field(content, "Required flag ABSENT", line.required_flag_absent, func(): return _scanner.flag_ids, func(v): line.required_flag_absent = v)
	FieldWidgets.add_text_field(content, "Animation id (hook only)", line.animation_id, func(v): line.animation_id = v)
	FieldWidgets.show_settings_node(self, content, "Line: %s" % (line.id if line.id != "" else "(unnamed)"))


func _open_choice_settings_popup(choice: DialogueChoiceData, choice_index: int) -> void:
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 6)
	var next_info := Label.new()
	next_info.text = (
		"Next line: %s\n\n" +
		"This choice's port can have TWO connections at once, to two " +
		"different kinds of targets: drag to another LINE to continue " +
		"the conversation (sets next_line_id — that's this field), and " +
		"separately drag to a quest STEP's yellow port to advance that " +
		"step. Both can be active on the same choice — linking a quest " +
		"step does NOT by itself end the conversation; the conversation " +
		"only ends if next_line_id is left blank."
	) % (choice.next_line_id if choice.next_line_id != "" else "— none —")
	next_info.autowrap_mode = TextServer.AUTOWRAP_WORD
	next_info.modulate = Color(1, 1, 1, 0.6)
	content.add_child(next_info)
	FieldWidgets.add_suggest_field(content, "Sets flag", choice.sets_flag, func(): return _scanner.flag_ids, func(v): choice.sets_flag = v; refresh_content())
	FieldWidgets.add_suggest_field(content, "Starts quest", choice.starts_quest, func(): return _scanner.quest_ids, func(v): choice.starts_quest = v; refresh_content())
	FieldWidgets.add_bool_field(content, "Is 'give item' choice", choice.is_give_item, func(v): choice.is_give_item = v; refresh_content(), "For a GIVE_ITEM_TO_NPC step — picking this attempts the item transfer.")
	FieldWidgets.add_strict_field(content, "Required skill", choice.required_skill_id, func(): return _scanner.skill_ids, func(v): choice.required_skill_id = v; refresh_content())
	FieldWidgets.add_int_field(content, "Required skill level", choice.required_skill_level, func(v): choice.required_skill_level = v; refresh_content())
	FieldWidgets.add_int_field(content, "Relationship delta", choice.relationship_delta, func(v): choice.relationship_delta = v; refresh_content())
	FieldWidgets.show_settings_node(self, content, "Choice %d settings" % (choice_index + 1))


func _on_add_choice_pressed() -> void:
	line.choices.append(DialogueChoiceData.new())
	rebuild_ports()
	structure_changed.emit(line)


func _on_remove_choice_pressed(choice_index: int) -> void:
	if choice_index < 0 or choice_index >= line.choices.size():
		return
	line.choices.remove_at(choice_index)
	rebuild_ports()
	structure_changed.emit(line)


func _update_title() -> void:
	var base := line.id if line.id != "" else "(unnamed line)"
	title = "★ %s" % base if is_entry_point else base
