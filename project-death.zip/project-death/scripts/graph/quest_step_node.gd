extends GraphNode
class_name QuestStepGraphNode

## One QuestStepData as a graph node. Row 0 owns BOTH a sequence input
## (left) and sequence output (right) port — chaining step nodes
## together via drag-connections IS what defines their order now (see
## main.gd's _reconstruct_step_order(), which walks these connections on
## save rather than trusting array order, since there's no side list to
## reorder via buttons anymore).
##
## Also owns a dedicated "Linked dialogue choice" INPUT port — drag a
## connection FROM a DialogueLineNode's choice output INTO it, and this
## step auto-configures itself as DIALOGUE_CHOICE watching that exact
## choice (target_id/dialogue_line_id/choice_index all set for you). See
## main.gd's connection handler for where that actually happens — this
## node just exposes the port.
##
## SCOPE NOTE: the reverse relationship ("this TALK_TO_NPC step is about
## THIS dialogue tree") is intentionally NOT a graph connection — the
## existing inline Target id field already covers "which NPC" perfectly
## well on its own, and forcing a second, differently-shaped connection
## type onto this same port for that relationship was more complexity
## than the win was worth for this pass.

signal step_changed(step)  ## step: QuestStepData — step type changed, main.gd refreshes the Quest Log-style summary if shown anywhere
signal delete_requested(step)  ## step: QuestStepData — user clicked the delete button on this node

var step: QuestStepData
var _scanner: ProjectScanner
var dialogue_tree: DialogueTreeData  ## set by main.gd right after setup() — used only to show the actual choice TEXT in the summary instead of an opaque index
var _target_row: VBoxContainer
var _summary_label: Label

const SEQ_PORT_TYPE := 1
const SEQ_COLOR := Color(0.6, 1.0, 0.6)
const DIALOGUE_LINK_PORT_TYPE := 2
const DIALOGUE_LINK_COLOR := Color(1.0, 0.8, 0.4)


func setup(quest_step: QuestStepData, scanner: ProjectScanner) -> void:
	step = quest_step
	_scanner = scanner
	title = "Step: %s" % QuestStepData.StepType.keys()[step.step_type]

	# Row 0: step type selector — owns the sequence in/out ports.
	var type_row := HBoxContainer.new()
	add_child(type_row)
	var type_button := OptionButton.new()
	for name_str in QuestStepData.StepType.keys():
		type_button.add_item(name_str)
	type_button.select(step.step_type)
	type_button.item_selected.connect(func(idx):
		step.step_type = idx
		title = "Step: %s" % QuestStepData.StepType.keys()[idx]
		_rebuild_target_field()
		step_changed.emit(step)
	)
	type_row.add_child(type_button)
	var delete_button := Button.new()
	delete_button.text = "✕"
	delete_button.tooltip_text = "Delete this step"
	delete_button.pressed.connect(func(): delete_requested.emit(step))
	type_row.add_child(delete_button)
	set_slot(0, true, SEQ_PORT_TYPE, SEQ_COLOR, true, SEQ_PORT_TYPE, SEQ_COLOR)

	# Row 1: target id (contextual — npc/recipe/location depending on step type). No ports.
	_target_row = VBoxContainer.new()
	add_child(_target_row)
	_rebuild_target_field()
	set_slot(1, false, 0, Color(), false, 0, Color())

	# Row 2: gear button for the less-common fields. No ports.
	var gear_row := HBoxContainer.new()
	var gear_button := Button.new()
	gear_button.text = "⚙ More fields"
	gear_button.tooltip_text = "Log description, items given/removed, sets flag, cutscene id, and (for Dialogue Choice / Use Item At Location steps) the extra fields those need"
	gear_button.pressed.connect(_open_more_fields_popup)
	gear_row.add_child(gear_button)
	add_child(gear_row)
	set_slot(2, false, 0, Color(), false, 0, Color())

	# Row 3: summary of the current dialogue-choice link (if any) — owns the dialogue-link input port.
	_summary_label = Label.new()
	_summary_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	add_child(_summary_label)
	set_slot(3, true, DIALOGUE_LINK_PORT_TYPE, DIALOGUE_LINK_COLOR, false, 0, Color())
	_refresh_summary()


func _rebuild_target_field() -> void:
	for child in _target_row.get_children():
		child.queue_free()
	if step.step_type == QuestStepData.StepType.CUSTOM_ACTION:
		FieldWidgets.add_text_field(_target_row, "Target id (custom action id)", step.target_id, func(v): step.target_id = v)
		return

	var get_options: Callable
	var strict := false
	match step.step_type:
		QuestStepData.StepType.TALK_TO_NPC, QuestStepData.StepType.DIALOGUE_CHOICE, QuestStepData.StepType.GIVE_ITEM_TO_NPC:
			get_options = func(): return _scanner.npc_ids
		QuestStepData.StepType.CRAFT_ITEM:
			get_options = func(): return _scanner.recipe_ids
			strict = true
		QuestStepData.StepType.GO_TO_LOCATION, QuestStepData.StepType.USE_ITEM_AT_LOCATION:
			get_options = func(): return _scanner.location_ids
		_:
			get_options = func(): return []

	if strict:
		FieldWidgets.add_strict_field(_target_row, "Target id", step.target_id, get_options, func(v): step.target_id = v)
	else:
		FieldWidgets.add_suggest_field(_target_row, "Target id", step.target_id, get_options, func(v): step.target_id = v)


## Called by main.gd's connection handler once it's configured this step
## from a dragged dialogue-choice connection, so the node reflects it
## without needing a full teardown/rebuild.
func refresh_after_dialogue_link() -> void:
	_rebuild_target_field()
	_refresh_summary()


func _refresh_summary() -> void:
	if step.step_type != QuestStepData.StepType.DIALOGUE_CHOICE or step.dialogue_line_id == "":
		_summary_label.text = "◂ (drag a choice's output here to link one)"
		return

	var choice_text := ""
	if dialogue_tree:
		var line := dialogue_tree.get_line(step.dialogue_line_id)
		if line and step.choice_index >= 0 and step.choice_index < line.choices.size():
			choice_text = line.choices[step.choice_index].text
	if choice_text != "":
		_summary_label.text = "◂ watching: \"%s\" on %s" % [choice_text, step.dialogue_line_id]
	else:
		_summary_label.text = "◂ watching %s / choice %d — ⚠ that choice doesn't exist, only OTHER choices on this line won't complete this step" % [step.dialogue_line_id, step.choice_index]


func _open_more_fields_popup() -> void:
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 6)
	FieldWidgets.add_multiline_field(content, "Quest Log description (what the player reads)", step.log_description, func(v): step.log_description = v)
	FieldWidgets.add_suggest_field(content, "Sets flag", step.sets_flag, func(): return _scanner.flag_ids, func(v): step.sets_flag = v)
	FieldWidgets.add_text_field(content, "Cutscene id (hook only)", step.cutscene_id, func(v): step.cutscene_id = v)
	if step.step_type == QuestStepData.StepType.GIVE_ITEM_TO_NPC or step.step_type == QuestStepData.StepType.USE_ITEM_AT_LOCATION:
		FieldWidgets.add_strict_field(content, "Item", step.item_id, func(): return _scanner.item_ids, func(v): step.item_id = v)
		FieldWidgets.add_int_field(content, "Item amount", step.item_amount, func(v): step.item_amount = v)
	FieldWidgets.add_item_list_field(content, "Items given (on this step's completion)", step.items_given, func(): return _scanner.item_ids, func(): pass)
	FieldWidgets.add_item_list_field(content, "Items removed (on this step's completion)", step.items_removed, func(): return _scanner.item_ids, func(): pass)
	FieldWidgets.show_settings_node(self, content, "Step settings")
