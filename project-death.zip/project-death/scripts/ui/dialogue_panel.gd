extends PanelContainer
class_name DialoguePanel

## The dialogue UI — same "extracted, self-contained panel" shape as
## StoragePanel/ShopPanel. Unlike those, this is fully self-driving: it
## connects directly to DialogueManager's signals in build() and shows/
## hides/refreshes itself, rather than UILayer calling open()/close() —
## DialogueManager is deliberately UI-agnostic (see its own header), and
## this is the one thing that translates its state into what's drawn.
##
## Blocks movement while open (added to UILayer.is_blocking_gameplay())
## — talking to someone is a focused interaction, not something you walk
## away from mid-sentence the way browsing a shop is. Also blocks opening
## the book/inventory (see ui_layer.gd's Tab-key handling) — messing with
## items mid-conversation didn't make sense, so dialogue is now fully
## separated from the rest of the menu system rather than sharing its
## generic tile-layout panel-positioning.
##
## Fixed position just above the hotbar (not the shared tile-layout
## system other panels use) — sitting center-screen used to cover
## whoever you were talking to; anchoring near the hotbar instead reads
## more like a normal dialogue box and keeps the speaker visible.

var _ui_layer: Node
var _speaker_label: Label
var _relationship_label: Label
var _text_label: Label
var _choices_container: VBoxContainer
var _continue_button: Button

const PANEL_WIDTH := 560.0
const PANEL_HEIGHT := 220.0
const GAP_ABOVE_HOTBAR := 100.0  ## hotbar's own box starts ~76px above the screen bottom edge — this clears it with room to spare


func build(ui_layer: Node) -> void:
	_ui_layer = ui_layer
	custom_minimum_size = Vector2(PANEL_WIDTH, PANEL_HEIGHT)
	visible = false

	anchor_left = 0.5
	anchor_right = 0.5
	anchor_top = 1.0
	anchor_bottom = 1.0
	offset_left = -PANEL_WIDTH / 2.0
	offset_right = PANEL_WIDTH / 2.0
	offset_bottom = -GAP_ABOVE_HOTBAR
	offset_top = offset_bottom - PANEL_HEIGHT

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 20)
	margin.add_theme_constant_override("margin_right", 20)
	margin.add_theme_constant_override("margin_top", 16)
	margin.add_theme_constant_override("margin_bottom", 16)
	add_child(margin)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 6)
	margin.add_child(vbox)

	var header_row := HBoxContainer.new()
	vbox.add_child(header_row)

	_speaker_label = Label.new()
	_speaker_label.add_theme_font_size_override("font_size", 15)
	_speaker_label.modulate = Color(1, 0.85, 0.5)
	_speaker_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header_row.add_child(_speaker_label)

	_relationship_label = Label.new()
	_relationship_label.add_theme_font_size_override("font_size", 11)
	_relationship_label.modulate = Color(1, 1, 1, 0.55)
	header_row.add_child(_relationship_label)

	vbox.add_child(HSeparator.new())

	_text_label = Label.new()
	_text_label.add_theme_font_size_override("font_size", 14)
	_text_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	_text_label.custom_minimum_size = Vector2(0, 70)
	vbox.add_child(_text_label)

	_choices_container = VBoxContainer.new()
	_choices_container.add_theme_constant_override("separation", 4)
	vbox.add_child(_choices_container)

	_continue_button = Button.new()
	_continue_button.text = "Continue"
	_continue_button.pressed.connect(func(): DialogueManager.advance())
	vbox.add_child(_continue_button)

	DialogueManager.dialogue_started.connect(func(_npc_id): visible = true)
	DialogueManager.dialogue_line_shown.connect(_on_line_shown)
	DialogueManager.dialogue_ended.connect(func(_npc_id): visible = false)


func _on_line_shown(npc_id: String, line: DialogueLine) -> void:
	var npc := _find_npc(npc_id)

	var speaker := line.speaker_override
	if speaker == "":
		speaker = npc.display_name if npc and npc.display_name != "" else npc_id
	_speaker_label.text = speaker
	_text_label.text = line.text

	if RelationshipManager.scores.has(npc_id):
		_relationship_label.text = RelationshipManager.get_tier(npc_id)
		_relationship_label.visible = true
	else:
		_relationship_label.visible = false

	if line.animation_id != "" and npc:
		npc.play_animation(line.animation_id)

	for child in _choices_container.get_children():
		child.queue_free()

	if line.choices.is_empty():
		_continue_button.visible = true
	else:
		_continue_button.visible = false
		for i in line.choices.size():
			_choices_container.add_child(_build_choice_button(npc_id, line, i))


func _build_choice_button(npc_id: String, line: DialogueLine, index: int) -> Button:
	var choice: DialogueChoiceData = line.choices[index]
	var button := Button.new()
	button.text = choice.text if choice.text != "" else "..."
	button.alignment = HORIZONTAL_ALIGNMENT_LEFT

	var skill_met := choice.required_skill_id == "" or SkillManager.meets_requirement(choice.required_skill_id, choice.required_skill_level)
	if not skill_met:
		button.disabled = true
		button.tooltip_text = "Requires %s level %d." % [choice.required_skill_id.capitalize(), choice.required_skill_level]
	elif DialogueManager.is_choice_visited(npc_id, line.id, index):
		# Still fully clickable — greyed out only relays that this
		# pathway's already been explored, doesn't block going down it
		# again if the player wants to.
		button.modulate = Color(1, 1, 1, 0.55)

	if skill_met:
		button.pressed.connect(func(): DialogueManager.choose(index))
	return button


## Finds the currently-active NPC node in the scene by npc_id, purely to
## read its display_name and (see above) trigger its animation hook —
## DialogueManager itself never needs a Node reference, keeping it fully
## decoupled from the 3D scene.
func _find_npc(npc_id: String) -> NPC:
	for node in get_tree().get_nodes_in_group("npcs"):
		if node is NPC and node.npc_id == npc_id:
			return node
	return null


func close_early() -> void:
	if DialogueManager.is_active():
		DialogueManager.end_dialogue()
