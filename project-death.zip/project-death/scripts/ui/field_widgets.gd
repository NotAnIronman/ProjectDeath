extends RefCounted
class_name FieldWidgets

## Small reusable field-widget builders — extracted from the old
## always-visible PropertiesPanel so the exact same widgets can be reused
## inside small per-node popups instead. Every function appends to
## whatever `parent` Control you pass in, rather than owning a fixed
## panel itself.

static func field_label(parent: Control, text: String) -> void:
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", 11)
	label.modulate = Color(1, 1, 1, 0.6)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD
	parent.add_child(label)


static func add_text_field(parent: Control, label: String, value: String, on_commit: Callable) -> LineEdit:
	field_label(parent, label)
	var line_edit := LineEdit.new()
	line_edit.text = value
	line_edit.text_submitted.connect(func(v): on_commit.call(v))
	line_edit.focus_exited.connect(func(): on_commit.call(line_edit.text))
	parent.add_child(line_edit)
	return line_edit


static func add_multiline_field(parent: Control, label: String, value: String, on_commit: Callable) -> TextEdit:
	field_label(parent, label)
	var text_edit := TextEdit.new()
	text_edit.text = value
	text_edit.custom_minimum_size = Vector2(0, 70)
	text_edit.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	text_edit.focus_exited.connect(func(): on_commit.call(text_edit.text))
	parent.add_child(text_edit)
	return text_edit


static func add_bool_field(parent: Control, label: String, value: bool, on_commit: Callable, tooltip: String = "") -> void:
	var checkbox := CheckBox.new()
	checkbox.text = label
	checkbox.button_pressed = value
	if tooltip != "":
		checkbox.tooltip_text = tooltip
	checkbox.toggled.connect(func(v): on_commit.call(v))
	parent.add_child(checkbox)


static func add_int_field(parent: Control, label: String, value: int, on_commit: Callable) -> void:
	field_label(parent, label)
	var spin_box := SpinBox.new()
	spin_box.min_value = -999999
	spin_box.max_value = 999999
	spin_box.value = value
	spin_box.value_changed.connect(func(v): on_commit.call(int(v)))
	parent.add_child(spin_box)


static func add_enum_field(parent: Control, label: String, selected_index: int, option_names: Array, on_commit: Callable) -> OptionButton:
	field_label(parent, label)
	var option_button := OptionButton.new()
	for name_str in option_names:
		option_button.add_item(String(name_str))
	option_button.select(selected_index)
	option_button.item_selected.connect(func(index): on_commit.call(index))
	parent.add_child(option_button)
	return option_button


## Freeform: editable text + a suggestion popup button, for ids that get
## newly invented as content is authored (flags, NPCs, locations, quests).
static func add_suggest_field(parent: Control, label: String, value: String, get_options: Callable, on_commit: Callable) -> LineEdit:
	field_label(parent, label)
	var hbox := HBoxContainer.new()
	parent.add_child(hbox)

	var line_edit := LineEdit.new()
	line_edit.text = value
	line_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	line_edit.text_submitted.connect(func(v): on_commit.call(v))
	line_edit.focus_exited.connect(func(): on_commit.call(line_edit.text))
	hbox.add_child(line_edit)

	var menu_button := MenuButton.new()
	menu_button.text = "▾"
	menu_button.custom_minimum_size = Vector2(28, 0)
	menu_button.get_popup().about_to_popup.connect(func():
		var popup := menu_button.get_popup()
		popup.clear()
		var options: Array = get_options.call()
		for i in options.size():
			popup.add_item(options[i], i)
		if options.is_empty():
			popup.add_item("(nothing found)", -1)
	)
	menu_button.get_popup().id_pressed.connect(func(id):
		if id < 0:
			return
		var options: Array = get_options.call()
		if id < options.size():
			line_edit.text = options[id]
			on_commit.call(options[id])
	)
	hbox.add_child(menu_button)
	return line_edit


## Strict: OptionButton only, for closed sets (items/recipes/skills) —
## there's nothing to "type new" here, you'd create the thing first.
static func add_strict_field(parent: Control, label: String, value: String, get_options: Callable, on_commit: Callable) -> void:
	field_label(parent, label)
	var option_button := OptionButton.new()
	var options: Array = get_options.call()
	var selected_index := -1
	for i in options.size():
		option_button.add_item(options[i])
		if options[i] == value:
			selected_index = i
	if selected_index == -1 and value != "":
		option_button.add_item(value + "  (not found)")
		selected_index = option_button.item_count - 1
	elif selected_index == -1:
		option_button.add_item("(none)")
		selected_index = 0
	option_button.select(selected_index)
	option_button.item_selected.connect(func(index):
		var text := option_button.get_item_text(index).replace("  (not found)", "")
		on_commit.call("" if text == "(none)" else text)
	)
	parent.add_child(option_button)


## A compact editable list of {item_id, quantity} entries — for
## items_given/items_removed on a step, and reward_items on the quest.
static func add_item_list_field(parent: Control, label: String, entries: Array[Dictionary], get_item_ids: Callable, on_change: Callable) -> void:
	field_label(parent, label)
	var list_vbox := VBoxContainer.new()
	parent.add_child(list_vbox)

	var rebuild: Callable
	rebuild = func():
		for child in list_vbox.get_children():
			child.queue_free()
		for i in entries.size():
			var entry: Dictionary = entries[i]
			var row := HBoxContainer.new()
			list_vbox.add_child(row)

			var item_option := OptionButton.new()
			var options: Array = get_item_ids.call()
			var selected_index := -1
			for j in options.size():
				item_option.add_item(options[j])
				if options[j] == entry.get("item_id", ""):
					selected_index = j
			if selected_index == -1:
				item_option.add_item("(none)")
				selected_index = item_option.item_count - 1
			item_option.select(selected_index)
			var index_captured := i
			item_option.item_selected.connect(func(idx):
				var text: String = item_option.get_item_text(idx)
				entries[index_captured]["item_id"] = "" if text == "(none)" else text
				on_change.call()
			)
			row.add_child(item_option)

			var qty_spin := SpinBox.new()
			qty_spin.min_value = 1
			qty_spin.max_value = 9999
			qty_spin.value = int(entry.get("quantity", 1))
			qty_spin.value_changed.connect(func(v):
				entries[index_captured]["quantity"] = int(v)
				on_change.call()
			)
			row.add_child(qty_spin)

			var remove_button := Button.new()
			remove_button.text = "✕"
			remove_button.pressed.connect(func():
				entries.remove_at(index_captured)
				on_change.call()
				rebuild.call()
			)
			row.add_child(remove_button)

	rebuild.call()

	var add_button := Button.new()
	add_button.text = "+ Add"
	add_button.pressed.connect(func():
		entries.append({"item_id": "", "quantity": 1})
		on_change.call()
		rebuild.call()
	)
	parent.add_child(add_button)


## A compact editable list of skill_id -> int amount entries — for
## QuestData.reward_xp, the one Dictionary<String,int> field in the
## schema. Same reasoning as add_item_list_field: small and simple
## enough that a purpose-built mini-editor here beats another Resource
## type conversion.
static func add_skill_amount_dict_field(parent: Control, label: String, dict: Dictionary, get_skill_ids: Callable, on_change: Callable) -> void:
	field_label(parent, label)
	var list_vbox := VBoxContainer.new()
	parent.add_child(list_vbox)

	var rebuild: Callable
	rebuild = func():
		for child in list_vbox.get_children():
			child.queue_free()
		var skill_ids: Array = get_skill_ids.call()
		for key in dict.keys():
			var row := HBoxContainer.new()
			list_vbox.add_child(row)

			var skill_option := OptionButton.new()
			var selected_index := -1
			for j in skill_ids.size():
				skill_option.add_item(skill_ids[j])
				if skill_ids[j] == key:
					selected_index = j
			if selected_index == -1:
				skill_option.add_item((String(key) if key != "" else "(pick one)") + "  (not found)")
				selected_index = skill_option.item_count - 1
			skill_option.select(selected_index)
			var old_key = key
			skill_option.item_selected.connect(func(idx):
				var new_key: String = skill_option.get_item_text(idx).replace("  (not found)", "")
				var amount = dict[old_key]
				dict.erase(old_key)
				dict[new_key] = amount
				on_change.call()
				rebuild.call()
			)
			row.add_child(skill_option)

			var amount_spin := SpinBox.new()
			amount_spin.min_value = -999999
			amount_spin.max_value = 999999
			amount_spin.value = int(dict[key])
			var key_captured = key
			amount_spin.value_changed.connect(func(v):
				dict[key_captured] = int(v)
				on_change.call()
			)
			row.add_child(amount_spin)

			var remove_button := Button.new()
			remove_button.text = "✕"
			remove_button.pressed.connect(func():
				dict.erase(key_captured)
				on_change.call()
				rebuild.call()
			)
			row.add_child(remove_button)

	rebuild.call()

	var add_button := Button.new()
	add_button.text = "+ Add"
	add_button.pressed.connect(func():
		if not dict.has(""):
			dict[""] = 0
			on_change.call()
			rebuild.call()
	)
	parent.add_child(add_button)


## A settings panel that's a REAL GraphNode living on the canvas, not a
## separate Window — a Window sits on top of everything and blocks
## interacting with the graph underneath it (can't pan, can't click other
## nodes) while it's open, which defeats "leave it open while you work."
## A GraphNode is just another citizen of the same GraphEdit: draggable
## with the same native dragging every other node has. Closing is a
## manually-added button in the titlebar (GraphNode.show_close/
## close_request are Godot 3-only and don't exist in Godot 4 — see the
## BUGFIX comment in _spawn_settings_node below), and the rest of the
## graph stays fully interactive the whole time it's open.
static func show_settings_node(anchor: GraphNode, content: Control, node_title: String) -> GraphNode:
	var graph_edit := anchor.get_parent() as GraphEdit
	if graph_edit == null:
		push_error("FieldWidgets.show_settings_node: anchor's parent isn't a GraphEdit.")
		return null
	return _spawn_settings_node(graph_edit, anchor.position_offset + Vector2(anchor.size.x + 40, 0), content, node_title)


## For settings not anchored to any specific existing node (e.g. quest-
## level settings) — spawns near wherever the graph is currently scrolled to.
static func show_settings_node_in_graph(graph_edit: GraphEdit, content: Control, node_title: String) -> GraphNode:
	return _spawn_settings_node(graph_edit, graph_edit.scroll_offset + Vector2(60, 60), content, node_title)


static func _spawn_settings_node(graph_edit: GraphEdit, spawn_position: Vector2, content: Control, node_title: String) -> GraphNode:
	var settings_node := GraphNode.new()
	settings_node.name = "settings_%d" % Time.get_ticks_usec()  # unique enough — these are transient, never saved
	settings_node.title = node_title
	settings_node.custom_minimum_size = Vector2(300, 0)

	# BUGFIX: show_close/close_request were removed from GraphNode
	# entirely in Godot 4 (this existed in Godot 3, not 4 — confirmed via
	# godotengine/godot#82909 and the PR that removed it). The Godot 4
	# way is adding your own button straight to the titlebar.
	var close_button := Button.new()
	close_button.text = "✕"
	close_button.tooltip_text = "Close"
	close_button.pressed.connect(func(): settings_node.queue_free())
	settings_node.get_titlebar_hbox().add_child(close_button)

	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(300, 360)
	settings_node.add_child(scroll)

	# BUGFIX: GraphEdit uses plain mouse wheel for zoom by default (a
	# deliberate Godot 4.0 change) — without this, scrolling inside this
	# panel zoomed the whole canvas instead of scrolling the panel's
	# content, since GraphEdit's zoom handling was winning the conflict
	# over plain scroll wheel input.
	scroll.gui_input.connect(func(event: InputEvent):
		if event is InputEventMouseButton and event.pressed:
			if event.button_index == MOUSE_BUTTON_WHEEL_UP:
				scroll.scroll_vertical -= 60
				scroll.get_viewport().set_input_as_handled()
			elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
				scroll.scroll_vertical += 60
				scroll.get_viewport().set_input_as_handled()
	)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 8)
	margin.add_theme_constant_override("margin_right", 8)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 8)
	scroll.add_child(margin)
	margin.add_child(content)
	content.custom_minimum_size = Vector2(280, 0)

	settings_node.position_offset = spawn_position
	graph_edit.add_child(settings_node)
	return settings_node
