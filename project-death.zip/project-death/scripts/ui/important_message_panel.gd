extends PanelContainer
class_name ImportantMessagePanel

## The UI for ImportantMessageManager. Deliberately positioned center-
## screen (not above the hotbar like DialoguePanel) and visually
## distinct — this needs to read as "stop and read this" rather than
## "casual conversation", matching why it exists at all: for things that
## matter more than a toast.

var _text_label: Label
var _confirm_button: Button

const PANEL_WIDTH := 480.0
const PANEL_HEIGHT := 180.0


func build(_ui_layer: Node) -> void:
	custom_minimum_size = Vector2(PANEL_WIDTH, PANEL_HEIGHT)
	visible = false

	anchor_left = 0.5
	anchor_right = 0.5
	anchor_top = 0.5
	anchor_bottom = 0.5
	offset_left = -PANEL_WIDTH / 2.0
	offset_right = PANEL_WIDTH / 2.0
	offset_top = -PANEL_HEIGHT / 2.0
	offset_bottom = PANEL_HEIGHT / 2.0

	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.08, 0.07, 0.06, 0.97)
	style.border_color = Color(1, 0.85, 0.4)
	style.set_border_width_all(2)
	style.set_corner_radius_all(6)
	style.content_margin_left = 20
	style.content_margin_right = 20
	style.content_margin_top = 16
	style.content_margin_bottom = 16
	add_theme_stylebox_override("panel", style)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 14)
	add_child(vbox)

	var header := Label.new()
	header.text = "⚠ Notice"
	header.add_theme_font_size_override("font_size", 15)
	header.modulate = Color(1, 0.85, 0.4)
	vbox.add_child(header)
	vbox.add_child(HSeparator.new())

	_text_label = Label.new()
	_text_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	_text_label.custom_minimum_size = Vector2(0, 70)
	vbox.add_child(_text_label)

	_confirm_button = Button.new()
	_confirm_button.text = "Continue"
	_confirm_button.pressed.connect(func(): ImportantMessageManager.confirm())
	vbox.add_child(_confirm_button)

	ImportantMessageManager.message_shown.connect(func(text):
		_text_label.text = text
		visible = true
	)
	ImportantMessageManager.message_dismissed.connect(func():
		visible = not ImportantMessageManager.is_active()
	)
