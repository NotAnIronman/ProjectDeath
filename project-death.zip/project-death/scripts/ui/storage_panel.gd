extends PanelContainer
class_name StoragePanel

## The storage/chest UI — extracted from ui_layer.gd so it can be read,
## debugged, and changed in isolation. Behavior is unchanged from before
## the extraction; this is a relocation, not a rewrite.
##
## Needs a reference to UILayer for the two things that are genuinely
## cross-panel concerns (the tile layout system, shared by every dockable
## panel) — everything else here is fully self-contained.

var _ui_layer: Node

var _title_label: Label
var _hint_label: Label
var _slots_container: GridContainer
var _slot_widgets: Array[StorageSlotUI] = []
var _search_field: LineEdit
var _current_container: StorageContainer = null


func build(ui_layer: Node) -> void:
	_ui_layer = ui_layer
	custom_minimum_size = Vector2(440, 460)
	visible = false
	_ui_layer.register_tile_panel(self)  # order relative to other panels = left-to-right slot order

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 16)
	margin.add_theme_constant_override("margin_right", 16)
	margin.add_theme_constant_override("margin_top", 16)
	margin.add_theme_constant_override("margin_bottom", 16)
	add_child(margin)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	margin.add_child(vbox)

	var header_row := HBoxContainer.new()
	vbox.add_child(header_row)

	_title_label = Label.new()
	_title_label.add_theme_font_size_override("font_size", 16)
	_title_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header_row.add_child(_title_label)

	var close_button := Button.new()
	close_button.text = "Close"
	close_button.pressed.connect(close)
	header_row.add_child(close_button)

	_hint_label = Label.new()
	_hint_label.add_theme_font_size_override("font_size", 11)
	_hint_label.modulate = Color(1, 1, 1, 0.6)
	vbox.add_child(_hint_label)

	var drag_hint_label := Label.new()
	drag_hint_label.text = "Click or drag items between your inventory and this container."
	drag_hint_label.add_theme_font_size_override("font_size", 10)
	drag_hint_label.modulate = Color(1, 1, 1, 0.45)
	drag_hint_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	vbox.add_child(drag_hint_label)

	var toolbar_row := HBoxContainer.new()
	toolbar_row.add_theme_constant_override("separation", 8)
	vbox.add_child(toolbar_row)

	_search_field = LineEdit.new()
	_search_field.placeholder_text = "Search..."
	_search_field.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_search_field.text_changed.connect(func(_text): _refresh())
	toolbar_row.add_child(_search_field)

	var sort_button := Button.new()
	sort_button.text = "Sort"
	sort_button.pressed.connect(func():
		if _current_container:
			_current_container.sort_slots()
	)
	toolbar_row.add_child(sort_button)

	var auto_deposit_button := Button.new()
	auto_deposit_button.text = "Auto Deposit"
	auto_deposit_button.pressed.connect(func():
		if _current_container:
			var moved: int = _current_container.auto_deposit_from_player()
			print("Auto-deposited %d item type(s)." % moved)
	)
	toolbar_row.add_child(auto_deposit_button)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(scroll)

	_slots_container = GridContainer.new()
	_slots_container.columns = 7
	_slots_container.add_theme_constant_override("h_separation", 4)
	_slots_container.add_theme_constant_override("v_separation", 4)
	scroll.add_child(_slots_container)


func open(container: StorageContainer) -> void:
	_current_container = container
	if not container.contents_changed.is_connected(_refresh):
		container.contents_changed.connect(_refresh)

	var type_data := container.get_type_data()
	_title_label.text = type_data.display_name if type_data else "Storage"

	var hint := "Accepts: "
	if type_data == null:
		hint += "anything"
	elif type_data.seeds_only:
		hint += "seeds only"
	elif type_data.allowed_categories.is_empty():
		hint += "anything"
	else:
		var names: Array = []
		for cat in type_data.allowed_categories:
			names.append(String(ItemData.ItemCategory.keys()[cat]).capitalize())
		hint += ", ".join(names)
	_hint_label.text = hint

	_search_field.text = ""
	visible = true
	InventorySlotUI.active_storage_target = container
	_refresh()
	_ui_layer.request_tile_layout()


func close() -> void:
	visible = false
	InventorySlotUI.active_storage_target = null
	if _current_container and _current_container.contents_changed.is_connected(_refresh):
		_current_container.contents_changed.disconnect(_refresh)
	_current_container = null
	_ui_layer.request_tile_layout()


func get_current_container() -> StorageContainer:
	return _current_container


func _refresh() -> void:
	if _current_container == null:
		return

	var slot_count: int = _current_container.slots.size()

	var needs_rebuild: bool = _slot_widgets.size() != slot_count \
		or (_slot_widgets.size() > 0 and _slot_widgets[0].container != _current_container)

	if needs_rebuild:
		for child in _slots_container.get_children():
			child.queue_free()
		_slot_widgets.clear()
		for i in slot_count:
			var widget := StorageSlotUI.new()
			widget.setup(_current_container, i)
			_slots_container.add_child(widget)
			_slot_widgets.append(widget)

	var filter_text: String = _search_field.text.to_lower()
	for i in slot_count:
		var widget := _slot_widgets[i]
		widget.refresh()

		var item_id: String = _current_container.slots[i]["item_id"]
		if item_id != "" and filter_text != "":
			var def: ItemData = InventoryManager.item_defs.get(item_id)
			var display_name: String = def.display_name if def else item_id
			widget.modulate = Color(1, 1, 1, 0.25) if not display_name.to_lower().contains(filter_text) else Color.WHITE
		else:
			widget.modulate = Color.WHITE
