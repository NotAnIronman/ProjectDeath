extends PanelContainer
class_name ShopPanel

## The shop UI — extracted from ui_layer.gd, same relocation-not-rewrite
## approach as StoragePanel (see its header comment for the reasoning).

var _ui_layer: Node

var _title_label: Label
var _sell_hint_label: Label
var _stock_container: GridContainer
var _current_shop: TradingPost = null


func build(ui_layer: Node) -> void:
	_ui_layer = ui_layer
	custom_minimum_size = Vector2(440, 460)
	visible = false
	_ui_layer.register_tile_panel(self)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 16)
	margin.add_theme_constant_override("margin_right", 16)
	margin.add_theme_constant_override("margin_top", 16)
	margin.add_theme_constant_override("margin_bottom", 16)
	add_child(margin)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	margin.add_child(vbox)

	var header_row := HBoxContainer.new()
	vbox.add_child(header_row)

	_title_label = Label.new()
	_title_label.add_theme_font_size_override("font_size", 16)
	_title_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header_row.add_child(_title_label)

	var close_button := Button.new()
	close_button.text = "Close"
	close_button.pressed.connect(close)
	header_row.add_child(close_button)

	_sell_hint_label = Label.new()
	_sell_hint_label.add_theme_font_size_override("font_size", 10)
	_sell_hint_label.modulate = Color(1, 1, 1, 0.45)
	_sell_hint_label.text = "Click any item in your inventory to sell it here."
	_sell_hint_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	vbox.add_child(_sell_hint_label)
	vbox.add_child(HSeparator.new())

	var buy_label := Label.new()
	buy_label.text = "For Sale"
	buy_label.add_theme_font_size_override("font_size", 12)
	buy_label.modulate = Color(1, 1, 1, 0.6)
	vbox.add_child(buy_label)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(scroll)

	_stock_container = GridContainer.new()
	_stock_container.columns = 5
	_stock_container.add_theme_constant_override("h_separation", 4)
	_stock_container.add_theme_constant_override("v_separation", 4)
	scroll.add_child(_stock_container)


func open(shop: TradingPost) -> void:
	_current_shop = shop
	var type_data := shop.get_type_data()
	_title_label.text = type_data.display_name if type_data else "Shop"

	for child in _stock_container.get_children():
		child.queue_free()
	for item_id in shop.get_purchasable_items():
		var widget := ShopSlotUI.new()
		widget.setup(shop, item_id)
		_stock_container.add_child(widget)

	visible = true
	InventorySlotUI.active_shop_target = shop
	_ui_layer.request_tile_layout()


func close() -> void:
	visible = false
	InventorySlotUI.active_shop_target = null
	_current_shop = null
	_ui_layer.request_tile_layout()


func get_current_shop() -> TradingPost:
	return _current_shop
