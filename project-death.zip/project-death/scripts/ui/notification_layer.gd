extends Control
class_name NotificationLayer

## Achievement completion popup + generic toast notifications, extracted
## from ui_layer.gd. Bundled into one file rather than two — both are
## small, visually-adjacent "toast" concerns, and splitting further would
## be over-atomizing for what they actually are.
##
## POSITIONING: uses direct pixel math (measure the control's own actual
## size, center it manually), the same proven approach the tile system
## uses — NOT nested anchor presets. Two rounds of anchor-preset attempts
## here both had real bugs (a Node where a Control was needed; then a
## zero-height PRESET_TOP_WIDE strip that made "centered within it"
## ambiguous no matter what the child's own anchors were). Both toasts and
## the achievement popup have CONTENT-DEPENDENT width (text length varies),
## so this recenters via the `resized` signal every time that width
## actually changes, rather than computing a position once and hoping it
## stays valid.
##
## Fully self-contained: connects directly to AchievementManager /
## NotificationManager, no reference back to UILayer needed.

@export var achievement_sound: AudioStream  ## optional — assign in the Inspector once you have one, silently skipped until then

var achievement_popup: PanelContainer
var achievement_popup_name_label: Label
var _achievement_popup_tween: Tween
var _achievement_audio_player: AudioStreamPlayer

var _notification_stack: VBoxContainer

const NOTIFICATION_COLORS := {
	"levelup": Color(0.16, 0.32, 0.2, 0.92),
	"world": Color(0.16, 0.24, 0.32, 0.92),
	"info": Color(0.14, 0.14, 0.14, 0.9),
	"tip": Color(0.22, 0.18, 0.32, 0.92),
}


func build() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_build_notification_stack()
	_build_achievement_popup()
	AchievementManager.achievement_completed.connect(_on_achievement_completed)


func _on_achievement_completed(def: AchievementData) -> void:
	_show_achievement_popup(def)


## Horizontally centers `control` on the current viewport width, at a
## fixed `y` — called once at build time AND every time the control's own
## size actually changes (its `resized` signal), so it stays centered
## even as its content (and therefore width) changes.
func _center_horizontally(control: Control, y: float) -> void:
	var viewport_width: float = get_viewport().get_visible_rect().size.x
	control.position = Vector2((viewport_width - control.size.x) / 2.0, y)


## --- Generic notification toasts (NotificationManager.notify) ---

func _build_notification_stack() -> void:
	_notification_stack = VBoxContainer.new()
	_notification_stack.alignment = BoxContainer.ALIGNMENT_CENTER
	_notification_stack.add_theme_constant_override("separation", 6)
	_notification_stack.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_notification_stack.set_anchors_preset(Control.PRESET_TOP_LEFT)
	add_child(_notification_stack)

	_notification_stack.resized.connect(func(): _center_horizontally(_notification_stack, 24))
	_center_horizontally(_notification_stack, 24)

	NotificationManager.notification_requested.connect(_on_notification_requested)


## Toasts are actual children of a VBoxContainer, which stacks and
## re-flows them automatically as each one is freed — no manual position
## math needed for multiple simultaneous notifications. Adding/removing a
## toast also changes the VBoxContainer's own width (longer messages =
## wider), which is exactly what re-triggers _center_horizontally via the
## resized signal above.
##
## BUGFIX (the "notifications drift down over a long session" report):
## modulate:a fading to 0 makes a toast invisible but does NOT remove it
## from the VBoxContainer's LAYOUT — it still reserves its full height
## until queue_free() actually runs. If that queue_free ever fails to
## fire (e.g. its Tween gets interrupted mid-sequence by the pause menu,
## or literally anything else stops it before completion), that toast
## silently stays in the stack forever, permanently taking up space, and
## every later toast gets pushed further down below it — worse the more
## messages have ever been shown, which matches exactly what was
## reported. Three independent layers below make this categorically not
## possible to happen again, regardless of what actually caused it:
##   1. The fade tween is pause-immune, so the pause menu can't strand it mid-fade.
##   2. A hard failsafe timer frees the toast a beat after the tween should
##      have finished, even if the tween itself was somehow killed/never ran.
##   3. The stack is hard-capped — if more than MAX_VISIBLE_TOASTS are ever
##      present at once for ANY reason, the oldest is force-removed
##      immediately. The stack's height (and therefore the drift) now has a
##      mathematical ceiling no matter what goes wrong upstream.
const MAX_VISIBLE_TOASTS: int = 6

func _on_notification_requested(message: String, category: String) -> void:
	# Layer 3: hard cap, checked BEFORE adding the new one.
	while _notification_stack.get_child_count() >= MAX_VISIBLE_TOASTS:
		_notification_stack.get_child(0).queue_free()
		_notification_stack.remove_child(_notification_stack.get_child(0))

	var toast := PanelContainer.new()
	toast.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style := StyleBoxFlat.new()
	style.bg_color = NOTIFICATION_COLORS.get(category, NOTIFICATION_COLORS["info"])
	style.set_corner_radius_all(6)
	style.content_margin_left = 14
	style.content_margin_right = 14
	style.content_margin_top = 6
	style.content_margin_bottom = 6
	toast.add_theme_stylebox_override("panel", style)
	toast.modulate.a = 0.0
	_notification_stack.add_child(toast)

	var label := Label.new()
	label.text = message
	label.add_theme_font_size_override("font_size", 13)
	toast.add_child(label)

	var tween := create_tween()
	tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)  # Layer 1: immune to the pause menu
	tween.tween_property(toast, "modulate:a", 1.0, 0.2)
	tween.tween_interval(2.5)
	tween.tween_property(toast, "modulate:a", 0.0, 0.4)
	tween.tween_callback(_free_toast_by_id.bind(toast.get_instance_id()))

	# Layer 2: fires ~1s after the tween above should already be done
	# (0.2 + 2.5 + 0.4 = 3.1s total). If the tween somehow never
	# completes, this guarantees the toast is gone anyway.
	var failsafe := get_tree().create_timer(4.2, true, false, true)  # process_always=true — also immune to pause
	failsafe.timeout.connect(_free_toast_by_id.bind(toast.get_instance_id()))


## BUGFIX: this used to bind the toast Node itself directly
## (tween_callback(toast.queue_free), then later _free_toast(toast)).
## Binding a raw Object reference to a signal/timer that fires LATER is
## unsafe if that object gets freed in the meantime — the engine can't
## safely marshal the now-dangling pointer when the callable actually
## fires, which threw exactly the reported
## "Cannot convert argument 1 from Object to Object" error. Binding the
## instance ID (a plain int, always safe to pass around) and resolving
## it back via instance_from_id() — which safely returns null for an ID
## that no longer exists — avoids the whole problem.
func _free_toast_by_id(instance_id: int) -> void:
	var toast := instance_from_id(instance_id)
	if toast and is_instance_valid(toast):
		(toast as Node).queue_free()


## --- Achievement completion popup (top-center, brief) ---

func _build_achievement_popup() -> void:
	achievement_popup = PanelContainer.new()
	achievement_popup.visible = false
	achievement_popup.modulate.a = 0.0
	achievement_popup.set_anchors_preset(Control.PRESET_TOP_LEFT)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.1, 0.09, 0.06, 0.92)
	style.set_corner_radius_all(10)
	style.set_border_width_all(1)
	style.border_color = Color(1, 0.85, 0.4, 0.6)
	style.content_margin_left = 20
	style.content_margin_right = 20
	style.content_margin_top = 8
	style.content_margin_bottom = 8
	achievement_popup.add_theme_stylebox_override("panel", style)
	add_child(achievement_popup)

	achievement_popup.resized.connect(func(): _center_horizontally(achievement_popup, 60))
	_center_horizontally(achievement_popup, 60)

	var vbox := VBoxContainer.new()
	achievement_popup.add_child(vbox)

	var title := Label.new()
	title.text = "Achievement Unlocked"
	title.add_theme_font_size_override("font_size", 11)
	title.modulate = Color(1, 0.85, 0.4)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)

	achievement_popup_name_label = Label.new()
	achievement_popup_name_label.add_theme_font_size_override("font_size", 16)
	achievement_popup_name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(achievement_popup_name_label)

	_achievement_audio_player = AudioStreamPlayer.new()
	add_child(_achievement_audio_player)


func _show_achievement_popup(def: AchievementData) -> void:
	achievement_popup_name_label.text = def.display_name
	achievement_popup.visible = true
	achievement_popup.modulate.a = 0.0
	_center_horizontally(achievement_popup, 60)  # text just changed -> width likely changed -> recenter immediately, don't wait for the next resize

	if achievement_sound:
		_achievement_audio_player.stream = achievement_sound
		_achievement_audio_player.play()

	if _achievement_popup_tween and _achievement_popup_tween.is_valid():
		_achievement_popup_tween.kill()
	_achievement_popup_tween = create_tween()
	_achievement_popup_tween.tween_property(achievement_popup, "modulate:a", 1.0, 0.25)
	_achievement_popup_tween.tween_interval(2.5)
	_achievement_popup_tween.tween_property(achievement_popup, "modulate:a", 0.0, 0.6)
	_achievement_popup_tween.tween_callback(func(): achievement_popup.visible = false)
