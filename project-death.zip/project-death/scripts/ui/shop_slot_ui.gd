extends PanelContainer
class_name ShopSlotUI

## One item in a shop's stock display. Simpler than StorageSlotUI — no
## drag-and-drop (buying isn't a drag gesture), just click to buy one.
## Visual style deliberately mirrors StorageSlotUI/InventorySlotUI so shop
## UI doesn't feel like a different app from the rest of the game's UI.

var shop: TradingPost
var item_id: String

var icon: TextureRect
var price_label: Label

static var style_normal: StyleBoxFlat
static var style_hover: StyleBoxFlat

var _is_hovered: bool = false


func _init() -> void:
	if style_normal == null:
		style_normal = StyleBoxFlat.new()
		style_normal.bg_color = Color(0.1, 0.1, 0.1, 0.55)
		style_normal.set_border_width_all(2)
		style_normal.border_color = Color(1, 1, 1, 0.15)
		style_normal.set_corner_radius_all(4)
		style_hover = style_normal.duplicate()
		style_hover.border_color = Color(0.6, 1.0, 0.6, 0.9)

	mouse_filter = Control.MOUSE_FILTER_STOP
	add_theme_stylebox_override("panel", style_normal)
	custom_minimum_size = Vector2(64, 68)

	var vbox := VBoxContainer.new()
	vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	add_child(vbox)

	var center := CenterContainer.new()
	vbox.add_child(center)
	icon = TextureRect.new()
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.custom_minimum_size = Vector2(34, 34)
	center.add_child(icon)

	price_label = Label.new()
	price_label.add_theme_font_size_override("font_size", 11)
	price_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	price_label.modulate = Color(1.0, 0.9, 0.5)
	vbox.add_child(price_label)

	mouse_entered.connect(func(): _is_hovered = true; add_theme_stylebox_override("panel", style_hover))
	mouse_exited.connect(func(): _is_hovered = false; add_theme_stylebox_override("panel", style_normal))


func setup(shop_ref: TradingPost, target_item_id: String) -> void:
	shop = shop_ref
	item_id = target_item_id
	var def: ItemData = InventoryManager.item_defs.get(item_id)
	if def == null:
		return
	icon.texture = def.icon
	price_label.text = "%d g" % def.buy_price
	tooltip_text = def.display_name


func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and not event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if shop.buy(item_id, 1):
			print("Bought 1 x %s." % item_id)
		else:
			print("Can't afford that (or something changed).")
