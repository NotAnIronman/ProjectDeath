extends PanelContainer
class_name WaypointPanel

## Fast travel UI (M key) — same "extracted, self-contained panel" shape
## as StoragePanel/ShopPanel: built once in UILayer._ready(), owns its
## own open/close, no reference back to UILayer needed beyond registering
## with the tile layout system.

var _ui_layer: Node
var _name_input: LineEdit
var _list_container: VBoxContainer


func build(ui_layer: Node) -> void:
	_ui_layer = ui_layer
	custom_minimum_size = Vector2(360, 420)
	visible = false
	_ui_layer.register_tile_panel(self)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 16)
	margin.add_theme_constant_override("margin_right", 16)
	margin.add_theme_constant_override("margin_top", 16)
	margin.add_theme_constant_override("margin_bottom", 16)
	add_child(margin)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	margin.add_child(vbox)

	var header_row := HBoxContainer.new()
	vbox.add_child(header_row)

	var title := Label.new()
	title.text = "Waypoints"
	title.add_theme_font_size_override("font_size", 16)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header_row.add_child(title)

	var close_button := Button.new()
	close_button.text = "Close"
	close_button.pressed.connect(close)
	header_row.add_child(close_button)

	vbox.add_child(HSeparator.new())

	# --- Bookmark current spot ---
	var bookmark_row := HBoxContainer.new()
	bookmark_row.add_theme_constant_override("separation", 6)
	vbox.add_child(bookmark_row)

	_name_input = LineEdit.new()
	_name_input.placeholder_text = "Name this spot..."
	_name_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_name_input.text_submitted.connect(func(_text: String): _bookmark_here())
	bookmark_row.add_child(_name_input)

	var bookmark_button := Button.new()
	bookmark_button.text = "Bookmark Here"
	bookmark_button.pressed.connect(_bookmark_here)
	bookmark_row.add_child(bookmark_button)

	vbox.add_child(HSeparator.new())

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(scroll)

	_list_container = VBoxContainer.new()
	_list_container.add_theme_constant_override("separation", 4)
	_list_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(_list_container)

	FastTravelManager.waypoints_changed.connect(_refresh_list)


func _bookmark_here() -> void:
	var player := WorldManager.get_player()
	if player == null:
		return
	if FastTravelManager.add_waypoint(_name_input.text, player.global_position):
		_name_input.text = ""


func open() -> void:
	visible = true
	_refresh_list()
	_ui_layer.request_tile_layout()


func close() -> void:
	visible = false
	_ui_layer.request_tile_layout()


func _refresh_list() -> void:
	for child in _list_container.get_children():
		child.queue_free()

	var names: Array = FastTravelManager.waypoints.keys()
	names.sort()

	if names.is_empty():
		var empty_label := Label.new()
		empty_label.text = "No waypoints yet — bookmark your first spot above."
		empty_label.modulate = Color(1, 1, 1, 0.6)
		empty_label.autowrap_mode = TextServer.AUTOWRAP_WORD
		_list_container.add_child(empty_label)
		return

	for waypoint_name in names:
		_list_container.add_child(_build_waypoint_row(waypoint_name))


func _build_waypoint_row(waypoint_name: String) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)

	var label := Label.new()
	label.text = waypoint_name
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.clip_text = true
	row.add_child(label)

	var travel_button := Button.new()
	travel_button.text = "Travel"
	travel_button.pressed.connect(func():
		if FastTravelManager.travel_to(waypoint_name):
			close()  # travelling elsewhere while looking at a UI list is disorienting — close so the player sees where they landed
	)
	row.add_child(travel_button)

	var delete_button := Button.new()
	delete_button.text = "✕"
	delete_button.custom_minimum_size = Vector2(28, 0)
	delete_button.pressed.connect(func(): FastTravelManager.remove_waypoint(waypoint_name))
	row.add_child(delete_button)

	return row
