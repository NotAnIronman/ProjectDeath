extends Control
class_name WorldMapView

## Live top-down camera view of the world around the player, built for
## the book's Map page. Renders into a SubViewport that shares the main
## scene's World3D (own_world_3d left false, its default) — so it shows
## exactly what's actually streamed in around the player right now,
## automatically, with no separate painted map to keep in sync with cell
## streaming. This was a deliberate choice over a pre-rendered/painted
## map image: no new art needed, and as a side benefit it doubles as a
## genuinely useful live debug view of what's currently loaded.
##
## Beacon markers are positioned via THIS camera's own unproject_position()
## against each beacon's real 3D position, so they track accurately as
## the view scrolls with the player — no separate world-to-map coordinate
## math to keep correct by hand.

const MAP_SIZE := Vector2i(420, 420)
const ORTHO_SIZE := 130.0     ## meters of world visible top-to-bottom in the view — smaller = more zoomed in
const CAMERA_HEIGHT := 150.0  ## how far above the player the camera sits

var _sub_viewport: SubViewport
var _camera: Camera3D
var _marker_layer: Control
var _player_marker: ColorRect

var _beacon_list: VBoxContainer
var _beacon_markers: Dictionary = {}  # persistent_id -> ColorRect
var _focused_beacon: WaypointBeacon = null


func build() -> void:
	var hbox := HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 12)
	hbox.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(hbox)

	# --- Live camera view ---
	var view_container := Control.new()
	view_container.custom_minimum_size = MAP_SIZE
	hbox.add_child(view_container)

	_sub_viewport = SubViewport.new()
	_sub_viewport.size = MAP_SIZE
	# Only actually renders while this page is visible — see _process,
	# which flips this on/off. No point spending render time on a map
	# nobody's looking at.
	_sub_viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED
	# Fix: the day/night DirectionalLight's shadows were showing up in
	# the map render (shared World3D means the same light/shadows apply
	# to both the main view and this one). UNSHADED renders everything
	# at flat albedo with no lighting/shadows at all — exactly what a
	# stylized top-down map wants, and it's a genuine engine feature for
	# this rather than a workaround.
	_sub_viewport.debug_draw = Viewport.DEBUG_DRAW_UNSHADED
	add_child(_sub_viewport)

	_camera = Camera3D.new()
	_camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	_camera.size = ORTHO_SIZE
	_camera.rotation_degrees = Vector3(-90, 0, 0)  # straight down
	_camera.far = CAMERA_HEIGHT + 400.0
	_camera.current = true  # only affects OUR SubViewport's active camera — completely independent of the main game camera's Viewport
	_sub_viewport.add_child(_camera)

	var texture_rect := TextureRect.new()
	texture_rect.texture = _sub_viewport.get_texture()
	texture_rect.custom_minimum_size = MAP_SIZE
	texture_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	# Fix #1 — a raw camera feed reads as "a camera hovering over the
	# player," not a map. This shader desaturates/tints/posterizes/
	# vignettes it toward the book's existing parchment palette instead.
	var shader: Shader = load("res://scripts/ui/world_map_stylized.gdshader")
	if shader:
		var shader_material := ShaderMaterial.new()
		shader_material.shader = shader
		texture_rect.material = shader_material
	view_container.add_child(texture_rect)

	_marker_layer = Control.new()
	_marker_layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	_marker_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	view_container.add_child(_marker_layer)

	_player_marker = ColorRect.new()
	_player_marker.color = Color(0.3, 0.9, 1.0, 1.0)
	_player_marker.size = Vector2(10, 10)
	_player_marker.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_marker_layer.add_child(_player_marker)

	# --- Beacon list / travel targets ---
	var list_vbox := VBoxContainer.new()
	list_vbox.add_theme_constant_override("separation", 6)
	list_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list_vbox.custom_minimum_size = Vector2(180, 0)
	hbox.add_child(list_vbox)

	var list_label := Label.new()
	list_label.text = "Beacons"
	list_label.add_theme_font_size_override("font_size", 13)
	list_vbox.add_child(list_label)
	list_vbox.add_child(HSeparator.new())

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	list_vbox.add_child(scroll)

	_beacon_list = VBoxContainer.new()
	_beacon_list.add_theme_constant_override("separation", 4)
	_beacon_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(_beacon_list)

	# CONNECT_DEFERRED: a rename is triggered FROM the beacon name
	# LineEdit's own text_submitted/focus_exited signal. Rebuilding the
	# whole list synchronously from there would free that very LineEdit
	# while still inside its own signal callback — connecting deferred
	# pushes the rebuild to the next idle frame instead, after the
	# LineEdit has safely finished its own signal processing.
	FastTravelManager.beacons_changed.connect(_refresh_beacon_list, CONNECT_DEFERRED)
	_refresh_beacon_list()


## Called by UILayer.open_map_page() when opened directly from a beacon's
## interact() — currently just excludes that beacon from the travel list
## (see FastTravelManager.get_travel_targets), since travelling from a
## beacon to itself isn't a real option.
func focus_on_beacon(beacon: WaypointBeacon) -> void:
	_focused_beacon = beacon
	_refresh_beacon_list()


func _process(_delta: float) -> void:
	if not is_visible_in_tree():
		if _sub_viewport.render_target_update_mode != SubViewport.UPDATE_DISABLED:
			_sub_viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED
		return
	if _sub_viewport.render_target_update_mode != SubViewport.UPDATE_ALWAYS:
		_sub_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS

	var player := WorldManager.get_player()
	if player == null:
		return

	_camera.global_position = Vector3(player.global_position.x, player.global_position.y + CAMERA_HEIGHT, player.global_position.z)
	_update_marker(_player_marker, player.global_position)

	for persistent_id in _beacon_markers:
		if FastTravelManager.beacons.has(persistent_id):
			_update_marker(_beacon_markers[persistent_id], FastTravelManager.beacons[persistent_id]["position"])


## Projects a world position into this camera's SubViewport space and
## positions `marker` there, hiding it if it's currently outside the
## visible map area (no point drawing a dot floating off in space at the
## viewport's edge).
func _update_marker(marker: Control, world_pos: Vector3) -> void:
	var screen_pos: Vector2 = _camera.unproject_position(world_pos)
	marker.position = screen_pos - marker.size / 2.0
	marker.visible = screen_pos.x >= 0 and screen_pos.x <= MAP_SIZE.x and screen_pos.y >= 0 and screen_pos.y <= MAP_SIZE.y


func _refresh_beacon_list() -> void:
	for child in _beacon_list.get_children():
		child.queue_free()
	for marker in _beacon_markers.values():
		if is_instance_valid(marker):
			marker.queue_free()
	_beacon_markers.clear()

	var exclude_id := ""
	if _focused_beacon and is_instance_valid(_focused_beacon):
		exclude_id = _focused_beacon.persistent_id

	var targets: Array = FastTravelManager.get_travel_targets(exclude_id)
	if targets.is_empty():
		var empty_label := Label.new()
		empty_label.text = "No beacons placed yet. Buy a Waypoint Beacon from the General Store, place it, and interact with it to start fast-traveling."
		empty_label.modulate = Color(1, 1, 1, 0.6)
		empty_label.autowrap_mode = TextServer.AUTOWRAP_WORD
		_beacon_list.add_child(empty_label)
	else:
		for persistent_id in targets:
			_beacon_list.add_child(_build_beacon_row(persistent_id))

	# Markers exist for EVERY placed beacon (including the one excluded
	# from the travel list) so the map itself always reads correctly —
	# only the travel LIST hides "travel to where you already are".
	for persistent_id in FastTravelManager.beacons:
		var marker := ColorRect.new()
		marker.color = Color(1.0, 0.85, 0.3, 1.0)
		marker.size = Vector2(8, 8)
		marker.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_marker_layer.add_child(marker)
		_beacon_markers[persistent_id] = marker


func _build_beacon_row(persistent_id: String) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)

	# Editable in place — commits on Enter or on losing focus (clicking
	# elsewhere), rather than needing a separate "Rename" button/dialog
	# for what's a single short text field.
	var name_input := LineEdit.new()
	name_input.text = FastTravelManager.beacons[persistent_id]["name"]
	name_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var commit_rename := func():
		FastTravelManager.rename_beacon(persistent_id, name_input.text)
	name_input.text_submitted.connect(func(_text: String): commit_rename.call())
	name_input.focus_exited.connect(commit_rename)
	row.add_child(name_input)

	var travel_button := Button.new()
	travel_button.text = "Travel"
	travel_button.pressed.connect(func(): FastTravelManager.travel_to(persistent_id))
	row.add_child(travel_button)

	return row
