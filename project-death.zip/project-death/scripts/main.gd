extends Control

## QuestBuilder's root controller — redesigned around a SINGLE unified
## graph (no side panels at all): quest steps and dialogue lines are
## both real graph nodes in the same GraphEdit. Quest step ORDER is now
## defined by chaining step nodes together via connections (see
## _reconstruct_step_order(), walked fresh on every save) rather than a
## side list with reorder buttons. A dedicated port on each step node
## links it directly to a specific dialogue choice.
##
## KNOWN LIMITATION, disclosed rather than hidden: dialogue line node
## positions persist across save/reload (keyed by the line's own stable
## id). Quest step node positions do NOT yet — QuestStepData has no
## natural persistent id to key a saved position against, so step nodes
## get fresh sequential names each time a bundle is opened and re-cascade
## to default positions. Real fix is adding a persistent id field to
## QuestStepData; scoped out of this pass.

const CONFIG_PATH := "user://config.json"

var scanner := ProjectScanner.new()
var project_root: String = ""
var bundle: QuestBundle = null

var _status_label: Label
var _graph_edit: GraphEdit
var _next_step_node_index: int = 0


func _ready() -> void:
	_load_config()
	_build_ui()
	if project_root != "":
		scanner.scan(project_root)


func _build_ui() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)

	var root_vbox := VBoxContainer.new()
	root_vbox.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(root_vbox)

	root_vbox.add_child(_build_toolbar())

	var header_row := HBoxContainer.new()
	root_vbox.add_child(header_row)

	var header := Label.new()
	header.text = "Quest Graph"
	header.add_theme_font_size_override("font_size", 14)
	header.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header_row.add_child(header)

	var add_step_button := Button.new()
	add_step_button.text = "+ Add Step"
	add_step_button.pressed.connect(_on_add_step_pressed)
	header_row.add_child(add_step_button)

	var add_line_button := Button.new()
	add_line_button.text = "+ Add Line"
	add_line_button.pressed.connect(_on_add_line_pressed)
	header_row.add_child(add_line_button)

	_graph_edit = GraphEdit.new()
	_graph_edit.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_graph_edit.right_disconnects = true
	# BUGFIX: this was the actual reason a choice couldn't connect to a
	# quest step's dialogue-link port at all — Godot's own docs are
	# explicit that "type compatibility simply allows the
	# connection_request signal to be emitted" at all. Same-type ports
	# (dialogue-to-dialogue, step-to-step sequence) connect fine by
	# default since matching types are always allowed; this cross-type
	# pairing (dialogue choice output -> quest step dialogue-link input)
	# needed to be explicitly registered or the drag silently does
	# nothing, with no error anywhere.
	_graph_edit.add_valid_connection_type(DialogueLineNode.PORT_TYPE, QuestStepGraphNode.DIALOGUE_LINK_PORT_TYPE)
	_graph_edit.connection_request.connect(_on_connection_request)
	_graph_edit.disconnection_request.connect(_on_disconnection_request)
	root_vbox.add_child(_graph_edit)

	_status_label = Label.new()
	_status_label.text = "No project folder set — use Settings to point at your Project Death folder."
	_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	root_vbox.add_child(_status_label)


func _build_toolbar() -> Control:
	var bar := HBoxContainer.new()
	bar.add_theme_constant_override("separation", 8)

	var settings_button := Button.new()
	settings_button.text = "Settings (Project Folder)"
	settings_button.pressed.connect(_on_settings_pressed)
	bar.add_child(settings_button)

	var new_button := Button.new()
	new_button.text = "New Quest"
	new_button.pressed.connect(_on_new_quest_pressed)
	bar.add_child(new_button)

	var open_button := Button.new()
	open_button.text = "Open Quest"
	open_button.pressed.connect(_on_open_quest_pressed)
	bar.add_child(open_button)

	var save_button := Button.new()
	save_button.text = "Save"
	save_button.pressed.connect(_on_save_pressed)
	bar.add_child(save_button)

	var quest_settings_button := Button.new()
	quest_settings_button.text = "Quest Settings"
	quest_settings_button.tooltip_text = "Quest id/name/description, rewards, prerequisite quest, and which NPC this dialogue tree belongs to"
	quest_settings_button.pressed.connect(_on_quest_settings_pressed)
	bar.add_child(quest_settings_button)

	var validate_button := Button.new()
	validate_button.text = "Quick Validate"
	validate_button.pressed.connect(_on_validate_pressed)
	bar.add_child(validate_button)

	return bar


## The dialogue tree's npc_id had NO editable field anywhere before this
## — it silently defaulted to the quest's own id at creation and was
## never exposed. This is also the direct answer to "how does a dialogue
## node know who's talking": it doesn't, on its own — DialogueLine.
## speaker_override (if set) wins; otherwise the ACTUAL game resolves the
## speaker name from whichever placed NPC scene instance has an npc_id
## matching THIS field, reading that NPC's own display_name at runtime.
## QuestBuilder has no visibility into that placed scene at all — this
## field is the one thing that has to match it by hand.
func _on_quest_settings_pressed() -> void:
	if bundle == null:
		_status_label.text = "Open or create a quest first."
		return
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 6)

	FieldWidgets.add_text_field(content, "Quest id", bundle.quest.id, func(v): bundle.quest.id = v)
	FieldWidgets.add_text_field(content, "Display name", bundle.quest.display_name, func(v): bundle.quest.display_name = v)
	FieldWidgets.add_multiline_field(content, "Description", bundle.quest.description, func(v): bundle.quest.description = v)
	content.add_child(HSeparator.new())

	var npc_note := Label.new()
	npc_note.text = "Which NPC this dialogue tree belongs to. Must match the npc_id set on that NPC's placed scene instance in the game, or dialogue can never start — run validate_quests_and_dialogue.gd in the game project to check that NPC is actually placed somewhere."
	npc_note.autowrap_mode = TextServer.AUTOWRAP_WORD
	npc_note.modulate = Color(1, 1, 1, 0.6)
	content.add_child(npc_note)
	FieldWidgets.add_suggest_field(content, "NPC id", bundle.dialogue_tree.npc_id, func(): return scanner.npc_ids, func(v): bundle.dialogue_tree.npc_id = v)
	content.add_child(HSeparator.new())

	FieldWidgets.add_suggest_field(content, "Required quest id (prerequisite)", bundle.quest.required_quest_id, func(): return scanner.quest_ids, func(v): bundle.quest.required_quest_id = v)
	FieldWidgets.add_bool_field(content, "Auto-start (no dialogue/trigger needed)", bundle.quest.auto_start, func(v): bundle.quest.auto_start = v, "Starts itself the moment the game checks quests (new game or loading a save that predates this quest existing). For a location-triggered start instead, set starts_quest directly on a placed QuestLocationMarker in the Godot editor — that's a scene-instance field QuestBuilder doesn't touch.")
	FieldWidgets.add_skill_amount_dict_field(content, "Reward XP", bundle.quest.reward_xp, func(): return scanner.skill_ids, func(): pass)
	FieldWidgets.add_item_list_field(content, "Reward items", bundle.quest.reward_items, func(): return scanner.item_ids, func(): pass)

	FieldWidgets.show_settings_node_in_graph(_graph_edit, content, "Quest Settings")


## --- Config / project folder ---

func _load_config() -> void:
	if not FileAccess.file_exists(CONFIG_PATH):
		return
	var file := FileAccess.open(CONFIG_PATH, FileAccess.READ)
	var data: Variant = JSON.parse_string(file.get_as_text())
	file.close()
	if data is Dictionary:
		project_root = data.get("project_root", "")


func _save_config() -> void:
	var file := FileAccess.open(CONFIG_PATH, FileAccess.WRITE)
	file.store_string(JSON.stringify({"project_root": project_root}))
	file.close()


func _on_settings_pressed() -> void:
	var dialog := FileDialog.new()
	dialog.file_mode = FileDialog.FILE_MODE_OPEN_DIR
	dialog.access = FileDialog.ACCESS_FILESYSTEM
	dialog.title = "Select your Project Death game folder (the one containing project.godot)"
	dialog.size = Vector2(800, 600)
	add_child(dialog)
	dialog.dir_selected.connect(func(path: String):
		project_root = path
		_save_config()
		scanner.scan(project_root)
		_status_label.text = "Project folder set: %s — scanned %d NPCs, %d locations, %d items, %d recipes, %d quests, %d flags." % [
			project_root, scanner.npc_ids.size(), scanner.location_ids.size(), scanner.item_ids.size(),
			scanner.recipe_ids.size(), scanner.quest_ids.size(), scanner.flag_ids.size()
		]
	)
	dialog.popup_centered()


## --- New / Open / Save ---

func _on_new_quest_pressed() -> void:
	if project_root == "":
		_status_label.text = "Set your project folder first (Settings)."
		return
	var dialog := FileDialog.new()
	dialog.file_mode = FileDialog.FILE_MODE_OPEN_DIR
	dialog.access = FileDialog.ACCESS_FILESYSTEM
	dialog.title = "Pick (or create) the folder for this quest, e.g. .../Quests/Veridian Meadows/Beginner/My New Quest"
	dialog.current_dir = project_root.path_join("resources/Quests")
	dialog.size = Vector2(800, 600)
	add_child(dialog)
	dialog.dir_selected.connect(func(quest_folder: String):
		var quest_id := quest_folder.get_file().to_snake_case()
		bundle = QuestBundle.create_new(quest_folder, quest_id, quest_folder.get_file())
		_load_bundle_into_ui()
		_status_label.text = "New quest created (not yet saved to disk): %s" % quest_folder
	)
	dialog.popup_centered()


func _on_open_quest_pressed() -> void:
	if project_root == "":
		_status_label.text = "Set your project folder first (Settings)."
		return
	var dialog := FileDialog.new()
	dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
	dialog.access = FileDialog.ACCESS_FILESYSTEM
	dialog.title = "Open a quest.tres (Steps/ folder of a quest)"
	dialog.add_filter("*.tres", "Godot Resource")
	dialog.current_dir = project_root.path_join("resources/Quests")
	dialog.size = Vector2(800, 600)
	add_child(dialog)
	dialog.file_selected.connect(func(quest_tres_path: String):
		var opened := QuestBundle.open(quest_tres_path)
		if opened == null:
			_status_label.text = "Failed to open '%s' — see the Output panel for details." % quest_tres_path
			return
		bundle = opened
		_load_bundle_into_ui()
		_status_label.text = "Opened: %s" % quest_tres_path
	)
	dialog.popup_centered()


func _on_save_pressed() -> void:
	if bundle == null:
		_status_label.text = "Nothing open to save."
		return
	bundle.quest.steps = _reconstruct_step_order()
	_capture_graph_layout()
	if bundle.save():
		_status_label.text = "Saved: %s + %s (%d steps, in graph order)" % [bundle.quest_path, bundle.dialogue_path, bundle.quest.steps.size()]
	else:
		_status_label.text = "Save FAILED — see the Output panel for details."


func _capture_graph_layout() -> void:
	for child in _graph_edit.get_children():
		if child is DialogueLineNode:
			bundle.layout[child.name] = (child as GraphNode).position_offset
		elif child is QuestStepGraphNode:
			bundle.layout[child.name] = (child as GraphNode).position_offset


## Walks sequence connections (port 0 -> port 0, between two
## QuestStepGraphNodes only) starting from every step node with no
## incoming sequence connection. Multiple disconnected chains are all
## included, ordered by node name for determinism; a step somehow never
## reached (a cycle) still gets appended at the end rather than silently
## dropped.
func _reconstruct_step_order() -> Array[QuestStepData]:
	var step_nodes: Dictionary = {}  ## node name -> QuestStepGraphNode
	for child in _graph_edit.get_children():
		if child is QuestStepGraphNode:
			step_nodes[String(child.name)] = child

	var next_of: Dictionary = {}
	var has_incoming: Dictionary = {}
	for connection in _graph_edit.get_connection_list():
		var from_name: String = connection["from_node"]
		var to_name: String = connection["to_node"]
		if int(connection["from_port"]) == 0 and int(connection["to_port"]) == 0 \
		and step_nodes.has(from_name) and step_nodes.has(to_name):
			next_of[from_name] = to_name
			has_incoming[to_name] = true

	var starts: Array = []
	for node_name in step_nodes:
		if not has_incoming.has(node_name):
			starts.append(node_name)
	starts.sort_custom(_compare_step_node_names)

	var ordered: Array[QuestStepData] = []
	var visited: Dictionary = {}
	for start_name in starts:
		var current: Variant = start_name
		while current != null and not visited.has(current):
			visited[current] = true
			ordered.append((step_nodes[current] as QuestStepGraphNode).step)
			current = next_of.get(current, null)

	var remaining: Array = step_nodes.keys()
	remaining.sort_custom(_compare_step_node_names)
	for node_name in remaining:
		if not visited.has(node_name):
			ordered.append((step_nodes[node_name] as QuestStepGraphNode).step)

	return ordered


## Plain string sort on "stepnode_N" names breaks for 10+ steps
## (lexicographic sort puts "stepnode_10" before "stepnode_2") — compare
## by the actual numeric index instead, which also happens to mean
## "created first" for nodes with no other ordering signal.
func _compare_step_node_names(a: String, b: String) -> bool:
	return int(a.get_slice("_", 1)) < int(b.get_slice("_", 1))


## --- Loading a bundle into the UI ---

func _load_bundle_into_ui() -> void:
	for child in _graph_edit.get_children():
		if child is DialogueLineNode or child is QuestStepGraphNode:
			child.queue_free()  # never free anything else — see the note on this in the session this came from about GraphEdit's internal connections_layer

	if bundle == null:
		return

	var step_position := Vector2(40, 40)
	var previous_step_name := ""
	for step in bundle.quest.steps:
		var node := QuestStepGraphNode.new()
		node.name = "stepnode_%d" % _next_step_node_index
		_next_step_node_index += 1
		node.dialogue_tree = bundle.dialogue_tree
		node.setup(step, scanner)
		node.position_offset = bundle.layout.get(node.name, step_position)
		step_position += Vector2(0, 260)
		node.delete_requested.connect(_on_delete_step_requested)
		_graph_edit.add_child(node)
		if previous_step_name != "":
			_graph_edit.connect_node(previous_step_name, 0, node.name, 0)
		previous_step_name = node.name

	var line_position := Vector2(420, 40)
	for line in bundle.dialogue_tree.lines:
		var node := DialogueLineNode.new()
		node.name = "line_%s" % line.id
		node.setup(line, scanner)
		node.position_offset = bundle.layout.get(node.name, line_position)
		line_position += Vector2(340, 0)
		node.structure_changed.connect(func(l): _redraw_connections_for_line(l))
		node.delete_requested.connect(_on_delete_line_requested)
		node.id_changed.connect(_on_line_id_changed)
		node.entry_point_toggled.connect(_on_entry_point_toggled)
		node.set_entry_point_state(_is_unconditional_entry_point(line.id))
		_graph_edit.add_child(node)

	_redraw_dialogue_connections()


## Redraws DialogueLine <-> DialogueLine connections from next_line_id
## fields, for ALL lines. Does NOT touch step-sequence or dialogue-link
## connections. Only used at load time and after a line rename (both
## rare, deliberate moments where a full rebuild is safe) — everyday
## editing (adding/removing a choice) uses _redraw_connections_for_line()
## instead, which only touches the ONE line that actually changed. A
## global wipe-and-rebuild on every routine edit was exactly the kind of
## thing that could silently lose an unrelated connection if anything
## about the graph and the data were even briefly out of step — scoping
## it removes that whole risk category rather than chasing one specific
## trigger for it.
func _redraw_dialogue_connections() -> void:
	for connection in _graph_edit.get_connection_list().duplicate():
		var from_node := _graph_edit.get_node_or_null(NodePath(String(connection["from_node"])))
		var to_node := _graph_edit.get_node_or_null(NodePath(String(connection["to_node"])))
		if from_node is DialogueLineNode and to_node is DialogueLineNode:
			_graph_edit.disconnect_node(connection["from_node"], connection["from_port"], connection["to_node"], connection["to_port"])

	for line in bundle.dialogue_tree.lines:
		_connect_line_outputs(line)


## Scoped version — only touches connections FROM this one line, safe to
## call on every routine edit (adding/removing a choice) without any risk
## to any other line's connections.
func _redraw_connections_for_line(line: DialogueLine) -> void:
	var from_name := "line_%s" % line.id
	for connection in _graph_edit.get_connection_list().duplicate():
		if String(connection["from_node"]) == from_name:
			var to_node := _graph_edit.get_node_or_null(NodePath(String(connection["to_node"])))
			if to_node is DialogueLineNode:
				_graph_edit.disconnect_node(connection["from_node"], connection["from_port"], connection["to_node"], connection["to_port"])
	_connect_line_outputs(line)


func _connect_line_outputs(line: DialogueLine) -> void:
	var from_name := "line_%s" % line.id
	if line.choices.is_empty():
		_try_connect_dialogue(from_name, 0, line.next_line_id)
	else:
		for i in line.choices.size():
			_try_connect_dialogue(from_name, i, line.choices[i].next_line_id)


func _try_connect_dialogue(from_name: String, from_port: int, next_line_id: String) -> void:
	if next_line_id == "":
		return
	var to_name := "line_%s" % next_line_id
	if _graph_edit.has_node(NodePath(to_name)):
		_graph_edit.connect_node(from_name, from_port, to_name, 0)


## --- Adding nodes ---

func _on_add_line_pressed() -> void:
	if bundle == null:
		_status_label.text = "Open or create a quest first."
		return
	var new_line := DialogueLine.new()
	new_line.id = "new_line_%d" % bundle.dialogue_tree.lines.size()
	bundle.dialogue_tree.lines.append(new_line)

	var node := DialogueLineNode.new()
	node.name = "line_%s" % new_line.id
	node.setup(new_line, scanner)
	node.position_offset = _graph_edit.scroll_offset + Vector2(40, 40)
	node.structure_changed.connect(func(l): _redraw_connections_for_line(l))
	node.delete_requested.connect(_on_delete_line_requested)
	node.id_changed.connect(_on_line_id_changed)
	node.entry_point_toggled.connect(_on_entry_point_toggled)
	_graph_edit.add_child(node)


func _on_add_step_pressed() -> void:
	if bundle == null:
		_status_label.text = "Open or create a quest first."
		return
	var new_step := QuestStepData.new()
	var node := QuestStepGraphNode.new()
	node.name = "stepnode_%d" % _next_step_node_index
	_next_step_node_index += 1
	node.dialogue_tree = bundle.dialogue_tree
	node.setup(new_step, scanner)
	node.position_offset = _graph_edit.scroll_offset + Vector2(40, 40)
	node.delete_requested.connect(_on_delete_step_requested)
	_graph_edit.add_child(node)
	# Not appended to bundle.quest.steps directly — _reconstruct_step_order()
	# picks it up from the graph itself at save time. An unconnected new
	# step node still gets included (as its own single-node chain), so
	# nothing is silently lost even before you wire it into the sequence.


## --- Connection handling: three distinct meanings depending on node types ---

func _on_connection_request(from_node: StringName, from_port: int, to_node: StringName, to_port: int) -> void:
	var from_graph_node := _graph_edit.get_node_or_null(NodePath(from_node))
	var to_graph_node := _graph_edit.get_node_or_null(NodePath(to_node))
	if from_graph_node == null or to_graph_node == null:
		return

	if from_graph_node is DialogueLineNode and to_graph_node is DialogueLineNode:
		_connect_dialogue_to_dialogue(from_graph_node, from_port, to_graph_node, to_node, to_port)
	elif from_graph_node is DialogueLineNode and to_graph_node is QuestStepGraphNode and to_port == 1:
		_connect_dialogue_choice_to_step(from_graph_node, from_port, to_graph_node)
	elif from_graph_node is QuestStepGraphNode and to_graph_node is QuestStepGraphNode and from_port == 0 and to_port == 0:
		_graph_edit.connect_node(from_node, from_port, to_node, to_port)
	# any other combination (e.g. a step's sequence port to a dialogue
	# node, or the dialogue-link port used as a source) doesn't mean
	# anything, so it's silently ignored rather than half-wired.


func _connect_dialogue_to_dialogue(from_graph_node: DialogueLineNode, from_port: int, to_graph_node: DialogueLineNode, to_node: StringName, to_port: int) -> void:
	var from_line: DialogueLine = from_graph_node.line
	if from_line.choices.is_empty():
		from_line.next_line_id = to_graph_node.line.id
	else:
		var choice_index := from_port
		if choice_index < 0 or choice_index >= from_line.choices.size():
			return
		from_line.choices[choice_index].next_line_id = to_graph_node.line.id

	_graph_edit.connect_node(from_graph_node.name, from_port, to_node, to_port)
	from_graph_node.refresh_content()


func _connect_dialogue_choice_to_step(from_graph_node: DialogueLineNode, from_port: int, to_graph_node: QuestStepGraphNode) -> void:
	var from_line: DialogueLine = from_graph_node.line
	var choice_index := from_port
	if from_line.choices.is_empty() or choice_index < 0 or choice_index >= from_line.choices.size():
		return  # the auto-continue port (no real choices) doesn't carry a choice index — linking a step to it wouldn't mean anything

	# Remove any PREVIOUS dialogue-link connection into this step first —
	# the port only makes sense pointing at one choice at a time.
	for connection in _graph_edit.get_connection_list().duplicate():
		if String(connection["to_node"]) == to_graph_node.name and int(connection["to_port"]) == 1:
			_graph_edit.disconnect_node(connection["from_node"], connection["from_port"], connection["to_node"], connection["to_port"])

	to_graph_node.step.step_type = QuestStepData.StepType.DIALOGUE_CHOICE
	to_graph_node.step.target_id = bundle.dialogue_tree.npc_id
	to_graph_node.step.dialogue_line_id = from_line.id
	to_graph_node.step.choice_index = choice_index
	to_graph_node.refresh_after_dialogue_link()

	# If this step is the FIRST in its sequence chain (nothing precedes
	# it) and the choice being linked doesn't already start some quest,
	# auto-wire this choice to start THIS quest. Without this, a step can
	# be perfectly configured to watch a choice and still never fire,
	# because nothing ever actually calls QuestManager.start_quest() —
	# exactly the bug this was built to catch after seeing it happen.
	var choice: DialogueChoiceData = from_line.choices[choice_index]
	if choice.starts_quest == "" and not _step_has_incoming_sequence(to_graph_node.name):
		choice.starts_quest = bundle.quest.id
		_status_label.text = "Linked — also set this choice's 'Starts quest' to '%s' since it's the first step (edit in the choice's settings if that's not what you wanted)." % bundle.quest.id

	_graph_edit.connect_node(from_graph_node.name, from_port, to_graph_node.name, 1)


func _step_has_incoming_sequence(step_node_name: String) -> bool:
	for connection in _graph_edit.get_connection_list():
		if String(connection["to_node"]) == step_node_name and int(connection["to_port"]) == 0:
			return true
	return false


func _on_disconnection_request(from_node: StringName, from_port: int, to_node: StringName, to_port: int) -> void:
	var from_graph_node := _graph_edit.get_node_or_null(NodePath(from_node))
	var to_graph_node := _graph_edit.get_node_or_null(NodePath(to_node))

	if from_graph_node is DialogueLineNode and to_graph_node is DialogueLineNode:
		var from_line: DialogueLine = from_graph_node.line
		if from_line.choices.is_empty():
			from_line.next_line_id = ""
		else:
			var choice_index := from_port
			if choice_index >= 0 and choice_index < from_line.choices.size():
				from_line.choices[choice_index].next_line_id = ""
		from_graph_node.refresh_content()
	elif to_graph_node is QuestStepGraphNode and to_port == 1:
		to_graph_node.step.dialogue_line_id = ""
		to_graph_node.step.choice_index = 0
		to_graph_node.refresh_after_dialogue_link()

	_graph_edit.disconnect_node(from_node, from_port, to_node, to_port)


## --- Line id renaming ---
## THE actual fix behind several reported symptoms at once: a line's id
## is referenced by STRING from three other places (other lines'
## next_line_id/choices' next_line_id, quest steps' dialogue_line_id, and
## entry_points' start_line_id) — renaming a line used to update only the
## line's own id field, silently orphaning every one of those references
## and leaving the GraphNode's own .name (what connections are actually
## wired to) stale forever. This is what "the connection uses the
## default name, not its correct name" was.

func _on_line_id_changed(node: DialogueLineNode, old_id: String, new_id: String) -> void:
	if old_id == new_id or bundle == null:
		return

	var old_name := "line_%s" % old_id
	var new_name := "line_%s" % new_id
	if new_name != old_name and _graph_edit.has_node(NodePath(new_name)):
		_status_label.text = "Can't rename to '%s' — another line already uses that id. Reverting." % new_id
		node.line.id = old_id
		node._update_title()
		return

	# Fix up every OTHER place that referenced the old id by string.
	for line in bundle.dialogue_tree.lines:
		if line == node.line:
			continue
		if line.next_line_id == old_id:
			line.next_line_id = new_id
		for choice in line.choices:
			if choice.next_line_id == old_id:
				choice.next_line_id = new_id
	for child in _graph_edit.get_children():
		if child is QuestStepGraphNode and (child as QuestStepGraphNode).step.dialogue_line_id == old_id:
			(child as QuestStepGraphNode).step.dialogue_line_id = new_id
	for entry in bundle.dialogue_tree.entry_points:
		if entry.get("start_line_id", "") == old_id:
			entry["start_line_id"] = new_id

	# Migrate the saved layout position and rename the actual GraphNode
	# (what connections are wired to internally) to match.
	if bundle.layout.has(old_name):
		bundle.layout[new_name] = bundle.layout[old_name]
		bundle.layout.erase(old_name)
	node.name = new_name

	# A rename is rare/deliberate, unlike adding a choice — safe to do a
	# full rebuild here rather than the scoped per-line version.
	_redraw_dialogue_connections()
	for child in _graph_edit.get_children():
		if child is QuestStepGraphNode:
			(child as QuestStepGraphNode).refresh_after_dialogue_link()
	_status_label.text = "Renamed '%s' to '%s' — fixed up every reference to the old id." % [old_id, new_id]


## --- Entry points ---
## DialogueTreeData.entry_points had NO editable UI anywhere — this is
## why entry points had to be hand-edited directly in the .tres file. The
## ★ toggle on each line covers the common case (one unconditional entry
## point). Multiple flag-gated entry points on the same NPC still need
## direct .tres editing for now — a real, disclosed scope limit, not
## silently dropped.

func _is_unconditional_entry_point(line_id: String) -> bool:
	for entry in bundle.dialogue_tree.entry_points:
		if entry.get("start_line_id", "") == line_id and entry.get("required_flag", "") == "" and entry.get("required_flag_absent", "") == "":
			return true
	return false


func _on_entry_point_toggled(node: DialogueLineNode, is_entry: bool) -> void:
	var entries: Array = bundle.dialogue_tree.entry_points
	if is_entry:
		if not _is_unconditional_entry_point(node.line.id):
			entries.append({"start_line_id": node.line.id})
	else:
		for i in range(entries.size() - 1, -1, -1):
			var entry: Dictionary = entries[i]
			if entry.get("start_line_id", "") == node.line.id and entry.get("required_flag", "") == "" and entry.get("required_flag_absent", "") == "":
				entries.remove_at(i)
	node.set_entry_point_state(is_entry)


## --- Deleting nodes ---

## Removing a step node needs no separate data cleanup — steps are
## entirely graph-derived (_reconstruct_step_order() rebuilds
## bundle.quest.steps from whatever step nodes exist at save time), so
## freeing the node is the whole operation.
func _on_delete_step_requested(step: QuestStepData) -> void:
	for child in _graph_edit.get_children():
		if child is QuestStepGraphNode and (child as QuestStepGraphNode).step == step:
			child.queue_free()
			return


## Removing a line DOES need explicit data cleanup, unlike a step — lines
## live in bundle.dialogue_tree.lines directly. Doesn't hunt down and
## clear other lines' next_line_id/dialogue_line_id references TO this
## one — Quick Validate already catches a dangling reference left behind
## by this, which felt like better UX than silently rewriting choices on
## OTHER nodes the user didn't touch.
func _on_delete_line_requested(line: DialogueLine) -> void:
	bundle.dialogue_tree.lines.erase(line)
	for child in _graph_edit.get_children():
		if child is DialogueLineNode and (child as DialogueLineNode).line == line:
			child.queue_free()
			break
	_redraw_dialogue_connections()


## --- Quick validate ---

## Targeted scan for exactly one thing: does any OTHER dialogue tree in
## the project already claim this npc_id? Text-based (not ResourceLoader)
## for the same reason project_scanner.gd is — reliable regardless of
## how this app is run.
func _find_other_dialogue_tree_with_npc_id(npc_id: String, exclude_path: String) -> String:
	return _scan_dir_for_npc_id(project_root.path_join("resources/Quests"), npc_id, exclude_path)


func _scan_dir_for_npc_id(path: String, npc_id: String, exclude_path: String) -> String:
	var dir := DirAccess.open(path)
	if dir == null:
		return ""
	for sub_dir in dir.get_directories():
		var found := _scan_dir_for_npc_id(path.path_join(sub_dir), npc_id, exclude_path)
		if found != "":
			return found
	for file_name in dir.get_files():
		if not file_name.ends_with(".tres"):
			continue
		var full_path := path.path_join(file_name)
		if full_path == exclude_path:
			continue
		var text := FileAccess.get_file_as_string(full_path)
		if text.find("script_class=\"DialogueTreeData\"") != -1 and text.find("npc_id = \"%s\"" % npc_id) != -1:
			return full_path
	return ""


func _on_validate_pressed() -> void:
	if bundle == null:
		_status_label.text = "Nothing open to validate."
		return
	var problems: Array[String] = []

	for line in bundle.dialogue_tree.lines:
		if line.id == "":
			problems.append("A dialogue line has no id.")
		var targets: Array[String] = []
		if line.choices.is_empty():
			targets.append(line.next_line_id)
		else:
			for choice in line.choices:
				targets.append(choice.next_line_id)
		for target_id in targets:
			if target_id != "" and bundle.dialogue_tree.get_line(target_id) == null:
				problems.append("Line '%s' points at a line id '%s' that doesn't exist in this tree." % [line.id, target_id])

	var steps := _reconstruct_step_order()
	for i in steps.size():
		var step: QuestStepData = steps[i]
		if step.target_id == "" and step.step_type != QuestStepData.StepType.CUSTOM_ACTION:
			problems.append("Step %d has no target id set." % (i + 1))

	if not bundle.dialogue_tree.lines.is_empty() and bundle.dialogue_tree.entry_points.is_empty():
		problems.append("No entry points set — this NPC can never start a conversation. Toggle the ★ on whichever line should be the default greeting.")

	if bundle.dialogue_tree.npc_id != "" and project_root != "":
		var other_path := _find_other_dialogue_tree_with_npc_id(bundle.dialogue_tree.npc_id, bundle.dialogue_path)
		if other_path != "":
			problems.append("npc_id '%s' is also used by another dialogue tree: %s — only one tree per NPC can actually load; the game keeps whichever it scans first and errors on the rest." % [bundle.dialogue_tree.npc_id, other_path])

	if problems.is_empty():
		_status_label.text = "Quick validate: no problems found (%d steps in graph order). This is a lighter check than validate_quests_and_dialogue.gd in the game project — run that too before considering a quest done." % steps.size()
	else:
		_status_label.text = "Quick validate found %d problem(s) — see Output panel." % problems.size()
		for p in problems:
			push_warning("[QuestBuilder Validate] " + p)
