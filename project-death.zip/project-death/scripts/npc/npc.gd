extends Node3D
class_name NPC

## A dialogue-capable NPC. Interact (E) opens a conversation via
## DialogueManager, using whichever DialogueTreeData has a matching
## npc_id.
##
## DELIBERATELY STATIONARY in this pass — no movement, no schedules, no
## pathing. Same "ship a real hook, not a fake system" pattern as
## everything else in this project: NPCManager/scheduling is a real,
## separate system that doesn't exist yet (needs Day/Night integration,
## a pathing solution, etc.), and faking idle wandering here would just
## be something to rip out and redo later. This NPC stands exactly where
## it's placed and talks — that's a complete, honest v1.
##
## Not a Placeable — like QuestLocationMarker, this is a level-design
## actor the developer hand-places in a world/cell scene, not something
## the player buys or carries.

@export var npc_id: String = ""
@export var display_name: String = ""  ## shown as the speaker name unless a DialogueLine overrides it


func _ready() -> void:
	add_to_group("interactables")
	add_to_group("npcs")
	if npc_id == "":
		push_warning("NPC '%s': npc_id is blank — dialogue won't be findable." % name)


## Called by Player's ambient interaction (same path as every other
## interactable in this project).
func interact(_player: Node) -> void:
	if npc_id == "":
		return
	if not DialogueManager.has_tree(npc_id):
		NotificationManager.notify("%s has nothing to say right now." % (display_name if display_name != "" else npc_id), "info")
		return
	if not DialogueManager.start_dialogue(npc_id):
		NotificationManager.notify("%s has nothing to say right now." % (display_name if display_name != "" else npc_id), "info")


## Called by DialoguePanel when a DialogueLine with a non-empty
## animation_id is shown. Documented hook — see DialogueLine.animation_id's
## own comment for why this is a real no-op rather than a fake
## implementation. Once NPCs have actual AnimationPlayers/animation sets,
## this is the one place that needs to change.
func play_animation(animation_id: String) -> void:
	print("NPC '%s': would play animation '%s' — no NPC animation system exists yet." % [npc_id, animation_id])
