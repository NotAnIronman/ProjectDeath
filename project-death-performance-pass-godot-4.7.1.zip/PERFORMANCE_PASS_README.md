# Project Death performance pass

This package is an overlay for the full Project Death Godot project. It
contains only changed or new project files; it does not contain or remove
`assets/`, `addons/`, or `.godot/`.

## Installation

1. Close Godot and make a backup of the full project.
2. Extract the ZIP into the directory that contains `project.godot`.
3. Allow matching files to be replaced.
4. Open the project with Godot 4.7.1 and let its normal filesystem scan
   finish before running the game.

The overlay is intended to be extracted directly over the original project.
It has no source-file deletions. If Godot reports stale UID/cache errors after
the overlay, close Godot, remove the local `.godot/` cache, and reopen the
project. That cache rebuild is normally unnecessary.

## Main performance changes

### World streaming

- Cell resources load asynchronously with two bounded worker requests.
- Movement direction and velocity warm likely cells 1.75 seconds ahead.
- Fast travel explicitly warms the destination neighborhood before moving the
  player, with a bounded fail-open timeout.
- A 16-scene LRU cache retains useful `PackedScene` resources without allowing
  memory use to grow with exploration.
- At most one authored cell is instantiated per frame.
- At most one retired cell is captured/freed per frame, and retirement never
  shares a frame with authored-cell activation.
- Persistent state is applied and captured only when cell content is actually
  ready, preventing an in-flight unload from replacing valid state with an
  empty snapshot.
- Autosave waits for a stable streaming interval.

Default tuning is in `autoloads/world_manager.gd`:

- cell size: 100 metres
- active radius: 1 cell
- unload radius: 2 cells
- concurrent loads: 2
- predicted look-ahead: 1.75 seconds
- prefetch/cache cap: 16 cells

### Grass streaming

The 34 supplied grass cells contain 43,065 instances. Their old text-resource
path required transform parsing, cluster construction, hash-table creation,
and `MultiMesh` population during play. The new binary resources contain:

- a directly assignable `MultiMesh` float buffer;
- baked cell bounds;
- baked cluster membership;
- a packed constant-time cluster lookup grid.

Runtime grass now uses one `MultiMeshInstance3D` per loaded grass cell. Intact
grass has no per-cluster processing. Only cut clusters are tracked, and regrow
checks run at 4 Hz. Grass IO uses the same bounded, destination-aware prefetch
model as authored cells, with a 16-cell LRU.

Measured in an isolated Godot 4.7.1 headless benchmark over all 34 cells:

| Path | Resource load | Main-thread prepare/activate | Worst cell |
| --- | ---: | ---: | ---: |
| Original text data | 1174.613 ms | 102.319 ms | 6.461 ms |
| Optimized binary, cold | 271.182 ms | 1.936 ms | 0.220 ms |
| Optimized binary, warm | 119.195 ms | 1.238 ms | 0.086 ms |

The cold binary pass reduced measured resource-load time by about 77% and
main-thread preparation by about 98%. Predictive loading is intended to move
the remaining IO away from the boundary-crossing frame.

After editing the source grass placement, run
`scripts/editor_tools/bake_grass.gd`. It writes current binary runtime data and
removes stale generated grass resources only after every new write succeeds.
`scripts/editor_tools/upgrade_grass_runtime_data.gd` upgrades legacy baked
data without changing placement.

### Cell authoring and static batching

`scripts/editor_tools/split_world_into_cells.gd` now:

- preserves flattened-folder global transforms;
- includes directly-authored spatial leaves;
- preserves local additions and inherited overrides on instanced scenes;
- keeps untouched inherited descendants atomic;
- aborts safely if duplication loses authored nodes;
- supports opt-in static mesh batching with
  `streaming_batch_static = true`;
- serializes complete `MultiMesh` buffers and bounds.

The 16 compatible fence meshes in `World.tscn` are supplied as one generated
batch in `cell_-1_0.tscn`. Interactive, scripted, animated, skeletal, audio,
special-visibility, and otherwise incompatible content is not flattened or
batched.

### Runtime CPU, physics, and UI

- Player interaction target selection is event-dirtied and capped at 15 Hz.
- Camera collision, building, and pickup systems reuse physics query objects.
- Building and pickup processing is disabled while their modes are inactive.
- Resource respawn and crop growth use timers plus authoritative world elapsed
  time rather than per-frame polling.
- Sleep, debug day skips, and save loads immediately resynchronize those
  timers.
- Day/night simulation remains continuous while lighting/shadow writes are
  limited to 10 Hz.
- Mesh-bound traversal is iterative and shared; temporary resource visuals no
  longer enter the live tree merely to calculate collision bounds.
- Placed objects use a dedicated static collision layer, and interaction Areas
  use a dedicated interaction layer, reducing unrelated broadphase pairs.
- Hidden world reference content is pruned in `_enter_tree()` before child
  scripts, rendering, and physics can initialize.
- Inventory rebuilds use one bulk signal; recipe/UI refreshes are coalesced.
- Book pages and debug tabs are created lazily.
- The collection log and item debug browser use pagination instead of creating
  controls for all 1,467 items at once.
- An explicit item catalog replaces repeated recursive directory discovery.
- Held placeable previews use lightweight static visuals when safe and retain
  the authored hierarchy for unsupported content.

## Correctness hardening included in the pass

- Save writes are validated and replaced through a temporary file while a
  valid backup is preserved.
- Invalid primary saves fall back to the backup.
- Fast-travel requests are cancelled correctly when another save is loaded.
- Cell and grass state cannot be erased by unloads that race pending IO.
- Terrain restore replay is silent/batched during load.
- Achievement boundary tracking follows the actual player cell.
- Inventory load/sort and storage changes avoid notification storms without
  losing final refreshes.
- Generated collision dimensions have a nonzero minimum.
- Stable autoload paths replace two fragile UID-only entries.

## Validation and remaining measurement boundary

The production scripts were checked with Godot 4.7.1 and warnings treated as
errors using isolated harnesses where the trimmed project could not resolve
omitted dependencies. Streaming tests covered initial readiness, real boundary
transitions, predictive and explicit destination prefetch, cache handoff,
retirement, stable state, and shutdown. Generator tests covered transforms,
ownership, local additions, overrides, static batching, and on-disk buffer
round-trips. All 34 binary grass resources loaded and retained all 43,065
instances. The 1,467-entry item catalog resolves every resource path present
in the supplied project.

The submitted archive intentionally omitted the real assets, `.godot` import
data, and Terrain3D addon. Consequently, an integrated GPU, shader, Terrain3D,
navigation, and asset-import profile cannot be measured from this copy.
`PackedScene.instantiate()` is also an indivisible Godot main-thread call; the
pass limits it to one authored cell per frame and keeps the supplied authored
cells small, but a future very large cell could still exceed a frame budget.
Profile the full build after installation and split unusually large authored
cells if the performance watchdog identifies one.

The SHA-256 manifest packaged beside this file can be used to verify every
overlay file after transfer.
