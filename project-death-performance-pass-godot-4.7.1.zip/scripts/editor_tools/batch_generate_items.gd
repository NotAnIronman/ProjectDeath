@tool
extends EditorScript

## ONE-OFF EDITOR TOOL — bulk-generates ItemData resources + wrapper
## scenes directly from a folder of source meshes (.obj etc), so you don't
## have to manually build each one by hand.
##
## For every mesh file found in a configured source folder, this creates:
##   1. (if placeable) A wrapper scene with Placeable.gd attached, box
##      collision added, used as the item's Placed Scene. held_model is
##      left unset — Player automatically falls back to showing placed_scene
##      itself, scaled by held_scale, so there's no separate held-only
##      scene to generate or maintain for placeable items anymore.
##   2. (if NOT placeable) A plain wrapper scene (Node3D + MeshInstance3D),
##      used as the item's Held Model directly — still needed here, since
##      a non-placeable item has no placed_scene for the fallback to use.
##   3. An ItemData .tres tying it together, with id/display_name derived
##      from the filename.
##
## Output respects YOUR folder organization — configure per source folder
## below (output_root, category, placeable, held_scale) to match structure
## like:
##   res://resources/Furniture/tres/
##   res://resources/Furniture/tscn/
##
## HOW TO USE:
##   1. Edit the JOBS array below to point at your actual source folders.
##   2. Open this script, File > Run (Ctrl+Shift+X).
##   3. Check Output for a summary. Generated files appear in FileSystem —
##      you may need to right-click > Reimport if they don't show up
##      immediately.
##   4. Review the generated ItemData resources — id/display_name are
##      auto-derived and icon is left blank; adjust anything that needs
##      manual attention (icons especially, since we can't auto-generate
##      those from a 3D mesh).
##
## Safe to re-run on the same source folder — skips files that already
## have a generated .tres with a matching id, so it won't duplicate work
## or overwrite your manual adjustments.
##
## ALREADY HAVE OLDER TWO-SCENE ITEMS FROM BEFORE? This script only
## affects NEWLY generated items (the "skip if .tres already exists" rule
## means it won't touch what you've already got). See
## scripts/editor_tools/migrate_to_held_scale.gd for a separate, dry-run-first
## tool that cleans up existing items to match this new one-scene approach.

## --- CONFIGURE THIS ---
## Each entry: which folder to scan, where output goes, what category/
## placeable flag to assign, and (optional) a held_scale override for this
## job's items specifically — omit to use ItemData's own default (0.15).
const JOBS: Array[Dictionary] = [
	{
		"source_dir": "res://assets/kenney_tower-defense-kit/Models/",
		"output_root": "res://resources/tower defense/",
		"category": 4,  # ItemData.ItemCategory.TOOL — change per job as needed; MISC=5
		"placeable": true,
	},
	# Add more jobs here, e.g.:
	# {
	# 	"source_dir": "res://assets/models/Models/OBJ format/Food",
	# 	"output_root": "res://resources/Food",
	# 	"category": 0,  # CROP_YIELD
	# 	"placeable": false,
	# },
]
## Flat source meshes otherwise produce near-zero broadphase shapes. A small
## deliberate thickness is still visually faithful while remaining robust.
const MIN_COLLISION_AXIS_SIZE: float = 0.05


func _run() -> void:
	var total_created := 0
	var total_skipped := 0

	for job in JOBS:
		var result := _process_job(job)
		total_created += result.created
		total_skipped += result.skipped

	print("BatchGenerateItems: done. Created %d, skipped %d (already existed)." % [total_created, total_skipped])
	print("You may need to right-click the FileSystem panel > Reimport if new files don't show up yet.")


func _process_job(job: Dictionary) -> Dictionary:
	var source_dir: String = job["source_dir"]
	var output_root: String = job["output_root"]
	var category: int = job["category"]
	var placeable: bool = job["placeable"]
	var held_scale: Variant = job.get("held_scale", null)  # null = use ItemData's own default

	var tres_dir := output_root.path_join("tres")
	var tscn_dir := output_root.path_join("tscn")
	_ensure_dir(tres_dir)
	_ensure_dir(tscn_dir)

	var dir := DirAccess.open(source_dir)
	if dir == null:
		push_error("BatchGenerateItems: source folder not found: %s" % source_dir)
		return {"created": 0, "skipped": 0}

	var created := 0
	var skipped := 0

	dir.list_dir_begin()
	var file_name := dir.get_next()
	while file_name != "":
		if file_name.ends_with(".obj"):
			var mesh_path := source_dir.path_join(file_name)
			var base_name := file_name.get_basename()
			var item_id := _to_snake_case(base_name)
			var tres_path := tres_dir.path_join(item_id + ".tres")

			if FileAccess.file_exists(tres_path):
				skipped += 1
			else:
				_generate_item(mesh_path, item_id, base_name, tres_dir, tscn_dir, category, placeable, held_scale)
				created += 1

		file_name = dir.get_next()
	dir.list_dir_end()

	return {"created": created, "skipped": skipped}


func _generate_item(mesh_path: String, item_id: String, base_name: String, tres_dir: String, tscn_dir: String, category: int, placeable: bool, held_scale: Variant) -> void:
	var mesh: Mesh = load(mesh_path)
	if mesh == null:
		push_warning("BatchGenerateItems: couldn't load mesh at %s" % mesh_path)
		return

	var item_data := ItemData.new()
	item_data.id = item_id
	item_data.display_name = _to_title_case(base_name)
	item_data.category = category
	item_data.is_placeable = placeable
	if held_scale != null:
		item_data.held_scale = held_scale

	if placeable:
		# Only scene generated for placeable items now — held_model stays
		# unset, Player falls back to this same scene at held_scale.
		var placed_scene_path := tscn_dir.path_join(item_id + "_placeable.tscn")
		var placeable_root := Node3D.new()
		placeable_root.name = _to_pascal_case(base_name) + "Placeable"
		placeable_root.set_script(load("res://scripts/building/placeable.gd"))

		var p_mesh_instance := MeshInstance3D.new()
		p_mesh_instance.name = "MeshInstance3D"
		p_mesh_instance.mesh = mesh
		placeable_root.add_child(p_mesh_instance)
		p_mesh_instance.owner = placeable_root

		# Box collision fit to the mesh's actual bounding box, same
		# approach as batch_add_box_collision.gd.
		var aabb: AABB = mesh.get_aabb()
		placeable_root.set("footprint_size", Vector2i(
			maxi(1, ceili(aabb.size.x / BuildGrid.DECOR_CELL_SIZE)),
			maxi(1, ceili(aabb.size.z / BuildGrid.DECOR_CELL_SIZE))
		))
		var static_body := StaticBody3D.new()
		static_body.name = "StaticBody3D"
		# Dedicated layer for placed decor/furniture (layer 3, bit value 4).
		# Kept separate from terrain (layer 1) so Player's pickup raycast
		# can target placed objects specifically without also hitting the
		# ground, and vice versa for the placement raycast.
		static_body.collision_layer = 4
		static_body.collision_mask = 0
		var collision_shape := CollisionShape3D.new()
		collision_shape.name = "CollisionShape3D"
		var box_shape := BoxShape3D.new()
		box_shape.size = Vector3(
			maxf(aabb.size.x, MIN_COLLISION_AXIS_SIZE),
			maxf(aabb.size.y, MIN_COLLISION_AXIS_SIZE),
			maxf(aabb.size.z, MIN_COLLISION_AXIS_SIZE)
		)
		collision_shape.shape = box_shape
		collision_shape.position = aabb.get_center()
		p_mesh_instance.add_child(static_body)
		static_body.owner = placeable_root
		static_body.add_child(collision_shape)
		collision_shape.owner = placeable_root

		var placeable_packed := PackedScene.new()
		placeable_packed.pack(placeable_root)
		ResourceSaver.save(placeable_packed, placed_scene_path)
		placeable_root.free()

		item_data.placed_scene = load(placed_scene_path)
	else:
		# Not placeable — no placed_scene for the held-model fallback to
		# use, so this item still needs its own dedicated held scene if
		# you want it to show anything in-hand at all.
		var model_scene_path := tscn_dir.path_join(item_id + "_model.tscn")
		var model_root := Node3D.new()
		model_root.name = _to_pascal_case(base_name)
		var mesh_instance := MeshInstance3D.new()
		mesh_instance.name = "MeshInstance3D"
		mesh_instance.mesh = mesh
		model_root.add_child(mesh_instance)
		mesh_instance.owner = model_root

		var model_packed := PackedScene.new()
		model_packed.pack(model_root)
		ResourceSaver.save(model_packed, model_scene_path)
		model_root.free()

		item_data.held_model = load(model_scene_path)

	var tres_path := tres_dir.path_join(item_id + ".tres")
	ResourceSaver.save(item_data, tres_path)


func _ensure_dir(path: String) -> void:
	if not DirAccess.dir_exists_absolute(path):
		DirAccess.make_dir_recursive_absolute(path)


func _to_snake_case(s: String) -> String:
	var result := ""
	for i in s.length():
		var c := s[i]
		if c == c.to_upper() and c != c.to_lower() and i > 0:
			result += "_"
		result += c.to_lower()
	return result.replace("-", "_").replace(" ", "_")


func _to_title_case(s: String) -> String:
	var words: PackedStringArray = s.replace("-", " ").replace("_", " ").split(" ")
	var result: PackedStringArray = []
	for w in words:
		if w.length() > 0:
			result.append(w[0].to_upper() + w.substr(1).to_lower())
	return " ".join(result)


func _to_pascal_case(s: String) -> String:
	return _to_title_case(s).replace(" ", "")
