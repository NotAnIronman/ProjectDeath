@tool
extends EditorScript

## One-time migration for legacy grass resources. It derives the bulk
## MultiMesh buffer and constant-time cluster lookup directly from the
## existing transforms, so Terrain3D does not need to be open or rebaked.

const GRASS_DATA_PATH := "res://data/grass/"
const CLUSTER_RADIUS := 2.0
const GRASS_RUNTIME_BUILDER := preload("res://scripts/systems/grass_runtime_builder.gd")


func _run() -> void:
	var directory := DirAccess.open(GRASS_DATA_PATH)
	if directory == null:
		push_error("upgrade_grass_runtime_data: grass data directory not found.")
		return

	var upgraded := 0
	var skipped := 0
	for file_name in directory.get_files():
		if not file_name.ends_with(".tres"):
			continue
		var source_path := GRASS_DATA_PATH.path_join(file_name)
		var output_path := source_path.get_basename() + ".res"
		var existing: GrassCellData = null
		if ResourceLoader.exists(output_path):
			existing = load(output_path) as GrassCellData
		if (
			existing != null
			and GRASS_RUNTIME_BUILDER.is_runtime_data_valid(
				existing,
				CLUSTER_RADIUS
			)
		):
			skipped += 1
			continue
		var data := load(source_path) as GrassCellData
		if data == null:
			push_error(
				"upgrade_grass_runtime_data: failed to load %s." % source_path
			)
			continue
		if GRASS_RUNTIME_BUILDER.is_runtime_data_valid(data, CLUSTER_RADIUS):
			skipped += 1
			continue
		if not GRASS_RUNTIME_BUILDER.populate_runtime_data(
			data,
			CLUSTER_RADIUS,
			true
		):
			push_error(
				"upgrade_grass_runtime_data: %s has no source transforms."
				% source_path
			)
			continue
		var error := ResourceSaver.save(data, output_path)
		if error != OK:
			push_error(
				"upgrade_grass_runtime_data: failed to save %s (error %d)."
				% [output_path, error]
			)
			continue
		upgraded += 1

	print(
		"upgrade_grass_runtime_data: upgraded %d file(s), skipped %d current file(s)."
		% [upgraded, skipped]
	)
