@tool
extends EditorScript

## Recursively splits everything under the "WorldContent" node (see
## scripts/systems/world_content_staging.gd) into per-cell scene files
## under scenes/world/cells/, bucketed by each object's global position
## using the SAME cell math as WorldManager (autoloads/world_manager.gd) —
## if you change CELL_SIZE in one, change it in the other.
##
## Safe to re-run anytime. Fully regenerates every affected cell file from
## WorldContent's current children each time — never hand-edit a
## scenes/world/cells/*.tscn file directly, always edit WorldContent and
## re-run this instead.

## FOLDERS FOR ORGANIZATION: fully supported. Nest content under as many
## plain folder nodes as you want, as deep as you want, purely for your own
## Scene-tree tidiness. Instanced scenes are atomic objects. Plain spatial
## leaves are also objects, so directly-authored MeshInstance3D decor is
## never silently discarded. A plain node with children remains a folder
## by default; set metadata `streaming_folder = false` when a directly
## authored subtree must stay atomic, or `streaming_folder = true` to
## explicitly flatten it.
##
## STATIC VISUAL BATCHING: set `streaming_batch_static = true` metadata on
## an organizational folder to combine compatible direct MeshInstance3D
## children into MultiMeshes. This is opt-in so interactive/scripted meshes
## never change semantics accidentally. The generated runtime cells remain
## optimized every time this tool is rerun.
##
## NOTE ON OBJECTS NEAR A CELL BOUNDARY: a node is assigned ENTIRELY to
## whichever cell its own position falls in — there's no partial-splitting
## of a single object across two cells. A large object straddling a
## boundary will pop in/out as one whole piece at that cell's load/unload
## distance, same as everything else in it. For anything large enough that
## this would be noticeable (a big building), either make sure its
## position isn't right on a boundary, or keep CELL_SIZE comfortably
## larger than your biggest single structure.

const WORLD_MANAGER_SCRIPT := preload("res://autoloads/world_manager.gd")
const CELL_SIZE: float = WORLD_MANAGER_SCRIPT.CELL_SIZE
const OUTPUT_PATH := "res://scenes/world/cells/"
const CONTENT_CONTAINER_NAME := "WorldContent"
const MIN_STATIC_BATCH_SIZE := 4


func _run() -> void:
	var scene_root: Node = get_scene()
	if scene_root == null:
		push_error("split_world_into_cells: no scene open. Open World.tscn first.")
		return

	var content: Node = scene_root.get_node_or_null(CONTENT_CONTAINER_NAME)
	if content == null:
		push_error("split_world_into_cells: no '%s' node found under the open scene. Create a Node3D named '%s', attach world_content_staging.gd to it, and put your cell-able content underneath." % [CONTENT_CONTAINER_NAME, CONTENT_CONTAINER_NAME])
		return
	if content.get_script() == null or content.get_script().resource_path != "res://scripts/systems/world_content_staging.gd":
		push_error("split_world_into_cells: WorldContent must use world_content_staging.gd or source content will also run in-game.")
		return

	if content.get_child_count() == 0:
		print("split_world_into_cells: '%s' has no children — nothing to split." % CONTENT_CONTAINER_NAME)
		return

	# Vector2i -> Array[{node: Node3D, batch_static: bool}]
	var buckets: Dictionary = {}
	var object_count: int = _gather_recursive(content, buckets)

	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(OUTPUT_PATH))

	var all_writes_succeeded := true
	for cell_coord in buckets:
		all_writes_succeeded = _write_cell_scene(cell_coord, buckets[cell_coord]) and all_writes_succeeded
	if not all_writes_succeeded:
		push_error("split_world_into_cells: generation failed; old cells were preserved for safety.")
		return
	_remove_stale_cells(buckets)

	print("split_world_into_cells: done — wrote %d cell scene(s) covering %d object(s)." % [buckets.size(), object_count])


## Walks `node`'s children, buckets placed spatial objects by their global
## position, and recurses only through organizational folders.
func _gather_recursive(
	node: Node,
	buckets: Dictionary,
	inherited_static_batch: bool = false
) -> int:
	var count: int = 0
	var static_batch: bool = (
		inherited_static_batch
		or bool(node.get_meta("streaming_batch_static", false))
	)
	for child: Node in node.get_children():
		if not _is_streaming_folder(child):
			if not (child is Node3D):
				push_warning("split_world_into_cells: skipping '%s' — not a Node3D, can't determine its world position." % child.name)
				continue
			var cell_coord: Vector2i = _world_to_cell(child.global_position)
			if not buckets.has(cell_coord):
				buckets[cell_coord] = []
			var bucket: Array = buckets[cell_coord]
			bucket.append({
				"node": child,
				"batch_static": (
					static_batch
					or bool(child.get_meta("streaming_batch_static", false))
				),
			})
			count += 1
		else:
			count += _gather_recursive(child, buckets, static_batch)
	return count


func _is_streaming_folder(node: Node) -> bool:
	if node.has_meta("streaming_folder"):
		return bool(node.get_meta("streaming_folder"))
	if node.scene_file_path != "":
		return false
	if not (node is Node3D):
		return true
	# Backward-compatible default for existing authoring hierarchies:
	# directly-authored containers are flattened, but spatial leaves are
	# real content and must be emitted.
	return node.get_child_count() > 0


func _world_to_cell(position: Vector3) -> Vector2i:
	return Vector2i(floori(position.x / CELL_SIZE), floori(position.z / CELL_SIZE))


func _write_cell_scene(cell_coord: Vector2i, records: Array) -> bool:
	var cell_root := Node3D.new()
	cell_root.name = "Cell_%d_%d" % [cell_coord.x, cell_coord.y]

	var batched_source_ids: Dictionary = {}
	var static_groups: Dictionary = {}
	for record_variant: Variant in records:
		var record: Dictionary = record_variant
		var original: Node3D = record["node"]
		if (
			not bool(record.get("batch_static", false))
			or not _is_batchable_static_mesh(original)
		):
			continue
		var mesh_instance: MeshInstance3D = original as MeshInstance3D
		var signature: String = _static_batch_signature(mesh_instance)
		if not static_groups.has(signature):
			static_groups[signature] = []
		var group: Array = static_groups[signature]
		group.append(mesh_instance)

	var batch_index: int = 0
	for signature_variant: Variant in static_groups:
		var signature: String = String(signature_variant)
		var group: Array = static_groups[signature]
		if group.size() < MIN_STATIC_BATCH_SIZE:
			continue
		_add_static_multimesh(cell_root, group, batch_index)
		batch_index += 1
		for original_variant: Variant in group:
			var original: MeshInstance3D = original_variant
			batched_source_ids[original.get_instance_id()] = true

	for record_variant: Variant in records:
		var record: Dictionary = record_variant
		var original: Node3D = record["node"]
		if batched_source_ids.has(original.get_instance_id()):
			continue
		# Default duplication also preserves scripts, groups, and persistent
		# signal connections. USE_INSTANTIATION keeps instanced subtrees
		# atomic; the other flags are required now that directly-authored
		# spatial leaves/subtrees are valid streamed objects too.
		var duplicate: Node = original.duplicate()
		cell_root.add_child(duplicate)
		# Organizational Node3D transforms are intentionally flattened by
		# the splitter. Preserve the authored world transform instead of
		# accidentally reusing a transform relative to a removed folder.
		if duplicate is Node3D:
			(duplicate as Node3D).transform = original.global_transform
		if not _set_owner_recursive(
			duplicate,
			cell_root,
			original,
			original.owner
		):
			push_error(
				"split_world_into_cells: could not preserve the complete "
				+ "authored subtree for '%s'; cell %s was not overwritten."
				% [original.name, cell_coord]
			)
			cell_root.free()
			return false

	var packed := PackedScene.new()
	var pack_err: int = packed.pack(cell_root)
	if pack_err != OK:
		push_error("split_world_into_cells: failed to pack cell %s (error %d)" % [cell_coord, pack_err])
		cell_root.free()
		return false

	var path := "%scell_%d_%d.tscn" % [OUTPUT_PATH, cell_coord.x, cell_coord.y]
	var save_err: int = ResourceSaver.save(packed, path)
	if save_err != OK:
		push_error("split_world_into_cells: failed to save %s (error %d)" % [path, save_err])
	else:
		print(
			"  wrote %s (%d object(s), %d static batch(es))"
			% [path, records.size(), batch_index]
		)

	cell_root.free()
	return save_err == OK


func _is_batchable_static_mesh(node: Node3D) -> bool:
	if not (node is MeshInstance3D):
		return false
	var mesh_instance: MeshInstance3D = node as MeshInstance3D
	if (
		mesh_instance.mesh == null
		or mesh_instance.get_child_count() != 0
		or mesh_instance.get_script() != null
		or not mesh_instance.get_groups().is_empty()
		or mesh_instance.is_unique_name_in_owner()
		or mesh_instance.is_set_as_top_level()
		or not mesh_instance.visible
		or mesh_instance.skin != null
		or mesh_instance.skeleton != NodePath("")
		or mesh_instance.custom_aabb != AABB()
		or mesh_instance.visibility_parent != NodePath("")
	):
		return false
	if (
		mesh_instance.mesh is ArrayMesh
		and (mesh_instance.mesh as ArrayMesh).get_blend_shape_count() > 0
	):
		return false
	for surface_index: int in mesh_instance.get_surface_override_material_count():
		if mesh_instance.get_surface_override_material(surface_index) != null:
			return false
	return true


func _static_batch_signature(mesh_instance: MeshInstance3D) -> String:
	var material_id: int = (
		mesh_instance.material_override.get_instance_id()
		if mesh_instance.material_override != null
		else 0
	)
	var overlay_id: int = (
		mesh_instance.material_overlay.get_instance_id()
		if mesh_instance.material_overlay != null
		else 0
	)
	return "|".join(PackedStringArray([
		str(mesh_instance.mesh.get_instance_id()),
		str(material_id),
		str(overlay_id),
		str(mesh_instance.layers),
		str(mesh_instance.cast_shadow),
		str(mesh_instance.extra_cull_margin),
		str(mesh_instance.gi_mode),
		str(mesh_instance.gi_lightmap_scale),
		str(mesh_instance.visibility_range_begin),
		str(mesh_instance.visibility_range_end),
		str(mesh_instance.visibility_range_begin_margin),
		str(mesh_instance.visibility_range_end_margin),
		str(mesh_instance.visibility_range_fade_mode),
		str(mesh_instance.sorting_offset),
		str(mesh_instance.sorting_use_aabb_center),
		str(mesh_instance.ignore_occlusion_culling),
		str(mesh_instance.lod_bias),
		str(mesh_instance.transparency),
	]))


func _add_static_multimesh(
	cell_root: Node3D,
	group: Array,
	batch_index: int
) -> void:
	var source: MeshInstance3D = group[0]
	var multimesh := MultiMesh.new()
	multimesh.transform_format = MultiMesh.TRANSFORM_3D
	multimesh.mesh = source.mesh
	multimesh.instance_count = group.size()
	var transform_buffer := PackedFloat32Array()
	transform_buffer.resize(group.size() * 12)
	var mesh_bounds: AABB = source.mesh.get_aabb()
	var batch_bounds := AABB()
	var has_batch_bounds := false
	for instance_index: int in group.size():
		var original: MeshInstance3D = group[instance_index]
		var source_transform: Transform3D = original.global_transform
		var offset: int = instance_index * 12
		transform_buffer[offset] = source_transform.basis.x.x
		transform_buffer[offset + 1] = source_transform.basis.y.x
		transform_buffer[offset + 2] = source_transform.basis.z.x
		transform_buffer[offset + 3] = source_transform.origin.x
		transform_buffer[offset + 4] = source_transform.basis.x.y
		transform_buffer[offset + 5] = source_transform.basis.y.y
		transform_buffer[offset + 6] = source_transform.basis.z.y
		transform_buffer[offset + 7] = source_transform.origin.y
		transform_buffer[offset + 8] = source_transform.basis.x.z
		transform_buffer[offset + 9] = source_transform.basis.y.z
		transform_buffer[offset + 10] = source_transform.basis.z.z
		transform_buffer[offset + 11] = source_transform.origin.z
		var instance_bounds: AABB = source_transform * mesh_bounds
		if has_batch_bounds:
			batch_bounds = batch_bounds.merge(instance_bounds)
		else:
			batch_bounds = instance_bounds
			has_batch_bounds = true
	# set_instance_transform() updates the rendering RID, but editor-generated
	# PackedScenes do not reliably serialize those RID-side writes. Assigning
	# the storage buffer explicitly preserves every transform on disk.
	multimesh.buffer = transform_buffer
	if has_batch_bounds:
		# Avoid a load-time scan across every instance merely to derive the
		# same bounds the editor already has while generating the batch.
		multimesh.custom_aabb = batch_bounds

	var batch := MultiMeshInstance3D.new()
	batch.name = "StaticBatch_%d" % batch_index
	batch.multimesh = multimesh
	batch.material_override = source.material_override
	batch.material_overlay = source.material_overlay
	batch.layers = source.layers
	batch.cast_shadow = source.cast_shadow
	batch.extra_cull_margin = source.extra_cull_margin
	batch.gi_mode = source.gi_mode
	batch.gi_lightmap_scale = source.gi_lightmap_scale
	batch.visibility_range_begin = source.visibility_range_begin
	batch.visibility_range_end = source.visibility_range_end
	batch.visibility_range_begin_margin = source.visibility_range_begin_margin
	batch.visibility_range_end_margin = source.visibility_range_end_margin
	batch.visibility_range_fade_mode = source.visibility_range_fade_mode
	batch.sorting_offset = source.sorting_offset
	batch.sorting_use_aabb_center = source.sorting_use_aabb_center
	batch.ignore_occlusion_culling = source.ignore_occlusion_culling
	batch.lod_bias = source.lod_bias
	batch.transparency = source.transparency
	cell_root.add_child(batch)
	batch.owner = cell_root


func _remove_stale_cells(generated_buckets: Dictionary) -> void:
	var dir := DirAccess.open(OUTPUT_PATH)
	if dir == null:
		return
	for file_name in dir.get_files():
		if not file_name.begins_with("cell_") or not file_name.ends_with(".tscn"):
			continue
		var pieces := file_name.trim_prefix("cell_").trim_suffix(".tscn").split("_")
		if pieces.size() != 2 or not pieces[0].is_valid_int() or not pieces[1].is_valid_int():
			continue
		var coord := Vector2i(int(pieces[0]), int(pieces[1]))
		if not generated_buckets.has(coord):
			var error := dir.remove(file_name)
			if error != OK:
				push_error("split_world_into_cells: could not remove stale %s (error %d)." % [file_name, error])
			else:
				print("  removed stale %s" % file_name)


func _set_owner_recursive(
	node: Node,
	owner: Node,
	source_node: Node,
	source_scene_owner: Node
) -> bool:
	node.owner = owner
	return _set_source_owned_descendants(
		node,
		source_node,
		owner,
		source_scene_owner
	)


## A duplicated scene instance contains two different kinds of descendants:
## inherited nodes owned by the instance root, and local additions owned by
## the outer authoring scene. Only the latter belong in the generated cell's
## SceneState. Re-owning inherited nodes expands the source scene; stopping
## at the instance root drops local additions such as FarmPlot's Bramble and
## GuardianPatch. Pairing the duplicate with its source preserves both.
func _set_source_owned_descendants(
	duplicate_parent: Node,
	source_parent: Node,
	new_owner: Node,
	source_scene_owner: Node
) -> bool:
	var succeeded := true
	for source_child: Node in source_parent.get_children():
		var duplicate_child: Node = duplicate_parent.get_node_or_null(
			NodePath(str(source_child.name))
		)
		if duplicate_child == null:
			push_error(
				(
					"split_world_into_cells: duplicate '%s' is missing child "
					+ "'%s'; the child cannot be included in the generated cell."
				)
				% [duplicate_parent.name, source_child.name]
			)
			succeeded = false
			continue
		if source_child.owner == source_scene_owner:
			duplicate_child.owner = new_owner
		succeeded = (
			_set_source_owned_descendants(
				duplicate_child,
				source_child,
				new_owner,
				source_scene_owner
			)
			and succeeded
		)
	return succeeded
