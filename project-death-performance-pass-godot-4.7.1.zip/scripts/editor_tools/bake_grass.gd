@tool
extends EditorScript

## Run this with World.tscn open (Script Editor > open this file > File >
## Run). Scans the Terrain3D control map, and for every cell (using the
## SAME cell grid as WorldManager) that contains any vertex painted with
## GRASS_TEXTURE_ID, bakes a GrassCellData resource full of instance
## transforms — positions jittered within each grid cell for a natural,
## non-grid-aligned look, with random rotation/scale for variety.
##
## Safe to re-run anytime — fully regenerates every cell's grass data file
## from the terrain's CURRENT painting each time. Re-run this after
## re-texturing terrain, same "never hand-edit, always regenerate" idea as
## split_world_into_cells.gd.
##
## Output: res://data/grass/grass_<x>_<z>.res — one compact binary resource
## per cell that actually
## has any grass-textured ground in it. Cells with none simply get no file
## (same "absence = nothing here" convention WorldManager already uses).

const GRASS_TEXTURE_ID := 2  # match your Asset Dock's Grass texture ID
const WORLD_MANAGER_SCRIPT := preload("res://autoloads/world_manager.gd")
const GRASS_RUNTIME_BUILDER := preload("res://scripts/systems/grass_runtime_builder.gd")
const CELL_SIZE: float = WORLD_MANAGER_SCRIPT.CELL_SIZE
const SAMPLE_SPACING := 2.0  # how finely to scan for grass-textured ground — smaller = more candidate points, slower bake, denser possible placement. Start here; only go denser once you've confirmed load times/frame rate stay fine at this setting.
const INSTANCES_PER_GRASS_POINT := 1  # how many blades to place per qualifying sample point, jittered around it
const JITTER_RADIUS := 0.9  # widened alongside the sparser sampling above, so single-blade points still cover reasonable ground
const CLUSTER_RADIUS := 2.0
const HIGH_COUNT_WARNING_THRESHOLD := 8000  # print a warning (not an error) if any one cell bakes more instances than this
const OUTPUT_PATH := "res://data/grass/"

## The world-space area to scan. Set these to comfortably cover your
## terrain's full extent (a little too generous just costs bake time, not
## correctness — unpainted/out-of-region points are cheaply skipped).
const SCAN_MIN := Vector2(-400.0, -400.0)
const SCAN_MAX := Vector2(400.0, 400.0)


func _run() -> void:
	var scene_root: Node = get_scene()
	if scene_root == null:
		push_error("bake_grass: no scene open. Open World.tscn first.")
		return

	var terrain: Terrain3D = _find_terrain_recursive(scene_root)
	if terrain == null:
		push_error("bake_grass: no Terrain3D node found in the open scene.")
		return

	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(OUTPUT_PATH))

	var rng := RandomNumberGenerator.new()
	rng.seed = 12345  # fixed seed: re-running produces the same jitter, not a new random look every time

	var cell_buckets: Dictionary = {}  # Vector2i -> Array[Transform3D]
	var x: float = SCAN_MIN.x
	while x <= SCAN_MAX.x:
		var z: float = SCAN_MIN.y
		while z <= SCAN_MAX.y:
			var sample_pos := Vector3(x, 0.0, z)
			var control: int = terrain.data.get_control(sample_pos)
			if control != 4294967295 and Terrain3DUtil.get_base(control) == GRASS_TEXTURE_ID:
				var ground_y: float = terrain.data.get_height(sample_pos)
				var cell_coord := Vector2i(floori(x / CELL_SIZE), floori(z / CELL_SIZE))
				if not cell_buckets.has(cell_coord):
					# Must be explicitly typed HERE — a bare [] literal stored
					# in a Dictionary value is just a plain Array at runtime,
					# regardless of any comment saying otherwise, and
					# GrassCellData.transforms (Array[Transform3D]) rejects a
					# plain Array on assignment.
					var new_bucket: Array[Transform3D] = []
					cell_buckets[cell_coord] = new_bucket
				for i in INSTANCES_PER_GRASS_POINT:
					var jitter_x: float = rng.randf_range(-JITTER_RADIUS, JITTER_RADIUS)
					var jitter_z: float = rng.randf_range(-JITTER_RADIUS, JITTER_RADIUS)
					var instance_pos := Vector3(x + jitter_x, ground_y, z + jitter_z)
					var rotation_y: float = rng.randf_range(0.0, TAU)
					var scale_variance: float = rng.randf_range(0.8, 1.2)
					var t := Transform3D(Basis.IDENTITY.rotated(Vector3.UP, rotation_y).scaled(Vector3.ONE * scale_variance), instance_pos)
					cell_buckets[cell_coord].append(t)
			z += SAMPLE_SPACING
		x += SAMPLE_SPACING

	var total_instances := 0
	var all_writes_succeeded := true
	for cell_coord in cell_buckets:
		var data := GrassCellData.new()
		data.transforms = cell_buckets[cell_coord]
		GRASS_RUNTIME_BUILDER.populate_runtime_data(data, CLUSTER_RADIUS, true)
		var path := "%sgrass_%d_%d.res" % [OUTPUT_PATH, cell_coord.x, cell_coord.y]
		var err: int = ResourceSaver.save(data, path)
		if err != OK:
			all_writes_succeeded = false
			push_error("bake_grass: failed to save %s (error %d)" % [path, err])
		else:
			print("  wrote %s (%d instance(s))" % [path, data.instance_count])
		if data.instance_count > HIGH_COUNT_WARNING_THRESHOLD:
			push_warning("bake_grass: cell %s baked %d instances — that's a lot for one cell. Consider raising SAMPLE_SPACING or lowering INSTANCES_PER_GRASS_POINT and re-running if load times or frame rate suffer near it." % [cell_coord, data.instance_count])
		total_instances += data.instance_count

	if all_writes_succeeded:
		_remove_stale_grass_cells(cell_buckets)
	else:
		push_error(
			"bake_grass: one or more writes failed; stale files were preserved."
		)
	print("bake_grass: done — %d cell(s), %d grass instance(s) total." % [cell_buckets.size(), total_instances])


func _remove_stale_grass_cells(generated_buckets: Dictionary) -> void:
	var directory := DirAccess.open(OUTPUT_PATH)
	if directory == null:
		return
	for file_name: String in directory.get_files():
		var extension: String = file_name.get_extension().to_lower()
		if (
			not file_name.begins_with("grass_")
			or (extension != "res" and extension != "tres")
		):
			continue
		var pieces: PackedStringArray = (
			file_name.get_basename().trim_prefix("grass_").split("_")
		)
		if (
			pieces.size() != 2
			or not pieces[0].is_valid_int()
			or not pieces[1].is_valid_int()
		):
			continue
		var coord := Vector2i(int(pieces[0]), int(pieces[1]))
		if generated_buckets.has(coord):
			continue
		var error: Error = directory.remove(file_name)
		if error != OK:
			push_error(
				"bake_grass: could not remove stale %s (error %d)."
				% [file_name, error]
			)
		else:
			print("  removed stale %s" % file_name)


func _find_terrain_recursive(node: Node) -> Terrain3D:
	if node is Terrain3D:
		return node
	for child in node.get_children():
		var found: Terrain3D = _find_terrain_recursive(child)
		if found:
			return found
	return null
