extends Node
class_name PlayerBuildMode

## Owns the "Placing" sub-mode of Decorate Mode: the translucent ghost that
## follows the mouse (snapped to the decor grid / neighbor edges), rotation,
## and confirming placement. Split out of player.gd so build-mode bugs and
## features can be worked on without wading through movement/pickup code.
##
## Created and owned by Player (added as a child in player.gd's _ready).
## Player still owns the public API surface (decorate_mode_changed,
## rotation_changed signals, is_building()) — this node just does the work
## and reports back through `player`.

## Optional translucent material shown on the ghost preview while placing.
@export var ghost_material: Material
## Physics layer(s) the placement raycast should hit — your terrain/floor
## collision (layer 1) PLUS placed decor/furniture (layer 3, bitmask value
## 4 — same layer batch_generate_items.gd assigns) so you can stack items
## on top of other placed items, like a wall on a wall. Default value 5 =
## 1 (terrain) | 4 (placed objects).
@export_flags_3d_physics var build_terrain_mask: int = 5

## --- Placement snapping (soft-snap, not rigid grid-cell snap) ---
## Actual snap increment = build_snap_size * build_snap_fraction. Tune these
## to taste — smaller fraction = looser/finer positioning, larger = more
## grid-like. Position snaps; the object's visual center (not its raw mesh
## origin) is what aligns to that snapped point.
@export var build_snap_size: float = 1.0
@export var build_snap_fraction: float = 0.05

## --- Rotation: hold R, then scroll to rotate. Shift = coarser step. ---
@export var rotation_degrees_per_scroll: float = 90.0
@export var rotation_degrees_per_scroll_shift: float = 90.0

## --- Grid overlay (visible during Placing) ---
@export var grid_overlay_color: Color = Color(0.4, 1.0, 1.0, 0.85)
@export var grid_overlay_extent_cells: int = 60  # radius in decor cells
@export var grid_overlay_major_line_interval: int = 10
@export var grid_overlay_major_line_color: Color = Color(1.0, 1.0, 0.3, 1.0)

var player: Player
var is_active: bool = false

var _ghost: Node3D = null
var _ghost_rotation_y: float = 0.0
var _ghost_local_center: Vector3 = Vector3.ZERO
var _ghost_local_bottom: Vector3 = Vector3.ZERO
var _ghost_local_size: Vector3 = Vector3.ZERO
var _item_id: String = ""
var _grid_overlay: MeshInstance3D = null
var _ray_query: PhysicsRayQueryParameters3D = null
var _has_cached_neighbor_aabb: bool = false
var _cached_neighbor_instance_id: int = 0
var _cached_neighbor_transform: Transform3D = Transform3D.IDENTITY
var _cached_neighbor_aabb: AABB = AABB()


func setup(owning_player: Player) -> void:
	player = owning_player
	set_process(false)
	_ray_query = PhysicsRayQueryParameters3D.new()
	_ray_query.collision_mask = build_terrain_mask
	_grid_overlay = MeshInstance3D.new()
	_grid_overlay.visible = false
	_grid_overlay.top_level = true
	player.get_tree().current_scene.add_child.call_deferred(_grid_overlay)


func _process(_delta: float) -> void:
	if is_active:
		_update_ghost()


## Starts placing `item_id`, or swaps the ghost live if already placing
## something else (e.g. player scrolled the hotbar mid-session).
func start(item_id: String, def: ItemData) -> void:
	is_active = true
	set_process(true)
	_item_id = item_id
	_has_cached_neighbor_aabb = false
	player.selection_indicator.visible = false

	if _ghost:
		_ghost.queue_free()
		_ghost = null

	_ghost = def.placed_scene.instantiate()
	# Disable preview collision before entering the SceneTree so the physics
	# server never registers a one-frame live collider for the ghost.
	if _ghost.has_method("set_collision_enabled"):
		_ghost.set_collision_enabled(false)
	# Parent to the scene root, NOT the player — parenting under Player would
	# make the placed object follow the character forever, since nothing
	# ever reparents it back out after confirming.
	player.get_tree().current_scene.add_child(_ghost)
	if ghost_material:
		_apply_ghost_material(_ghost)

	# Compute the object's visual bounding-box center/bottom BEFORE ever
	# moving it — at this instant the ghost still sits at its default
	# transform, so this correctly captures the offset from origin to
	# visual center regardless of where the source mesh's pivot actually
	# is. Used every frame afterward so the object appears CENTERED under
	# the cursor instead of pivoting from an arbitrary corner.
	_cache_ghost_visual_bounds(_ghost)

	_show_grid_overlay()
	player.decorate_mode_changed.emit(true, "placing")
	player.rotation_changed.emit(fposmod(rad_to_deg(_ghost_rotation_y), 360.0))
	print("Placing '%s' — hold R + scroll to rotate (+Shift = 5°), click to confirm, Esc to exit. Scroll to switch items." % def.display_name)


## True if we're already placing exactly this item — lets Player's
## _refresh_decorate_target() skip redundant restarts.
func is_placing_item(item_id: String) -> bool:
	return is_active and _item_id == item_id


func stop() -> void:
	is_active = false
	set_process(false)
	if _ghost:
		_ghost.queue_free()
		_ghost = null
	_item_id = ""
	_has_cached_neighbor_aabb = false
	_hide_grid_overlay()


## Handles the "hold R + scroll" rotate gesture. Returns true if it consumed
## the event (so Player can mark input as handled).
func handle_scroll_rotate(event: InputEventMouseButton) -> bool:
	if not is_active:
		return false
	var step_degrees: float = rotation_degrees_per_scroll_shift if event.shift_pressed else rotation_degrees_per_scroll
	var step_radians: float = deg_to_rad(step_degrees)
	var direction: float = 1.0 if event.button_index == MOUSE_BUTTON_WHEEL_UP else -1.0
	_ghost_rotation_y += step_radians * direction
	player.rotation_changed.emit(fposmod(rad_to_deg(_ghost_rotation_y), 360.0))
	return true


## Confirms placement: commits the ghost as a real object, consumes the
## item from inventory, and reports back to Player what happens next.
func confirm() -> void:
	if _ghost == null:
		return

	var placed := _ghost
	var item_id := _item_id
	_ghost = null
	is_active = false
	set_process(false)
	_has_cached_neighbor_aabb = false

	if ghost_material:
		_restore_original_material(placed)

	if placed.has_method("set_collision_enabled"):
		placed.set_collision_enabled(true)

	if placed.has_method("commit_placement"):
		placed.source_item_id = item_id
		var success: bool = placed.commit_placement()
		if not success:
			print("Can't place here — that spot is already occupied.")
			placed.queue_free()
			_item_id = ""
			return
	else:
		push_warning("Placed scene for '%s' has no Placeable script on its root — it won't be grid-tracked or pickup-able." % item_id)

	InventoryManager.remove_item(item_id, 1)
	print("Placed: ", item_id)
	_item_id = ""


func _update_ghost() -> void:
	if _ghost == null or player._camera_rig == null:
		return

	var hit: Variant = _raycast_to_terrain()
	if hit == null:
		return

	var hit_pos: Vector3 = hit["position"]
	var hit_normal: Vector3 = hit["normal"]

	_ghost.rotation.y = _ghost_rotation_y
	var basis: Basis = _ghost.global_transform.basis

	var snapped_x: float = _soft_snap_axis(hit_pos.x)
	var snapped_z: float = _soft_snap_axis(hit_pos.z)
	hit_pos.y = _soft_snap_axis(hit_pos.y)

	# Best-effort edge-snap: if we're hitting the SIDE of another placed
	# object (not its top, not terrain), try to align flush edge-to-edge
	# with it instead of the normal soft-snap — makes lining up walls
	# side by side much easier. First pass: assumes both objects are
	# roughly axis-aligned (clean at 0/90/180/270°) since it compares raw
	# AABBs rather than doing full oriented-box math.
	if hit_normal.y <= 0.7:
		var edge_snap: Variant = _try_edge_snap(hit)
		if edge_snap != null:
			var snap_data: Dictionary = edge_snap
			snapped_x = snap_data["x"]
			snapped_z = snap_data["z"]

	if hit_normal.y > 0.7:
		# Floor-like surface (including the TOP of another placed object,
		# e.g. stacking a wall on a wall) — rest the mesh's actual BOTTOM
		# on the surface, X/Z still centered on the cursor.
		var rotated_offset: Vector3 = basis * _ghost_local_bottom
		var target := Vector3(snapped_x, hit_pos.y, snapped_z)
		_ghost.global_position = target - rotated_offset
	else:
		# Wall / vertical surface — keep full centering behavior (don't
		# try to "rest" against a wall the way we do against a floor).
		var rotated_offset: Vector3 = basis * _ghost_local_center
		var target := Vector3(snapped_x, hit_pos.y, snapped_z)
		_ghost.global_position = target - rotated_offset


func _soft_snap_axis(value: float) -> float:
	var increment: float = build_snap_size * build_snap_fraction
	if increment <= 0.0001:
		return value
	return round(value / increment) * increment


## Caches all three placement bounds from one tree traversal. The previous
## helpers independently recomputed the same combined world AABB three times.
func _cache_ghost_visual_bounds(node: Node3D) -> void:
	var world_aabb: Variant = MeshUtils.compute_world_aabb(node)
	if world_aabb == null:
		_ghost_local_center = Vector3.ZERO
		_ghost_local_bottom = Vector3.ZERO
		_ghost_local_size = Vector3.ZERO
		return
	var aabb: AABB = world_aabb
	var world_center: Vector3 = aabb.get_center()
	var bottom_world: Vector3 = Vector3(world_center.x, aabb.position.y, world_center.z)
	var inverse_transform: Transform3D = node.global_transform.affine_inverse()
	_ghost_local_center = inverse_transform * world_center
	_ghost_local_bottom = inverse_transform * bottom_world
	_ghost_local_size = aabb.size


## Tries to find a Placeable object under the raycast hit and, if found,
## returns {x, z} to align the ghost flush against its nearest edge instead
## of the normal soft-snap. Returns null if the hit wasn't a placed object
## (e.g. it was terrain) so the caller falls back normally.
func _try_edge_snap(hit: Dictionary) -> Variant:
	var collider: Object = hit.get("collider")
	var owner_node: Node = collider.owner if collider is Node else null
	if not (owner_node is Placeable) or owner_node == _ghost:
		return null

	var neighbor: Placeable = owner_node
	var neighbor_instance_id: int = neighbor.get_instance_id()
	var neighbor_transform: Transform3D = neighbor.global_transform
	var n_aabb: AABB
	if (
		_has_cached_neighbor_aabb
		and neighbor_instance_id == _cached_neighbor_instance_id
		and neighbor_transform == _cached_neighbor_transform
	):
		n_aabb = _cached_neighbor_aabb
	else:
		var neighbor_aabb: Variant = MeshUtils.compute_world_aabb(neighbor)
		if neighbor_aabb == null:
			_has_cached_neighbor_aabb = false
			return null
		n_aabb = neighbor_aabb
		_cached_neighbor_instance_id = neighbor_instance_id
		_cached_neighbor_transform = neighbor_transform
		_cached_neighbor_aabb = n_aabb
		_has_cached_neighbor_aabb = true

	var normal: Vector3 = hit["normal"]
	var half_x: float = _ghost_local_size.x * 0.5
	var half_z: float = _ghost_local_size.z * 0.5

	var result_x: float = _soft_snap_axis(hit["position"].x)
	var result_z: float = _soft_snap_axis(hit["position"].z)

	if abs(normal.x) > abs(normal.z):
		result_x = (n_aabb.position.x + n_aabb.size.x + half_x) if normal.x > 0 else (n_aabb.position.x - half_x)
	else:
		result_z = (n_aabb.position.z + n_aabb.size.z + half_z) if normal.z > 0 else (n_aabb.position.z - half_z)

	# Deliberately NOT touching Y here — the raycast's own hit position is
	# already a correct real-world point on the neighbor's surface. Using
	# the neighbor's raw transform origin instead double-counts the anchor
	# offset and produces floating/sunken objects, since that origin itself
	# was already anchor-adjusted when the neighbor was placed.
	return {"x": result_x, "z": result_z}


func _raycast_to_terrain() -> Variant:
	var camera: Camera3D = player._camera_rig.camera
	var mouse_pos := player.get_viewport().get_mouse_position()
	var ray_origin := camera.project_ray_origin(mouse_pos)
	var ray_dir := camera.project_ray_normal(mouse_pos)
	var ray_end := ray_origin + ray_dir * 1000.0

	_ray_query.from = ray_origin
	_ray_query.to = ray_end
	_ray_query.collision_mask = build_terrain_mask
	var space_state: PhysicsDirectSpaceState3D = player.get_world_3d().direct_space_state
	var hit: Dictionary = space_state.intersect_ray(_ray_query)

	if not hit.is_empty():
		return hit  # Dictionary with "position", "normal", "collider", etc.
	return null


## --- Grid overlay — a translucent snap-grid shown around the ghost while
## Placing, so it's visually obvious where objects will land. ---

func _show_grid_overlay() -> void:
	_grid_overlay.mesh = _build_grid_mesh()
	var cell := BuildGrid.world_to_decor_cell(player.global_position)
	_grid_overlay.global_position = BuildGrid.decor_cell_to_world(cell)
	_grid_overlay.visible = true


func _hide_grid_overlay() -> void:
	_grid_overlay.visible = false


func _build_grid_mesh() -> ArrayMesh:
	var cell_size := BuildGrid.DECOR_CELL_SIZE
	var extent := grid_overlay_extent_cells
	var half := extent * cell_size

	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_LINES)

	var i := -extent
	while i <= extent:
		var offset := i * cell_size
		var is_major: bool = (i % grid_overlay_major_line_interval) == 0
		var line_color: Color = grid_overlay_major_line_color if is_major else grid_overlay_color

		st.set_color(line_color)
		st.add_vertex(Vector3(offset, 0, -half))
		st.set_color(line_color)
		st.add_vertex(Vector3(offset, 0, half))
		st.set_color(line_color)
		st.add_vertex(Vector3(-half, 0, offset))
		st.set_color(line_color)
		st.add_vertex(Vector3(half, 0, offset))
		i += 1

	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	st.set_material(mat)

	return st.commit()


func _apply_ghost_material(node: Node) -> void:
	if node is MeshInstance3D:
		node.material_override = ghost_material
	for child in node.get_children():
		_apply_ghost_material(child)


func _restore_original_material(node: Node) -> void:
	if node is MeshInstance3D:
		node.material_override = null
	for child in node.get_children():
		_restore_original_material(child)
