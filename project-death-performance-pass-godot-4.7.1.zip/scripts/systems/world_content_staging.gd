@tool
extends Node3D

## Editor-only staging/pruning helper.
##
## On WorldContent, place/edit everything that should eventually live in a streamed cell
## (buildings, resource nodes, decor, FarmPlots) directly as a child of
## this node, in World.tscn, same as you always have. Because it's all one
## normal scene, you see EVERYTHING at once while editing — no cell
## boundaries, full context, easy to spot something straddling where a
## cell edge will eventually fall.
##
## The same helper may be attached to editor-only reference-map roots.
## In both cases this node's content is NEVER what runs in the shipped game —
## the instant the real game runs (not the editor), _enter_tree() below
## removes every child before it can enter the SceneTree or run _ready().
## Real runtime
## content comes entirely from the streamed cell scenes under
## scenes/world/cells/, generated FROM this node's current children by
## scripts/editor_tools/split_world_into_cells.gd.
##
## WORKFLOW:
##   1. Edit content here, in the editor, with full spatial context.
##   2. Run split_world_into_cells.gd (Script Editor > open it > File > Run,
##      or the little play-button in the script editor toolbar) whenever
##      you want to test how it actually streams. Safe to re-run anytime —
##      it fully regenerates every cell file from this node's current
##      state each time, so there's never a "stale cell file" to worry
##      about as long as you always re-run after editing.
##   3. Run the game normally to test streaming — this node's content
##      won't appear (see above), only the freshly-generated cells will.

func _enter_tree() -> void:
	if Engine.is_editor_hint():
		return

	# Reference-map roots may themselves be renderable. Hide the root
	# immediately so queue_free() at the end of the frame cannot produce a
	# one-frame runtime flash, while preserving editor visibility.
	visible = false

	# A parent's _enter_tree() runs before its children enter. Detaching and
	# freeing the staging children here prevents their scripts from running
	# _enter_tree()/_ready() and registering duplicate runtime side effects.
	for child: Node in get_children():
		remove_child(child)
		child.free()
	queue_free()
