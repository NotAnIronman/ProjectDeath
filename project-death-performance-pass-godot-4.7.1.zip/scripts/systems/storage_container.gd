extends Placeable
class_name StorageContainer

## A placed storage container — a wooden crate, magical chest, seed
## cabinet, etc. Placed/picked up exactly like any other Placeable
## (inherits ALL of that unchanged — build mode, grid tracking, B-key
## pickup). This only ADDS the ability to open it: walk up, press E, same
## ambient "interactables" interaction FarmPlot/ResourceNode already use
## (Placeable itself deliberately does NOT use ambient interaction — see
## its own header comment — so this opts in separately, on top).
##
## Slot data uses the exact same {item_id, quantity} shape as
## InventorySlotManager's own slots — same convention on purpose, so nothing
## about how a "slot" is represented needs reinventing here.
##
## Which specific container TYPE this is (slot count, category
## restriction) comes from source_item_id -> InventoryManager.item_defs,
## same as everything else Placeable already tracks — see get_type_data().

signal contents_changed()

var slots: Array[Dictionary] = []
var _type_data: StorageItemData = null
var _bulk_mutation_depth: int = 0
var _contents_dirty: bool = false


func _notify_contents_changed() -> void:
	if _bulk_mutation_depth > 0:
		_contents_dirty = true
	else:
		contents_changed.emit()


func _begin_bulk_mutation() -> void:
	_bulk_mutation_depth += 1


func _end_bulk_mutation() -> void:
	_bulk_mutation_depth = maxi(0, _bulk_mutation_depth - 1)
	if _bulk_mutation_depth == 0 and _contents_dirty:
		_contents_dirty = false
		contents_changed.emit()


func _ready() -> void:
	add_to_group("interactables")


func get_type_data() -> StorageItemData:
	if _type_data == null and source_item_id != "":
		var def: ItemData = InventoryManager.item_defs.get(source_item_id)
		if def is StorageItemData:
			_type_data = def
			_ensure_slots_sized()
	return _type_data


func _ensure_slots_sized() -> void:
	var target_size: int = _type_data.slot_count if _type_data else 12
	while slots.size() < target_size:
		slots.append({"item_id": "", "quantity": 0})


## Called by Player's ambient interaction (same path as FarmPlot/ResourceNode).
func interact(_player: Node) -> void:
	get_type_data()
	var ui := get_tree().get_first_node_in_group("ui_layer")
	if ui and ui.has_method("open_storage"):
		ui.open_storage(self)
	else:
		push_warning("StorageContainer: no UILayer with open_storage() found.")


func accepts(item_id: String) -> bool:
	var data := get_type_data()
	if data == null:
		return true
	var def: ItemData = InventoryManager.item_defs.get(item_id)
	if def == null:
		return false
	if data.seeds_only:
		return def is SeedData
	if data.allowed_categories.is_empty():
		return true
	return data.allowed_categories.has(def.category)


## Deposits up to `amount` of `item_id` INTO this container (does not
## touch the player's inventory itself — caller is responsible for
## removing what actually got deposited, see auto_deposit_from_player for
## the pattern). Returns how many actually fit.
func deposit(item_id: String, amount: int) -> int:
	if amount <= 0 or not accepts(item_id):
		return 0
	get_type_data()
	var def: ItemData = InventoryManager.item_defs.get(item_id)
	var max_stack: int = def.max_stack if def else 99
	var remaining := amount

	for slot in slots:
		if remaining <= 0:
			break
		if slot["item_id"] == item_id and slot["quantity"] < max_stack:
			var space: int = max_stack - int(slot["quantity"])
			var add_amount: int = mini(space, remaining)
			slot["quantity"] = int(slot["quantity"]) + add_amount
			remaining -= add_amount

	for slot in slots:
		if remaining <= 0:
			break
		if slot["item_id"] == "":
			var add_amount: int = mini(max_stack, remaining)
			slot["item_id"] = item_id
			slot["quantity"] = add_amount
			remaining -= add_amount

	var deposited := amount - remaining
	if deposited > 0:
		_notify_contents_changed()
	return deposited


## Withdraws up to `amount` of `item_id` OUT of this container directly
## into the player's inventory via InventoryManager. Returns how many
## actually got withdrawn.
## Places item_id/quantity directly into slot `index`, REPLACING whatever
## was there — the building block for drag-and-drop onto a specific slot,
## including swaps. Returns the displaced {item_id, quantity} (quantity 0
## if the slot was already empty). Does NOT check accepts() — callers that
## need to reject an item should check that BEFORE touching anything else
## (usually before removing it from wherever it came from).
func place_in_slot(index: int, item_id: String, quantity: int) -> Dictionary:
	var displaced: Dictionary = slots[index].duplicate()
	slots[index] = {"item_id": item_id, "quantity": quantity}
	_notify_contents_changed()
	return displaced


## Clears slot `index` and returns what was there (quantity 0 if it was
## already empty).
func take_from_slot(index: int) -> Dictionary:
	var taken: Dictionary = slots[index].duplicate()
	slots[index] = {"item_id": "", "quantity": 0}
	_notify_contents_changed()
	return taken


func withdraw(item_id: String, amount: int) -> int:
	if amount <= 0:
		return 0
	var accepted := mini(amount, InventorySlotManager.get_add_capacity(item_id))
	var remaining := accepted
	for slot in slots:
		if remaining <= 0:
			break
		if slot["item_id"] == item_id:
			var take: int = mini(int(slot["quantity"]), remaining)
			slot["quantity"] = int(slot["quantity"]) - take
			remaining -= take
			if int(slot["quantity"]) <= 0:
				slot["item_id"] = ""
				slot["quantity"] = 0

	var withdrawn := accepted - remaining
	if withdrawn > 0:
		InventoryManager.try_add_item(item_id, withdrawn)
		_notify_contents_changed()
	return withdrawn


func withdraw_slot_to_player(index: int, amount: int = -1) -> int:
	if index < 0 or index >= slots.size():
		return 0
	var slot: Dictionary = slots[index]
	var item_id: String = slot.get("item_id", "")
	if item_id == "":
		return 0
	var requested := int(slot.get("quantity", 0)) if amount < 0 else mini(amount, int(slot.get("quantity", 0)))
	var accepted := mini(requested, InventorySlotManager.get_add_capacity(item_id))
	if accepted <= 0:
		return 0
	if InventoryManager.try_add_item(item_id, accepted) != accepted:
		return 0
	var remaining := int(slot["quantity"]) - accepted
	slots[index] = {"item_id": item_id if remaining > 0 else "", "quantity": remaining}
	_notify_contents_changed()
	return accepted


## "Auto deposit" from the design doc: deposits everything in the
## player's CURRENT inventory that this container accepts, up to
## available space. Returns how many distinct item types were moved.
func auto_deposit_from_player() -> int:
	var moved_types := 0
	_begin_bulk_mutation()
	for item_id in InventoryManager.item_counts.keys().duplicate():
		if not accepts(item_id):
			continue
		var have: int = InventoryManager.get_count(item_id)
		if have <= 0:
			continue
		var deposited := deposit(item_id, have)
		if deposited > 0:
			InventoryManager.remove_item(item_id, deposited)
			moved_types += 1
	_end_bulk_mutation()
	return moved_types


## Sorts non-empty slots alphabetically by display name, compacting empty
## slots to the end. Small container sizes (12-30ish), so a plain sort is
## more than fast enough — no need for anything cleverer.
## Splits slot `index` roughly in half, placing the split-off portion into
## the first empty slot in this same container. No-op if there's no empty
## slot to split into, or the stack has only 1 item.
func split_slot(index: int) -> void:
	var slot: Dictionary = slots[index]
	var item_id: String = slot["item_id"]
	var quantity: int = slot["quantity"]
	if item_id == "" or quantity <= 1:
		return

	var split_amount: int = quantity / 2
	var remaining: int = quantity - split_amount

	for i in slots.size():
		if i == index:
			continue
		if slots[i]["item_id"] == "":
			slots[index] = {"item_id": item_id, "quantity": remaining}
			slots[i] = {"item_id": item_id, "quantity": split_amount}
			_notify_contents_changed()
			return


func sort_slots() -> void:
	var non_empty: Array[Dictionary] = []
	for slot in slots:
		if slot["item_id"] != "":
			non_empty.append(slot)

	non_empty.sort_custom(func(a, b):
		var def_a: ItemData = InventoryManager.item_defs.get(a["item_id"])
		var def_b: ItemData = InventoryManager.item_defs.get(b["item_id"])
		var name_a: String = def_a.display_name if def_a else a["item_id"]
		var name_b: String = def_b.display_name if def_b else b["item_id"]
		return name_a < name_b
	)

	var empty_count: int = slots.size() - non_empty.size()
	slots.clear()
	slots.append_array(non_empty)
	for i in empty_count:
		slots.append({"item_id": "", "quantity": 0})

	_notify_contents_changed()


## --- Save/Load — extends Placeable's own contract with slot contents ---

func get_save_data() -> Dictionary:
	var data := super.get_save_data()
	data["slots"] = slots.duplicate(true)
	return data


func pick_up() -> bool:
	for slot in slots:
		if slot.get("item_id", "") != "" and int(slot.get("quantity", 0)) > 0:
			NotificationManager.notify("Empty this container before picking it up.", "warning")
			return false
	return super.pick_up()


func load_save_data(data: Dictionary) -> void:
	super.load_save_data(data)
	get_type_data()
	var saved_slots: Array = data.get("slots", [])
	slots.clear()
	for entry in saved_slots:
		slots.append({"item_id": entry.get("item_id", ""), "quantity": entry.get("quantity", 0)})
	_ensure_slots_sized()
