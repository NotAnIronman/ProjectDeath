extends Placeable
class_name TradingPost

## A placed shop — general store, seed merchant, etc. Inherits ALL of
## Placeable unchanged (build mode, grid tracking, pickup) and ADDS
## opening via ambient E-interact, same as StorageContainer does (see its
## header comment for why Placeable itself doesn't use that path).
##
## No extra save data needed — see shop_item_data.gd's header for why.

signal stock_changed()  ## unused today (stock is static), kept for UI consistency with StorageContainer's contents_changed

var _type_data: ShopItemData = null


func _ready() -> void:
	add_to_group("interactables")


func get_type_data() -> ShopItemData:
	if _type_data == null and source_item_id != "":
		var def: ItemData = InventoryManager.item_defs.get(source_item_id)
		if def is ShopItemData:
			_type_data = def
	return _type_data


func interact(_player: Node) -> void:
	get_type_data()
	var ui := get_tree().get_first_node_in_group("ui_layer")
	if ui and ui.has_method("open_shop"):
		ui.open_shop(self)
	else:
		push_warning("TradingPost: no UILayer with open_shop() found.")


## Every item this shop actually has for sale right now — filters
## stock_item_ids down to ones with a real buy_price set, so listing an
## item_id here without pricing it doesn't silently show a free item.
func get_purchasable_items() -> Array[String]:
	var result: Array[String] = []
	var data := get_type_data()
	if data == null:
		return result
	for item_id in data.stock_item_ids:
		var def: ItemData = InventoryManager.item_defs.get(item_id)
		if def and def.buy_price > 0:
			result.append(item_id)
	return result


## Attempts to buy `amount` of `item_id`. Returns true if the purchase
## succeeded (false if not stocked, not priced, or too expensive).
func buy(item_id: String, amount: int = 1) -> bool:
	if amount <= 0 or not get_purchasable_items().has(item_id):
		return false
	var def: ItemData = InventoryManager.item_defs.get(item_id)
	var total_cost: int = def.buy_price * amount
	if InventorySlotManager.get_add_capacity(item_id) < amount:
		return false
	if not EconomyManager.remove_currency(total_cost):
		return false
	var accepted: int = InventoryManager.try_add_item(item_id, amount)
	if accepted != amount:
		EconomyManager.add_currency(total_cost)
		return false
	return accepted == amount


## Attempts to sell `amount` of `item_id` from the player's inventory.
## Returns true if the sale succeeded (false if the item has no sell_price
## set, or the player doesn't actually have that many).
func sell(item_id: String, amount: int = 1) -> bool:
	if amount <= 0:
		return false
	var def: ItemData = InventoryManager.item_defs.get(item_id)
	if def == null or def.sell_price <= 0:
		return false
	if not InventoryManager.has_item(item_id, amount):
		return false

	InventoryManager.remove_item(item_id, amount)
	EconomyManager.add_currency(def.sell_price * amount)
	return true
