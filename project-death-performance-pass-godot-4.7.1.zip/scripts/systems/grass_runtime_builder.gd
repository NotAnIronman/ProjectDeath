extends RefCounted
class_name GrassRuntimeBuilder

## Builds the immutable, runtime-oriented representation of baked grass.
## The expensive work belongs in editor tooling; GrassManager only falls
## back to this at runtime when it encounters a legacy resource.


static func is_runtime_data_valid(data: Variant, expected_cluster_radius: float) -> bool:
	if data == null or data.instance_count <= 0:
		return false
	if data.multimesh_buffer.size() != data.instance_count * 12:
		return false
	if not is_equal_approx(data.cluster_radius, expected_cluster_radius):
		return false
	if data.cluster_keys.size() != data.cluster_centers.size():
		return false
	if data.cluster_keys.size() != data.cluster_instance_indices.size():
		return false
	return (
		data.cluster_grid_size.x > 0
		and data.cluster_grid_size.y > 0
		and data.cluster_index_grid.size()
			== data.cluster_grid_size.x * data.cluster_grid_size.y
	)


static func populate_runtime_data(
	data: Variant,
	target_cluster_radius: float,
	discard_source_transforms: bool = true
) -> bool:
	if data == null or data.transforms.is_empty() or target_cluster_radius <= 0.0:
		return false

	data.instance_count = data.transforms.size()
	data.cluster_radius = target_cluster_radius
	data.cluster_keys.clear()
	data.cluster_centers.clear()
	data.cluster_instance_indices.clear()
	data.cluster_index_grid.clear()

	var buffer := PackedFloat32Array()
	buffer.resize(data.instance_count * 12)
	var buckets: Dictionary = {}
	var position_bounds := AABB(data.transforms[0].origin, Vector3.ZERO)

	for index in data.instance_count:
		var transform: Transform3D = data.transforms[index]
		var offset: int = index * 12
		buffer[offset] = transform.basis.x.x
		buffer[offset + 1] = transform.basis.y.x
		buffer[offset + 2] = transform.basis.z.x
		buffer[offset + 3] = transform.origin.x
		buffer[offset + 4] = transform.basis.x.y
		buffer[offset + 5] = transform.basis.y.y
		buffer[offset + 6] = transform.basis.z.y
		buffer[offset + 7] = transform.origin.y
		buffer[offset + 8] = transform.basis.x.z
		buffer[offset + 9] = transform.basis.y.z
		buffer[offset + 10] = transform.basis.z.z
		buffer[offset + 11] = transform.origin.z
		position_bounds = position_bounds.expand(transform.origin)

		var key := Vector2i(
			floori(transform.origin.x / target_cluster_radius),
			floori(transform.origin.z / target_cluster_radius)
		)
		if not buckets.has(key):
			buckets[key] = {
				"sum": Vector3.ZERO,
				"indices": PackedInt32Array(),
			}
		var bucket: Dictionary = buckets[key]
		bucket["sum"] = Vector3(bucket["sum"]) + transform.origin
		var indices: PackedInt32Array = bucket["indices"]
		indices.append(index)
		bucket["indices"] = indices

	data.multimesh_buffer = buffer
	data.position_aabb = position_bounds

	var sorted_keys: Array[Vector2i] = []
	for key: Vector2i in buckets:
		sorted_keys.append(key)
	sorted_keys.sort_custom(func(a: Vector2i, b: Vector2i) -> bool:
		return a.x < b.x or (a.x == b.x and a.y < b.y)
	)

	var minimum_key: Vector2i = sorted_keys[0]
	var maximum_key: Vector2i = sorted_keys[0]
	for cluster_index in sorted_keys.size():
		var key := sorted_keys[cluster_index]
		var indices: PackedInt32Array = buckets[key]["indices"]
		data.cluster_keys.append(key)
		data.cluster_centers.append(
			Vector3(buckets[key]["sum"]) / float(indices.size())
		)
		data.cluster_instance_indices.append(indices)
		minimum_key = Vector2i(
			mini(minimum_key.x, key.x),
			mini(minimum_key.y, key.y)
		)
		maximum_key = Vector2i(
			maxi(maximum_key.x, key.x),
			maxi(maximum_key.y, key.y)
		)

	data.cluster_grid_origin = minimum_key
	data.cluster_grid_size = maximum_key - minimum_key + Vector2i.ONE
	data.cluster_index_grid.resize(
		data.cluster_grid_size.x * data.cluster_grid_size.y
	)
	data.cluster_index_grid.fill(-1)
	for cluster_index in data.cluster_keys.size():
		var local_key: Vector2i = data.cluster_keys[cluster_index] - minimum_key
		var grid_offset: int = (
			local_key.y * data.cluster_grid_size.x + local_key.x
		)
		data.cluster_index_grid[grid_offset] = cluster_index

	if discard_source_transforms:
		data.transforms.clear()
	return true


static func transform_from_buffer(
	buffer: PackedFloat32Array,
	instance_index: int
) -> Transform3D:
	var offset := instance_index * 12
	return Transform3D(
		Basis(
			Vector3(buffer[offset], buffer[offset + 4], buffer[offset + 8]),
			Vector3(buffer[offset + 1], buffer[offset + 5], buffer[offset + 9]),
			Vector3(buffer[offset + 2], buffer[offset + 6], buffer[offset + 10])
		),
		Vector3(buffer[offset + 3], buffer[offset + 7], buffer[offset + 11])
	)
