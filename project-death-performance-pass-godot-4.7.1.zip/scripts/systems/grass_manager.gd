extends Node

@export var grass_mesh: Mesh
@export var grass_material: Material
@export var cluster_radius: float = 2.0
@export var regrow_seconds: float = 45.0
@export var cut_radius: float = 1.5

const GRASS_DATA_PATH := "res://data/grass/"
const HIDDEN_SCALE := 0.0001
const MAX_CONCURRENT_LOADS := 2
const MAX_PREFETCH_CACHE_CELLS := 16
const REGROW_POLL_INTERVAL_SECONDS := 0.25
const GRASS_RUNTIME_BUILDER := preload(
	"res://scripts/systems/grass_runtime_builder.gd"
)

var _data_paths: Dictionary = {}
var _queued_roots: Dictionary = {} # Vector2i -> WeakRef
var _prefetch_queue: Dictionary = {} # Vector2i -> true
var _loading_cells: Dictionary = {} # Vector2i -> true
var _prefetched_data: Dictionary = {} # Vector2i -> GrassCellData
var _prefetch_lru: Array[Vector2i] = []
var _multimesh_by_cell: Dictionary = {} # Vector2i -> MultiMeshInstance3D
var _data_by_cell: Dictionary = {} # Vector2i -> GrassCellData
## Vector2i -> {cluster_index: regrow_world_seconds}. Intact grass has no
## per-frame CPU cost; cut grass is checked at a low fixed cadence.
var _cut_clusters_by_cell: Dictionary = {}
var _saved_cut_state: Dictionary = {}
var _warned_legacy_data := false
var _regrow_poll_accumulator := 0.0


func _ready() -> void:
	_discover_grass_data()
	WorldManager.cell_loaded.connect(_on_cell_loaded)
	WorldManager.cell_unloaded.connect(_on_cell_unloaded)
	WorldManager.world_shutdown.connect(_on_world_shutdown)
	if WorldManager.has_signal("cell_prefetch_requested"):
		WorldManager.connect(
			"cell_prefetch_requested",
			Callable(self, "_on_cell_prefetch_requested")
		)
	set_process(false)


func _discover_grass_data() -> void:
	_data_paths.clear()
	var directory := DirAccess.open(GRASS_DATA_PATH)
	if directory == null:
		return
	for file_name in directory.get_files():
		var extension := file_name.get_extension().to_lower()
		if (
			not file_name.begins_with("grass_")
			or (extension != "res" and extension != "tres")
		):
			continue
		var pieces := file_name.get_basename().trim_prefix("grass_").split("_")
		if (
			pieces.size() == 2
			and pieces[0].is_valid_int()
			and pieces[1].is_valid_int()
		):
			var coord := Vector2i(int(pieces[0]), int(pieces[1]))
			# Binary, precomputed resources always win over legacy text files.
			if extension == "res" or not _data_paths.has(coord):
				_data_paths[coord] = GRASS_DATA_PATH.path_join(file_name)


func _process(delta: float) -> void:
	var activated := _poll_loading_cells()
	if not activated:
		_activate_one_prefetched_cell()
	_start_queued_loads()

	if not _cut_clusters_by_cell.is_empty():
		_regrow_poll_accumulator += delta
		if _regrow_poll_accumulator >= REGROW_POLL_INTERVAL_SECONDS:
			_regrow_poll_accumulator = 0.0
			_update_regrowing_clusters()

	if (
		_queued_roots.is_empty()
		and _prefetch_queue.is_empty()
		and _loading_cells.is_empty()
		and _cut_clusters_by_cell.is_empty()
	):
		set_process(false)


func _on_cell_loaded(cell_coord: Vector2i, cell_root: Node) -> void:
	if not _data_paths.has(cell_coord) or grass_mesh == null:
		return
	WorldManager.mark_cell_layer_pending(cell_coord, "grass")
	_queued_roots[cell_coord] = weakref(cell_root)
	_prefetch_queue.erase(cell_coord)
	set_process(true)


func _on_cell_prefetch_requested(cell_coord: Vector2i) -> void:
	if (
		not _data_paths.has(cell_coord)
		or _queued_roots.has(cell_coord)
		or _loading_cells.has(cell_coord)
		or _prefetched_data.has(cell_coord)
	):
		return
	_prefetch_queue[cell_coord] = true
	set_process(true)


## Read-only readiness probe used by seamless fast travel. Coordinates with
## no authored grass are already ready; populated coordinates are ready once
## their compact cell data is active or resident in the bounded prefetch LRU.
func is_neighborhood_prepared(
	center: Vector2i,
	radius: int
) -> bool:
	var safe_radius: int = maxi(0, radius)
	for dx in range(-safe_radius, safe_radius + 1):
		for dz in range(-safe_radius, safe_radius + 1):
			var coord: Vector2i = center + Vector2i(dx, dz)
			# WorldManager bounds explicit destination warm-up. If a future
			# load radius contains more cells than that cap, wait only for
			# the coordinates it actually asked layer systems to prepare.
			if not WorldManager.is_destination_prefetch_target(coord):
				continue
			if (
				_data_paths.has(coord)
				and not _data_by_cell.has(coord)
				and not _prefetched_data.has(coord)
			):
				return false
	return true


func _start_queued_loads() -> void:
	_discard_stale_prefetch_requests()
	while _loading_cells.size() < MAX_CONCURRENT_LOADS:
		var selected: Variant = _next_queued_coord()
		if selected == null:
			return
		var cell_coord: Vector2i = selected
		_prefetch_queue.erase(cell_coord)
		if _prefetched_data.has(cell_coord):
			continue

		var path: String = _data_paths[cell_coord]
		var error: Error = ResourceLoader.load_threaded_request(
			path,
			"",
			false,
			ResourceLoader.CACHE_MODE_REUSE
		)
		var status: int = ResourceLoader.load_threaded_get_status(path)
		if (
			error == OK
			or status == ResourceLoader.THREAD_LOAD_IN_PROGRESS
			or status == ResourceLoader.THREAD_LOAD_LOADED
		):
			_loading_cells[cell_coord] = true
			continue

		push_error(
			"GrassManager: failed to request %s (error %d)." % [path, error]
		)
		if _queued_roots.has(cell_coord):
			_queued_roots.erase(cell_coord)
			WorldManager.mark_cell_layer_ready(cell_coord, "grass")


func _next_queued_coord() -> Variant:
	var candidates: Array[Vector2i] = []
	for coord: Vector2i in _queued_roots:
		if not _loading_cells.has(coord) and not _prefetched_data.has(coord):
			candidates.append(coord)

	var center := Vector2i.ZERO
	var player := WorldManager.get_player() as Node3D
	if player != null:
		center = WorldManager.world_to_cell(player.global_position)
	if not candidates.is_empty():
		candidates.sort_custom(func(a: Vector2i, b: Vector2i) -> bool:
			return _cell_distance_squared(a, center) < _cell_distance_squared(b, center)
		)
		return candidates[0]

	for coord: Vector2i in _prefetch_queue:
		if not _loading_cells.has(coord) and not _prefetched_data.has(coord):
			candidates.append(coord)
	if candidates.is_empty():
		return null

	# Fast-travel destinations are useful immediately and can be far from the
	# current player, so rank them ahead of ordinary movement prediction.
	candidates.sort_custom(func(a: Vector2i, b: Vector2i) -> bool:
		var a_is_destination: bool = WorldManager.is_destination_prefetch_target(a)
		var b_is_destination: bool = WorldManager.is_destination_prefetch_target(b)
		if a_is_destination != b_is_destination:
			return a_is_destination
		return _cell_distance_squared(a, center) < _cell_distance_squared(b, center)
	)
	return candidates[0]


func _discard_stale_prefetch_requests() -> void:
	var queued_coords: Array = _prefetch_queue.keys()
	for coord_variant: Variant in queued_coords:
		var coord: Vector2i = coord_variant
		if not WorldManager.is_cell_prefetch_target(coord):
			_prefetch_queue.erase(coord)


func _poll_loading_cells() -> bool:
	var activated := false
	var loading_coords: Array = _loading_cells.keys()
	for coord_variant: Variant in loading_coords:
		var coord: Vector2i = coord_variant
		var path: String = _data_paths[coord]
		var status: int = ResourceLoader.load_threaded_get_status(path)
		if (
			status == ResourceLoader.THREAD_LOAD_FAILED
			or status == ResourceLoader.THREAD_LOAD_INVALID_RESOURCE
		):
			_loading_cells.erase(coord)
			if _queued_roots.has(coord):
				_queued_roots.erase(coord)
				WorldManager.mark_cell_layer_ready(coord, "grass")
			continue
		if status != ResourceLoader.THREAD_LOAD_LOADED:
			continue

		var data: Variant = ResourceLoader.load_threaded_get(path)
		_loading_cells.erase(coord)
		if data == null:
			if _queued_roots.has(coord):
				_queued_roots.erase(coord)
				WorldManager.mark_cell_layer_ready(coord, "grass")
			continue

		_cache_prefetched_data(coord, data)
		if activated or not _queued_roots.has(coord):
			continue
		activated = _activate_prefetched_cell(coord)
	return activated


func _activate_one_prefetched_cell() -> bool:
	for coord: Vector2i in _queued_roots:
		if _prefetched_data.has(coord):
			return _activate_prefetched_cell(coord)
	return false


func _activate_prefetched_cell(coord: Vector2i) -> bool:
	if not _queued_roots.has(coord) or not _prefetched_data.has(coord):
		return false
	var root_reference: WeakRef = _queued_roots[coord]
	_queued_roots.erase(coord)
	var root := root_reference.get_ref() as Node
	if root == null:
		return false

	var data: Variant = _prefetched_data[coord]
	_prefetched_data.erase(coord)
	_prefetch_lru.erase(coord)
	if data != null:
		_create_grass(coord, root, data)
	WorldManager.mark_cell_layer_ready(coord, "grass")
	return true


func _cache_prefetched_data(coord: Vector2i, data: Variant) -> void:
	_prefetched_data[coord] = data
	_prefetch_lru.erase(coord)
	_prefetch_lru.append(coord)
	while _prefetch_lru.size() > MAX_PREFETCH_CACHE_CELLS:
		var evicted: Vector2i = _prefetch_lru.pop_front()
		if not _queued_roots.has(evicted):
			_prefetched_data.erase(evicted)


func _cell_distance_squared(a: Vector2i, b: Vector2i) -> int:
	var offset: Vector2i = a - b
	return offset.x * offset.x + offset.y * offset.y


func _update_regrowing_clusters() -> void:
	var now := DayNightManager.get_world_elapsed_seconds()
	var cell_coords: Array = _cut_clusters_by_cell.keys()
	for coord_variant: Variant in cell_coords:
		var coord: Vector2i = coord_variant
		var cut_clusters: Dictionary = _cut_clusters_by_cell[coord]
		var cluster_indices: Array = cut_clusters.keys()
		for cluster_index_variant: Variant in cluster_indices:
			var cluster_index := int(cluster_index_variant)
			if float(cut_clusters[cluster_index]) <= now:
				_regrow_cluster(coord, cluster_index)


func _create_grass(
	coord: Vector2i,
	root: Node,
	data: Variant
) -> void:
	if not GRASS_RUNTIME_BUILDER.is_runtime_data_valid(data, cluster_radius):
		if (
			data.transforms.is_empty()
			or not GRASS_RUNTIME_BUILDER.populate_runtime_data(
				data,
				cluster_radius,
				false
			)
		):
			push_error(
				"GrassManager: invalid baked runtime data for cell %s." % coord
			)
			return
		if not _warned_legacy_data:
			_warned_legacy_data = true
			push_warning(
				"GrassManager: legacy grass data required main-thread preparation. "
				+ "Run scripts/editor_tools/upgrade_grass_runtime_data.gd once."
			)

	var multimesh := MultiMesh.new()
	multimesh.transform_format = MultiMesh.TRANSFORM_3D
	multimesh.mesh = grass_mesh
	multimesh.instance_count = data.instance_count
	multimesh.buffer = data.multimesh_buffer

	var bounds: AABB = data.position_aabb
	var mesh_size: Vector3 = grass_mesh.get_aabb().size
	bounds = bounds.grow(maxf(mesh_size.x, maxf(mesh_size.y, mesh_size.z)))
	multimesh.custom_aabb = bounds

	var instance := MultiMeshInstance3D.new()
	instance.name = "Grass"
	instance.multimesh = multimesh
	instance.material_override = grass_material
	root.add_child(instance)

	_multimesh_by_cell[coord] = instance
	_data_by_cell[coord] = data
	_apply_saved_cut_state(coord)


func cut_at(world_position: Vector3) -> bool:
	var cell_coord := WorldManager.world_to_cell(world_position)
	var key_radius := ceili(cut_radius / cluster_radius)
	var cut_radius_squared := cut_radius * cut_radius
	var base_key := Vector2i(
		floori(world_position.x / cluster_radius),
		floori(world_position.z / cluster_radius)
	)
	for dx in range(-1, 2):
		for dz in range(-1, 2):
			var coord := cell_coord + Vector2i(dx, dz)
			var data: Variant = _data_by_cell.get(coord)
			if data == null:
				continue
			var cut_clusters: Dictionary = _cut_clusters_by_cell.get(coord, {})
			for key_x in range(-key_radius, key_radius + 1):
				for key_z in range(-key_radius, key_radius + 1):
					var cluster_index := _cluster_index_at(
						data,
						base_key + Vector2i(key_x, key_z)
					)
					if cluster_index < 0 or cut_clusters.has(cluster_index):
						continue
					if (
						data.cluster_centers[cluster_index].distance_squared_to(
							world_position
						)
						<= cut_radius_squared
					):
						_cut_cluster(coord, cluster_index)
						return true
	return false


func _cluster_index_at(data: Variant, key: Vector2i) -> int:
	var local_key: Vector2i = key - data.cluster_grid_origin
	if (
		local_key.x < 0
		or local_key.y < 0
		or local_key.x >= data.cluster_grid_size.x
		or local_key.y >= data.cluster_grid_size.y
	):
		return -1
	return data.cluster_index_grid[
		local_key.y * data.cluster_grid_size.x + local_key.x
	]


func _cut_cluster(coord: Vector2i, cluster_index: int) -> void:
	var instance := _multimesh_by_cell.get(coord) as MultiMeshInstance3D
	var data: Variant = _data_by_cell.get(coord)
	if instance == null or data == null:
		return
	var cut_clusters: Dictionary = _cut_clusters_by_cell.get(coord, {})
	if cut_clusters.has(cluster_index):
		return
	for instance_index: int in data.cluster_instance_indices[cluster_index]:
		var transform: Transform3D = (
			instance.multimesh.get_instance_transform(instance_index)
		)
		transform.basis = transform.basis.scaled(Vector3.ONE * HIDDEN_SCALE)
		instance.multimesh.set_instance_transform(instance_index, transform)
	cut_clusters[cluster_index] = (
		DayNightManager.get_world_elapsed_seconds() + regrow_seconds
	)
	_cut_clusters_by_cell[coord] = cut_clusters
	set_process(true)


func _regrow_cluster(coord: Vector2i, cluster_index: int) -> void:
	var instance := _multimesh_by_cell.get(coord) as MultiMeshInstance3D
	var data: Variant = _data_by_cell.get(coord)
	if instance != null and data != null:
		for instance_index: int in data.cluster_instance_indices[cluster_index]:
			instance.multimesh.set_instance_transform(
				instance_index,
				GRASS_RUNTIME_BUILDER.transform_from_buffer(
					data.multimesh_buffer,
					instance_index
				)
			)
	var cut_clusters: Dictionary = _cut_clusters_by_cell.get(coord, {})
	cut_clusters.erase(cluster_index)
	if cut_clusters.is_empty():
		_cut_clusters_by_cell.erase(coord)


func _on_cell_unloaded(coord: Vector2i) -> void:
	_capture_active_cut_state(coord)
	_queued_roots.erase(coord)
	_prefetch_queue.erase(coord)
	_multimesh_by_cell.erase(coord)
	_data_by_cell.erase(coord)
	_cut_clusters_by_cell.erase(coord)


func _capture_active_cut_state(coord: Vector2i) -> void:
	var data: Variant = _data_by_cell.get(coord)
	# A logical cell can retire while its grass resource is still loading.
	# In that case there is no active state to snapshot, and the previously
	# saved cut records remain authoritative.
	if data == null:
		return
	var cut_clusters: Dictionary = _cut_clusters_by_cell.get(coord, {})
	if cut_clusters.is_empty():
		_saved_cut_state.erase(coord)
		return
	var records: Dictionary = {}
	var now := DayNightManager.get_world_elapsed_seconds()
	for cluster_index in cut_clusters:
		var key: Vector2i = data.cluster_keys[int(cluster_index)]
		records["%d,%d" % [key.x, key.y]] = {
			"remaining": maxf(
				0.0,
				float(cut_clusters[cluster_index]) - now
			),
			"captured_world_seconds": now,
		}
	_saved_cut_state[coord] = records


func _apply_saved_cut_state(coord: Vector2i) -> void:
	var records: Dictionary = _saved_cut_state.get(coord, {})
	var data: Variant = _data_by_cell.get(coord)
	if records.is_empty() or data == null:
		return
	var now := DayNightManager.get_world_elapsed_seconds()
	for key_string in records:
		var pieces := String(key_string).split(",")
		if pieces.size() != 2:
			continue
		var cluster_index := _cluster_index_at(
			data,
			Vector2i(int(pieces[0]), int(pieces[1]))
		)
		if cluster_index < 0:
			continue
		var record: Dictionary = records[key_string]
		var remaining := (
			float(record.get("remaining", 0.0))
			- maxf(
				0.0,
				now - float(record.get("captured_world_seconds", now))
			)
		)
		if remaining > 0.0:
			_cut_cluster(coord, cluster_index)
			var cut_clusters: Dictionary = _cut_clusters_by_cell[coord]
			cut_clusters[cluster_index] = now + remaining
	_saved_cut_state.erase(coord)


func get_save_data() -> Dictionary:
	for coord in _data_by_cell:
		_capture_active_cut_state(coord)
	var serialized: Dictionary = {}
	for coord in _saved_cut_state:
		serialized["%d,%d" % [coord.x, coord.y]] = _saved_cut_state[coord]
	return {"cells": serialized}


func load_save_data(data: Dictionary) -> void:
	var active_cells: Array = _cut_clusters_by_cell.keys()
	for coord_variant: Variant in active_cells:
		var coord: Vector2i = coord_variant
		var cut_clusters: Dictionary = _cut_clusters_by_cell[coord]
		var cluster_indices: Array = cut_clusters.keys()
		for cluster_index_variant: Variant in cluster_indices:
			_regrow_cluster(coord, int(cluster_index_variant))
	_saved_cut_state.clear()
	var serialized: Dictionary = data.get("cells", {})
	for coord_string in serialized:
		var pieces := String(coord_string).split(",")
		if pieces.size() == 2:
			_saved_cut_state[Vector2i(int(pieces[0]), int(pieces[1]))] = (
				serialized[coord_string]
			)
	for coord in _data_by_cell:
		_apply_saved_cut_state(coord)


func _on_world_shutdown() -> void:
	_queued_roots.clear()
	_prefetch_queue.clear()
	_loading_cells.clear()
	_prefetched_data.clear()
	_prefetch_lru.clear()
	_saved_cut_state.clear()
	_multimesh_by_cell.clear()
	_data_by_cell.clear()
	_cut_clusters_by_cell.clear()
	_regrow_poll_accumulator = 0.0
	set_process(false)
