extends RefCounted
class_name MeshUtils

## Small static helpers for combined mesh bounding boxes. Previously this
## logic was copy-pasted between player.gd and resource_node.gd — pulled
## out here so any future placeable/interactable can reuse it instead of
## re-implementing it a third time.


## Every MeshInstance3D found under `node`, recursively.
static func find_mesh_instances(node: Node) -> Array[MeshInstance3D]:
	var result: Array[MeshInstance3D] = []
	var pending: Array[Node] = [node]
	var index: int = 0
	while index < pending.size():
		var current: Node = pending[index]
		index += 1
		if current is MeshInstance3D:
			result.append(current)
		for child: Node in current.get_children():
			pending.append(child)
	return result


## World-space AABB of every MeshInstance3D/MultiMeshInstance3D under
## `node`, combined. Returns null if the node has no renderable meshes.
static func compute_world_aabb(node: Node3D) -> Variant:
	var combined: AABB = AABB()
	var found_mesh: bool = false
	var pending: Array[Node] = [node]
	var index: int = 0
	while index < pending.size():
		var current: Node = pending[index]
		index += 1
		var has_geometry: bool = false
		if current is MeshInstance3D:
			has_geometry = (current as MeshInstance3D).mesh != null
		elif current is MultiMeshInstance3D:
			var multimesh: MultiMesh = (
				(current as MultiMeshInstance3D).multimesh
			)
			has_geometry = (
				multimesh != null and multimesh.instance_count > 0
			)
		if has_geometry:
			var visual: VisualInstance3D = current as VisualInstance3D
			var world_aabb: AABB = (
				visual.global_transform * visual.get_aabb()
			)
			if not found_mesh:
				combined = world_aabb
				found_mesh = true
			else:
				combined = combined.merge(world_aabb)
		for child: Node in current.get_children():
			pending.append(child)
	if not found_mesh:
		return null
	return combined


## Combined AABB in `node`'s parent space without attaching the hierarchy
## to a live SceneTree. This is important for collision baking: temporary
## scene instances must not run scripts or register render/physics objects
## merely so their mesh bounds can be inspected.
static func compute_local_aabb(node: Node3D) -> Variant:
	var combined: AABB = AABB()
	var found_mesh: bool = false
	var pending_nodes: Array[Node] = [node]
	var pending_transforms: Array[Transform3D] = [node.transform]
	var index: int = 0
	while index < pending_nodes.size():
		var current: Node = pending_nodes[index]
		var current_transform: Transform3D = pending_transforms[index]
		index += 1

		var has_geometry: bool = false
		if current is MeshInstance3D:
			has_geometry = (current as MeshInstance3D).mesh != null
		elif current is MultiMeshInstance3D:
			var multimesh: MultiMesh = (
				(current as MultiMeshInstance3D).multimesh
			)
			has_geometry = (
				multimesh != null and multimesh.instance_count > 0
			)
		if has_geometry:
			var visual: VisualInstance3D = current as VisualInstance3D
			var local_aabb: AABB = current_transform * visual.get_aabb()
			if not found_mesh:
				combined = local_aabb
				found_mesh = true
			else:
				combined = combined.merge(local_aabb)

		for child: Node in current.get_children():
			var child_transform: Transform3D = current_transform
			if child is Node3D:
				var child_3d: Node3D = child
				child_transform = (
					child_3d.transform
					if child_3d.top_level
					else current_transform * child_3d.transform
				)
			pending_nodes.append(child)
			pending_transforms.append(child_transform)
	if not found_mesh:
		return null
	return combined
