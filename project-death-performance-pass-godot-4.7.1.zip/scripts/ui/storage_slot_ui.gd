extends PanelContainer
class_name StorageSlotUI

## A single storage-container slot widget — deliberately mirrors
## InventorySlotUI's structure (icon, count label, drag-and-drop) so the
## two feel identical and can be dragged into each other. See
## InventorySlotUI for the inventory-side half of that same drag contract
## (both sides tag their drag data with an "origin" key: "inventory" or
## "storage", and each accepts either).

var container: StorageContainer
var slot_index: int

var icon: TextureRect
var count_label: Label

static var style_normal: StyleBoxFlat
static var style_hover: StyleBoxFlat

var _is_hovered: bool = false


func _init() -> void:
	if style_normal == null:
		_build_shared_styles()

	mouse_filter = Control.MOUSE_FILTER_STOP
	add_theme_stylebox_override("panel", style_normal)

	var center := CenterContainer.new()
	add_child(center)

	icon = TextureRect.new()
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.custom_minimum_size = Vector2(34, 34)
	center.add_child(icon)

	count_label = Label.new()
	count_label.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	count_label.add_theme_font_size_override("font_size", 12)
	count_label.clip_text = true
	count_label.custom_minimum_size = Vector2.ZERO
	add_child(count_label)

	custom_minimum_size = Vector2(52, 52)

	mouse_entered.connect(_on_mouse_entered)
	mouse_exited.connect(_on_mouse_exited)


static func _build_shared_styles() -> void:
	style_normal = StyleBoxFlat.new()
	style_normal.bg_color = Color(0.1, 0.1, 0.1, 0.55)
	style_normal.set_border_width_all(2)
	style_normal.border_color = Color(1, 1, 1, 0.15)
	style_normal.set_corner_radius_all(4)

	style_hover = style_normal.duplicate()
	style_hover.border_color = Color(1, 1, 1, 0.85)


func setup(storage_container: StorageContainer, index: int) -> void:
	container = storage_container
	slot_index = index


func refresh() -> void:
	if container == null or slot_index >= container.slots.size():
		return
	var slot: Dictionary = container.slots[slot_index]
	var item_id: String = slot["item_id"]

	if item_id == "":
		icon.texture = null
		count_label.text = ""
		tooltip_text = ""
	else:
		var def: ItemData = InventoryManager.item_defs.get(item_id)
		icon.texture = def.icon if def else null
		var qty: int = slot["quantity"]
		count_label.text = str(qty) if qty > 1 else ""
		tooltip_text = def.display_name if def else item_id

	_update_style()


func _update_style() -> void:
	add_theme_stylebox_override("panel", style_hover if _is_hovered else style_normal)


func _on_mouse_entered() -> void:
	_is_hovered = true
	_update_style()


func _on_mouse_exited() -> void:
	_is_hovered = false
	_update_style()


## --- Click to withdraw (whole stack) ---

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and not event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if InventorySlotUI.held_item_id != "":
			_try_place_held_item()
			return
		if Input.is_key_pressed(KEY_SHIFT):
			_try_pick_up_half()
			return

		var slot: Dictionary = container.slots[slot_index]
		if slot["item_id"] != "":
			container.withdraw_slot_to_player(slot_index)
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_RIGHT:
		_open_context_menu()


## Picks up half of this slot's stack onto the shared cursor payload
## (InventorySlotUI.held_item_id/held_quantity — shared across both
## inventory and storage slots so an item can be carried between the two).
## The other half stays here. Click any valid slot afterward to place it.
func _try_pick_up_half() -> void:
	if InventorySlotUI.held_item_id != "":
		return  # already holding something
	var slot: Dictionary = container.slots[slot_index]
	var item_id: String = slot["item_id"]
	if item_id == "" or slot["quantity"] <= 1:
		return

	var half: int = slot["quantity"] / 2
	var remaining: int = slot["quantity"] - half
	container.place_in_slot(slot_index, item_id, remaining)
	InventorySlotUI.held_item_id = item_id
	InventorySlotUI.held_quantity = half


## Places whatever's currently held on the cursor into this slot — merges
## if empty/same item (respecting max_stack), swaps if a different item
## occupies it. Mirrors InventorySlotUI's version of this same action.
func _try_place_held_item() -> void:
	var held_item_id: String = InventorySlotUI.held_item_id
	var held_quantity: int = InventorySlotUI.held_quantity
	if held_item_id == "" or not container.accepts(held_item_id):
		return  # can't place here — stays held

	var slot: Dictionary = container.slots[slot_index]
	var existing_item_id: String = slot["item_id"]
	var existing_qty: int = slot["quantity"]

	if existing_item_id == "" or existing_item_id == held_item_id:
		var def: ItemData = InventoryManager.item_defs.get(held_item_id)
		var max_stack: int = def.max_stack if def else 99
		var space: int = max_stack - existing_qty
		var move_amount: int = mini(space, held_quantity)
		if move_amount <= 0:
			return  # full, nothing placed, still holding

		container.place_in_slot(slot_index, held_item_id, existing_qty + move_amount)
		InventorySlotUI.held_quantity -= move_amount
		if InventorySlotUI.held_quantity <= 0:
			InventorySlotUI.held_item_id = ""
			InventorySlotUI.held_quantity = 0
	else:
		container.place_in_slot(slot_index, held_item_id, held_quantity)
		InventorySlotUI.held_item_id = existing_item_id
		InventorySlotUI.held_quantity = existing_qty


## Same four-slot layout as InventorySlotUI's context menu: 1) primary
## action, 2) Split Stack, 3) Drop, 4) Cancel — "Drop" here means delete
## this stack from the chest entirely (there's no "drop in the world"
## mechanic anywhere in the game yet, so this matches what "Drop" already
## means for your own inventory: gone, not placed anywhere).
var _context_menu: PopupMenu

func _open_context_menu() -> void:
	var slot: Dictionary = container.slots[slot_index]
	if slot["item_id"] == "":
		return

	if _context_menu == null:
		_context_menu = PopupMenu.new()
		add_child(_context_menu)
		_context_menu.id_pressed.connect(_on_context_menu_id_pressed)

	_context_menu.clear()
	_context_menu.add_item("Move to Inventory", 0)
	_context_menu.add_item("Split Stack", 1)
	_context_menu.add_item("Drop", 2)
	_context_menu.add_item("Cancel", 3)

	_context_menu.position = get_viewport().get_mouse_position()  # viewport-local, not OS-global — DisplayServer coords broke under an embedded editor window
	_context_menu.popup()


func _on_context_menu_id_pressed(id: int) -> void:
	var slot: Dictionary = container.slots[slot_index]
	var item_id: String = slot["item_id"]
	if item_id == "":
		return

	match id:
		0:
			# Use the container's capacity-aware transaction. Removing the
			# stack first could lose anything the player inventory cannot fit.
			container.withdraw_slot_to_player(slot_index)
		1:
			container.split_slot(slot_index)
		2:
			container.take_from_slot(slot_index)
		3:
			pass  # Cancel


## --- Drag and drop — same contract as InventorySlotUI, see its header ---

func _get_drag_data(_at_position: Vector2) -> Variant:
	var slot: Dictionary = container.slots[slot_index]
	if slot["item_id"] == "":
		return null

	var preview := TextureRect.new()
	preview.texture = icon.texture
	preview.custom_minimum_size = icon.custom_minimum_size
	preview.modulate.a = 0.8
	set_drag_preview(preview)

	return {
		"origin": "storage",
		"container": container,
		"slot_index": slot_index,
		"item_id": slot["item_id"],
		"quantity": slot["quantity"],
	}


func _can_drop_data(_at_position: Vector2, data: Variant) -> bool:
	return typeof(data) == TYPE_DICTIONARY and data.has("origin")


func _drop_data(_at_position: Vector2, data: Variant) -> void:
	var origin: String = data.get("origin", "")

	if origin == "inventory":
		var from_type: InventorySlotManager.SlotType = data["slot_type"]
		var from_index: int = data["slot_index"]
		var from_slot := InventorySlotManager.get_slot(from_type, from_index)
		var incoming_item_id: String = from_slot["item_id"]
		var incoming_qty: int = from_slot["quantity"]
		if incoming_item_id == "" or not container.accepts(incoming_item_id):
			return

		var existing_item_id: String = container.slots[slot_index]["item_id"]
		if existing_item_id == "" or existing_item_id == incoming_item_id:
			var def: ItemData = InventoryManager.item_defs.get(incoming_item_id)
			var max_stack: int = def.max_stack if def else 99
			var existing_qty: int = container.slots[slot_index]["quantity"]
			var space: int = max_stack - existing_qty
			var move_amount: int = mini(space, incoming_qty)
			if move_amount <= 0:
				return  # this exact slot's stack is already full

			InventorySlotManager.take_from_slot_for_external(from_type, from_index)
			container.place_in_slot(slot_index, incoming_item_id, existing_qty + move_amount)

			var leftover: int = incoming_qty - move_amount
			if leftover > 0:
				InventorySlotManager.place_in_slot_from_external(from_type, from_index, incoming_item_id, leftover)
		else:
			# Genuinely different item — true swap, exact slots both sides.
			InventorySlotManager.take_from_slot_for_external(from_type, from_index)
			var displaced: Dictionary = container.place_in_slot(slot_index, incoming_item_id, incoming_qty)
			if displaced["item_id"] != "":
				InventorySlotManager.place_in_slot_from_external(from_type, from_index, displaced["item_id"], displaced["quantity"])

	elif origin == "storage":
		var from_container: StorageContainer = data["container"]
		var from_slot_index: int = data["slot_index"]
		if from_container != container:
			return  # cross-container drag — no scenario for two open containers at once yet, safe no-op rather than risking data loss
		if from_slot_index == slot_index:
			return  # dropped on itself

		var this_slot: Dictionary = container.slots[slot_index]
		var other_slot: Dictionary = container.slots[from_slot_index]

		if this_slot["item_id"] == "" or this_slot["item_id"] == other_slot["item_id"]:
			# Empty destination or same item — merge (respecting max_stack),
			# same as every other drag path already does. This was the
			# actual bug: this branch used to swap unconditionally, so two
			# same-item stacks just traded places instead of combining.
			var def: ItemData = InventoryManager.item_defs.get(other_slot["item_id"])
			var max_stack: int = def.max_stack if def else 99
			var space: int = max_stack - this_slot["quantity"]
			var move_amount: int = mini(space, other_slot["quantity"])
			if move_amount <= 0:
				return
			container.place_in_slot(slot_index, other_slot["item_id"], this_slot["quantity"] + move_amount)
			var leftover: int = other_slot["quantity"] - move_amount
			container.place_in_slot(from_slot_index, other_slot["item_id"] if leftover > 0 else "", leftover)
		else:
			# Genuinely different items — swap, exact positions both sides.
			container.place_in_slot(slot_index, other_slot["item_id"], other_slot["quantity"])
			container.place_in_slot(from_slot_index, this_slot["item_id"], this_slot["quantity"])
