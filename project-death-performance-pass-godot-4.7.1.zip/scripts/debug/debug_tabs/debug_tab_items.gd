extends Control
class_name DebugTabItems

## DEBUG TAB — "Items". Lists every registered item (name + id) with a
## quantity field and an Add button per row, for quickly spawning items
## into your inventory for testing.
##
## This is the original DebugItemSpawner panel body, unchanged in
## behavior, just repackaged as one tab inside DebugMenu (see
## scripts/debug/debug_menu.gd) instead of owning its own top-level panel
## and F1 handling.

var search_box: LineEdit
var quantity_box: SpinBox
var list_container: VBoxContainer
var _status_label: Label
var _page_label: Label
var _all_entries: Array[Dictionary] = []
var _filtered_entries: Array[Dictionary] = []
var row_nodes: Array[Control] = []
var _page_index: int = 0
var _catalog_indexed: bool = false
var _indexed_item_def_count: int = -1
var _indexed_item_def_signature: int = 0

const PAGE_SIZE: int = 100


func _ready() -> void:
	_build_ui()


## Called by DebugMenu each time this tab becomes visible. The count check
## handles the normal add/remove case in O(1); the lightweight signature
## also catches a same-size key/resource replacement without rebuilding
## the 100-row page when the catalog is unchanged.
func on_tab_shown() -> void:
	if not _catalog_indexed:
		_populate_list()
		return
	var current_count: int = InventoryManager.item_defs.size()
	if (
		current_count != _indexed_item_def_count
		or _item_defs_signature() != _indexed_item_def_signature
	):
		_populate_list()


func _build_ui() -> void:
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	custom_minimum_size = Vector2(560, 520)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(vbox)

	var controls_row := HBoxContainer.new()
	controls_row.add_theme_constant_override("separation", 8)
	vbox.add_child(controls_row)

	search_box = LineEdit.new()
	search_box.placeholder_text = "Search by name or id..."
	search_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	search_box.text_changed.connect(_on_search_changed)
	controls_row.add_child(search_box)

	var qty_label := Label.new()
	qty_label.text = "Qty:"
	controls_row.add_child(qty_label)

	quantity_box = SpinBox.new()
	quantity_box.min_value = 1
	quantity_box.max_value = 9999
	quantity_box.value = 1
	quantity_box.custom_minimum_size = Vector2(80, 0)
	controls_row.add_child(quantity_box)

	var previous_button := Button.new()
	previous_button.text = "◀"
	previous_button.tooltip_text = "Previous page"
	previous_button.pressed.connect(_change_page.bind(-1))
	controls_row.add_child(previous_button)

	_page_label = Label.new()
	_page_label.custom_minimum_size = Vector2(72, 0)
	_page_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	controls_row.add_child(_page_label)

	var next_button := Button.new()
	next_button.text = "▶"
	next_button.tooltip_text = "Next page"
	next_button.pressed.connect(_change_page.bind(1))
	controls_row.add_child(next_button)

	vbox.add_child(HSeparator.new())

	_status_label = Label.new()
	_status_label.text = "Loading item list..."
	vbox.add_child(_status_label)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.custom_minimum_size = Vector2(0, 380)
	vbox.add_child(scroll)

	list_container = VBoxContainer.new()
	list_container.add_theme_constant_override("separation", 2)
	list_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(list_container)


func _populate_list() -> void:
	_clear_visible_rows()
	_all_entries.clear()
	_filtered_entries.clear()

	# Defensive check — if this ever prints 0, the item list is genuinely
	# empty at InventoryManager (autoload ordering / item_defs not loaded
	# yet), which is a different problem than a UI/layout bug and would
	# show up here in the Output panel rather than as a silent blank tab.
	if InventoryManager == null or InventoryManager.item_defs == null:
		_catalog_indexed = false
		_status_label.text = "ERROR: InventoryManager or item_defs unavailable — check autoload order in Project Settings."
		push_error("DebugTabItems: InventoryManager.item_defs unavailable.")
		return

	_indexed_item_def_count = InventoryManager.item_defs.size()
	_indexed_item_def_signature = _item_defs_signature()
	_catalog_indexed = true

	var ids: Array = InventoryManager.item_defs.keys()
	ids.sort()

	if ids.is_empty():
		_status_label.text = "InventoryManager.item_defs is empty (0 registered items) — nothing to list."
		push_warning("DebugTabItems: InventoryManager.item_defs is empty.")
		return

	for item_id: String in ids:
		var def: ItemData = InventoryManager.item_defs[item_id]
		if def == null:
			push_warning("DebugTabItems: item_defs['%s'] is null, skipping." % item_id)
			continue
		_all_entries.append({
			"item_id": item_id,
			"display_name": def.display_name,
			"icon": def.icon,
			"search_text": (def.display_name + " " + item_id).to_lower(),
		})

	_apply_filter(search_box.text)
	print("DebugTabItems: indexed %d items." % _all_entries.size())


func _item_defs_signature() -> int:
	var signature: int = InventoryManager.item_defs.size()
	for item_id: Variant in InventoryManager.item_defs:
		# Hashing each id/resource pair is order-independent at the outer
		# level and observes replacements even when the dictionary size and
		# key set stay the same. Resource hashing is identity-based, so this
		# does not walk or reload the underlying item assets.
		var entry_signature: int = hash(
			[item_id, InventoryManager.item_defs[item_id]]
		)
		signature = signature ^ entry_signature
	return signature


func _clear_visible_rows() -> void:
	for row: Control in row_nodes:
		if is_instance_valid(row):
			row.free()
	row_nodes.clear()


func _apply_filter(text: String) -> void:
	var query := text.strip_edges().to_lower()
	_filtered_entries.clear()
	for entry: Dictionary in _all_entries:
		if query == "" or String(entry["search_text"]).contains(query):
			_filtered_entries.append(entry)
	_page_index = 0
	_render_page()


func _render_page() -> void:
	_clear_visible_rows()
	var page_count := maxi(
		1,
		ceili(float(_filtered_entries.size()) / float(PAGE_SIZE))
	)
	_page_index = clampi(_page_index, 0, page_count - 1)
	var first_index := _page_index * PAGE_SIZE
	var last_index := mini(first_index + PAGE_SIZE, _filtered_entries.size())
	for index in range(first_index, last_index):
		_create_item_row(_filtered_entries[index])

	_page_label.text = "%d / %d" % [_page_index + 1, page_count]
	_status_label.text = (
		"Showing %d–%d of %d matching items."
		% [
			0 if _filtered_entries.is_empty() else first_index + 1,
			last_index,
			_filtered_entries.size(),
		]
	)


func _create_item_row(entry: Dictionary) -> void:
	var item_id: String = entry["item_id"]
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	row.custom_minimum_size = Vector2(0, 36)
	list_container.add_child(row)

	var icon_rect := TextureRect.new()
	icon_rect.custom_minimum_size = Vector2(32, 32)
	icon_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon_rect.texture = entry["icon"]
	row.add_child(icon_rect)

	var label := Label.new()
	label.text = "%s  (%s)" % [entry["display_name"], item_id]
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.clip_text = true
	row.add_child(label)

	var add_btn := Button.new()
	add_btn.text = "Add"
	add_btn.pressed.connect(_add_item.bind(item_id))
	row.add_child(add_btn)

	row_nodes.append(row)


func _add_item(item_id: String) -> void:
	var qty := int(quantity_box.value)
	InventoryManager.add_item(item_id, qty)
	print("Debug spawned %d x %s" % [qty, item_id])


func _on_search_changed(text: String) -> void:
	_apply_filter(text)


func _change_page(offset: int) -> void:
	_page_index += offset
	_render_page()
