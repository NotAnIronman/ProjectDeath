extends Node

## AUTOLOAD — register in Project Settings > Globals, name it "InventorySlotManager".
## Register it AFTER InventoryManager in the Globals list (it reads from
## InventoryManager on sync).
##
## Owns the POSITIONAL layout of items into fixed hotbar/inventory slots.
## InventoryManager remains the source of truth for total item counts —
## this layer just decides which slot each unit of an item visually sits
## in, and lets the player drag items between slots freely.
##
## Sync philosophy: when total counts change (item picked up / consumed),
## this reconciles slot contents to match — but never reshuffles items the
## player has already manually arranged. New quantity fills existing
## matching stacks first, then empty slots. Removed quantity comes out of
## existing stacks, emptying slots as needed.

const HOTBAR_SIZE: int = 7
const MAIN_SIZE: int = 28
const DEFAULT_MAX_STACK: int = 99

enum SlotType { HOTBAR, MAIN }

signal slot_changed(slot_type: SlotType, index: int)
## Emitted after a bulk layout replacement (sort/load). Listeners should
## rebuild once instead of doing one redraw for every slot.
signal slots_rebuilt()
signal selection_changed(index: int)

var hotbar_slots: Array[Dictionary] = []
var main_slots: Array[Dictionary] = []
var selected_hotbar_index: int = 0
var _suppress_sync: bool = false


func _ready() -> void:
	for i in HOTBAR_SIZE:
		hotbar_slots.append(_empty_slot())
	for i in MAIN_SIZE:
		main_slots.append(_empty_slot())

	InventoryManager.item_added.connect(_on_item_added)
	InventoryManager.item_removed.connect(_on_item_removed)


func _empty_slot() -> Dictionary:
	return {"item_id": "", "quantity": 0}


func _get_max_stack(item_id: String) -> int:
	var def: ItemData = InventoryManager.item_defs.get(item_id)
	return def.max_stack if def else DEFAULT_MAX_STACK


func get_slot(slot_type: SlotType, index: int) -> Dictionary:
	var arr := hotbar_slots if slot_type == SlotType.HOTBAR else main_slots
	if index < 0 or index >= arr.size():
		return _empty_slot()
	return arr[index]


func get_add_capacity(item_id: String) -> int:
	var capacity := 0
	var max_stack := _get_max_stack(item_id)
	for arr in [hotbar_slots, main_slots]:
		for slot in arr:
			if slot["item_id"] == "":
				capacity += max_stack
			elif slot["item_id"] == item_id:
				capacity += maxi(0, max_stack - int(slot["quantity"]))
	return capacity


func can_accept_batch(items: Dictionary) -> bool:
	var simulated: Array[Dictionary] = []
	for slot in hotbar_slots:
		simulated.append(slot.duplicate())
	for slot in main_slots:
		simulated.append(slot.duplicate())
	for item_id in items:
		var remaining := int(items[item_id])
		if remaining <= 0:
			continue
		var max_stack := _get_max_stack(item_id)
		for slot in simulated:
			if slot["item_id"] == item_id:
				var add := mini(remaining, maxi(0, max_stack - int(slot["quantity"])))
				slot["quantity"] += add
				remaining -= add
		for slot in simulated:
			if remaining <= 0:
				break
			if slot["item_id"] == "":
				var add := mini(remaining, max_stack)
				slot["item_id"] = item_id
				slot["quantity"] = add
				remaining -= add
		if remaining > 0:
			return false
	return true


## --- Reconciliation with InventoryManager's totals ---

func _on_item_added(item_id: String, amount: int, _new_total: int) -> void:
	if _suppress_sync:
		return  # an exact-slot external placement already handled this — see place_in_slot_from_external
	var remaining := amount
	var max_stack := _get_max_stack(item_id)

	# Fill existing matching stacks first (hotbar, then main).
	remaining = _fill_existing_stacks(hotbar_slots, SlotType.HOTBAR, item_id, remaining, max_stack)
	remaining = _fill_existing_stacks(main_slots, SlotType.MAIN, item_id, remaining, max_stack)

	# Then spill into empty slots (hotbar first, then main).
	remaining = _fill_empty_slots(hotbar_slots, SlotType.HOTBAR, item_id, remaining, max_stack)
	remaining = _fill_empty_slots(main_slots, SlotType.MAIN, item_id, remaining, max_stack)

	if remaining > 0:
		push_warning("InventorySlotManager: no room for %d more of '%s' — inventory full." % [remaining, item_id])


func _fill_existing_stacks(arr: Array[Dictionary], slot_type: SlotType, item_id: String, remaining: int, max_stack: int) -> int:
	for i in arr.size():
		if remaining <= 0:
			break
		if arr[i]["item_id"] == item_id and arr[i]["quantity"] < max_stack:
			var space: int = max_stack - arr[i]["quantity"]
			var add: int = min(space, remaining)
			arr[i]["quantity"] += add
			remaining -= add
			slot_changed.emit(slot_type, i)
	return remaining


func _fill_empty_slots(arr: Array[Dictionary], slot_type: SlotType, item_id: String, remaining: int, max_stack: int) -> int:
	for i in arr.size():
		if remaining <= 0:
			break
		if arr[i]["item_id"] == "":
			var add: int = min(max_stack, remaining)
			arr[i]["item_id"] = item_id
			arr[i]["quantity"] = add
			remaining -= add
			slot_changed.emit(slot_type, i)
	return remaining


func _on_item_removed(item_id: String, amount: int, _new_total: int) -> void:
	if _suppress_sync:
		return  # discard_from_slot already handled this slot directly
	var remaining := amount
	remaining = _remove_from_slots(hotbar_slots, SlotType.HOTBAR, item_id, remaining)
	remaining = _remove_from_slots(main_slots, SlotType.MAIN, item_id, remaining)
	if remaining > 0:
		push_warning("InventorySlotManager: tried to remove more '%s' than slots contained." % item_id)


func _remove_from_slots(arr: Array[Dictionary], slot_type: SlotType, item_id: String, remaining: int) -> int:
	for i in arr.size():
		if remaining <= 0:
			break
		if arr[i]["item_id"] == item_id:
			var take: int = min(arr[i]["quantity"], remaining)
			arr[i]["quantity"] -= take
			remaining -= take
			if arr[i]["quantity"] <= 0:
				arr[i] = _empty_slot()
			slot_changed.emit(slot_type, i)
	return remaining


## --- Manual drag-and-drop moves, called by InventorySlotUI ---

## Moves/merges/swaps contents between two slots (can be hotbar<->hotbar,
## main<->main, or hotbar<->main in any combination).
func move_item(from_type: SlotType, from_index: int, to_type: SlotType, to_index: int) -> void:
	var from_arr := hotbar_slots if from_type == SlotType.HOTBAR else main_slots
	var to_arr := hotbar_slots if to_type == SlotType.HOTBAR else main_slots

	if from_type == to_type and from_index == to_index:
		return  # dropped on itself, no-op

	var from_slot: Dictionary = from_arr[from_index]
	var to_slot: Dictionary = to_arr[to_index]

	if from_slot["item_id"] == "":
		return  # nothing to move

	if to_slot["item_id"] == "":
		# Empty destination — simple move.
		to_arr[to_index] = from_slot
		from_arr[from_index] = _empty_slot()

	elif to_slot["item_id"] == from_slot["item_id"]:
		# Same item — merge stacks, overflow stays in the source slot.
		var max_stack := _get_max_stack(from_slot["item_id"])
		var space: int = max_stack - to_slot["quantity"]
		var move_amount: int = min(space, from_slot["quantity"])
		to_arr[to_index]["quantity"] += move_amount
		from_arr[from_index]["quantity"] -= move_amount
		if from_arr[from_index]["quantity"] <= 0:
			from_arr[from_index] = _empty_slot()

	else:
		# Different items — swap.
		from_arr[from_index] = to_slot
		to_arr[to_index] = from_slot

	slot_changed.emit(from_type, from_index)
	slot_changed.emit(to_type, to_index)


## --- Exact-slot placement for EXTERNAL systems (e.g. StorageContainer) ---
## Everything above this point auto-distributes (fills matching stacks,
## then first empty slot) — correct for normal pickups, but wrong for
## drag-and-drop swaps where the specific slot matters (dragging a
## storage item onto an occupied inventory slot should swap with THAT
## slot, not land wherever the normal fill logic happens to put it).
## These bypass auto-distribution and use the same _suppress_sync pattern
## discard_from_slot already established, just for placement instead of
## just removal.

## Places item_id/quantity directly into slot [slot_type][index],
## replacing whatever was there. Returns the displaced {item_id,quantity}
## (quantity 0 if it was empty). Keeps InventoryManager's totals correct.
func place_in_slot_from_external(slot_type: SlotType, index: int, item_id: String, quantity: int) -> Dictionary:
	var arr := hotbar_slots if slot_type == SlotType.HOTBAR else main_slots
	if index < 0 or index >= arr.size() or quantity < 0:
		return _empty_slot()
	var displaced: Dictionary = arr[index].duplicate()

	_suppress_sync = true
	if displaced["item_id"] != "":
		InventoryManager.apply_slot_delta(displaced["item_id"], -int(displaced["quantity"]))
	arr[index] = {"item_id": item_id if quantity > 0 else "", "quantity": quantity}
	if item_id != "" and quantity > 0:
		InventoryManager.apply_slot_delta(item_id, quantity)
	_suppress_sync = false

	slot_changed.emit(slot_type, index)
	return displaced


## Clears slot [slot_type][index] entirely and returns what was there —
## the withdrawal half of the same exact-slot contract as
## place_in_slot_from_external above.
func take_from_slot_for_external(slot_type: SlotType, index: int) -> Dictionary:
	var arr := hotbar_slots if slot_type == SlotType.HOTBAR else main_slots
	var taken: Dictionary = arr[index].duplicate()
	if taken["item_id"] != "":
		_suppress_sync = true
		InventoryManager.apply_slot_delta(taken["item_id"], -int(taken["quantity"]))
		_suppress_sync = false
		arr[index] = _empty_slot()
		slot_changed.emit(slot_type, index)
	return taken


## --- Hotbar selection (scroll wheel) ---

func select_hotbar_index(index: int) -> void:
	var next_index: int = clampi(index, 0, HOTBAR_SIZE - 1)
	if next_index == selected_hotbar_index:
		return
	selected_hotbar_index = next_index
	selection_changed.emit(selected_hotbar_index)


func cycle_hotbar_selection(direction: int) -> void:
	# Moves through ALL slots by strict index, including empty ones — this
	# is intentional: the player should be able to scroll to an empty slot
	# and have empty hands, e.g. before entering pickup mode.
	var next_index := (selected_hotbar_index + direction) % HOTBAR_SIZE
	if next_index < 0:
		next_index += HOTBAR_SIZE
	select_hotbar_index(next_index)


func get_selected_hotbar_item_id() -> String:
	return hotbar_slots[selected_hotbar_index]["item_id"]


## Discards everything in a specific slot directly — used by right-click
## discard in the inventory UI. NOTE: no confirmation dialog (intentional
## for now, since this is primarily a debug/testing convenience while the
## game doesn't have real item scarcity yet) — add a confirmation prompt
## before shipping, once the debugger/spawner tools are gone and losing
## an item actually matters to the player.
func discard_from_slot(slot_type: SlotType, index: int) -> void:
	var arr := hotbar_slots if slot_type == SlotType.HOTBAR else main_slots
	var slot: Dictionary = arr[index]
	var item_id: String = slot["item_id"]
	var quantity: int = slot["quantity"]
	if item_id == "":
		return

	arr[index] = _empty_slot()
	slot_changed.emit(slot_type, index)

	# Suppress the normal auto-sync while adjusting InventoryManager's
	# total, since we've already cleared this EXACT slot directly — without
	# this guard, the sync handler would also remove `quantity` from
	# whichever slots it finds first, potentially hitting a different
	# stack of the same item than the one the player actually discarded.
	_suppress_sync = true
	InventoryManager.remove_item(item_id, quantity)
	_suppress_sync = false


## Sorts your MAIN inventory alphabetically by display name, empties
## pushed to the end — same approach as StorageContainer.sort_slots().
## Hotbar is deliberately left untouched: reordering it would break your
## muscle memory for which number selects what, which sorting your
## backpack shouldn't cost you. Pure reordering of existing slot
## contents — total counts never change, so this doesn't need any
## InventoryManager interaction at all, unlike most other slot operations.
## Splits slot [slot_type][index] roughly in half (the original slot keeps
## the remainder on an odd count), placing the split-off portion into the
## first empty slot found — hotbar checked first, then main. No-op if
## there's no empty slot anywhere to split into, or the stack only has 1
## item (nothing meaningful to split). Pure reordering of existing
## quantities, same as sort_main_slots() — total counts never change, so
## this needs no InventoryManager interaction at all.
func split_slot(slot_type: SlotType, index: int) -> void:
	var arr := hotbar_slots if slot_type == SlotType.HOTBAR else main_slots
	var slot: Dictionary = arr[index]
	var item_id: String = slot["item_id"]
	var quantity: int = slot["quantity"]
	if item_id == "" or quantity <= 1:
		return

	var split_amount: int = quantity / 2
	var remaining: int = quantity - split_amount

	for check_type in [SlotType.HOTBAR, SlotType.MAIN]:
		var check_arr := hotbar_slots if check_type == SlotType.HOTBAR else main_slots
		for i in check_arr.size():
			if check_type == slot_type and i == index:
				continue
			if check_arr[i]["item_id"] == "":
				arr[index] = {"item_id": item_id, "quantity": remaining}
				check_arr[i] = {"item_id": item_id, "quantity": split_amount}
				slot_changed.emit(slot_type, index)
				slot_changed.emit(check_type, i)
				return
	# No empty slot anywhere — nothing to do, original slot untouched.


func sort_main_slots() -> void:
	var non_empty: Array[Dictionary] = []
	for slot in main_slots:
		if slot["item_id"] != "":
			non_empty.append(slot)

	non_empty.sort_custom(func(a, b):
		var def_a: ItemData = InventoryManager.item_defs.get(a["item_id"])
		var def_b: ItemData = InventoryManager.item_defs.get(b["item_id"])
		var name_a: String = def_a.display_name if def_a else a["item_id"]
		var name_b: String = def_b.display_name if def_b else b["item_id"]
		return name_a < name_b
	)

	var empty_count: int = main_slots.size() - non_empty.size()
	main_slots.clear()
	main_slots.append_array(non_empty)
	for i in empty_count:
		main_slots.append(_empty_slot())

	slots_rebuilt.emit()


## --- Save/Load ---

func get_save_data() -> Dictionary:
	return {
		"hotbar_slots": hotbar_slots,
		"main_slots": main_slots,
		"selected_hotbar_index": selected_hotbar_index
	}


func load_save_data(data: Dictionary) -> void:
	var previous_selection: int = selected_hotbar_index
	hotbar_slots = _normalized_slots(data.get("hotbar_slots", []), HOTBAR_SIZE)
	main_slots = _normalized_slots(data.get("main_slots", []), MAIN_SIZE)
	selected_hotbar_index = clampi(int(data.get("selected_hotbar_index", 0)), 0, HOTBAR_SIZE - 1)
	rebuild_totals_from_slots()
	slots_rebuilt.emit()
	if selected_hotbar_index != previous_selection:
		selection_changed.emit(selected_hotbar_index)


func _normalized_slots(saved: Array, required_size: int) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for index in required_size:
		if index >= saved.size():
			result.append(_empty_slot())
			continue
		var entry: Dictionary = saved[index]
		var item_id: String = entry.get("item_id", "")
		var quantity: int = maxi(0, int(entry.get("quantity", 0)))
		if item_id == "" or quantity == 0 or not InventoryManager.item_defs.has(item_id):
			result.append(_empty_slot())
		else:
			result.append({"item_id": item_id, "quantity": mini(quantity, _get_max_stack(item_id))})
	return result


func rebuild_totals_from_slots() -> void:
	for item_id in InventoryManager.item_defs:
		InventoryManager.item_counts[item_id] = 0
	for arr in [hotbar_slots, main_slots]:
		for slot in arr:
			if slot["item_id"] != "":
				InventoryManager.item_counts[slot["item_id"]] = InventoryManager.get_count(slot["item_id"]) + int(slot["quantity"])
