extends Node

## Streams non-terrain world content around the player.
##
## Persistent data is authoritative. Loaded cell roots are temporary
## presentation and may be discarded at any time without losing state.

signal cell_loaded(cell_coord: Vector2i, cell_root: Node)
signal cell_content_ready(cell_coord: Vector2i, cell_root: Node)
signal cell_unloaded(cell_coord: Vector2i)
## INVALID_CELL_COORD -> current is emitted once when a gameplay world is
## entered. Subsequent emissions are real player cell-boundary crossings.
## Resource prefetching never emits this signal.
signal player_cell_changed(old_coord: Vector2i, new_coord: Vector2i)
## Emitted once when a coordinate newly enters the bounded predictive
## neighborhood. This is only a resource-warm hint: no logical cell exists,
## no gameplay state is applied, and cell_loaded is not emitted.
signal cell_prefetch_requested(cell_coord: Vector2i)
signal world_ready()
signal world_shutdown()

const CELL_SIZE := 100.0
const LOAD_RADIUS_CELLS := 1
const UNLOAD_RADIUS_CELLS := 2
const CELLS_PATH := "res://scenes/world/cells/"
const MAX_CONCURRENT_LOADS := 2
const MAX_INSTANTIATIONS_PER_FRAME := 1
const MAX_RETIREMENTS_PER_FRAME := 1
const MAX_ACTIVATION_BUDGET_MS := 2.0
const PREFETCH_LOOKAHEAD_SECONDS := 1.75
const MAX_PREFETCH_COORDS := 16
const MAX_PACKED_SCENE_CACHE_SIZE := 16
const INVALID_CELL_COORD := Vector2i(2147483647, 2147483647)

var load_radius_cells: int = LOAD_RADIUS_CELLS
var unload_radius_cells: int = UNLOAD_RADIUS_CELLS
var debug_overlay_enabled: bool = false

## Vector2i -> logical Node3D root. A root exists even when the cell has no
## authored scene, allowing grass/ambient systems to stream independently.
var _active_cells: Dictionary = {}
## Vector2i -> state records captured when the cell was last unloaded.
var _cell_state: Dictionary = {}
## Vector2i -> scene path discovered once at world initialization.
var _scene_paths: Dictionary = {}
var _load_queue: Array[Vector2i] = []
var _threaded_loads: Dictionary = {} # Vector2i -> scene path
var _activation_queue: Array[Vector2i] = []
var _retirement_queue: Array[Vector2i] = []
var _packed_scene_cache: Dictionary = {} # Vector2i -> PackedScene
var _scene_cache_recency: Dictionary = {} # Vector2i -> monotonically increasing serial
var _scene_cache_serial: int = 0
var _desired_cells: Dictionary = {}
var _predictive_prefetch_cells: Dictionary = {}
var _destination_prefetch_cells: Dictionary = {}
var _prefetch_cells: Dictionary = {}
var _prefetch_center: Vector2i = INVALID_CELL_COORD
var _destination_prefetch_center: Vector2i = INVALID_CELL_COORD
var _legacy_state_by_id: Dictionary = {}
var _content_ready_cells: Dictionary = {}
## Cells whose authored content has existed long enough for persistent state
## to be applied. A cell unloaded while its resource is still in flight must
## not overwrite authoritative save data with a snapshot of an empty root.
var _state_applied_cells: Dictionary = {}
var _pending_cell_layers: Dictionary = {}
var _cell_node_estimates: Dictionary = {}
var _streamed_node_count_estimate: int = 0
var _streaming_stable_seconds: float = 0.0

var _player: Node3D = null
var _cells_root: Node3D = null
var _current_cell: Vector2i = INVALID_CELL_COORD
var _session_ready := false
var _streaming_active := false
var _debug_overlay: MeshInstance3D = null
var _debug_overlay_cell: Vector2i = INVALID_CELL_COORD
var _debug_overlay_radius := -1


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	call_deferred("_connect_world_signals")


func _connect_world_signals() -> void:
	if not DayNightManager.day_started.is_connected(_on_unloaded_day_started):
		DayNightManager.day_started.connect(_on_unloaded_day_started)


func reinitialize() -> void:
	# This state is immediately discarded below, so do not spend a frame
	# recursively serializing every outgoing cell first.
	shutdown_world(false)
	_cell_state.clear()
	_legacy_state_by_id.clear()
	_player = get_tree().get_first_node_in_group("player") as Node3D
	if _player == null or get_tree().current_scene == null:
		push_warning("WorldManager: no active gameplay player; streaming remains disabled.")
		return

	_discover_cell_scenes()
	_cells_root = Node3D.new()
	_cells_root.name = "StreamedCells"
	get_tree().current_scene.add_child(_cells_root)
	_current_cell = world_to_cell(_player.global_position)
	_streaming_active = true
	_refresh_desired_cells(_current_cell)
	# A world entry is the one intentional INVALID -> current transition.
	# It is emitted only after the real logical neighborhood has been queued.
	player_cell_changed.emit(INVALID_CELL_COORD, _current_cell)
	_check_initial_neighborhood_ready()


func shutdown_world(capture_state: bool = true) -> void:
	_session_ready = false
	_streaming_active = false
	_clear_debug_overlay()
	_load_queue.clear()
	_threaded_loads.clear()
	_activation_queue.clear()
	_retirement_queue.clear()
	_desired_cells.clear()
	_predictive_prefetch_cells.clear()
	_destination_prefetch_cells.clear()
	_prefetch_cells.clear()
	_prefetch_center = INVALID_CELL_COORD
	_destination_prefetch_center = INVALID_CELL_COORD
	_content_ready_cells.clear()
	_pending_cell_layers.clear()
	for coord: Vector2i in _active_cells.keys().duplicate():
		_unload_cell(coord, capture_state)
	_active_cells.clear()
	_state_applied_cells.clear()
	_packed_scene_cache.clear()
	_scene_cache_recency.clear()
	_scene_cache_serial = 0
	_cell_node_estimates.clear()
	_streamed_node_count_estimate = 0
	_streaming_stable_seconds = 0.0
	if is_instance_valid(_cells_root):
		_cells_root.queue_free()
	_cells_root = null
	_player = null
	_current_cell = INVALID_CELL_COORD
	world_shutdown.emit()


func is_world_ready() -> bool:
	return _session_ready and is_instance_valid(_player) and is_instance_valid(_cells_root)


func get_current_cell() -> Vector2i:
	return _current_cell


func get_player() -> Node3D:
	return _player if is_instance_valid(_player) else null


func is_streaming_busy() -> bool:
	if not _streaming_active:
		return false
	return (
		not _session_ready
		or not _load_queue.is_empty()
		or not _threaded_loads.is_empty()
		or not _activation_queue.is_empty()
		or not _retirement_queue.is_empty()
		or not _pending_cell_layers.is_empty()
	)


func is_streaming_stable(minimum_seconds: float = 0.5) -> bool:
	return not is_streaming_busy() and _streaming_stable_seconds >= maxf(0.0, minimum_seconds)


func get_streaming_stable_seconds() -> float:
	return _streaming_stable_seconds


func is_cell_prefetch_target(coord: Vector2i) -> bool:
	return _prefetch_cells.has(coord)


func is_destination_prefetch_target(coord: Vector2i) -> bool:
	return _destination_prefetch_cells.has(coord)


## Warms the destination neighborhood without creating logical cells or
## emitting gameplay load signals. Repeated calls are deduplicated. The
## return value covers authored PackedScenes; cell-layer systems receive the
## same prefetch hint and may finish their own resource work independently.
func prepare_destination(center: Vector2i) -> bool:
	if not _streaming_active:
		return false
	if center != _destination_prefetch_center:
		_destination_prefetch_center = center
		_destination_prefetch_cells.clear()
		for coord: Vector2i in _get_destination_prefetch_coords(center):
			_destination_prefetch_cells[coord] = true
	_rebuild_prefetch_targets()
	_poll_threaded_loads()
	_start_queued_loads()
	return is_destination_prepared(center)


func is_destination_prepared(center: Vector2i) -> bool:
	for coord: Vector2i in _get_destination_prefetch_coords(center):
		if not _scene_paths.has(coord):
			continue
		if _active_cells.has(coord):
			if not _content_ready_cells.has(coord):
				return false
		elif not _packed_scene_cache.has(coord):
			return false
	return true


func _get_destination_prefetch_coords(center: Vector2i) -> Array[Vector2i]:
	var candidates: Array[Vector2i] = []
	var radius: int = maxi(0, load_radius_cells)
	for dx in range(-radius, radius + 1):
		for dz in range(-radius, radius + 1):
			candidates.append(center + Vector2i(dx, dz))
	candidates.sort_custom(func(a: Vector2i, b: Vector2i) -> bool:
		return _cell_distance(a, center) < _cell_distance(b, center)
	)
	candidates.resize(mini(MAX_PREFETCH_COORDS, candidates.size()))
	return candidates


func clear_prepared_destination() -> void:
	if _destination_prefetch_cells.is_empty():
		return
	# Fast travel moves the player before WorldManager's next process tick.
	# Keep the warm cache protected across that one-frame handoff; the
	# boundary refresh clears it after destination logical roots exist.
	if is_instance_valid(_player):
		var observed_cell: Vector2i = world_to_cell(_player.global_position)
		if (
			observed_cell == _destination_prefetch_center
			and _current_cell != _destination_prefetch_center
		):
			return
	_destination_prefetch_cells.clear()
	_destination_prefetch_center = INVALID_CELL_COORD
	_rebuild_prefetch_targets()


func refresh_streaming_neighborhood() -> void:
	if not _streaming_active or not is_instance_valid(_player) or not is_instance_valid(_cells_root):
		return
	load_radius_cells = maxi(0, load_radius_cells)
	unload_radius_cells = maxi(load_radius_cells, unload_radius_cells)
	_refresh_desired_cells(_current_cell)
	refresh_debug_overlay()


func force_reload_all_cells() -> void:
	if not _streaming_active or not is_instance_valid(_cells_root):
		return
	_retirement_queue.clear()
	for coord: Vector2i in _active_cells.keys().duplicate():
		_unload_cell(coord)
	_session_ready = false
	_streaming_stable_seconds = 0.0
	_refresh_desired_cells(_current_cell)
	_check_initial_neighborhood_ready()


func set_debug_overlay_enabled(enabled: bool) -> void:
	debug_overlay_enabled = enabled
	if enabled:
		refresh_debug_overlay()
	else:
		_clear_debug_overlay()


func refresh_debug_overlay() -> void:
	if not debug_overlay_enabled:
		_clear_debug_overlay()
		return
	if not is_instance_valid(_player) or not is_instance_valid(_cells_root):
		return
	if (
		is_instance_valid(_debug_overlay)
		and _debug_overlay_cell == _current_cell
		and _debug_overlay_radius == unload_radius_cells
	):
		return

	_debug_overlay_cell = _current_cell
	_debug_overlay_radius = unload_radius_cells
	if not is_instance_valid(_debug_overlay):
		_debug_overlay = MeshInstance3D.new()
		_debug_overlay.name = "WorldStreamingDebugOverlay"
		_cells_root.add_child(_debug_overlay)

	var radius := maxi(0, unload_radius_cells)
	var minimum_x := float(_current_cell.x - radius) * CELL_SIZE
	var maximum_x := float(_current_cell.x + radius + 1) * CELL_SIZE
	var minimum_z := float(_current_cell.y - radius) * CELL_SIZE
	var maximum_z := float(_current_cell.y + radius + 1) * CELL_SIZE
	var line_y := _player.global_position.y + 0.1
	var mesh := ImmediateMesh.new()
	mesh.surface_begin(Mesh.PRIMITIVE_LINES)
	for grid_x in range(_current_cell.x - radius, _current_cell.x + radius + 2):
		var world_x := float(grid_x) * CELL_SIZE
		mesh.surface_add_vertex(Vector3(world_x, line_y, minimum_z))
		mesh.surface_add_vertex(Vector3(world_x, line_y, maximum_z))
	for grid_z in range(_current_cell.y - radius, _current_cell.y + radius + 2):
		var world_z := float(grid_z) * CELL_SIZE
		mesh.surface_add_vertex(Vector3(minimum_x, line_y, world_z))
		mesh.surface_add_vertex(Vector3(maximum_x, line_y, world_z))
	mesh.surface_end()

	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = Color(0.15, 0.9, 1.0, 0.85)
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.no_depth_test = true
	mesh.surface_set_material(0, material)
	_debug_overlay.mesh = mesh


func get_debug_snapshot() -> Dictionary:
	var loaded_cells: Array[Vector2i] = []
	for coord: Vector2i in _active_cells:
		loaded_cells.append(coord)
	loaded_cells.sort_custom(func(a: Vector2i, b: Vector2i) -> bool:
		return a.x < b.x or (a.x == b.x and a.y < b.y)
	)
	var snapshot: Dictionary = get_streaming_metrics()
	snapshot["loaded_cells"] = loaded_cells
	snapshot["cached_unloaded_count"] = maxi(0, _cell_state.size() - loaded_cells.size())
	return snapshot


## O(1) diagnostic snapshot safe to query from a frame-hitch watchdog.
## streamed_node_count is an estimate built from PackedScene state counts;
## it intentionally avoids walking the live scene tree during a slow frame.
func get_streaming_metrics() -> Dictionary:
	return {
		"current_cell": _current_cell,
		"loaded_count": _active_cells.size(),
		"pending_load_count": _load_queue.size() + _threaded_loads.size() + _activation_queue.size(),
		"queued_load_count": _load_queue.size(),
		"threaded_load_count": _threaded_loads.size(),
		"activation_queue_count": _activation_queue.size(),
		"retirement_queue_count": _retirement_queue.size(),
		"prefetch_count": _prefetch_cells.size(),
		"destination_prefetch_count": _destination_prefetch_cells.size(),
		"packed_scene_cache_count": _packed_scene_cache.size(),
		"streamed_node_count": _streamed_node_count_estimate,
		"streamed_node_count_is_estimate": true,
		"streaming_busy": is_streaming_busy(),
		"streaming_stable_seconds": _streaming_stable_seconds,
	}


func _clear_debug_overlay() -> void:
	if is_instance_valid(_debug_overlay):
		_debug_overlay.queue_free()
	_debug_overlay = null
	_debug_overlay_cell = INVALID_CELL_COORD
	_debug_overlay_radius = -1


func _process(delta: float) -> void:
	if not _streaming_active or not is_instance_valid(_player) or not is_instance_valid(_cells_root):
		return

	var new_cell: Vector2i = world_to_cell(_player.global_position)
	if new_cell != _current_cell:
		var old_cell: Vector2i = _current_cell
		_current_cell = new_cell
		_refresh_desired_cells(new_cell)
		player_cell_changed.emit(old_cell, new_cell)
	else:
		_update_prefetch_targets()

	# Harvest completed requests before filling the bounded worker slots, so
	# new IO can begin in the same frame instead of one frame later.
	_poll_threaded_loads()
	_start_queued_loads()
	var activated_content: bool = _activate_ready_loads()
	# Never combine an authored-scene instantiation with persistent-state
	# capture/free work in the same frame. Both are main-thread operations.
	if not activated_content:
		_retire_queued_cells()
	if is_streaming_busy():
		_streaming_stable_seconds = 0.0
	else:
		_streaming_stable_seconds += delta


func _discover_cell_scenes() -> void:
	_scene_paths.clear()
	var dir := DirAccess.open(CELLS_PATH)
	if dir == null:
		return
	for file_name in dir.get_files():
		var coord: Variant = _parse_coord(file_name, "cell_", ".tscn")
		if coord != null:
			_scene_paths[coord] = CELLS_PATH.path_join(file_name)


func _parse_coord(file_name: String, prefix: String, suffix: String) -> Variant:
	if not file_name.begins_with(prefix) or not file_name.ends_with(suffix):
		return null
	var pieces := file_name.trim_prefix(prefix).trim_suffix(suffix).split("_")
	if pieces.size() != 2 or not pieces[0].is_valid_int() or not pieces[1].is_valid_int():
		return null
	return Vector2i(int(pieces[0]), int(pieces[1]))


func _refresh_desired_cells(center: Vector2i) -> void:
	load_radius_cells = maxi(0, load_radius_cells)
	unload_radius_cells = maxi(load_radius_cells, unload_radius_cells)
	for coord: Vector2i in _active_cells.keys().duplicate():
		if _cell_distance(coord, center) > unload_radius_cells:
			_queue_cell_retirement(coord)
		else:
			# A quick direction reversal can bring a queued cell back into
			# range before its one-per-frame retirement turn.
			if _retirement_queue.has(coord):
				_retirement_queue.erase(coord)
				if _scene_paths.has(coord) and not _content_ready_cells.has(coord):
					_queue_scene_resource(coord)

	var desired: Array[Vector2i] = []
	for dx in range(-load_radius_cells, load_radius_cells + 1):
		for dz in range(-load_radius_cells, load_radius_cells + 1):
			desired.append(center + Vector2i(dx, dz))
	var movement: Vector2 = _get_player_movement_direction()
	desired.sort_custom(func(a: Vector2i, b: Vector2i) -> bool:
		return _load_priority(a, center, movement) < _load_priority(b, center, movement)
	)

	_desired_cells.clear()
	for coord in desired:
		_desired_cells[coord] = true
		if not _active_cells.has(coord):
			_activate_logical_cell(coord)
	if (
		_destination_prefetch_center != INVALID_CELL_COORD
		and _cell_distance(center, _destination_prefetch_center) <= load_radius_cells
	):
		_destination_prefetch_cells.clear()
		_destination_prefetch_center = INVALID_CELL_COORD
	_update_prefetch_targets(true)
	_reprioritize_load_queue()
	_reprioritize_activation_queue()
	_trim_packed_scene_cache()


func _load_priority(coord: Vector2i, center: Vector2i, movement: Vector2) -> float:
	var offset: Vector2 = Vector2(coord - center)
	return float(_cell_distance(coord, center)) * 100.0 - offset.dot(movement) * 10.0


func _request_priority(coord: Vector2i, center: Vector2i, movement: Vector2) -> float:
	var tier: float = 3.0
	if _desired_cells.has(coord):
		tier = 0.0
	elif _destination_prefetch_cells.has(coord):
		tier = 1.0
	elif _prefetch_cells.has(coord):
		tier = 2.0
	return tier * 100000.0 + _load_priority(coord, center, movement)


func _get_player_movement_direction() -> Vector2:
	if not (_player is CharacterBody3D):
		return Vector2.ZERO
	var body: CharacterBody3D = _player as CharacterBody3D
	return Vector2(body.velocity.x, body.velocity.z).normalized()


func _get_predicted_cell() -> Vector2i:
	var predicted_position: Vector3 = _player.global_position
	if _player is CharacterBody3D:
		var body: CharacterBody3D = _player as CharacterBody3D
		predicted_position += body.velocity * PREFETCH_LOOKAHEAD_SECONDS
	return world_to_cell(predicted_position)


func _update_prefetch_targets(force: bool = false) -> void:
	if not is_instance_valid(_player):
		return
	var predicted_center: Vector2i = _get_predicted_cell()
	if not force and predicted_center == _prefetch_center:
		return
	_prefetch_center = predicted_center

	var candidates: Array[Vector2i] = []
	for dx in range(-load_radius_cells, load_radius_cells + 1):
		for dz in range(-load_radius_cells, load_radius_cells + 1):
			var coord: Vector2i = predicted_center + Vector2i(dx, dz)
			if not _active_cells.has(coord):
				candidates.append(coord)
	var movement: Vector2 = _get_player_movement_direction()
	candidates.sort_custom(func(a: Vector2i, b: Vector2i) -> bool:
		return _load_priority(a, predicted_center, movement) < _load_priority(b, predicted_center, movement)
	)

	var next_predictive: Dictionary = {}
	var prefetch_count: int = mini(MAX_PREFETCH_COORDS, candidates.size())
	for index in prefetch_count:
		var coord: Vector2i = candidates[index]
		next_predictive[coord] = true
	_predictive_prefetch_cells = next_predictive
	_rebuild_prefetch_targets()


func _rebuild_prefetch_targets() -> void:
	var next_prefetch: Dictionary = {}
	# Explicit destination warm-up wins the bounded slots; predictive cells
	# use whatever remains.
	for coord: Vector2i in _destination_prefetch_cells:
		if _active_cells.has(coord):
			continue
		next_prefetch[coord] = true
		if next_prefetch.size() >= MAX_PREFETCH_COORDS:
			break
	if next_prefetch.size() < MAX_PREFETCH_COORDS:
		for coord: Vector2i in _predictive_prefetch_cells:
			if _active_cells.has(coord) or next_prefetch.has(coord):
				continue
			next_prefetch[coord] = true
			if next_prefetch.size() >= MAX_PREFETCH_COORDS:
				break

	var previous_prefetch: Dictionary = _prefetch_cells
	var targets_changed: bool = next_prefetch.size() != previous_prefetch.size()
	if not targets_changed:
		for coord: Vector2i in next_prefetch:
			if not previous_prefetch.has(coord):
				targets_changed = true
				break
	_prefetch_cells = next_prefetch

	for coord: Vector2i in _prefetch_cells:
		if not _scene_paths.has(coord):
			continue
		_queue_scene_resource(coord)
	if targets_changed:
		_streaming_stable_seconds = 0.0
		for coord: Vector2i in _prefetch_cells:
			# Existing targets have already received the hint. Emit only for
			# coordinates newly entering the bounded warm-up set.
			if not previous_prefetch.has(coord):
				cell_prefetch_requested.emit(coord)
	_reprioritize_load_queue()
	_trim_packed_scene_cache()


func _activate_logical_cell(coord: Vector2i) -> void:
	var root := Node3D.new()
	root.name = "Cell_%d_%d" % [coord.x, coord.y]
	_cells_root.add_child(root)
	_active_cells[coord] = root
	_cell_node_estimates[coord] = 1
	_streamed_node_count_estimate += 1
	_streaming_stable_seconds = 0.0
	cell_loaded.emit(coord, root)

	if _scene_paths.has(coord):
		_queue_scene_resource(coord)
	else:
		_apply_cell_state(root, _cell_state.get(coord, {}))
		_state_applied_cells[coord] = true
		_content_ready_cells[coord] = true
		cell_content_ready.emit(coord, root)
		_check_initial_neighborhood_ready()


func _queue_scene_resource(coord: Vector2i) -> void:
	if not _scene_paths.has(coord):
		return
	if _packed_scene_cache.has(coord):
		_touch_cached_scene(coord)
		if _active_cells.has(coord):
			_queue_cell_activation(coord)
		return
	if _threaded_loads.has(coord) or _load_queue.has(coord):
		return
	_load_queue.append(coord)
	_streaming_stable_seconds = 0.0


func _queue_cell_activation(coord: Vector2i) -> void:
	if (
		not _active_cells.has(coord)
		or _content_ready_cells.has(coord)
		or _activation_queue.has(coord)
		or _retirement_queue.has(coord)
	):
		return
	_activation_queue.append(coord)
	_streaming_stable_seconds = 0.0


func _reprioritize_load_queue() -> void:
	var filtered: Array[Vector2i] = []
	var seen: Dictionary = {}
	for coord: Vector2i in _load_queue:
		if seen.has(coord):
			continue
		seen[coord] = true
		if not _scene_paths.has(coord):
			continue
		if not _active_cells.has(coord) and not _prefetch_cells.has(coord):
			continue
		if _retirement_queue.has(coord):
			continue
		if _packed_scene_cache.has(coord):
			if _active_cells.has(coord):
				_queue_cell_activation(coord)
			continue
		if _threaded_loads.has(coord):
			continue
		filtered.append(coord)
	var center: Vector2i = _current_cell
	var movement: Vector2 = _get_player_movement_direction()
	filtered.sort_custom(func(a: Vector2i, b: Vector2i) -> bool:
		return _request_priority(a, center, movement) < _request_priority(b, center, movement)
	)
	_load_queue = filtered


func _reprioritize_activation_queue() -> void:
	var filtered: Array[Vector2i] = []
	var seen: Dictionary = {}
	for coord: Vector2i in _activation_queue:
		if seen.has(coord):
			continue
		seen[coord] = true
		if (
			_active_cells.has(coord)
			and not _content_ready_cells.has(coord)
			and _packed_scene_cache.has(coord)
			and not _retirement_queue.has(coord)
		):
			filtered.append(coord)
	var center: Vector2i = _current_cell
	var movement: Vector2 = _get_player_movement_direction()
	filtered.sort_custom(func(a: Vector2i, b: Vector2i) -> bool:
		return _request_priority(a, center, movement) < _request_priority(b, center, movement)
	)
	_activation_queue = filtered


func _start_queued_loads() -> void:
	if _threaded_loads.size() >= MAX_CONCURRENT_LOADS or _load_queue.is_empty():
		return
	_reprioritize_load_queue()
	while _threaded_loads.size() < MAX_CONCURRENT_LOADS and not _load_queue.is_empty():
		var coord: Vector2i = _load_queue.pop_front()
		if (
			(not _active_cells.has(coord) and not _prefetch_cells.has(coord))
			or _threaded_loads.has(coord)
		):
			continue
		if _packed_scene_cache.has(coord):
			if _active_cells.has(coord):
				_queue_cell_activation(coord)
			continue
		var path: String = _scene_paths[coord]
		var error: int = ResourceLoader.load_threaded_request(path)
		var status: int = ResourceLoader.load_threaded_get_status(path)
		if error == OK or status == ResourceLoader.THREAD_LOAD_IN_PROGRESS or status == ResourceLoader.THREAD_LOAD_LOADED:
			_threaded_loads[coord] = path
			_streaming_stable_seconds = 0.0
		else:
			push_error("WorldManager: threaded load request failed for %s (error %d)." % [path, error])
			if _active_cells.has(coord):
				_content_ready_cells[coord] = true
				_check_initial_neighborhood_ready()


func _poll_threaded_loads() -> void:
	for coord: Vector2i in _threaded_loads.keys().duplicate():
		var path: String = _threaded_loads[coord]
		var status: int = ResourceLoader.load_threaded_get_status(path)
		if status == ResourceLoader.THREAD_LOAD_FAILED or status == ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
			push_error("WorldManager: failed loading %s." % path)
			_threaded_loads.erase(coord)
			if _active_cells.has(coord):
				_content_ready_cells[coord] = true
				_check_initial_neighborhood_ready()
			continue
		if status != ResourceLoader.THREAD_LOAD_LOADED:
			continue

		var packed: PackedScene = ResourceLoader.load_threaded_get(path) as PackedScene
		_threaded_loads.erase(coord)
		if packed == null:
			push_error("WorldManager: %s did not resolve to a PackedScene." % path)
			if _active_cells.has(coord):
				_content_ready_cells[coord] = true
				_check_initial_neighborhood_ready()
			continue
		_store_cached_scene(coord, packed)
		if _active_cells.has(coord) and not _retirement_queue.has(coord):
			_queue_cell_activation(coord)


func _activate_ready_loads() -> bool:
	if _activation_queue.is_empty():
		return false
	_reprioritize_activation_queue()
	var activated := 0
	var started_usec: int = Time.get_ticks_usec()
	while not _activation_queue.is_empty():
		if activated >= MAX_INSTANTIATIONS_PER_FRAME:
			break
		var elapsed_ms: float = float(Time.get_ticks_usec() - started_usec) / 1000.0
		if elapsed_ms >= MAX_ACTIVATION_BUDGET_MS:
			break
		var coord: Vector2i = _activation_queue.pop_front()
		if (
			not _active_cells.has(coord)
			or _content_ready_cells.has(coord)
			or _retirement_queue.has(coord)
		):
			continue
		var packed: PackedScene = _packed_scene_cache.get(coord) as PackedScene
		if packed == null:
			_queue_scene_resource(coord)
			continue

		var root: Node = _active_cells[coord]
		var content: Node = packed.instantiate()
		content.name = "AuthoredContent"
		root.add_child(content)
		var scene_state: SceneState = packed.get_state()
		var declared_node_count: int = 1
		if scene_state != null:
			declared_node_count = maxi(1, scene_state.get_node_count())
		_streamed_node_count_estimate += declared_node_count
		_cell_node_estimates[coord] = int(_cell_node_estimates.get(coord, 1)) + declared_node_count
		_apply_cell_state(root, _cell_state.get(coord, {}))
		_state_applied_cells[coord] = true
		_content_ready_cells[coord] = true
		cell_content_ready.emit(coord, root)
		activated += 1
		_touch_cached_scene(coord)
		_check_initial_neighborhood_ready()
	_trim_packed_scene_cache()
	return activated > 0


func _queue_cell_retirement(coord: Vector2i) -> void:
	if not _active_cells.has(coord) or _retirement_queue.has(coord):
		return
	_retirement_queue.append(coord)
	_load_queue.erase(coord)
	_activation_queue.erase(coord)
	_streaming_stable_seconds = 0.0


func _retire_queued_cells() -> void:
	if _retirement_queue.is_empty():
		return
	var candidates: Array[Vector2i] = []
	for coord: Vector2i in _retirement_queue:
		if (
			_active_cells.has(coord)
			and _cell_distance(coord, _current_cell) > unload_radius_cells
		):
			candidates.append(coord)
	var center: Vector2i = _current_cell
	candidates.sort_custom(func(a: Vector2i, b: Vector2i) -> bool:
		return _cell_distance(a, center) > _cell_distance(b, center)
	)
	_retirement_queue = candidates

	var retired: int = 0
	while retired < MAX_RETIREMENTS_PER_FRAME and not _retirement_queue.is_empty():
		var coord: Vector2i = _retirement_queue.pop_front()
		_unload_cell(coord)
		retired += 1


func _store_cached_scene(coord: Vector2i, packed: PackedScene) -> void:
	_packed_scene_cache[coord] = packed
	_touch_cached_scene(coord)
	_trim_packed_scene_cache()


func _touch_cached_scene(coord: Vector2i) -> void:
	if not _packed_scene_cache.has(coord):
		return
	_scene_cache_serial += 1
	_scene_cache_recency[coord] = _scene_cache_serial


func _trim_packed_scene_cache() -> void:
	while _packed_scene_cache.size() > MAX_PACKED_SCENE_CACHE_SIZE:
		var eviction_candidate: Vector2i = INVALID_CELL_COORD
		var candidate_protection_rank: int = 2147483647
		var candidate_distance := -1
		var candidate_recency := 2147483647
		for coord: Vector2i in _packed_scene_cache:
			# A scene awaiting activation has no other strong reference that
			# WorldManager can rely on, so defer eviction until it is attached.
			if _active_cells.has(coord) and not _content_ready_cells.has(coord):
				continue
			# Instantiated active content no longer needs its PackedScene.
			# Predictive resources are more valuable, and an explicit
			# fast-travel destination is the last thing we should evict.
			var protection_rank: int = 0
			if _active_cells.has(coord):
				protection_rank = 1
			if _prefetch_cells.has(coord):
				protection_rank = 2
			if _destination_prefetch_cells.has(coord):
				protection_rank = 3
			var distance: int = _cell_distance(coord, _current_cell)
			var recency: int = int(_scene_cache_recency.get(coord, 0))
			if eviction_candidate == INVALID_CELL_COORD:
				eviction_candidate = coord
				candidate_protection_rank = protection_rank
				candidate_distance = distance
				candidate_recency = recency
				continue
			if protection_rank < candidate_protection_rank:
				eviction_candidate = coord
				candidate_protection_rank = protection_rank
				candidate_distance = distance
				candidate_recency = recency
				continue
			if protection_rank != candidate_protection_rank:
				continue
			if distance > candidate_distance or (distance == candidate_distance and recency < candidate_recency):
				eviction_candidate = coord
				candidate_distance = distance
				candidate_recency = recency
		if eviction_candidate == INVALID_CELL_COORD:
			# Only active scenes awaiting attachment can transiently exceed
			# the cap; the bounded activation queue drains them over frames.
			break
		if candidate_protection_rank >= 2:
			# The effective warm-up set is itself capped to the cache size.
			# If pending active scenes temporarily push us over, preserve
			# warm resources and let attachment make those actives evictable.
			break
		_packed_scene_cache.erase(eviction_candidate)
		_scene_cache_recency.erase(eviction_candidate)


func _unload_cell(coord: Vector2i, capture_state: bool = true) -> void:
	if not _active_cells.has(coord):
		return
	var state_was_applied: bool = _state_applied_cells.has(coord)
	_load_queue.erase(coord)
	_activation_queue.erase(coord)
	_retirement_queue.erase(coord)
	_content_ready_cells.erase(coord)
	_state_applied_cells.erase(coord)
	_pending_cell_layers.erase(coord)
	var root: Node = _active_cells[coord]
	if capture_state and state_was_applied:
		var captured_state: Dictionary = _capture_cell_state(root)
		if captured_state.is_empty():
			_cell_state.erase(coord)
		else:
			_cell_state[coord] = captured_state
	_active_cells.erase(coord)
	_streamed_node_count_estimate = maxi(
		0,
		_streamed_node_count_estimate - int(_cell_node_estimates.get(coord, 1))
	)
	_cell_node_estimates.erase(coord)
	_streaming_stable_seconds = 0.0
	# Emit while the root is still valid so cell-scoped systems can snapshot.
	cell_unloaded.emit(coord)
	if is_instance_valid(root):
		root.queue_free()


func _check_initial_neighborhood_ready() -> void:
	if _session_ready or not _streaming_active:
		return
	for dx in range(-load_radius_cells, load_radius_cells + 1):
		for dz in range(-load_radius_cells, load_radius_cells + 1):
			if not _content_ready_cells.has(_current_cell + Vector2i(dx, dz)):
				return
			if not _pending_cell_layers.get(_current_cell + Vector2i(dx, dz), {}).is_empty():
				return
	_session_ready = true
	world_ready.emit()


func mark_cell_layer_pending(coord: Vector2i, layer_name: String) -> void:
	if not _pending_cell_layers.has(coord):
		_pending_cell_layers[coord] = {}
	_pending_cell_layers[coord][layer_name] = true
	_streaming_stable_seconds = 0.0


func mark_cell_layer_ready(coord: Vector2i, layer_name: String) -> void:
	if _pending_cell_layers.has(coord):
		_pending_cell_layers[coord].erase(layer_name)
		if _pending_cell_layers[coord].is_empty():
			_pending_cell_layers.erase(coord)
	_streaming_stable_seconds = 0.0
	_check_initial_neighborhood_ready()


func world_to_cell(position: Vector3) -> Vector2i:
	return Vector2i(floori(position.x / CELL_SIZE), floori(position.z / CELL_SIZE))


func _cell_distance(a: Vector2i, b: Vector2i) -> int:
	return maxi(absi(a.x - b.x), absi(a.y - b.y))


func adopt_node_to_cell(node: Node3D) -> bool:
	if not is_world_ready() or not is_instance_valid(node):
		return false
	var coord := world_to_cell(node.global_position)
	var root: Node = _active_cells.get(coord)
	if root == null:
		return false
	if node.get_parent() != root:
		node.reparent(root, true)
	return true


func _capture_cell_state(root: Node) -> Dictionary:
	var state: Dictionary = {}
	_capture_recursive(root, root, state)
	return state


func _capture_recursive(node: Node, root: Node, state: Dictionary) -> void:
	if node != root and node.has_method("get_save_data"):
		var data: Dictionary = node.get_save_data()
		if not data.is_empty():
			var key: String = _persistent_key(node, root)
			state[key] = {
				"data": data,
				"captured_world_seconds": DayNightManager.get_world_elapsed_seconds()
			}
	for child in node.get_children():
		_capture_recursive(child, root, state)


func _persistent_key(node: Node, root: Node) -> String:
	if node.has_method("get_persistent_id"):
		var persistent_id: String = node.get_persistent_id()
		if persistent_id != "":
			return "id:" + persistent_id
	return "path:" + str(root.get_path_to(node))


func _apply_cell_state(root: Node, state: Dictionary) -> void:
	if state.is_empty() and _legacy_state_by_id.is_empty():
		return
	var nodes_by_key: Dictionary = {}
	_index_persistent_nodes(root, root, nodes_by_key)
	var now: float = DayNightManager.get_world_elapsed_seconds()

	for key in state:
		var record: Dictionary = state[key]
		var data: Dictionary = record.get("data", record) # version-1 compatibility
		var node: Node = nodes_by_key.get(key)
		if node == null and key.begins_with("path:"):
			node = root.get_node_or_null(NodePath(key.trim_prefix("path:")))
		if node == null and key.begins_with("id:placed_") and data.has("source_item_id"):
			node = _instantiate_saved_placeable(root, data)
		if node == null:
			continue
		var elapsed := maxf(0.0, now - float(record.get("captured_world_seconds", now)))
		if node.has_method("load_save_data_with_elapsed"):
			node.load_save_data_with_elapsed(data, elapsed)
		elif node.has_method("load_save_data"):
			node.load_save_data(data)
	for persistent_id in _legacy_state_by_id.keys().duplicate():
		var node: Node = nodes_by_key.get("id:" + String(persistent_id))
		if node != null and node.has_method("load_save_data"):
			node.load_save_data(_legacy_state_by_id[persistent_id])
			_legacy_state_by_id.erase(persistent_id)


func _index_persistent_nodes(node: Node, root: Node, result: Dictionary) -> void:
	if node != root and node.has_method("get_save_data"):
		result[_persistent_key(node, root)] = node
	for child in node.get_children():
		_index_persistent_nodes(child, root, result)


func _instantiate_saved_placeable(root: Node, data: Dictionary) -> Node:
	var item_id: String = data.get("source_item_id", "")
	var definition: ItemData = InventoryManager.item_defs.get(item_id)
	if definition == null or definition.placed_scene == null:
		push_warning("WorldManager: cannot restore placeable for item '%s'." % item_id)
		return null
	var instance := definition.placed_scene.instantiate()
	root.add_child(instance)
	return instance


func get_save_data() -> Dictionary:
	# Nested records are not mutated while this synchronous snapshot is
	# serialized, so a shallow dictionary copy avoids duplicating every
	# unloaded entity record before active cells are replaced below.
	var snapshot: Dictionary = _cell_state.duplicate(false)
	for coord: Vector2i in _active_cells:
		# A logical root can exist before its PackedScene arrives. Capturing
		# that placeholder would erase saved records which have not had a
		# chance to materialize yet.
		if not _state_applied_cells.has(coord):
			continue
		var captured_state: Dictionary = _capture_cell_state(_active_cells[coord])
		if captured_state.is_empty():
			snapshot.erase(coord)
		else:
			snapshot[coord] = captured_state
	var serialized: Dictionary = {}
	for coord: Vector2i in snapshot:
		var records: Dictionary = snapshot[coord]
		if records.is_empty():
			continue
		serialized["%d,%d" % [coord.x, coord.y]] = records
	return {"cells": serialized}


func load_save_data(data: Dictionary) -> void:
	for coord in _active_cells:
		_remove_dynamic_placeables(_active_cells[coord])
	_cell_state.clear()
	var serialized: Dictionary = data.get("cells", {})
	for coord_key in serialized:
		var pieces := String(coord_key).split(",")
		if pieces.size() == 2 and pieces[0].is_valid_int() and pieces[1].is_valid_int():
			var records: Dictionary = serialized[coord_key]
			if not records.is_empty():
				_cell_state[Vector2i(int(pieces[0]), int(pieces[1]))] = records
	for coord: Vector2i in _active_cells:
		_apply_cell_state(_active_cells[coord], _cell_state.get(coord, {}))


func _remove_dynamic_placeables(node: Node) -> void:
	for child in node.get_children().duplicate():
		_remove_dynamic_placeables(child)
	if node is Placeable and node.get_persistent_id().begins_with("placed_"):
		node.release_placement()
		node.free()


func load_legacy_entity_states(states_by_id: Dictionary) -> void:
	_legacy_state_by_id.merge(states_by_id, true)
	for coord in _active_cells:
		_apply_cell_state(_active_cells[coord], _cell_state.get(coord, {}))


func queue_legacy_placeable(data: Dictionary) -> void:
	var position_data: Dictionary = data.get("position", {})
	var position := Vector3(position_data.get("x", 0.0), position_data.get("y", 0.0), position_data.get("z", 0.0))
	var coord := world_to_cell(position)
	if not _cell_state.has(coord):
		_cell_state[coord] = {}
	var migrated := data.duplicate(true)
	var persistent_id: String = migrated.get("persistent_id", "")
	if persistent_id == "":
		persistent_id = "placed_migrated_%s" % str(migrated).sha256_text().substr(0, 16)
		migrated["persistent_id"] = persistent_id
	_cell_state[coord]["id:" + persistent_id] = {
		"data": migrated,
		"captured_world_seconds": DayNightManager.get_world_elapsed_seconds()
	}
	if _active_cells.has(coord):
		_apply_cell_state(_active_cells[coord], _cell_state[coord])


func _on_unloaded_day_started() -> void:
	# Loaded ShippingBins receive the signal themselves. Reconcile stored bins
	# here so selling does not depend on presentation being instantiated.
	for coord in _cell_state:
		# Once state has been applied, the live bin is authoritative and
		# receives day_started itself. Its cached unload snapshot may still
		# contain yesterday's slots and must not be sold a second time.
		if (
			_active_cells.has(coord)
			and _state_applied_cells.has(coord)
		):
			continue
		var records: Dictionary = _cell_state[coord]
		for key in records:
			var record: Dictionary = records[key]
			var data: Dictionary = record.get("data", {})
			if data.get("persistent_type", "") != "shipping_bin":
				continue
			var earned := 0
			for slot in data.get("slots", []):
				var definition: ItemData = InventoryManager.item_defs.get(slot.get("item_id", ""))
				if definition != null and definition.sell_price > 0:
					earned += definition.sell_price * int(slot.get("quantity", 0))
			if earned > 0:
				EconomyManager.add_currency(earned)
				data["slots"] = []
				record["data"] = data
