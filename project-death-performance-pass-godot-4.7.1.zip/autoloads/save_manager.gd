extends Node

var pending_continue_load: bool = false
var pending_new_game: bool = false

const SAVE_VERSION := 2
const SAVE_PATH := "user://savegame.json"
const TEMP_PATH := "user://savegame.tmp"
const BACKUP_PATH := "user://savegame.backup.json"

signal game_saved()
signal game_loaded()


func save_game() -> void:
	if not WorldManager.is_world_ready():
		push_warning("SaveManager: ignored save request outside an initialized game world.")
		return

	# A cursor payload is transient UI state. Return it before snapshotting so
	# closing a panel or saving mid-drag cannot destroy an item.
	InventorySlotUI.cancel_held_payload()

	var player_data: Dictionary = {}
	var player := get_tree().get_first_node_in_group("player") as Node3D
	if player:
		player_data = {
			"position": _vector3_to_dict(player.global_position),
			"rotation_y": player.rotation.y
		}

	var save_data: Dictionary = {
		"save_version": SAVE_VERSION,
		"player": player_data,
		"skills": SkillManager.get_save_data(),
		"inventory_slots": InventorySlotManager.get_save_data(),
		"world": WorldManager.get_save_data(),
		"grass": GrassManager.get_save_data(),
		"terrain_restoration": TerrainRestoration.get_save_data(),
		"achievements": AchievementManager.get_save_data(),
		"collection_log": CollectionLogManager.get_save_data(),
		"day_night": DayNightManager.get_save_data(),
		"weather": WeatherManager.get_save_data(),
		"luck": LuckManager.get_save_data(),
		"fast_travel": FastTravelManager.get_save_data(),
		"tutorial": TutorialManager.get_save_data(),
		"quests": QuestManager.get_save_data(),
		"dialogue": DialogueManager.get_save_data(),
		"relationships": RelationshipManager.get_save_data(),
		"economy": EconomyManager.get_save_data()
	}

	var file := FileAccess.open(TEMP_PATH, FileAccess.WRITE)
	if file == null:
		push_error("SaveManager: failed to open temporary save file.")
		return
	file.store_string(JSON.stringify(save_data))
	file.flush()
	file.close()

	if not _validate_json_file(TEMP_PATH):
		push_error("SaveManager: temporary save failed validation; existing save was preserved.")
		DirAccess.remove_absolute(ProjectSettings.globalize_path(TEMP_PATH))
		return

	if not _replace_save_atomically():
		return
	print("Game saved to ", SAVE_PATH)
	game_saved.emit()


func _replace_save_atomically() -> bool:
	var save_abs := ProjectSettings.globalize_path(SAVE_PATH)
	var temp_abs := ProjectSettings.globalize_path(TEMP_PATH)
	var backup_abs := ProjectSettings.globalize_path(BACKUP_PATH)
	var rotated_primary: bool = false
	if FileAccess.file_exists(SAVE_PATH):
		if _validate_json_file(SAVE_PATH):
			if FileAccess.file_exists(BACKUP_PATH):
				var remove_backup_error: Error = (
					DirAccess.remove_absolute(backup_abs)
				)
				if remove_backup_error != OK:
					push_error(
						"SaveManager: could not replace the old backup (error %d)."
						% remove_backup_error
					)
					return false
			var backup_error: Error = DirAccess.rename_absolute(
				save_abs,
				backup_abs
			)
			if backup_error != OK:
				push_error(
					"SaveManager: could not rotate existing save (error %d)."
					% backup_error
				)
				return false
			rotated_primary = true
		else:
			# Preserve a valid recovery backup instead of overwriting it
			# with a primary file already known to be corrupt.
			var remove_primary_error: Error = DirAccess.remove_absolute(
				save_abs
			)
			if remove_primary_error != OK:
				push_error(
					"SaveManager: could not replace corrupt primary save (error %d)."
					% remove_primary_error
				)
				return false
	var replace_error := DirAccess.rename_absolute(temp_abs, save_abs)
	if replace_error != OK:
		push_error("SaveManager: could not install new save (error %d)." % replace_error)
		if rotated_primary and FileAccess.file_exists(BACKUP_PATH):
			DirAccess.rename_absolute(backup_abs, save_abs)
		return false
	return true


func _validate_json_file(path: String) -> bool:
	return _read_json_dictionary(path) is Dictionary


func _read_json_dictionary(path: String) -> Variant:
	if not FileAccess.file_exists(path):
		return null
	var file: FileAccess = FileAccess.open(path, FileAccess.READ)
	if file == null:
		return null
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	file.close()
	if parsed is Dictionary:
		return parsed
	return null


func load_game() -> void:
	InventorySlotUI.cancel_held_payload()

	var candidate_paths: Array[String] = [SAVE_PATH, BACKUP_PATH]
	var load_path: String = ""
	var parsed: Variant = null
	var found_candidate: bool = false
	for candidate_path: String in candidate_paths:
		if not FileAccess.file_exists(candidate_path):
			continue
		found_candidate = true
		parsed = _read_json_dictionary(candidate_path)
		if parsed is Dictionary:
			load_path = candidate_path
			break
		push_warning("SaveManager: '%s' is unreadable or invalid JSON; trying the next recovery candidate." % candidate_path)

	if load_path == "":
		if found_candidate:
			push_error("SaveManager: neither the primary save nor its backup is valid.")
			return
		print("SaveManager: no save file found.")
		return

	if load_path == BACKUP_PATH and FileAccess.file_exists(SAVE_PATH):
		push_warning("SaveManager: primary save is invalid; loading the backup instead.")

	var save_data: Dictionary = parsed
	var version: int = int(save_data.get("save_version", 1))
	if version > SAVE_VERSION:
		push_error("SaveManager: save version %d is newer than this build supports." % version)
		return

	if save_data.has("skills"):
		SkillManager.load_save_data(save_data["skills"])
	if save_data.has("day_night"):
		DayNightManager.load_save_data(save_data["day_night"])
	if save_data.has("weather"):
		WeatherManager.load_save_data(save_data["weather"])
	if save_data.has("luck"):
		LuckManager.load_save_data(save_data["luck"])
	if save_data.has("fast_travel"):
		FastTravelManager.load_save_data(save_data["fast_travel"])
	if save_data.has("tutorial"):
		TutorialManager.load_save_data(save_data["tutorial"])
	if save_data.has("quests"):
		QuestManager.load_save_data(save_data["quests"])
	QuestManager.check_auto_start_quests()
	if save_data.has("dialogue"):
		DialogueManager.load_save_data(save_data["dialogue"])
	if save_data.has("relationships"):
		RelationshipManager.load_save_data(save_data["relationships"])
	if save_data.has("inventory_slots"):
		InventorySlotManager.load_save_data(save_data["inventory_slots"])
	elif save_data.has("inventory"):
		InventoryManager.load_save_data(save_data["inventory"])

	# Achievement state must be authoritative before any world state is
	# replayed. Terrain deserialization is silent as an additional guard,
	# so loading can never unlock an achievement or grant its reward again.
	var achievement_data: Dictionary = save_data.get("achievements", {})
	AchievementManager.load_save_data(achievement_data)
	if save_data.has("terrain_restoration"):
		TerrainRestoration.load_save_data(save_data["terrain_restoration"])
	if save_data.has("collection_log"):
		CollectionLogManager.load_save_data(save_data["collection_log"])
	if save_data.has("economy"):
		EconomyManager.load_save_data(save_data["economy"])
	if save_data.has("world"):
		WorldManager.load_save_data(save_data["world"])
	if save_data.has("grass"):
		GrassManager.load_save_data(save_data["grass"])

	var player := get_tree().get_first_node_in_group("player") as Node3D
	if player and save_data.has("player"):
		var player_data: Dictionary = save_data["player"]
		player.global_position = _dict_to_vector3(player_data.get("position", {}))
		player.rotation.y = float(player_data.get("rotation_y", player.rotation.y))
	if player:
		var restored_player_cell: Vector2i = WorldManager.world_to_cell(player.global_position)
		AchievementManager.seed_visited_cell_silently(restored_player_cell)

	if version == 1:
		_load_legacy_world_data(save_data)

	print("Game loaded from ", load_path)
	game_loaded.emit()


func _load_legacy_world_data(save_data: Dictionary) -> void:
	if save_data.has("plots"):
		WorldManager.load_legacy_entity_states(save_data["plots"])
	if save_data.has("placed_objects"):
		for object_data in save_data["placed_objects"]:
			WorldManager.queue_legacy_placeable(object_data)


func _vector3_to_dict(value: Vector3) -> Dictionary:
	return {"x": value.x, "y": value.y, "z": value.z}


func _dict_to_vector3(value: Dictionary) -> Vector3:
	return Vector3(value.get("x", 0.0), value.get("y", 0.0), value.get("z", 0.0))


func has_save_file() -> bool:
	return FileAccess.file_exists(SAVE_PATH) or FileAccess.file_exists(BACKUP_PATH)


func delete_save_file() -> void:
	for path in [SAVE_PATH, TEMP_PATH, BACKUP_PATH]:
		if FileAccess.file_exists(path):
			DirAccess.remove_absolute(ProjectSettings.globalize_path(path))


func reset_runtime_state_for_new_game() -> void:
	SkillManager.reset_state()
	BuildGrid.clear_all_placed_objects()
	InventorySlotManager.load_save_data({})
	TerrainRestoration.load_save_data({})
	AchievementManager.reset_state(true)
	CollectionLogManager.load_save_data({})
	DayNightManager.load_save_data({
		"time_of_day": 8.0,
		"total_elapsed_days": 0.0,
		"total_elapsed_world_seconds": 0.0
	})
	EconomyManager.load_save_data({"currency": 666})
	WeatherManager.load_save_data({})
	LuckManager.load_save_data({})
	FastTravelManager.load_save_data({})
	TutorialManager.on_new_game_started()
	QuestManager.load_save_data({})
	QuestManager.check_auto_start_quests()
	DialogueManager.load_save_data({})
	RelationshipManager.load_save_data({})
	WorldManager.load_save_data({})
	GrassManager.load_save_data({})
