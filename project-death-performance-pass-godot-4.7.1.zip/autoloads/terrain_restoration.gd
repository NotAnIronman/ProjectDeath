extends Node

## AUTOLOAD — register in Project Settings > Globals as "TerrainRestoration".
##
## NAMING: internally still "bad dirt"/"good dirt" (the const names below)
## to avoid a wide, risky rename across working code — but the player-
## facing concept is "Withered Ground" (BAD_DIRT_TEXTURE_ID) restored to
## "Restored Ground" (GOOD_DIRT_TEXTURE_ID). Use those terms in any new
## player-facing text/UI. If you want the Terrain3D texture asset's own
## in-editor label to match, that's a one-line manual rename in the Asset
## Dock (its "Name" field) — purely cosmetic, doesn't touch any code here.
##
## Lets gameplay repaint a circular patch of Terrain3D's control map at
## runtime — this is the "restore withered ground" mechanic. FarmPlot uses
## this to gate planting on whether its own ground has been restored yet
## (see FarmPlot._is_ground_restored()) — that's the "Only restored
## terrain becomes plantable" rule from the design doc, implemented by
## FarmPlot asking THIS system rather than duplicating any state here.
##
## CRITICAL GUARANTEE: this script only ever calls Terrain3D.data.set_control()
## — an in-memory edit to the running terrain. It never calls any of
## Terrain3D's own data-saving functions, so the actual .res region files
## under the Terrain3D node's data_directory are never touched. Every run
## starts from the same authored terrain state.
##
## LOADING IS AUTHORITATIVE: loading applies every saved patch AND reverts
## any vertex currently painted that no surviving patch still wants —
## otherwise unsaved changes would visually stick around after a load.
##
## PER-VERTEX ORIGINAL TRACKING (not per-patch): the first time any given
## vertex is ever painted this session, its true starting texture is
## recorded once, globally, independent of which patch(es) later cover it.
## This is deliberate — tracking "original" per PATCH instead breaks the
## moment two patches overlap (a common case when painting several patches
## close together), because the second patch would wrongly record the
## first patch's fresh paint as its own "original." Per-vertex tracking
## means overlapping patches can never corrupt each other's revert data,
## and reverting only ever un-paints a vertex when NO remaining patch
## still needs it — never one that's still legitimately in use.
##
## SCALE NOTE: the save file stores one small entry per restoration EVENT
## (position/texture/radius), not per-vertex — save size tracks how many
## restoration points you've authored, not world size. The expensive part,
## Terrain3DData.update_maps(), is called exactly once per paint/load call,
## batched across every vertex touched, however many patches are involved.

## Emitted for live gameplay restoration only. Save-load replay applies
## terrain silently so deserialization cannot trigger gameplay rewards.
signal patch_restored(patch_id: String)

## Texture asset IDs — match the Asset Dock order in World.tscn's Terrain3D
## node (Dirt=0, Water=1, Grass=2, Sand=3, Bad Dirt=4).
const GOOD_DIRT_TEXTURE_ID := 0
const BAD_DIRT_TEXTURE_ID := 4

const DEFAULT_RESTORE_RADIUS := 3.0

var _terrain: Terrain3D = null

## patch_id -> {"position": Vector3, "texture_id": int, "radius": float}
var restored_patches: Dictionary = {}

## Vector2i grid key (x,z in vertex-spacing units) -> the true original
## base texture ID at that vertex, recorded the first time it's ever
## painted this session. Session-scoped only — never saved/loaded, since a
## fresh boot always starts from the real unpainted terrain anyway, so
## originals get captured fresh and correctly as vertices are first
## touched again.
var _vertex_originals: Dictionary = {}


func _ready() -> void:
	call_deferred("_find_terrain")


func _find_terrain() -> void:
	_terrain = _find_terrain_recursive(get_tree().current_scene)
	if _terrain:
		print("TerrainRestoration: found terrain node '%s'." % _terrain.name)
	else:
		push_warning("TerrainRestoration: no Terrain3D node found in the current scene.")


func _find_terrain_recursive(node: Node) -> Terrain3D:
	if node is Terrain3D:
		return node
	for child in node.get_children():
		var found: Terrain3D = _find_terrain_recursive(child)
		if found:
			return found
	return null


## Lazily re-resolves the terrain reference if it's missing — removes any
## dependency on exact _ready()/call_deferred timing.
func _ensure_terrain() -> bool:
	if _terrain != null and is_instance_valid(_terrain):
		return true
	_find_terrain()
	return _terrain != null


## --- Vertex grid keys ---
## A vertex is uniquely identified by its (x,z) grid coordinate in units of
## vertex_spacing — this is what lets overlapping patches agree on "this is
## the same vertex" regardless of the exact float position each patch's
## circle math produced.

func _vertex_key(global_pos: Vector3) -> Vector2i:
	var spacing: float = _terrain.vertex_spacing
	return Vector2i(roundi(global_pos.x / spacing), roundi(global_pos.z / spacing))


func _key_to_position(key: Vector2i) -> Vector3:
	var spacing: float = _terrain.vertex_spacing
	return Vector3(key.x * spacing, 0.0, key.y * spacing)


## Every vertex grid key within `radius` meters of `center`.
func _circle_vertex_keys(center: Vector3, radius: float) -> Array[Vector2i]:
	var keys: Array[Vector2i] = []
	if not _ensure_terrain():
		return keys

	var spacing: float = _terrain.vertex_spacing
	var steps: int = int(ceil(radius / spacing))

	var x: int = -steps
	while x <= steps:
		var z: int = -steps
		while z <= steps:
			var offset := Vector3(x * spacing, 0.0, z * spacing)
			if offset.length() <= radius:
				keys.append(_vertex_key(center + offset))
			z += 1
		x += 1
	return keys


## --- Core repaint (in-memory only, see guarantee above) ---

## Repaints every vertex within `radius` meters of `center` to `texture_id`.
## `apply_update` controls whether the (expensive) GPU map rebuild happens
## immediately — leave it true for one-off calls, pass false when painting
## several patches in a row and call _apply_map_update() once yourself
## after the whole batch (see load_save_data).
func paint_circle(center: Vector3, radius: float, texture_id: int, apply_update: bool = true) -> void:
	if not _ensure_terrain():
		push_warning("TerrainRestoration: paint_circle called but no Terrain3D node could be found.")
		return

	for key in _circle_vertex_keys(center, radius):
		_paint_vertex_key(key, texture_id)

	if apply_update:
		_apply_map_update()


## Paints a single vertex (by grid key) to `texture_id`, recording its true
## original texture the first time — and only the first time — it's ever
## touched this session.
func _paint_vertex_key(key: Vector2i, texture_id: int) -> void:
	var pos := _key_to_position(key)
	var existing: int = _terrain.data.get_control(pos)
	if existing == 4294967295:  # UINT32_MAX — position isn't inside any region
		return

	if not _vertex_originals.has(key):
		_vertex_originals[key] = Terrain3DUtil.get_base(existing)

	# Keep whatever blend was already painted there — we're only overriding
	# which texture(s) show, not how they're blended. These are static
	# functions on Terrain3DUtil (confirmed via debugger warning) — call
	# them on the class, not an instance.
	var blend: int = Terrain3DUtil.get_blend(existing)
	var new_control: int = Terrain3DUtil.enc_base(texture_id) | Terrain3DUtil.enc_overlay(texture_id) | Terrain3DUtil.enc_blend(blend)
	_terrain.data.set_control(pos, new_control)


## Reverts a single vertex back to its recorded true original texture.
## No-op if this vertex was never actually recorded (nothing to revert to).
func _revert_vertex_key(key: Vector2i) -> void:
	if not _vertex_originals.has(key):
		return

	var pos := _key_to_position(key)
	var existing: int = _terrain.data.get_control(pos)
	if existing == 4294967295:
		return

	var original_base: int = _vertex_originals[key]
	var blend: int = Terrain3DUtil.get_blend(existing)
	var new_control: int = Terrain3DUtil.enc_base(original_base) | Terrain3DUtil.enc_overlay(original_base) | Terrain3DUtil.enc_blend(blend)
	_terrain.data.set_control(pos, new_control)


## CRITICAL: set_control() only edits the CPU-side data. Without this call,
## the change is real (get_control would reflect it) but the GPU-side
## texture array the shader actually samples never gets rebuilt, so
## nothing visually changes even though nothing errors either.
func _apply_map_update() -> void:
	if _terrain.data.has_method("update_maps"):
		_terrain.data.update_maps()
	elif _terrain.data.has_method("force_update_maps"):
		_terrain.data.force_update_maps()
	else:
		push_warning("TerrainRestoration: Terrain3DData has neither update_maps() nor force_update_maps() — check your Terrain3D addon version.")


## --- Restoration mechanic ---

## Restores a "bad dirt" patch to "good dirt" centered on `position`, and
## remembers it under `patch_id` so it survives save/load.
##
## IMPORTANT: `patch_id` must be a stable, unique identifier that doesn't
## collide across sessions or with other patches — reusing an id silently
## REPLACES that patch's entry (this is intentional, it's what lets you
## call restore_at() again on an already-restored patch idempotently), but
## means accidental id reuse looks like "my other patch disappeared."
func restore_at(
	position: Vector3,
	patch_id: String,
	texture_id: int = GOOD_DIRT_TEXTURE_ID,
	radius: float = DEFAULT_RESTORE_RADIUS,
	apply_update: bool = true,
	emit_gameplay_event: bool = true
) -> void:
	paint_circle(position, radius, texture_id, apply_update)
	restored_patches[patch_id] = {"position": position, "texture_id": texture_id, "radius": radius}
	if emit_gameplay_event:
		patch_restored.emit(patch_id)


func is_restored(patch_id: String) -> bool:
	return restored_patches.has(patch_id)


## --- Save/Load (same Dictionary contract as every other manager) ---

func get_save_data() -> Dictionary:
	var out: Dictionary = {}
	for patch_id in restored_patches:
		var entry: Dictionary = restored_patches[patch_id]
		var pos: Vector3 = entry["position"]
		out[patch_id] = {
			"position": [pos.x, pos.y, pos.z],
			"texture_id": entry["texture_id"],
			"radius": entry["radius"],
		}
	return out


## Makes the terrain match `data` exactly: applies every saved patch, AND
## reverts any vertex currently painted that no surviving patch still
## covers, back to its true original texture (see PER-VERTEX ORIGINAL
## TRACKING above for why this is done per-vertex rather than per-patch).
## Every write is batched into a single update_maps() call at the end.
func load_save_data(data: Dictionary) -> void:
	if not _ensure_terrain():
		push_warning("TerrainRestoration: load_save_data called but no Terrain3D node could be found — terrain will NOT reflect the loaded save.")
		return

	# Every vertex any SURVIVING (still-saved) patch will cover — a vertex
	# in here must NOT be reverted, even if it also belonged to a patch
	# that's being removed, because something we're keeping still needs it.
	var surviving_keys: Dictionary = {}
	for patch_id in data:
		var entry: Dictionary = data[patch_id]
		var pos_array: Array = entry.get("position", [0.0, 0.0, 0.0])
		var position := Vector3(
			float(pos_array[0]),
			float(pos_array[1]),
			float(pos_array[2])
		)
		var radius: float = float(entry.get("radius", DEFAULT_RESTORE_RADIUS))
		for key in _circle_vertex_keys(position, radius):
			surviving_keys[key] = true

	# Revert every vertex belonging ONLY to patches being removed.
	for patch_id in restored_patches.keys():
		if not data.has(patch_id):
			var old_entry: Dictionary = restored_patches[patch_id]
			var old_position: Vector3 = old_entry["position"]
			var old_radius: float = float(old_entry["radius"])
			for key in _circle_vertex_keys(old_position, old_radius):
				if not surviving_keys.has(key):
					_revert_vertex_key(key)
			restored_patches.erase(patch_id)

	# Apply every patch in the save without replaying gameplay events.
	# Deserialization must not unlock achievements or grant rewards again.
	for patch_id in data:
		var entry: Dictionary = data[patch_id]
		var pos_array: Array = entry.get("position", [0.0, 0.0, 0.0])
		var position := Vector3(
			float(pos_array[0]),
			float(pos_array[1]),
			float(pos_array[2])
		)
		var texture_id: int = int(entry.get("texture_id", GOOD_DIRT_TEXTURE_ID))
		var radius: float = float(entry.get("radius", DEFAULT_RESTORE_RADIUS))
		restore_at(position, patch_id, texture_id, radius, false, false)

	_apply_map_update()
	print("TerrainRestoration: load complete — %d patch(es) now restored." % restored_patches.size())
