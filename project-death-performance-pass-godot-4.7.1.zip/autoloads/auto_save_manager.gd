extends Node

## AUTOLOAD "AutoSaveManager".
##
## Periodically calls SaveManager.save_game() in the background. Enabled
## state and interval are player-configurable preferences, owned by
## SettingsManager (autosave_enabled / autosave_interval_minutes) — same
## place every other player preference lives, persisted the same way,
## rather than a separate settings store just for this.
##
## Manual saves (F5, pause menu, etc.) are completely untouched by this —
## they still just call SaveManager.save_game() directly, same as always.
## This only adds a background trigger on top.
##
## SAFETY: if a skip condition is true right when a save is due, this
## doesn't just wait a full extra interval — it retries every
## RETRY_DELAY_SECONDS until it's actually safe, then saves and resets the
## normal timer from that point. _is_safe_to_autosave() is the extension
## point for future "don't autosave right now" conditions (combat,
## cutscenes, dialogue...) once those systems exist. Today it waits for
## world streaming to remain idle and for blocking menus to close.
##
## VISUAL INDICATOR: this doesn't own any UI itself — it relies on
## SaveManager's existing game_saved signal, which already fires for both
## manual and automatic saves. See ui_layer.gd for the on-screen indicator
## hooked to that signal.

const RETRY_DELAY_SECONDS := 5.0
const STREAMING_STABLE_SECONDS := 0.75

var _timer: float = 0.0
var _request_pending: bool = false
var _request_generation: int = 0
var _retry_generation: int = -1
var _retry_timer: Timer = null


func _ready() -> void:
	WorldManager.world_shutdown.connect(reset_timer)
	_retry_timer = Timer.new()
	_retry_timer.name = "AutoSaveRetryTimer"
	_retry_timer.one_shot = true
	_retry_timer.wait_time = RETRY_DELAY_SECONDS
	_retry_timer.timeout.connect(_on_retry_timeout)
	add_child(_retry_timer)


func _process(delta: float) -> void:
	if not SettingsManager.autosave_enabled or not WorldManager.is_world_ready():
		return

	_timer += delta
	var interval_seconds: float = SettingsManager.autosave_interval_minutes * 60.0

	if _timer >= interval_seconds and not _request_pending:
		_request_autosave()


func _request_autosave() -> void:
	_request_generation += 1
	_request_pending = true
	_attempt_autosave(_request_generation)


func _attempt_autosave(generation: int) -> void:
	if generation != _request_generation or not _request_pending:
		return
	if not SettingsManager.autosave_enabled or not WorldManager.is_world_ready():
		_cancel_pending_request()
		return
	if not _is_safe_to_autosave():
		_retry_generation = generation
		_retry_timer.start(RETRY_DELAY_SECONDS)
		return

	_request_pending = false
	_retry_generation = -1
	_timer = 0.0
	SaveManager.save_game()


func _on_retry_timeout() -> void:
	var generation: int = _retry_generation
	_retry_generation = -1
	_attempt_autosave(generation)


func _is_safe_to_autosave() -> bool:
	if not WorldManager.is_world_ready():
		return false
	if not WorldManager.is_streaming_stable(STREAMING_STABLE_SECONDS):
		return false
	var ui_layer: Node = get_tree().get_first_node_in_group("ui_layer")
	if ui_layer and ui_layer.has_method("is_blocking_gameplay") and ui_layer.is_blocking_gameplay():
		return false
	return true


## Manually trigger an autosave-style save right now and reset the timer —
## exposed so future systems (finishing a quest, leaving an area, etc.)
## can piggyback on the same save call without waiting for the interval,
## instead of duplicating a call to SaveManager directly.
func trigger_now() -> void:
	if not WorldManager.is_world_ready():
		return
	_timer = 0.0
	if _request_pending:
		_cancel_pending_request()
	# Preserve this method's explicit/immediate semantics even when periodic
	# autosave is disabled. Manual and event-driven saves must not silently
	# become conditional on the autosave preference.
	SaveManager.save_game()


func reset_timer() -> void:
	_timer = 0.0
	_cancel_pending_request()


func _cancel_pending_request() -> void:
	_request_generation += 1
	_request_pending = false
	_retry_generation = -1
	if is_instance_valid(_retry_timer):
		_retry_timer.stop()
