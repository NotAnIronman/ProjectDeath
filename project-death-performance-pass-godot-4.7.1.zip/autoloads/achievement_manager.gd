extends Node

## AUTOLOAD "AchievementManager".
##
## Loads every AchievementData .tres from res://resources/achievements/
## (same scan-a-folder pattern as SkillManager/InventoryManager), tracks
## progress automatically by listening to signals other systems already
## had for their own reasons, and persists progress through the normal
## SaveManager flow.
##
## AUTOMATIC TRACKING — no other system needs to know achievements exist:
##   - InventoryManager.item_added -> ITEM_COLLECTED_TOTAL. This is a
##     LIFETIME cumulative count tracked here separately from
##     InventoryManager's current-inventory count, so selling or using an
##     item never regresses achievement progress.
##   - SkillManager.leveled_up -> SKILL_LEVEL.
##   - TerrainRestoration.patch_restored -> GROUND_RESTORED_TOTAL. Reads
##     restored_patches.size() fresh each time rather than incrementing.
##     Save-load replay is deliberately silent and never reaches this hook.
##   - WorldManager.player_cell_changed -> CELLS_EXPLORED_TOTAL, counting
##     only cells the player actually enters, not the surrounding preload
##     neighborhood (a Set via Dictionary keys).
## CUSTOM-type achievements have no automatic source and need
## report_custom_progress() called explicitly from wherever makes sense —
## for anything not covered above (combat, cooking, crafting, relationships,
## trading, festivals, story, secrets — none of which have a real system
## in the project yet), that's the hook to use once one exists.

signal achievement_completed(achievement: AchievementData)

const ACHIEVEMENTS_PATH := "res://resources/achievements/"

var achievement_defs: Dictionary = {}   # id -> AchievementData
var progress: Dictionary = {}           # id -> int
var completed: Dictionary = {}          # id -> bool

var _lifetime_item_totals: Dictionary = {}    # item_id -> int, NOT saved directly (derived from item_added over the whole game, but persisted so it survives reload — see save data)
var _visited_cells: Dictionary = {}           # Vector2i -> true


func _ready() -> void:
	_load_all_achievement_defs()
	InventoryManager.item_added.connect(_on_item_added)
	SkillManager.leveled_up.connect(_on_leveled_up)
	call_deferred("_connect_deferred_signals")


## TerrainRestoration/WorldManager may not have finished their own _ready()
## yet at this point — deferred to be safe, same reasoning as their own
## call_deferred("_find_terrain") pattern.
func _connect_deferred_signals() -> void:
	TerrainRestoration.patch_restored.connect(_on_patch_restored)
	WorldManager.player_cell_changed.connect(_on_player_cell_changed)


func _load_all_achievement_defs() -> void:
	_scan_directory_recursive(ACHIEVEMENTS_PATH)
	print("AchievementManager loaded achievements: ", achievement_defs.keys())


func _scan_directory_recursive(path: String) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		push_warning("AchievementManager: could not open %s" % path)
		return

	dir.list_dir_begin()
	var file_name := dir.get_next()
	while file_name != "":
		if file_name.begins_with("."):
			file_name = dir.get_next()
			continue
		var full_path := path.path_join(file_name)
		if dir.current_is_dir():
			_scan_directory_recursive(full_path)
		elif file_name.ends_with(".tres"):
			var res: Resource = load(full_path)
			if res is AchievementData:
				if res.id == "":
					push_warning("AchievementManager: AchievementData at %s has no id set — skipped." % full_path)
				else:
					achievement_defs[res.id] = res
					progress[res.id] = 0
					completed[res.id] = false
		file_name = dir.get_next()
	dir.list_dir_end()


## --- Automatic tracking handlers ---

func _on_item_added(item_id: String, amount: int, _new_total: int) -> void:
	_lifetime_item_totals[item_id] = _lifetime_item_totals.get(item_id, 0) + amount
	for id in achievement_defs:
		var def: AchievementData = achievement_defs[id]
		if def.condition_type == AchievementData.ConditionType.ITEM_COLLECTED_TOTAL and def.condition_target_id == item_id:
			_set_progress(id, _lifetime_item_totals[item_id])


func _on_leveled_up(skill_id: String, new_level: int) -> void:
	for id in achievement_defs:
		var def: AchievementData = achievement_defs[id]
		if def.condition_type == AchievementData.ConditionType.SKILL_LEVEL and def.condition_target_id == skill_id:
			_set_progress(id, new_level)


func _on_patch_restored(_patch_id: String) -> void:
	var current_total: int = TerrainRestoration.restored_patches.size()
	for id in achievement_defs:
		var def: AchievementData = achievement_defs[id]
		if def.condition_type == AchievementData.ConditionType.GROUND_RESTORED_TOTAL:
			_set_progress(id, current_total)


func _on_player_cell_changed(_old_coord: Vector2i, new_coord: Vector2i) -> void:
	_record_visited_cell(new_coord, true)


## Ensures a restored player's current cell is represented without treating
## deserialization as a gameplay event. Completion/reward emission remains
## reserved for an actual player_cell_changed signal.
func seed_visited_cell_silently(cell_coord: Vector2i) -> void:
	_record_visited_cell(cell_coord, false)


func _record_visited_cell(cell_coord: Vector2i, allow_completion: bool) -> void:
	if _visited_cells.has(cell_coord):
		return  # already counted this one — don't recount on repeated visits
	_visited_cells[cell_coord] = true
	var current_total: int = _visited_cells.size()
	for id in achievement_defs:
		var def: AchievementData = achievement_defs[id]
		if def.condition_type == AchievementData.ConditionType.CELLS_EXPLORED_TOTAL:
			if allow_completion:
				_set_progress(id, current_total)
			elif not completed.get(id, false):
				progress[id] = maxi(int(progress.get(id, 0)), current_total)


## --- Manual hook for CUSTOM-type achievements ---

func report_custom_progress(condition_target_id: String, amount: int = 1) -> void:
	for id in achievement_defs:
		var def: AchievementData = achievement_defs[id]
		if def.condition_type == AchievementData.ConditionType.CUSTOM and def.condition_target_id == condition_target_id:
			_set_progress(id, progress.get(id, 0) + amount)


## --- Core progress/completion ---

func _set_progress(id: String, value: int) -> void:
	if completed.get(id, false):
		return
	var def: AchievementData = achievement_defs[id]
	progress[id] = value
	if value >= def.condition_target_amount:
		_complete(id)


func _complete(id: String) -> void:
	completed[id] = true
	var def: AchievementData = achievement_defs[id]
	if def.reward_item_id != "":
		InventoryManager.add_item(def.reward_item_id, def.reward_item_amount)
	achievement_completed.emit(def)
	print("Achievement unlocked: ", def.display_name)


func get_completion_percentage() -> float:
	if achievement_defs.is_empty():
		return 0.0
	var done := 0
	for id in completed:
		if completed[id]:
			done += 1
	return float(done) / float(achievement_defs.size()) * 100.0


## --- Save/Load ---

func get_save_data() -> Dictionary:
	var visited_cells_array: Array = []
	for cell_coord in _visited_cells:
		visited_cells_array.append([cell_coord.x, cell_coord.y])

	return {
		"progress": progress.duplicate(),
		"completed": completed.duplicate(),
		"lifetime_item_totals": _lifetime_item_totals.duplicate(),
		"visited_cells": visited_cells_array,
	}


func load_save_data(data: Dictionary) -> void:
	# Loading replaces runtime state rather than overlaying it. Without this,
	# loading an older save in the same process could retain newer unlocks.
	reset_state()

	var saved_progress: Dictionary = data.get("progress", {})
	var saved_completed: Dictionary = data.get("completed", {})
	var saved_lifetime_totals: Dictionary = data.get("lifetime_item_totals", {})
	_lifetime_item_totals = saved_lifetime_totals.duplicate()

	var visited_entries: Array = data.get("visited_cells", [])
	for entry_variant: Variant in visited_entries:
		if not (entry_variant is Array):
			continue
		var entry: Array = entry_variant
		if entry.size() < 2:
			continue
		_visited_cells[Vector2i(int(entry[0]), int(entry[1]))] = true

	for id in saved_progress:
		if achievement_defs.has(id):
			progress[id] = int(saved_progress[id])
	for id in saved_completed:
		if achievement_defs.has(id):
			completed[id] = bool(saved_completed[id])


func reset_state(seed_current_cell: bool = false) -> void:
	progress.clear()
	completed.clear()
	_lifetime_item_totals.clear()
	_visited_cells.clear()
	for id in achievement_defs:
		progress[id] = 0
		completed[id] = false

	if seed_current_cell and WorldManager.get_player() != null:
		_record_visited_cell(WorldManager.get_current_cell(), false)
