extends Node

## AUTOLOAD "FastTravelManager".
##
## Physical in-world landmarks — place a Waypoint Beacon (a placeable
## item, like any other furniture), and it registers itself here
## automatically. See scripts/building/waypoint_beacon.gd for the
## placeable side of this.
##
## PERSISTENCE: this DOES save its own state (a past version of this
## file deliberately didn't, reasoning that a beacon's existence was
## already captured by the normal Placeable save contract — that
## reasoning was wrong in practice: this registry is only ever populated
## when a beacon's commit_placement() actually runs, which only happens
## when its cell is loaded. A beacon whose cell simply hadn't streamed
## in yet this session — including right after loading a save far from
## where it's placed — would be invisible to fast travel despite
## definitely existing, which defeats the entire point of a fast-travel
## system for a large streamed world. Saving the registry directly means
## every beacon you've ever placed is known and travel-able from the
## moment a save loads, regardless of what's currently streamed in.
## Loaded beacons still re-register on commit_placement(). Identical
## registrations are ignored, while genuinely changed transforms update
## the registry and notify listeners once.
##
## Also owns the safe-teleport logic used by beacon travel. travel_to()
## first warms the destination's bounded scene/grass neighborhood without
## activating gameplay there, then spawns above the target and lets normal
## gravity/collision settle the player. A short safety timeout preserves
## the old fail-open behavior if a corrupt resource can never report ready.

signal beacons_changed()

## How far in front of a beacon (along its own local forward) the player
## lands, so they spawn beside it rather than inside/on top of it.
const SPAWN_OFFSET_DISTANCE: float = 1.75

## persistent_id (from Placeable) -> {"name": String, "position": Vector3, "rotation_y": float}
var beacons: Dictionary = {}


func register_beacon(persistent_id: String, beacon_name: String, position: Vector3, rotation_y: float) -> void:
	var existing: Dictionary = beacons.get(persistent_id, {})
	if (
		existing.has("name")
		and existing.has("position")
		and existing.has("rotation_y")
	):
		var existing_position: Vector3 = existing["position"]
		if (
			String(existing["name"]) == beacon_name
			and existing_position.is_equal_approx(position)
			and is_equal_approx(float(existing["rotation_y"]), rotation_y)
		):
			return

	beacons[persistent_id] = {
		"name": beacon_name,
		"position": position,
		"rotation_y": rotation_y
	}
	beacons_changed.emit()


## BUGFIX (see header): only ever called from WaypointBeacon.pick_up(),
## meaning genuine player pickup — NOT from a cell merely streaming out.
func unregister_beacon(persistent_id: String) -> void:
	if beacons.erase(persistent_id):
		beacons_changed.emit()


func rename_beacon(persistent_id: String, new_name: String) -> void:
	if not beacons.has(persistent_id):
		return
	var trimmed := new_name.strip_edges()
	if trimmed == "":
		return
	var entry: Dictionary = beacons[persistent_id]
	if String(entry.get("name", "")) == trimmed:
		return
	entry["name"] = trimmed
	beacons[persistent_id] = entry
	beacons_changed.emit()


## Returns all beacons EXCEPT the one the player is currently at (if
## `exclude_id` is passed) — travelling from a beacon to itself isn't a
## real option, so the Map page doesn't need to show it as one.
func get_travel_targets(exclude_id: String = "") -> Array[String]:
	var result: Array[String] = []
	for persistent_id_variant: Variant in beacons:
		var persistent_id: String = String(persistent_id_variant)
		if persistent_id != exclude_id:
			result.append(persistent_id)
	result.sort_custom(func(a: String, b: String) -> bool:
		var entry_a: Dictionary = beacons[a]
		var entry_b: Dictionary = beacons[b]
		return String(entry_a["name"]) < String(entry_b["name"])
	)
	return result


## The old immediate raycast could miss a cold destination entirely.
## Resource warm-up now removes the normal cold-arrival spike, while the
## elevated spawn remains a final collision-safety net.
const SAFE_DROP_HEIGHT: float = 4.0
const MAX_DESTINATION_PREPARE_SECONDS: float = 3.0

var _pending_travel_id: String = ""
var _pending_destination_cell: Vector2i = Vector2i.ZERO
var _pending_prepare_seconds: float = 0.0


func _ready() -> void:
	set_process(false)
	WorldManager.world_shutdown.connect(_cancel_pending_travel)

func travel_to(persistent_id: String) -> bool:
	if not beacons.has(persistent_id):
		return false
	var player := WorldManager.get_player()
	if player == null:
		return false

	var entry: Dictionary = beacons[persistent_id]
	var beacon_position: Vector3 = entry["position"]
	_pending_travel_id = persistent_id
	_pending_destination_cell = WorldManager.world_to_cell(beacon_position)
	_pending_prepare_seconds = 0.0

	var scenes_ready: bool = WorldManager.prepare_destination(
		_pending_destination_cell
	)
	if scenes_ready and _is_pending_grass_ready():
		_complete_pending_travel()
	else:
		set_process(true)
		NotificationManager.notify(
			"Preparing travel to '%s'…" % entry["name"],
			"info"
		)
	return true


func _process(delta: float) -> void:
	if _pending_travel_id == "":
		set_process(false)
		return
	if (
		not beacons.has(_pending_travel_id)
		or WorldManager.get_player() == null
	):
		_cancel_pending_travel()
		return

	_pending_prepare_seconds += delta
	var scenes_ready: bool = WorldManager.is_destination_prepared(
		_pending_destination_cell
	)
	if (
		(scenes_ready and _is_pending_grass_ready())
		or _pending_prepare_seconds >= MAX_DESTINATION_PREPARE_SECONDS
	):
		_complete_pending_travel()


func _is_pending_grass_ready() -> bool:
	return GrassManager.is_neighborhood_prepared(
		_pending_destination_cell,
		WorldManager.load_radius_cells
	)


func _complete_pending_travel() -> void:
	if _pending_travel_id == "" or not beacons.has(_pending_travel_id):
		_cancel_pending_travel()
		return
	var player: Node3D = WorldManager.get_player()
	if player == null:
		_cancel_pending_travel()
		return
	var entry: Dictionary = beacons[_pending_travel_id]
	var beacon_position: Vector3 = entry["position"]
	var rotation_y: float = float(entry.get("rotation_y", 0.0))

	# Land just in front of the beacon along ITS OWN facing (local +Z,
	# rotated with it) rather than on top of it — rotating a placed
	# beacon in build mode now directly controls which direction the
	# player lands facing, which is the whole point of exposing this.
	var forward: Vector3 = Basis(Vector3.UP, rotation_y) * Vector3(0, 0, 1)
	var target_xz := beacon_position + forward * SPAWN_OFFSET_DISTANCE

	if player is CharacterBody3D:
		(player as CharacterBody3D).velocity = Vector3.ZERO  # stop any residual fall/jump velocity carrying over into the new location
	player.global_position = Vector3(target_xz.x, beacon_position.y + SAFE_DROP_HEIGHT, target_xz.z)

	NotificationManager.notify("Traveled to '%s'." % entry["name"], "info")
	_pending_travel_id = ""
	_pending_prepare_seconds = 0.0
	set_process(false)
	# Keep the destination protected until WorldManager observes the new
	# player cell on its next process pass; it clears this warm-up set as
	# part of that boundary transition after consuming the cached scenes.
	# For two beacons inside the same cell there is no boundary transition,
	# so this call clears the protection immediately in that case.
	WorldManager.clear_prepared_destination()


func _cancel_pending_travel() -> void:
	_pending_travel_id = ""
	_pending_prepare_seconds = 0.0
	set_process(false)
	WorldManager.clear_prepared_destination()


func get_save_data() -> Dictionary:
	var serialized: Dictionary = {}
	for persistent_id in beacons:
		var entry: Dictionary = beacons[persistent_id]
		var pos: Vector3 = entry["position"]
		serialized[persistent_id] = {
			"name": entry["name"],
			"rotation_y": entry.get("rotation_y", 0.0),
			"x": pos.x, "y": pos.y, "z": pos.z,
		}
	return {"beacons": serialized}


func load_save_data(data: Dictionary) -> void:
	# A quickload can occur while a destination is still warming. Never let
	# that old request teleport the newly loaded game a few frames later.
	_cancel_pending_travel()
	var loaded_beacons: Dictionary = {}
	var serialized: Dictionary = data.get("beacons", {})
	for persistent_id_variant: Variant in serialized:
		var persistent_id: String = String(persistent_id_variant)
		var entry: Dictionary = serialized[persistent_id_variant]
		var beacon_name: String = String(entry.get("name", "Beacon"))
		var position := Vector3(
			float(entry.get("x", 0.0)),
			float(entry.get("y", 0.0)),
			float(entry.get("z", 0.0))
		)
		var rotation_y: float = float(entry.get("rotation_y", 0.0))
		loaded_beacons[persistent_id] = {
			"name": beacon_name,
			"position": position,
			"rotation_y": rotation_y,
		}
	if loaded_beacons == beacons:
		return
	beacons = loaded_beacons
	beacons_changed.emit()
