extends Node

## AUTOLOAD "TutorialManager".
##
## One-time onboarding tips, shown via the existing toast notification
## system (a new "tip" category, visually distinct color) rather than a
## separate UI system — there's enough going on in this game now
## (farming, mining, crafting, weather, luck, seasons, shop, storage)
## that a totally silent first-time player has a lot to piece together
## alone, and confusion is the fastest way to make a fun game stop being
## fun.
##
## DELIBERATE SCOPE: every trigger below hooks an EXISTING signal that
## was already being emitted for other reasons (xp_granted, weather_changed,
## etc.) — nothing here reaches into FarmPlot/ResourceNode/RecipeDatabase
## to add new signals just for tutorial purposes. That keeps this file
## fully decoupled (deleting it breaks nothing else) and means shipping
## it carries zero risk to any already-working gameplay system. A few
## genuinely granular tips (first plant, first harvest) aren't covered
## for exactly this reason — they'd need new signals added to working
## scripts, which isn't worth the risk for tutorial text. Revisit if
## those specific gaps turn out to matter once this is played.
##
## Each tip fires only once ever, tracked in `shown` and persisted via
## save data so they don't repeat every session once seen.

var shown: Dictionary = {}


func _ready() -> void:
	# BUGFIX-BEFORE-IT-SHIPPED: autoload _ready() fires at engine boot,
	# well before SaveManager has actually loaded a save file (that
	# happens on a deferred chain kicked off from global_hotkeys.gd). An
	# unconditional welcome message here would show up EVERY session for
	# a returning player, since `shown` is still empty at this exact
	# moment regardless of what a save file says. If a save file exists
	# at all, trust that load_save_data() below will restore `shown`
	# shortly — and if "welcome" was already true in it, it correctly
	# never fires again. Only show it immediately for a genuinely fresh
	# game, where there's nothing to load in the first place.
	if not SaveManager.has_save_file():
		_show_once("welcome", "Welcome! Tab opens your book (inventory/skills/recipes/calendar), E interacts, B enters build/pickup mode, M manages waypoints.")

	SkillManager.xp_granted.connect(_on_xp_granted)
	SkillManager.leveled_up.connect(_on_leveled_up)
	WeatherManager.weather_changed.connect(_on_weather_changed)
	LuckManager.luck_changed.connect(_on_luck_changed)
	SeasonManager.season_changed.connect(_on_season_changed)
	EconomyManager.currency_changed.connect(_on_currency_changed)


func _show_once(tip_id: String, message: String) -> void:
	if shown.get(tip_id, false):
		return
	shown[tip_id] = true
	NotificationManager.notify(message, "tip")


func _on_xp_granted(_skill_id: String, _amount: int, _new_total: int) -> void:
	_show_once("first_xp", "Tip: gathering and farming grant skill XP — open the Skills page (Tab) to track your progress.")


func _on_leveled_up(_skill_id: String, _new_level: int) -> void:
	_show_once("first_levelup", "Tip: higher skill levels unlock perks and gate some crafting recipes — check the Recipes page.")


func _on_weather_changed(weather: int) -> void:
	if weather == WeatherManager.WeatherType.RAIN:
		_show_once("first_rain", "Tip: rain waters every farm plot for you — no need to water by hand on a rainy day.")


func _on_luck_changed(luck: int) -> void:
	if luck != 0:
		_show_once("first_luck", "Tip: today's luck nudges how much you gather from crops and resource nodes — check it each morning.")


func _on_season_changed(_season: int, _year: int) -> void:
	_show_once("first_season", "Tip: open the Calendar page (Tab) to track the season and see how many days remain.")


func _on_currency_changed(_new_total: int) -> void:
	_show_once("first_currency_change", "Tip: sell items instantly at a shop, or drop them in a Shipping Bin overnight for gold while you sleep.")


func get_save_data() -> Dictionary:
	return {"shown": shown}


func load_save_data(data: Dictionary) -> void:
	shown = data.get("shown", {})


## Call from SaveManager.reset_runtime_state_for_new_game() — the boot-time
## has_save_file() check in _ready() only covers a genuinely first-ever
## launch. Clicking "New Game" from an existing save (the file's still on
## disk, just intentionally discarded) needs this separate explicit reset,
## or a returning-but-restarting player would silently never see it.
func on_new_game_started() -> void:
	shown.clear()
	_show_once("welcome", "Welcome! Tab opens your book (inventory/skills/recipes/calendar), E interacts, B enters build/pickup mode, M manages waypoints.")
