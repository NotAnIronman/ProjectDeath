extends Node

## AUTOLOAD "PerformanceWatchdog" — debug-build diagnostic.
##
## Rather than guess at what's causing the reported lag spike when
## walking into new chunks, this watches every frame for a real stutter
## and logs exactly what the streaming systems were doing at that
## instant — correlate this output against WorldManager's/GrassManager's
## own "loaded cell X" print lines (already in the console) to see
## whether a spike lines up with a cell load, a grass MultiMesh
## activation, or something else (Terrain3D's own region collision
## generation is a strong candidate — that's engine-level, outside these
## scripts, and known to be a real cost in Terrain3D generally — but
## this gives real evidence either way instead of a guess).
##
## The hitch path deliberately reads WorldManager's O(1) cached counters.
## It must never recursively walk streamed scene trees while the game is
## already recovering from a slow frame.

const SPIKE_THRESHOLD_MS: float = 50.0  ## below ~20fps momentarily — the point a stutter is actually noticeable
const MIN_SECONDS_BETWEEN_LOGS: float = 0.25  ## avoid spamming the console if several frames in a row are slow

var _seconds_since_last_log: float = 999.0


func _ready() -> void:
	# Release builds should pay no per-frame cost for diagnostics.
	set_process(OS.is_debug_build())


func _process(delta: float) -> void:
	if not WorldManager.is_world_ready():
		return  # skip startup noise (asset loading, shader compilation, etc.) — not what's being investigated
	_seconds_since_last_log += delta
	var frame_ms: float = delta * 1000.0
	if frame_ms < SPIKE_THRESHOLD_MS or _seconds_since_last_log < MIN_SECONDS_BETWEEN_LOGS:
		return
	_seconds_since_last_log = 0.0

	var snapshot: Dictionary = WorldManager.get_streaming_metrics()
	print("PerformanceWatchdog: SPIKE %.1fms | cell %s | loaded cells %d | queued/threaded/activate/retire %d/%d/%d/%d | prefetched %d | cached scenes %d | streamed node estimate %d | static mem %.1f MB | engine objects %d | draw calls %d" % [
		frame_ms,
		snapshot.get("current_cell", "?"),
		snapshot.get("loaded_count", -1),
		snapshot.get("queued_load_count", -1),
		snapshot.get("threaded_load_count", -1),
		snapshot.get("activation_queue_count", -1),
		snapshot.get("retirement_queue_count", -1),
		snapshot.get("prefetch_count", -1),
		snapshot.get("packed_scene_cache_count", -1),
		snapshot.get("streamed_node_count", -1),
		Performance.get_monitor(Performance.MEMORY_STATIC) / 1048576.0,
		Performance.get_monitor(Performance.OBJECT_COUNT),
		Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME),
	])
