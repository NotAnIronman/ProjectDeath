extends Node3D
class_name CameraRig

## Attach to a Node3D. Add a Camera3D as its direct child (name it "Camera3D").
## IMPORTANT: reset the Camera3D child's own Transform to identity (position
## 0,0,0 and rotation 0,0,0) in the Inspector — this script fully controls
## its position/orientation every frame via look_at(), so any leftover manual
## transform on the Camera3D itself will just cause confusing offsets.
##
## Handles two modes:
##   FOLLOW    — smoothly trails a target (the player), always looking at
##               them, at a height/distance ratio you control (which
##               determines the viewing angle). Automatically pulls in
##               closer if a wall/object would otherwise block the view.
##   CINEMATIC — camera is "grabbed" and moves independently (e.g. tweened
##               to a scripted position) for cutscenes, ignoring the follow
##               target until released back to FOLLOW mode.
##
## Usage from gameplay code:
##   camera_rig.set_follow_target(player)
## Usage for a cutscene:
##   camera_rig.enter_cinematic_mode()
##   camera_rig.move_to(some_position, 2.0)
##   ... do cutscene stuff ...
##   camera_rig.return_to_follow(1.5)
## Usage for the view-swap button:
##   camera_rig.toggle_view_direction()

enum Mode { FOLLOW, CINEMATIC }

## How high above the target the camera sits.
@export var follow_height: float = 8.0
## How far horizontally behind the target the camera sits (before the
## 180-degree view swap is applied — see toggle_view_direction()).
@export var follow_distance: float = 8.0
## Point the camera looks at, relative to the target's origin — usually a
## little above the target's feet (e.g. y=1) so it frames the character
## nicely instead of aiming at ground level.
@export var look_at_offset: Vector3 = Vector3(0, 1, 0)
@export var follow_smoothing: float = 5.0  # higher = snappier, lower = more lag

## --- Zoom (Ctrl + scroll wheel) ---
@export var zoom_speed: float = 0.5
@export var min_zoom: float = 0.2   # closest — multiplies height/distance
@export var max_zoom: float = 10   # farthest

## --- Field of view, exposed for a Settings menu ---
@export var field_of_view: float = 70.0:
	set(value):
		field_of_view = value
		if camera:
			camera.fov = value

## --- Collision avoidance (pulls the camera in if something's in the way) ---
## Set this to whatever physics layer your terrain/walls/buildings are on.
## Leave the Player's own layer OUT of this mask so the camera doesn't try
## to avoid the character it's supposed to be looking at.
@export_flags_3d_physics var collision_mask: int = 5
## Small buffer so the camera stops just short of a wall instead of
## touching/clipping into it.
@export var collision_margin: float = 0.3

## --- View swap (flip 180 degrees around the player) ---
@export var view_swap_duration: float = 0.5

var mode: Mode = Mode.FOLLOW
var follow_target: Node3D = null
var zoom_level: float = 1.0
var is_view_flipped: bool = false
var _cinematic_tween: Tween = null
var _view_swap_tween: Tween = null
var _current_yaw_offset: float = 0.0  # 0 or PI, smoothly tweened between
var _collision_query: PhysicsRayQueryParameters3D
var _collision_exclude: Array[RID] = []
var _last_collision_physics_frame: int = -1
var _collision_cache_valid: bool = false
var _collision_hit: bool = false
var _collision_distance_ratio: float = 1.0
var _cached_follow_height: float = -1.0
var _cached_follow_distance: float = -1.0
var _base_follow_offset: Vector3 = Vector3.ZERO
var _rotated_follow_offset: Vector3 = Vector3.ZERO
var _base_follow_length: float = 0.0
var _follow_pitch: float = 0.0

@onready var camera: Camera3D = $Camera3D


func _ready() -> void:
	add_to_group("camera_rig")
	# Guard against inheriting rotation if this rig ever ends up nested under
	# a rotating parent (e.g. accidentally placed under Player) — this forces
	# the rig's global transform to be fully independent either way.
	top_level = true
	# Pull the saved FOV from SettingsManager rather than trusting the
	# exported default — SettingsManager loads before this scene exists
	# (it's an autoload), so it can't push the value into us at startup;
	# we have to pull it ourselves once we're ready.
	field_of_view = SettingsManager.field_of_view
	camera.fov = field_of_view
	_collision_query = PhysicsRayQueryParameters3D.new()
	_collision_query.collision_mask = collision_mask
	_refresh_follow_geometry_if_needed()
	_update_collision_exclusion()


func _process(delta: float) -> void:
	if mode != Mode.FOLLOW or follow_target == null:
		return

	_refresh_follow_geometry_if_needed()
	var desired_offset: Vector3 = _rotated_follow_offset * zoom_level
	var target_anchor: Vector3 = follow_target.global_position + look_at_offset
	var desired_position: Vector3 = target_anchor + desired_offset

	# Physics state only changes on physics ticks. Querying once on the first
	# rendered frame after each tick preserves collision correctness while
	# avoiding duplicate raycasts on high-refresh-rate displays.
	var physics_frame: int = Engine.get_physics_frames()
	if not _collision_cache_valid or physics_frame != _last_collision_physics_frame:
		_refresh_collision_cache(target_anchor, desired_position, physics_frame)

	var final_position: Vector3 = target_anchor + desired_offset * _collision_distance_ratio

	# Snap in quickly when something blocks the view (avoids briefly seeing
	# through the wall while easing), but ease normally when moving further out.
	var current_distance_squared: float = global_position.distance_squared_to(target_anchor)
	var desired_distance_squared: float = final_position.distance_squared_to(target_anchor)
	var smoothing: float = follow_smoothing
	if _collision_hit and desired_distance_squared < current_distance_squared:
		smoothing = follow_smoothing * 4.0

	global_position = global_position.lerp(final_position, 1.0 - exp(-smoothing * delta))

	# Orientation is fully DETERMINISTIC — based only on the configured
	# height/distance angle and the current view-swap yaw, never on the
	# player's live position. This is what eliminates the tilt: previously
	# look_at() re-aimed at the player's exact real-time position every
	# frame, which combined with the camera's own eased/lagging position
	# caused constant tiny corrective swivels (reads as "tilt" when
	# strafing). Position eases smoothly; rotation never wobbles.
	rotation.x = -_follow_pitch
	rotation.y = _current_yaw_offset
	rotation.z = 0
	# even under edge cases (e.g. looking nearly straight down).
	camera.rotation.z = 0


func _unhandled_input(event: InputEvent) -> void:
	if mode != Mode.FOLLOW:
		return
	if not (event is InputEventMouseButton and event.pressed):
		return
	if not event.ctrl_pressed:
		return  # leave plain scroll free for future inventory scrolling

	if event.button_index == MOUSE_BUTTON_WHEEL_UP:
		zoom_level = clampf(zoom_level - zoom_speed * 0.1, min_zoom, max_zoom)
		_collision_cache_valid = false
	elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
		zoom_level = clampf(zoom_level + zoom_speed * 0.1, min_zoom, max_zoom)
		_collision_cache_valid = false


## Returns the horizontal offset direction (behind the target), rotated by
## the current view-swap yaw, scaled to height/distance.
func _get_rotated_offset() -> Vector3:
	_refresh_follow_geometry_if_needed()
	return _rotated_follow_offset


func _refresh_follow_geometry_if_needed() -> void:
	if is_equal_approx(follow_height, _cached_follow_height) and is_equal_approx(follow_distance, _cached_follow_distance):
		return
	_cached_follow_height = follow_height
	_cached_follow_distance = follow_distance
	_base_follow_offset = Vector3(0.0, follow_height, follow_distance)
	_rotated_follow_offset = _base_follow_offset.rotated(Vector3.UP, _current_yaw_offset)
	_base_follow_length = _base_follow_offset.length()
	_follow_pitch = atan2(follow_height, follow_distance)
	_collision_cache_valid = false


func _set_current_yaw_offset(value: float) -> void:
	_current_yaw_offset = value
	_rotated_follow_offset = _base_follow_offset.rotated(Vector3.UP, value)
	# A view-swap tween changes the ray endpoint between physics ticks.
	# Never reuse a hit ratio calculated for the previous tween angle.
	_collision_cache_valid = false


func _update_collision_exclusion() -> void:
	_collision_exclude.clear()
	if follow_target is CollisionObject3D:
		var collision_target: CollisionObject3D = follow_target
		_collision_exclude.append(collision_target.get_rid())
	if _collision_query != null:
		_collision_query.exclude = _collision_exclude


func _refresh_collision_cache(target_anchor: Vector3, desired_position: Vector3, physics_frame: int) -> void:
	_last_collision_physics_frame = physics_frame
	_collision_cache_valid = true
	_collision_hit = false
	_collision_distance_ratio = 1.0

	var desired_distance: float = _base_follow_length * zoom_level
	if desired_distance <= 0.0001:
		return

	_collision_query.from = target_anchor
	_collision_query.to = desired_position
	_collision_query.collision_mask = collision_mask
	var space_state: PhysicsDirectSpaceState3D = get_world_3d().direct_space_state
	var hit: Dictionary = space_state.intersect_ray(_collision_query)
	if hit.is_empty():
		return

	var hit_position: Vector3 = hit["position"]
	var hit_distance: float = target_anchor.distance_to(hit_position)
	var safe_distance: float = maxf(0.0, hit_distance - collision_margin)
	_collision_hit = true
	_collision_distance_ratio = clampf(safe_distance / desired_distance, 0.0, 1.0)


func set_follow_target(target: Node3D) -> void:
	follow_target = target
	_update_collision_exclusion()
	_collision_cache_valid = false
	# Snap immediately on first assignment so the camera doesn't swoop in
	# from wherever it happened to be sitting in the editor.
	if target != null:
		var offset := _get_rotated_offset() * zoom_level
		global_position = target.global_position + look_at_offset + offset
		rotation.x = -_follow_pitch
		rotation.y = _current_yaw_offset
		rotation.z = 0


## --- View swap: flip the camera 180 degrees around the player ---
## Call this from a keybind or a UI button. Smoothly tweens, doesn't snap.
func toggle_view_direction() -> void:
	if mode != Mode.FOLLOW:
		return  # don't fight with cinematic camera moves

	is_view_flipped = not is_view_flipped
	var target_yaw: float = PI if is_view_flipped else 0.0

	if _view_swap_tween:
		_view_swap_tween.kill()

	_collision_cache_valid = false
	_view_swap_tween = create_tween()
	_view_swap_tween.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	_view_swap_tween.tween_method(
		_set_current_yaw_offset,
		_current_yaw_offset,
		target_yaw,
		view_swap_duration
	)


## --- Cinematic control, for cutscenes / scripted camera moments ---

func enter_cinematic_mode() -> void:
	mode = Mode.CINEMATIC
	if _cinematic_tween:
		_cinematic_tween.kill()


## Tweens the rig to a position over `duration` seconds, looking at `look_target`
## throughout the move. Call enter_cinematic_mode() first.
func move_to(target_position: Vector3, duration: float = 2.0, look_target: Vector3 = Vector3.ZERO) -> Tween:
	if mode != Mode.CINEMATIC:
		push_warning("CameraRig: move_to() called outside cinematic mode — call enter_cinematic_mode() first.")

	if _cinematic_tween:
		_cinematic_tween.kill()

	_cinematic_tween = create_tween()
	_cinematic_tween.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	_cinematic_tween.tween_property(self, "global_position", target_position, duration)
	if look_target != Vector3.ZERO:
		_cinematic_tween.parallel().tween_method(
			func(t): camera.look_at(t, Vector3.UP), global_position, look_target, duration
		)
	return _cinematic_tween


## Tweens smoothly back to the follow target and resumes FOLLOW mode once arrived.
func return_to_follow(duration: float = 1.5) -> void:
	if follow_target == null:
		mode = Mode.FOLLOW
		return

	if _cinematic_tween:
		_cinematic_tween.kill()

	var offset := _get_rotated_offset() * zoom_level
	var target_pos := follow_target.global_position + look_at_offset + offset

	_cinematic_tween = create_tween()
	_cinematic_tween.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	_cinematic_tween.tween_property(self, "global_position", target_pos, duration)
	_cinematic_tween.chain().tween_callback(func():
		mode = Mode.FOLLOW
		# Cinematic mode may have set the Camera3D node's own rotation
		# directly (via look_at in move_to()) — reset it to identity so it
		# purely inherits the rig's deterministic rotation again.
		camera.rotation = Vector3.ZERO
	)
