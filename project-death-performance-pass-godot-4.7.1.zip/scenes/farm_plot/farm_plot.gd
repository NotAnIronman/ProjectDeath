extends Node3D
class_name FarmPlot

## Attach to a Node3D representing one plantable tile of soil.
## Scene structure expected:
##   FarmPlot (Node3D, this script)
##     └── SoilMesh (MeshInstance3D)  -- visual for empty/tilled dirt, optional but recommended
##
## Add an Area3D as a child too (see interaction_area below) sized to roughly
## the plot's footprint, so the player's detection radius can find it.

## The Crop scene to instantiate when planting. Point this at res://scenes/crops/Crop.tscn
@export var crop_scene: PackedScene

## Unique identifier for this specific plot instance — set a different value
## per FarmPlot in the Inspector (e.g. "plot_01", "plot_02"). Used by
## SaveManager to know which saved state belongs to which plot in the scene.
@export var plot_id: String = ""

signal planted(crop_data: CropData)
signal plot_emptied()

var current_crop: Crop = null


func _ready() -> void:
	add_to_group("interactables")
	add_to_group("farm_plots")
	if plot_id == "":
		push_warning("FarmPlot: no plot_id assigned — save/load won't work correctly for this plot.")


func is_empty() -> bool:
	return current_crop == null


## Returns true if this plot currently has something the player can harvest.
func is_harvestable() -> bool:
	if current_crop == null:
		return false
	var stage := current_crop.get_current_stage()
	return stage != null and stage.is_harvestable


## Called by the Player when this plot is the nearest interactable and the
## player presses the interact key. Decides plant-vs-restore-vs-harvest-vs-water
## automatically based on plot state.
func interact(player: Node) -> void:
	if is_empty():
		if not _is_ground_restored():
			_try_restore_from_player_selection(player)
		else:
			_try_plant_from_player_selection(player)
	elif is_harvestable():
		var result := current_crop.harvest()
		if result.is_empty():
			print("Harvested — no items configured for this stage yet.")
		else:
			print("Harvested: ", result)
	else:
		_try_tend_from_player_selection(player)


## Attempts to water OR fertilize this plot's crop, depending on what's
## equipped — WateringCanData waters (see water()/_try_water_from_player_selection's
## old behavior, now folded in here), FertilizerData fertilizes. Checking
## both here (rather than two separate branches in interact()) keeps
## "what does interacting with a growing crop do" in one place.
func _try_tend_from_player_selection(_player: Node) -> void:
	if current_crop == null:
		print("Nothing planted here to tend.")
		return

	var item_id: String = InventorySlotManager.get_selected_hotbar_item_id()
	var def: ItemData = InventoryManager.item_defs.get(item_id) if item_id != "" else null

	if def is WateringCanData:
		water(def.water_radius)
	elif def is FertilizerData:
		_try_fertilize(item_id, def)
	else:
		print("This crop isn't ready to harvest yet. Equip a watering can or fertilizer to tend it instead.")


func _try_fertilize(item_id: String, def: FertilizerData) -> void:
	if not InventoryManager.has_item(item_id, 1):
		return  # shouldn't normally happen (it's equipped), but stay safe
	current_crop.fertilize(def.growth_multiplier)
	InventoryManager.remove_item(item_id, 1)
	print("Fertilized — this crop will grow %.0f%% faster for the rest of its life." % ((def.growth_multiplier - 1.0) * 100.0))


## Waters THIS plot's crop directly, and any other FarmPlot within
## `radius` meters (0 = just this one). Public so a future automated
## sprinkler/irrigation system can call it the same way the player does.
func water(radius: float = 0.0) -> void:
	if current_crop:
		current_crop.water()
		print("Watered.")

	if radius <= 0.0:
		return
	for other in get_tree().get_nodes_in_group("farm_plots"):
		if other == self or not (other is FarmPlot):
			continue
		if global_position.distance_to(other.global_position) <= radius and other.current_crop:
			other.current_crop.water()


## Whether this plot's own ground has been restored (see
## TerrainRestoration) — until it has, it can't be planted at all. Uses
## plot_id as the restoration patch id, so a given plot's restored state
## is exactly the state TerrainRestoration already tracks/saves for it —
## no separate bookkeeping needed here.
func _is_ground_restored() -> bool:
	if plot_id == "":
		return true  # no plot_id means restoration can't be tracked for this plot at all — fail open rather than permanently blocking planting on a misconfigured plot
	return TerrainRestoration.is_restored(plot_id)


## Attempts to restore this plot's ground using whatever's currently
## equipped in the hotbar. Requires a RestorationToolData item, sufficient
## Spiritkeeping level, and (if the tool specifies one) a consumable cost.
func _try_restore_from_player_selection(_player: Node) -> void:
	var item_id: String = InventorySlotManager.get_selected_hotbar_item_id()
	if item_id == "":
		print("This ground is withered and can't be planted yet. Equip a restoration tool to restore it.")
		return

	var def: ItemData = InventoryManager.item_defs.get(item_id)
	if not (def is RestorationToolData):
		print("This ground is withered and can't be planted yet. Equip a restoration tool to restore it.")
		return

	var tool_def: RestorationToolData = def

	var failure := RestorationService.try_restore(global_position, plot_id, tool_def)
	print(failure if failure != "" else "The ground stirs — this patch has been restored, and can now be planted.")


func _try_plant_from_player_selection(player: Node) -> void:
	var seed_id: String = player.get_selected_seed_id()
	if seed_id == "":
		print("No seed selected — press Tab to select one, or you have none in inventory.")
		return

	var seed_def: SeedData = InventoryManager.item_defs[seed_id]
	if seed_def.crop_data == null:
		push_warning("SeedData '%s' has no crop_data assigned." % seed_id)
		return

	var success := plant(seed_def.crop_data)
	if success:
		InventoryManager.remove_item(seed_id, 1)


## Attempts to plant the given CropData in this plot.
## Returns true on success, false if the plot is already occupied or the
## player doesn't meet the required skill level for this crop.
func plant(data: CropData) -> bool:
	if not is_empty():
		push_warning("FarmPlot: tried to plant in an occupied plot.")
		return false

	if not SkillManager.meets_requirement(data.skill_id, data.required_level):
		print("Cannot plant '%s' — requires %s level %d (you are level %d)." % [
			data.display_name, data.skill_id, data.required_level,
			SkillManager.get_level(data.skill_id)
		])
		return false

	if crop_scene == null:
		push_warning("FarmPlot: no crop_scene assigned, cannot instantiate.")
		return false

	var crop_instance: Crop = crop_scene.instantiate()
	crop_instance.setup(data)
	add_child(crop_instance)
	crop_instance.removed_after_final_harvest.connect(_on_crop_removed)

	current_crop = crop_instance
	planted.emit(data)
	return true


func _on_crop_removed() -> void:
	current_crop = null
	plot_emptied.emit()
	print("Plot is now empty and ready to replant.")


## --- Save/Load ---

## Returns this plot's state as a plain Dictionary (JSON-safe types only).
func get_save_data() -> Dictionary:
	if is_empty():
		return {}
	return {
		"empty": false,
		"crop_id": current_crop.crop_data.id,
		"elapsed_time": current_crop.get_elapsed_time(),
		"is_watered": current_crop.is_watered,
		"growth_multiplier": current_crop.growth_multiplier,
		"seconds_until_day_end": DayNightManager.get_seconds_until_next_day()
	}


## Restores this plot's state from previously saved data.
## Safe to call on an empty plot with {"empty": true}.
func load_save_data(data: Dictionary) -> void:
	load_save_data_with_elapsed(data, 0.0)


func load_save_data_with_elapsed(data: Dictionary, unloaded_seconds: float) -> void:
	if current_crop != null:
		current_crop.free()
		current_crop = null
	if data.get("empty", true):
		return  # plot stays empty, nothing to restore

	var crop_id: String = data.get("crop_id", "")
	var elapsed: float = data.get("elapsed_time", 0.0)
	var was_watered: bool = data.get("is_watered", false)
	var growth_mult: float = data.get("growth_multiplier", 1.0)

	var crop_data: CropData = CropDatabase.get_crop(crop_id)
	if crop_data == null:
		push_warning("FarmPlot load: unknown crop_id '%s' in save data." % crop_id)
		return

	if crop_scene == null:
		push_warning("FarmPlot load: no crop_scene assigned, cannot restore.")
		return

	var crop_instance: Crop = crop_scene.instantiate()
	crop_instance.setup_from_save(crop_data, elapsed, was_watered, growth_mult)
	# Watering ends at the next day boundary. Reconcile only the portion of
	# unloaded time for which the saved watering state remained valid.
	var watered_growth_seconds := minf(unloaded_seconds, float(data.get("seconds_until_day_end", 0.0)))
	crop_instance.advance_while_unloaded(watered_growth_seconds)
	if unloaded_seconds > watered_growth_seconds:
		crop_instance.is_watered = false
	add_child(crop_instance)
	crop_instance.removed_after_final_harvest.connect(_on_crop_removed)

	current_crop = crop_instance


func get_persistent_id() -> String:
	return plot_id
