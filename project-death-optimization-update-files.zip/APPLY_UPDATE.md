# Project Death Optimization Update

This archive contains only the files added or changed by the technical optimization pass. It does not include the omitted `Assets` or `.godot` directories, and it does not require Git.

## Install

1. Back up the current project folder.
2. Extract this archive directly into the Project Death project root: the folder that already contains `project.godot`.
3. When prompted, allow the extracted files to replace matching files.
4. Open the project in Godot 4.7 and allow Godot to finish importing resources.

The archive does not delete existing files. Your assets and local `.godot` import data will remain in place.

## Rebuild Generated Content

After opening the updated project, run these editor scripts in order:

1. `scripts/editor/build_item_catalog.gd`
2. `scripts/editor/bake_resource_collision_metadata.gd`
3. `scripts/editor/repair_placeable_footprints.gd`
4. `scripts/editor/split_world_into_cells.gd`
5. `scripts/editor/bake_grass.gd`
6. `scripts/editor/validate_runtime_content.gd`

Run the world-cell splitter even if cells already exist. It regenerates the cell index and removes stale generated cells that are no longer part of the source world.

## Verification

- Run the project and check startup/output for validation errors.
- Test crossing several cell boundaries in both directions.
- Test saving, quitting, and restoring in multiple cells.
- Test harvesting, dropped items, placed objects, and inventory persistence.
- Run the scripts in `tests/` using the project's normal test workflow.

This update was verified statically because the original review archive intentionally omitted the large asset set and `.godot` import cache. Final runtime validation and profiling must therefore be performed in the complete project on the build PC.
