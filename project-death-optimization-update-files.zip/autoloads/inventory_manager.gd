extends Node

## AUTOLOAD — register in Project Settings > Globals, name it "InventoryManager".
## Owns all player inventory state. Any system that grants items (crops, cooking,
## herbalism) calls InventoryManager.add_item(...) — nothing else mutates it directly.
## Mirrors the same load-all-.tres-from-folder pattern as SkillManager, so adding
## a new item is just adding a new .tres file — zero code changes.

signal item_added(item_id: String, amount: int, new_total: int)
signal item_removed(item_id: String, amount: int, new_total: int)

## item_id -> ItemData resource. Auto-discovered by recursively scanning
## RESOURCES_ROOT — items can live in any organized subfolder structure
## you want (res://resources/Furniture/tres/, res://resources/crops/tres/,
## etc.) rather than being forced into one flat folder. Any .tres file
## that turns out to be an ItemData (or subclass, like SeedData) gets
## picked up automatically, wherever it is.
var item_defs: Dictionary = {}

## item_id -> current quantity held
var item_counts: Dictionary = {}

const RESOURCES_ROOT := "res://resources/"
const ITEM_CATALOG_PATH := "res://data/item_catalog.json"


func _ready() -> void:
	_load_all_item_defs()
	print("InventoryManager loaded %d items." % item_defs.size())


func _load_all_item_defs() -> void:
	item_defs.clear()
	if _load_catalog():
		return
	push_warning("InventoryManager: item catalog missing; falling back to the slow resource scan. Run build_item_catalog.gd before release.")
	_scan_directory_recursive(RESOURCES_ROOT)


func _load_catalog() -> bool:
	if not FileAccess.file_exists(ITEM_CATALOG_PATH):
		return false
	var file := FileAccess.open(ITEM_CATALOG_PATH, FileAccess.READ)
	if file == null:
		return false
	var parsed := JSON.parse_string(file.get_as_text())
	file.close()
	if not (parsed is Array):
		push_error("InventoryManager: invalid item catalog.")
		return false
	for path in parsed:
		var resource := load(String(path))
		if resource is ItemData:
			_register_item(resource, String(path))
	return true


func _register_item(resource: ItemData, source_path: String) -> void:
	if resource.id == "":
		return
	if item_defs.has(resource.id):
		push_error("InventoryManager: duplicate item id '%s' in %s and %s." % [
			resource.id, item_defs[resource.id].resource_path, source_path
		])
		return
	item_defs[resource.id] = resource
	if not item_counts.has(resource.id):
		item_counts[resource.id] = 0


func _scan_directory_recursive(path: String) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return

	dir.list_dir_begin()
	var entry_name := dir.get_next()
	while entry_name != "":
		if entry_name.begins_with("."):
			entry_name = dir.get_next()
			continue

		var full_path := path.path_join(entry_name)

		if dir.current_is_dir():
			_scan_directory_recursive(full_path)
		elif entry_name.ends_with(".tres"):
			var resource: Resource = load(full_path)
			# Accepts ItemData AND any subclass (SeedData, future item
			# types) since `is` checks the whole inheritance chain.
			if resource is ItemData and resource.id != "":
				_register_item(resource, full_path)

		entry_name = dir.get_next()
	dir.list_dir_end()


## Adds as many items as fit. Returns the new total, or -1 for invalid input.
func add_item(item_id: String, amount: int) -> int:
	if not item_defs.has(item_id) or amount <= 0:
		push_warning("InventoryManager: invalid add request '%s' x %d." % [item_id, amount])
		return -1
	try_add_item(item_id, amount)
	return get_count(item_id)


## Atomic capacity-aware grant. Returns the quantity actually accepted.
func try_add_item(item_id: String, amount: int) -> int:
	if not item_defs.has(item_id) or amount <= 0:
		return 0
	var accepted := amount
	var slot_manager := get_node_or_null("/root/InventorySlotManager")
	if slot_manager != null:
		accepted = mini(amount, slot_manager.get_add_capacity(item_id))
	if accepted <= 0:
		return 0
	item_counts[item_id] = item_counts.get(item_id, 0) + accepted
	var new_total: int = item_counts[item_id]
	item_added.emit(item_id, accepted, new_total)
	return accepted


## Removes a quantity of an item, clamped at 0. Returns true if the full amount
## was available and removed, false if there wasn't enough (removes what it can).
func remove_item(item_id: String, amount: int) -> bool:
	if amount <= 0 or not item_defs.has(item_id):
		return false
	var current: int = item_counts.get(item_id, 0)
	if current < amount:
		return false
	var new_total: int = current - amount
	item_counts[item_id] = new_total
	item_removed.emit(item_id, amount, new_total)
	return true


## Used only by InventorySlotManager after it has already performed an
## exact-slot mutation. Keeps totals/signals in sync without redistributing.
func apply_slot_delta(item_id: String, delta: int) -> void:
	if delta == 0 or not item_defs.has(item_id):
		return
	var new_total := maxi(0, get_count(item_id) + delta)
	item_counts[item_id] = new_total
	if delta > 0:
		item_added.emit(item_id, delta, new_total)
	else:
		item_removed.emit(item_id, -delta, new_total)


func get_count(item_id: String) -> int:
	return item_counts.get(item_id, 0)


func has_item(item_id: String, amount: int = 1) -> bool:
	return amount > 0 and get_count(item_id) >= amount


## --- Save/Load hooks — wire into SaveManager later ---

func get_save_data() -> Dictionary:
	return {"item_counts": item_counts}


func load_save_data(data: Dictionary) -> void:
	if data.has("item_counts"):
		item_counts = data["item_counts"]
